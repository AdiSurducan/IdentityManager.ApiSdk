import * as i0 from '@angular/core';
import { Injectable, Component, NgModule } from '@angular/core';
import * as i5 from '@angular/router';
import { RouterModule } from '@angular/router';
import { V2Client, TypedClient, PortalAdminRoleOrg, PortalRespOrg, V2ApiClientMethodFactory, PortalPersonRolemembershipsOrg } from '@imx-modules/imx-api-rmb';
import { ReadOnlyEntity, MethodDefinition } from '@imx-modules/imx-qbm-dbts';
import * as i4 from 'qbm';
import { calculateSidesheetWidth, HELP_CONTEXTUAL } from 'qbm';
import * as i3$1 from 'qer';
import { BaseMembership, RoleDetailComponent, RoleRecommendationsComponent, BaseTreeRoleRestoreHandler, BaseTreeEntitlement, isRoleAdmin, isRoleStatistics, isAuditor, RolesOverviewComponent, TilesModule } from 'qer';
import * as i2 from '@elemental-ui/core';
import { EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i3 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i7 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i8 from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class OrgDataModel {
    api;
    constructor(api) {
        this.api = api;
    }
    async getModel(filter, isAdmin) {
        return isAdmin
            ? this.api.client.portal_admin_role_org_datamodel_get({ filter: filter })
            : this.api.client.portal_resp_org_datamodel_get({ filter: filter });
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
// do not inherit from BaseMembership because classes cannot inherit across modules :-(
class OrgMembership extends BaseMembership {
    api;
    session;
    translator;
    constructor(api, session, translator) {
        super(api, session, translator);
        this.api = api;
        this.session = session;
        this.translator = translator;
        this.setRoleName('Org', 'UID_Org');
    }
    async delete(role, identity) {
        return this.api.client.portal_roles_config_membership_Org_delete(role, identity);
    }
    hasPrimaryMemberships() {
        return true;
    }
    getPrimaryMembers(uid, navigationstate) {
        return this.api.typedClient.PortalRolesConfigOrgPrimarymembers.Get(uid, navigationstate);
    }
    getPrimaryMembersSchema() {
        return this.api.typedClient.PortalRolesConfigOrgPrimarymembers.GetSchema();
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RmbApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing RMB API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function RmbApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RmbApiService)(i0.ɵɵinject(i4.AppConfigService), i0.ɵɵinject(i4.ClassloggerService), i0.ɵɵinject(i4.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RmbApiService, factory: RmbApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RmbApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i4.AppConfigService }, { type: i4.ClassloggerService }, { type: i4.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function TeamRoleComponent_imx_icon_tile_0_ng_template_4_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "button", 5);
    i0.ɵɵlistener("click", function TeamRoleComponent_imx_icon_tile_0_ng_template_4_ng_container_0_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.onManageTeamRole()); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Edit team role"), " ");
} }
function TeamRoleComponent_imx_icon_tile_0_ng_template_4_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 5);
    i0.ɵɵlistener("click", function TeamRoleComponent_imx_icon_tile_0_ng_template_4_ng_template_1_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.onCreateTeamRole()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Create team role"), " ");
} }
function TeamRoleComponent_imx_icon_tile_0_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, TeamRoleComponent_imx_icon_tile_0_ng_template_4_ng_container_0_Template, 4, 3, "ng-container", 4)(1, TeamRoleComponent_imx_icon_tile_0_ng_template_4_ng_template_1_Template, 3, 3, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
} if (rf & 2) {
    const noTeamRole_r4 = i0.ɵɵreference(2);
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("ngIf", ctx_r1.existTeamRole)("ngIfElse", noTeamRole_r4);
} }
function TeamRoleComponent_imx_icon_tile_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "imx-icon-tile", 3);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵtemplate(4, TeamRoleComponent_imx_icon_tile_0_ng_template_4_Template, 3, 2, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("caption", i0.ɵɵpipeBind1(1, 4, "#LDS#Heading Team Role"))("subtitle", ctx_r1.existTeamRole ? i0.ɵɵpipeBind1(2, 6, "#LDS#Manage your team role, its memberships and entitlements.") : i0.ɵɵpipeBind1(3, 8, "#LDS#Manage the entitlements required for your team using a team role."))("identifier", "team-role")("loadingState", ctx_r1.loadingState);
} }
class TeamRoleComponent {
    rmbApiService;
    sidesheetService;
    translateService;
    roleService;
    dataManagementService;
    route;
    permissionService;
    roleEntitlementActionService;
    snackbar;
    teamRole;
    loadingState = false;
    showTeamRole = false;
    orgTag = 'Org';
    constructor(rmbApiService, sidesheetService, translateService, roleService, dataManagementService, route, permissionService, roleEntitlementActionService, snackbar) {
        this.rmbApiService = rmbApiService;
        this.sidesheetService = sidesheetService;
        this.translateService = translateService;
        this.roleService = roleService;
        this.dataManagementService = dataManagementService;
        this.route = route;
        this.permissionService = permissionService;
        this.roleEntitlementActionService = roleEntitlementActionService;
        this.snackbar = snackbar;
    }
    async ngOnInit() {
        const canCreate = (await this.rmbApiService.client.portal_roles_config_businessroles_get()).EnableNewTeamRole;
        if (await this.permissionService.isPersonManager()) {
            await this.getTeamRole();
            this.showTeamRole = canCreate || this.existTeamRole;
        }
    }
    /**
     * Load team role data and open details sidesheet
     */
    async onManageTeamRole() {
        if (!this.teamRole.Uid) {
            return;
        }
        try {
            this.loadingState = true;
            const roleItem = (await this.roleService.targetMap.get(this.orgTag)?.interactiveResp?.Get_byid(this.teamRole.Uid))?.Data[0].GetEntity();
            if (!roleItem) {
                throw new Error('There was an error getting details about this role');
            }
            await this.setRoleData(roleItem);
            await this.dataManagementService.setInteractive();
            this.sidesheetService
                .open(RoleDetailComponent, {
                title: this.translateService.instant('#LDS#Heading Edit Team Role'),
                subTitle: roleItem.GetDisplay(),
                padding: '0px',
                width: calculateSidesheetWidth(1250, 0.7),
                disableClose: true,
                testId: `${this.orgTag}-role-detail-sidesheet`,
            })
                .afterClosed()
                .subscribe(() => {
                this.getTeamRole();
            });
        }
        finally {
            this.loadingState = false;
        }
    }
    /**
     * Load recomenndation options and open sidesheet where you can select the options.
     */
    async onCreateTeamRole() {
        try {
            this.loadingState = true;
            const teamRoleRecommendOptions = await this.rmbApiService.client.portal_resp_team_teamrole_recommendations_get();
            this.sidesheetService
                .open(RoleRecommendationsComponent, {
                title: this.translateService.instant('#LDS#Heading Create Team Role'),
                padding: '0px',
                width: calculateSidesheetWidth(1000),
                testId: 'role-recommendation-sidesheet',
                data: {
                    recommendation: teamRoleRecommendOptions.Items || [],
                    canEdit: true,
                    infoText: '#LDS#Here you can create a team role. To do this, select the entitlements that are currently assigned individually to the members of your team. After you have created the team role, the entitlements are added to your shopping cart and you must submit the request. This team role will then be automatically assigned to all members of your team (along with the aforementioned entitlements).',
                    selectionTitle: '#LDS#Selected entitlements',
                    submitButtonTitle: '#LDS#Create team role',
                    actionColumnTitle: '#LDS#Distribution among the team',
                    hideActionConfirmation: true,
                    applyWithoutSelection: true,
                    noDataText: '#LDS#Currently, no entitlements can be recommended. You can still create the team role and assign entitlements later.',
                },
            })
                .afterClosed()
                .subscribe((result) => {
                if (!!result) {
                    this.saveRecommendations(result.items);
                }
            });
        }
        finally {
            this.loadingState = false;
        }
    }
    /**
     * Check loaded team role data existence.
     * @returns boolean
     */
    get existTeamRole() {
        return !!this.teamRole?.Uid;
    }
    /**
     * Loading team role.
     */
    async getTeamRole() {
        try {
            this.loadingState = true;
            this.teamRole = await this.rmbApiService.client.portal_resp_team_teamrole_get();
        }
        finally {
            this.loadingState = false;
        }
    }
    /**
     * This function is called after selected options of recommended team roles.
     * Save the selection and add recommendations to the cart.
     * @param resultItem
     */
    async saveRecommendations(resultItem) {
        try {
            // It can take a moment for the team role to become visible over the ownerships API because of DBQUeue calculations.
            this.loadingState = true;
            const collectionData = await this.rmbApiService.client.portal_resp_team_teamrole_post({
                ObjectKeys: resultItem.map((item) => item.ObjectKey.value),
            });
            // This entity represents the new team role.
            if (!collectionData.Entities) {
                throw new Error('There was an error posting this role recommendation');
            }
            const entity = new ReadOnlyEntity(PortalAdminRoleOrg.GetEntitySchema(), collectionData.Entities[0]);
            await this.setRoleData(entity);
            const count = await this.roleEntitlementActionService.addRecommendation(entity, resultItem);
            if (count > 0) {
                this.snackbar.open({ key: '#LDS#The entitlement assignments have been successfully added to your shopping cart.' }, '#LDS#Close');
            }
            this.getTeamRole();
        }
        finally {
            this.loadingState = false;
        }
    }
    /**
     * Set role service sidesheet data with the required params.
     * @param IEntity
     */
    async setRoleData(entity) {
        const isAdmin = this.route.snapshot?.url[0]?.path === 'admin';
        const isStructureAdmin = await this.permissionService.isStructAdmin();
        this.roleService.setSidesheetData({
            ownershipInfo: {
                TableName: this.orgTag,
                Count: 0,
            },
            entity,
            isAdmin,
            canEdit: !isAdmin || (isAdmin && isStructureAdmin),
        });
    }
    static ɵfac = function TeamRoleComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TeamRoleComponent)(i0.ɵɵdirectiveInject(RmbApiService), i0.ɵɵdirectiveInject(i2.EuiSidesheetService), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i3$1.RoleService), i0.ɵɵdirectiveInject(i3$1.DataManagementService), i0.ɵɵdirectiveInject(i5.ActivatedRoute), i0.ɵɵdirectiveInject(i3$1.QerPermissionsService), i0.ɵɵdirectiveInject(i3$1.RoleEntitlementActionService), i0.ɵɵdirectiveInject(i4.SnackBarService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TeamRoleComponent, selectors: [["imx-team-role"]], decls: 1, vars: 1, consts: [["ActionTemplate", ""], ["noTeamRole", ""], ["data-imx-identifier", "start-tile-team-role", 3, "caption", "subtitle", "identifier", "loadingState", 4, "ngIf"], ["data-imx-identifier", "start-tile-team-role", 3, "caption", "subtitle", "identifier", "loadingState"], [4, "ngIf", "ngIfElse"], ["mat-button", "", "color", "primary", 1, "imx-button-uppercase", 3, "click"]], template: function TeamRoleComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, TeamRoleComponent_imx_icon_tile_0_Template, 6, 10, "imx-icon-tile", 2);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.showTeamRole);
        } }, dependencies: [i7.NgIf, i8.MatButton, i3$1.IconTileComponent, i3.TranslatePipe], encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamRoleComponent, [{
        type: Component,
        args: [{ selector: 'imx-team-role', template: "<imx-icon-tile\n  data-imx-identifier=\"start-tile-team-role\"\n  [caption]=\"'#LDS#Heading Team Role' | translate\"\n  [subtitle]=\"\n    existTeamRole\n      ? ('#LDS#Manage your team role, its memberships and entitlements.' | translate)\n      : ('#LDS#Manage the entitlements required for your team using a team role.' | translate)\n  \"\n  [identifier]=\"'team-role'\"\n  [loadingState]=\"loadingState\"\n  *ngIf=\"showTeamRole\"\n>\n  <ng-template #ActionTemplate>\n    <ng-container *ngIf=\"existTeamRole; else noTeamRole\">\n      <button mat-button color=\"primary\" class=\"imx-button-uppercase\" (click)=\"onManageTeamRole()\">\n        {{ '#LDS#Edit team role' | translate }}\n      </button>\n    </ng-container>\n    <ng-template #noTeamRole>\n      <button mat-button color=\"primary\" class=\"imx-button-uppercase\" (click)=\"onCreateTeamRole()\">\n        {{ '#LDS#Create team role' | translate }}\n      </button>\n    </ng-template>\n  </ng-template>\n</imx-icon-tile>\n" }]
    }], () => [{ type: RmbApiService }, { type: i2.EuiSidesheetService }, { type: i3.TranslateService }, { type: i3$1.RoleService }, { type: i3$1.DataManagementService }, { type: i5.ActivatedRoute }, { type: i3$1.QerPermissionsService }, { type: i3$1.RoleEntitlementActionService }, { type: i4.SnackBarService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TeamRoleComponent, { className: "TeamRoleComponent", filePath: "lib\\team-role\\team-role.component.ts", lineNumber: 49 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    router;
    api;
    qerApi;
    session;
    translator;
    dynamicMethodService;
    dataExplorerRegistryService;
    menuService;
    roleService;
    identityRoleMembershipService;
    myResponsibilitiesRegistryService;
    extService;
    qerPermissionsService;
    orgTag = 'Org';
    constructor(router, api, qerApi, session, translator, dynamicMethodService, dataExplorerRegistryService, menuService, roleService, identityRoleMembershipService, myResponsibilitiesRegistryService, extService, qerPermissionsService) {
        this.router = router;
        this.api = api;
        this.qerApi = qerApi;
        this.session = session;
        this.translator = translator;
        this.dynamicMethodService = dynamicMethodService;
        this.dataExplorerRegistryService = dataExplorerRegistryService;
        this.menuService = menuService;
        this.roleService = roleService;
        this.identityRoleMembershipService = identityRoleMembershipService;
        this.myResponsibilitiesRegistryService = myResponsibilitiesRegistryService;
        this.extService = extService;
        this.qerPermissionsService = qerPermissionsService;
    }
    onInit(routes) {
        this.addRoutes(routes);
        // wrapper class for interactive methods
        class ApiWrapper {
            getApi;
            getByIdApi;
            constructor(getApi, getByIdApi) {
                this.getApi = getApi;
                this.getByIdApi = getByIdApi;
            }
            Get() {
                return this.getApi.Get();
            }
            GetSchema() {
                return this.getApi.GetSchema();
            }
            Get_byid(id) {
                return this.getByIdApi.Get_byid(id);
            }
        }
        const restore = new BaseTreeRoleRestoreHandler(() => this.api.client.portal_roles_Org_restore_get(), () => this.api.client.portal_resp_Org_restore_get(), (uid) => this.api.client.portal_roles_Org_restore_byid_get(uid), (uid) => this.api.client.portal_resp_Org_restore_byid_get(uid), (uidRole, actions) => this.api.client.portal_roles_Org_restore_byid_post(uidRole, actions), (uidRole, actions) => this.api.client.portal_resp_Org_restore_byid_post(uidRole, actions));
        this.roleService.targetMap.set(this.orgTag, {
            canBeSplitTarget: true,
            canBeSplitSource: true,
            table: this.orgTag,
            respType: PortalRespOrg,
            resp: this.api.typedClient.PortalRespOrg,
            adminType: PortalAdminRoleOrg,
            adminHasHierarchy: true,
            admin: {
                get: async (parameter) => this.api.client.portal_admin_role_org_get(parameter),
            },
            adminSchema: this.api.typedClient.PortalAdminRoleOrg.GetSchema(),
            dataModel: new OrgDataModel(this.api),
            interactiveResp: new ApiWrapper(this.api.typedClient.PortalRespOrgInteractive, this.api.typedClient.PortalRespOrgInteractive),
            interactiveAdmin: new ApiWrapper(this.api.typedClient.PortalAdminRoleOrgInteractive, this.api.typedClient.PortalAdminRoleOrgInteractive),
            adminCanCreate: async () => {
                return (await this.api.client.portal_roles_config_businessroles_get()).EnableNewOrg;
            },
            respCanCreate: async () => {
                return (await this.api.client.portal_roles_config_businessroles_get()).EnableNewOrg;
            },
            entitlements: new BaseTreeEntitlement(this.qerApi, this.session, this.dynamicMethodService, this.translator, this.orgTag, (e) => e.GetColumn('UID_OrgRoot').GetValue()),
            membership: new OrgMembership(this.api, this.session, this.translator),
            canUseRecommendations: true,
            restore,
            exportMethod: (isAdmin) => {
                const factory = new V2ApiClientMethodFactory();
                return {
                    getMethod: (withProperties, navigationState, PageSize) => {
                        let method;
                        if (PageSize) {
                            method = isAdmin
                                ? factory.portal_admin_role_org_get({ ...navigationState, withProperties, PageSize, StartIndex: 0 })
                                : factory.portal_resp_org_get({ ...navigationState, withProperties, PageSize, StartIndex: 0 });
                        }
                        else {
                            method = isAdmin
                                ? factory.portal_admin_role_org_get({ ...navigationState, withProperties })
                                : factory.portal_resp_org_get({ ...navigationState, withProperties });
                        }
                        return new MethodDefinition(method);
                    },
                };
            },
            translateKeys: {
                create: '#LDS#Create business role',
                createChild: '#LDS#Create child business role',
                createHeading: '#LDS#Heading Create Business Role',
                editHeading: '#LDS#Heading Edit Business Role',
                createSnackbar: '#LDS#The business role has been successfully created.',
            },
            adminHelpContextId: HELP_CONTEXTUAL.DataExplorerBusinessRolesRoleEntitlements,
            respHelpContextId: HELP_CONTEXTUAL.MyResponsibilitiesBusinessRolesRoleEntitlements,
        });
        this.identityRoleMembershipService.addTarget({
            table: this.orgTag,
            type: PortalPersonRolemembershipsOrg,
            entitySchema: this.api.typedClient.PortalPersonRolemembershipsOrg.GetSchema(),
            controlInfo: {
                label: '#LDS#Menu Entry Business roles',
                index: 70,
            },
            get: async (uidPerson, parameter) => this.api.client.portal_person_rolememberships_Org_get(uidPerson, parameter),
            withAnalysis: true,
        });
        this.setupMenu();
        this.dataExplorerRegistryService.registerFactory((preProps, features, projectConfig, groups) => {
            if (!isRoleAdmin(features) && !isRoleStatistics(features) && !isAuditor(groups)) {
                return undefined;
            }
            return {
                instance: RolesOverviewComponent,
                data: {
                    TableName: this.orgTag,
                    Count: 0,
                },
                contextId: HELP_CONTEXTUAL.DataExplorerBusinessRoles,
                sortOrder: 7,
                name: 'businessroles',
                caption: '#LDS#Menu Entry Business roles',
            };
        });
        this.myResponsibilitiesRegistryService.registerFactory((preProps, features) => ({
            instance: RolesOverviewComponent,
            sortOrder: 7,
            name: this.orgTag,
            caption: '#LDS#Menu Entry Business roles',
            data: {
                TableName: this.orgTag,
                Count: 0,
            },
            contextId: HELP_CONTEXTUAL.MyResponsibilitiesBusinessRoles,
        }));
        this.extService.register('Dashboard-MediumTiles', { instance: TeamRoleComponent });
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features, projectConfig, groups) => {
            if (!isRoleAdmin(features) && !isRoleStatistics(features) && !isAuditor(groups)) {
                return undefined;
            }
            const menu = {
                id: 'ROOT_Data',
                title: '#LDS#Data administration',
                sorting: '40',
                items: [
                    {
                        id: 'QER_DataExplorer',
                        navigationCommands: { commands: ['admin', 'dataexplorer'] },
                        title: '#LDS#Menu Entry Data Explorer',
                        sorting: '40-10',
                    },
                ],
            };
            return menu;
        });
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i5.Router), i0.ɵɵinject(RmbApiService), i0.ɵɵinject(i3$1.QerApiService), i0.ɵɵinject(i4.imx_SessionService), i0.ɵɵinject(i4.ImxTranslationProviderService), i0.ɵɵinject(i4.DynamicMethodService), i0.ɵɵinject(i3$1.DataExplorerRegistryService), i0.ɵɵinject(i4.MenuService), i0.ɵɵinject(i3$1.RoleService), i0.ɵɵinject(i3$1.IdentityRoleMembershipsService), i0.ɵɵinject(i3$1.MyResponsibilitiesRegistryService), i0.ɵɵinject(i4.ExtService), i0.ɵɵinject(i3$1.QerPermissionsService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i5.Router }, { type: RmbApiService }, { type: i3$1.QerApiService }, { type: i4.imx_SessionService }, { type: i4.ImxTranslationProviderService }, { type: i4.DynamicMethodService }, { type: i3$1.DataExplorerRegistryService }, { type: i4.MenuService }, { type: i3$1.RoleService }, { type: i3$1.IdentityRoleMembershipsService }, { type: i3$1.MyResponsibilitiesRegistryService }, { type: i4.ExtService }, { type: i3$1.QerPermissionsService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TeamRoleModule {
    static ɵfac = function TeamRoleModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TeamRoleModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: TeamRoleModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, EuiCoreModule, EuiMaterialModule, TranslateModule, TilesModule, FormsModule, ReactiveFormsModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamRoleModule, [{
        type: NgModule,
        args: [{
                declarations: [TeamRoleComponent],
                imports: [CommonModule, EuiCoreModule, EuiMaterialModule, TranslateModule, TilesModule, FormsModule, ReactiveFormsModule],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(TeamRoleModule, { declarations: [TeamRoleComponent], imports: [CommonModule, EuiCoreModule, EuiMaterialModule, TranslateModule, TilesModule, FormsModule, ReactiveFormsModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [];
class RmbConfigModule {
    initializer;
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 RMB loaded');
        this.initializer.onInit(routes);
        console.log('▶️ RMB initialized');
    }
    static ɵfac = function RmbConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RmbConfigModule)(i0.ɵɵinject(InitService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RmbConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [RouterModule.forChild(routes), TeamRoleModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RmbConfigModule, [{
        type: NgModule,
        args: [{
                imports: [RouterModule.forChild(routes), TeamRoleModule],
            }]
    }], () => [{ type: InitService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RmbConfigModule, { imports: [i5.RouterModule, TeamRoleModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of rmb
 */

/**
 * Generated bundle index. Do not edit.
 */

export { RmbConfigModule };
//# sourceMappingURL=rmb.mjs.map
