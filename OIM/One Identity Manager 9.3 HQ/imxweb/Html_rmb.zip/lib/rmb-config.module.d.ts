import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/router";
import * as i2 from "./team-role/team-role.module";
export declare class RmbConfigModule {
    private readonly initializer;
    constructor(initializer: InitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<RmbConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RmbConfigModule, never, [typeof i1.RouterModule, typeof i2.TeamRoleModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RmbConfigModule>;
}
