import { Route, Router } from '@angular/router';
import { DynamicMethodService, ExtService, ImxTranslationProviderService, MenuService, imx_SessionService } from 'qbm';
import { DataExplorerRegistryService, IdentityRoleMembershipsService, MyResponsibilitiesRegistryService, QerApiService, QerPermissionsService, RoleService } from 'qer';
import { RmbApiService } from './rmb-api-client.service';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly router;
    private readonly api;
    private readonly qerApi;
    private readonly session;
    private readonly translator;
    private readonly dynamicMethodService;
    private readonly dataExplorerRegistryService;
    private readonly menuService;
    private readonly roleService;
    private readonly identityRoleMembershipService;
    private readonly myResponsibilitiesRegistryService;
    private readonly extService;
    private readonly qerPermissionsService;
    protected readonly orgTag = "Org";
    constructor(router: Router, api: RmbApiService, qerApi: QerApiService, session: imx_SessionService, translator: ImxTranslationProviderService, dynamicMethodService: DynamicMethodService, dataExplorerRegistryService: DataExplorerRegistryService, menuService: MenuService, roleService: RoleService, identityRoleMembershipService: IdentityRoleMembershipsService, myResponsibilitiesRegistryService: MyResponsibilitiesRegistryService, extService: ExtService, qerPermissionsService: QerPermissionsService);
    onInit(routes: Route[]): void;
    private setupMenu;
    private addRoutes;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
