export { RmbConfigModule } from './lib/rmb-config.module';
