import * as i7 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, NgModule, Input, Inject, ViewChild, ElementRef, computed, EventEmitter, Output } from '@angular/core';
import * as i8 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i10 from '@angular/material/stepper';
import { MatStepperModule } from '@angular/material/stepper';
import * as i9 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i1$2 from '@angular/forms';
import { UntypedFormGroup, FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import * as i1$1 from '@elemental-ui/core';
import { EuiCoreModule, EUI_SIDESHEET_DATA, EuiDownloadDirective, EuiMaterialModule } from '@elemental-ui/core';
import * as i7$1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i2 from 'qbm';
import { BaseCdr, CdrModule, LdsReplaceModule, HelpContextualModule, BusyService, EntityTreeDatabase, CdrFactoryService, isMobile, FkAdvancedPickerComponent, calculateSidesheetWidth, DataViewSource, FilterTreeDatabase, HELP_CONTEXTUAL, DataSourceToolbarModule, DataTableModule, DataTreeModule, ExtModule, BusyIndicatorModule, DynamicTabsModule, ObjectHistoryModule, SelectedElementsModule, DataViewModule, RouteGuardService, TileModule } from 'qbm';
import * as i1 from 'qer';
import { SourceDetectiveType, SourceDetectiveSidesheetComponent, RequestableEntitlementType, ObjectHyperviewModule, OwnerControlModule, ServiceItemsEditFormModule, IdentityRoleMembershipsModule, BusinessownerAddonTileModule, BusinessownerOverviewTileModule } from 'qer';
import * as i6$1 from '@imx-modules/imx-api-tsb';
import { V2Client, TypedClient, V2ApiClientMethodFactory, PortalTargetsystemUnsGroupServiceitem } from '@imx-modules/imx-api-tsb';
import { DbObjectKey, ValType, DisplayColumns, FilterType, CompareOperator, TypedEntity, MethodDefinition, WriteExtTypedEntity } from '@imx-modules/imx-qbm-dbts';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import * as i1$3 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i9$1 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import { Subject, Observable } from 'rxjs';
import * as i6 from '@angular/material/button-toggle';
import * as i8$1 from '@angular/material/table';
import * as i9$2 from '@angular/material/tooltip';
import * as i10$1 from '@angular/material/tabs';
import * as i11 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i12 from '@angular/material/sort';
import * as i11$1 from '@angular/material/slide-toggle';
import * as i6$2 from '@angular/cdk/overlay';
import * as i5 from '@angular/common/http';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSidenavModule } from '@angular/material/sidenav';
import * as i5$1 from '@angular/material/divider';
import * as i6$3 from '@angular/material/form-field';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TsbApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing TSB API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function TsbApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TsbApiService)(i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TsbApiService, factory: TsbApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TsbApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2.AppConfigService }, { type: i2.ClassloggerService }, { type: i2.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TargetSystemService {
    apiService;
    constructor(apiService) {
        this.apiService = apiService;
    }
    async getUserConfig() {
        return this.apiService.client.portal_targetsystem_userconfig_get();
    }
    static ɵfac = function TargetSystemService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TargetSystemService)(i0.ɵɵinject(TsbApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TargetSystemService, factory: TargetSystemService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TargetSystemService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: TsbApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ClaimGroupService {
    apiService;
    entityService;
    constructor(apiService, entityService) {
        this.apiService = apiService;
        this.entityService = entityService;
    }
    async hasSuggestedOwners(tableName, key) {
        const collection = await this.getOwnerCandidates(tableName, key);
        return collection.Entities != null && collection.Entities.length > 0;
    }
    async assignOwner(tableName, key, uidOwner) {
        return this.apiService.client.portal_claimgroup_post(uidOwner, tableName, key);
    }
    getFkValue(column) {
        const dbObjectKey = DbObjectKey.FromXml(column.GetValue());
        return {
            table: dbObjectKey.TableName,
            key: dbObjectKey.Keys[0],
        };
    }
    createCdrSystemEntitlement() {
        const column = this.createColumn({
            ChildColumnName: 'UID_UNSGroup',
            IsMemberRelation: false,
            ParentTableName: 'UNSGroup',
            ParentColumnName: 'XObjectKey',
        }, (parameters) => this.apiService.client.portal_claimgroup_group_get(parameters));
        return new BaseCdr(column, '#LDS#System entitlement' /* TODO: globalize */);
    }
    createColumnSuggestedOwner(tableName, key) {
        const fkRelation = {
            ChildColumnName: 'UID_Owner',
            IsMemberRelation: false,
            ParentTableName: tableName,
            ParentColumnName: 'XObjectKey',
        };
        return this.createColumn(fkRelation, (parameters) => this.getOwnerCandidates(fkRelation.ParentTableName, key, parameters));
    }
    createColumn(fkRelation, loadFkCandidates) {
        return this.entityService.createLocalEntityColumn({
            ColumnName: fkRelation.ChildColumnName,
            Type: ValType.String,
            MinLen: 1,
            FkRelation: fkRelation,
        }, [
            {
                columnName: fkRelation.ChildColumnName,
                fkTableName: fkRelation.ParentTableName,
                parameterNames: ['OrderBy', 'StartIndex', 'PageSize', 'filter', 'search'],
                load: async (_, parameters = {}) => loadFkCandidates(parameters),
                getDataModel: async () => ({}),
                getFilterTree: async () => ({ Elements: [] }),
            },
        ]);
    }
    async getOwnerCandidates(tableName, uid, parameters = {}) {
        const collection = await this.apiService.client.portal_claimgroup_suggestedowner_get(tableName, uid, parameters);
        if (collection.Entities && collection.Entities.length > 0) {
            return collection;
        }
        return this.apiService.client.portal_claimgroup_suggestedowner2_get(tableName, uid, parameters);
    }
    static ɵfac = function ClaimGroupService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ClaimGroupService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.EntityService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ClaimGroupService, factory: ClaimGroupService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ClaimGroupService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: TsbApiService }, { type: i2.EntityService }], null); })();

function ClaimGroupComponent_mat_stepper_6_button_7_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 20);
    i0.ɵɵlistener("click", function ClaimGroupComponent_mat_stepper_6_button_7_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.loadSuggestedOwners()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("disabled", ctx_r1.entitlementForm.invalid);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Next"), " ");
} }
function ClaimGroupComponent_mat_stepper_6_ng_template_9_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵpipe(3, "ldsReplace");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind2(3, 3, i0.ɵɵpipeBind1(2, 1, "#LDS#Specify the owner for the system entitlement \"{0}\"."), ctx_r1.entitlementCdr.column.GetDisplayValue()), " ");
} }
function ClaimGroupComponent_mat_stepper_6_ng_template_9_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(1, 1, "#LDS#Specify the owner"), " ");
} }
function ClaimGroupComponent_mat_stepper_6_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, ClaimGroupComponent_mat_stepper_6_ng_template_9_ng_container_0_Template, 4, 6, "ng-container", 21)(1, ClaimGroupComponent_mat_stepper_6_ng_template_9_ng_template_1_Template, 2, 3, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
} if (rf & 2) {
    const specifyOwner_r4 = i0.ɵɵreference(2);
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("ngIf", ctx_r1.entitlementCdr.column.GetDisplayValue())("ngIfElse", specifyOwner_r4);
} }
function ClaimGroupComponent_mat_stepper_6_mat_radio_group_13_mat_radio_button_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-radio-button", 24);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r6 = ctx.$implicit;
    const i_r7 = ctx.index;
    i0.ɵɵproperty("value", option_r6)("checked", i_r7 === 0);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, option_r6.title), " ");
} }
function ClaimGroupComponent_mat_stepper_6_mat_radio_group_13_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-radio-group", 22);
    i0.ɵɵlistener("change", function ClaimGroupComponent_mat_stepper_6_mat_radio_group_13_Template_mat_radio_group_change_0_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.ownerCandidateListChange($event)); });
    i0.ɵɵtemplate(1, ClaimGroupComponent_mat_stepper_6_mat_radio_group_13_mat_radio_button_1_Template, 3, 5, "mat-radio-button", 23);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r1.ownershipOptions);
} }
function ClaimGroupComponent_mat_stepper_6_imx_cdr_editor_15_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 10);
    i0.ɵɵlistener("controlCreated", function ClaimGroupComponent_mat_stepper_6_imx_cdr_editor_15_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.ownerForm.addControl(ctx_r1.ownerCdr.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("cdr", ctx_r1.ownerCdr);
} }
function ClaimGroupComponent_mat_stepper_6_button_20_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 20);
    i0.ɵɵlistener("click", function ClaimGroupComponent_mat_stepper_6_button_20_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r9); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.assignOwner()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("disabled", ctx_r1.ownerForm.invalid);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Next"), " ");
} }
function ClaimGroupComponent_mat_stepper_6_ng_template_22_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵpipe(3, "ldsReplace");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind3(3, 3, i0.ɵɵpipeBind1(2, 1, "#LDS#Assign ownership for the system entitlement \"{0}\" to \"{1}\"."), ctx_r1.entitlementCdr.column.GetDisplayValue(), ctx_r1.ownerDisplay), " ");
} }
function ClaimGroupComponent_mat_stepper_6_ng_template_22_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(1, 1, "#LDS#Assign ownership"), " ");
} }
function ClaimGroupComponent_mat_stepper_6_ng_template_22_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, ClaimGroupComponent_mat_stepper_6_ng_template_22_ng_container_0_Template, 4, 7, "ng-container", 21)(1, ClaimGroupComponent_mat_stepper_6_ng_template_22_ng_template_1_Template, 2, 3, "ng-template", null, 3, i0.ɵɵtemplateRefExtractor);
} if (rf & 2) {
    const disabledDisplay_r10 = i0.ɵɵreference(2);
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("ngIf", ctx_r1.entitlementCdr.column.GetDisplayValue() && ctx_r1.ownerDisplay)("ngIfElse", disabledDisplay_r10);
} }
function ClaimGroupComponent_mat_stepper_6_div_23_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 25)(1, "p");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 26);
    i0.ɵɵlistener("click", function ClaimGroupComponent_mat_stepper_6_div_23_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r11); i0.ɵɵnextContext(); const stepper_r12 = i0.ɵɵreference(1); const ctx_r1 = i0.ɵɵnextContext(); ctx_r1.resetForms(); return i0.ɵɵresetView(stepper_r12.reset()); });
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Your changes have been successfully saved. It may take some time for the changes to take effect."), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 4, "#LDS#Assign another system entitlement"), " ");
} }
function ClaimGroupComponent_mat_stepper_6_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-stepper", 7, 1);
    i0.ɵɵlistener("selectionChange", function ClaimGroupComponent_mat_stepper_6_Template_mat_stepper_selectionChange_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.stepChange($event)); });
    i0.ɵɵelementStart(2, "mat-step", 8);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementStart(4, "form", 9)(5, "imx-cdr-editor", 10);
    i0.ɵɵlistener("controlCreated", function ClaimGroupComponent_mat_stepper_6_Template_imx_cdr_editor_controlCreated_5_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.entitlementForm.addControl(ctx_r1.entitlementCdr.column.ColumnName, $event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(6, "div", 11);
    i0.ɵɵtemplate(7, ClaimGroupComponent_mat_stepper_6_button_7_Template, 3, 4, "button", 12);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(8, "mat-step", 13);
    i0.ɵɵtemplate(9, ClaimGroupComponent_mat_stepper_6_ng_template_9_Template, 3, 2, "ng-template", 14);
    i0.ɵɵelementStart(10, "p");
    i0.ɵɵtext(11);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(13, ClaimGroupComponent_mat_stepper_6_mat_radio_group_13_Template, 2, 1, "mat-radio-group", 15);
    i0.ɵɵelementStart(14, "form", 9);
    i0.ɵɵtemplate(15, ClaimGroupComponent_mat_stepper_6_imx_cdr_editor_15_Template, 1, 1, "imx-cdr-editor", 16);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(16, "div", 11)(17, "button", 17);
    i0.ɵɵtext(18);
    i0.ɵɵpipe(19, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(20, ClaimGroupComponent_mat_stepper_6_button_20_Template, 3, 4, "button", 12);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(21, "mat-step", 18);
    i0.ɵɵtemplate(22, ClaimGroupComponent_mat_stepper_6_ng_template_22_Template, 3, 2, "ng-template", 14)(23, ClaimGroupComponent_mat_stepper_6_div_23_Template, 7, 6, "div", 19);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("linear", true);
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(3, 17, "#LDS#Select a system entitlement"));
    i0.ɵɵproperty("stepControl", ctx_r1.entitlementForm)("editable", !ctx_r1.ownerAssigned);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("formGroup", ctx_r1.entitlementForm);
    i0.ɵɵadvance();
    i0.ɵɵproperty("cdr", ctx_r1.entitlementCdr);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.entitlementForm);
    i0.ɵɵadvance();
    i0.ɵɵproperty("stepControl", ctx_r1.ownerForm)("editable", !ctx_r1.ownerAssigned);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(12, 19, "#LDS#Here you can claim ownership of the system entitlement. If you are not the owner of the system entitlement, you can specify the actual owner (who will be notified and must confirm the ownership)."), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.ownershipOptions.length > 1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("formGroup", ctx_r1.ownerForm);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.ownerCdr);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(19, 21, "#LDS#Previous"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.ownerForm);
    i0.ɵɵadvance();
    i0.ɵɵproperty("editable", !ctx_r1.ownerAssigned);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.ownerAssigned);
} }
function ClaimGroupComponent_ng_template_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#You cannot currently assign owners for system entitlements. The system entitlement ownership attestation policy is deactivated."), " ");
} }
class ClaimGroupComponent {
    targetSystem;
    claimGroupService;
    personService;
    busyService;
    authentication;
    errorHandler;
    get ownerDisplay() {
        return this.ownerCdr ? this.ownerCdr.column.GetDisplayValue() : this.user.name;
    }
    entitlementCdr;
    ownerCdr;
    ownershipOptions = [];
    ownerAssigned = false;
    canClaimGroup = false;
    entitlementForm = new UntypedFormGroup({});
    ownerForm = new UntypedFormGroup({});
    entitlementFkValue = { table: '', key: '' };
    user = { uid: '', name: '' };
    subscriptions = [];
    constructor(targetSystem, claimGroupService, personService, busyService, authentication, errorHandler) {
        this.targetSystem = targetSystem;
        this.claimGroupService = claimGroupService;
        this.personService = personService;
        this.busyService = busyService;
        this.authentication = authentication;
        this.errorHandler = errorHandler;
        this.initEntitlementCdr();
        this.subscriptions.push(this.authentication.onSessionResponse.subscribe(async (sessionState) => {
            if (sessionState) {
                this.user.uid = sessionState.UserUid;
                this.user.name = sessionState.Username;
            }
        }));
    }
    async ngOnInit() {
        this.showBusyIndicator();
        try {
            // TODO wrap in cache
            this.canClaimGroup = (await this.targetSystem.getUserConfig()).CanClaimGroup;
        }
        finally {
            this.busyService.hide();
        }
    }
    ngOnDestroy() {
        this.subscriptions.forEach((subscription) => subscription.unsubscribe());
    }
    resetForms() {
        this.initEntitlementCdr();
        this.initOwnerCdr(undefined);
        this.ownerAssigned = false;
    }
    ownerCandidateListChange(change) {
        this.initOwnerCdr(change.value.createOwnerCdr());
    }
    async stepChange(change) {
        switch (change.selectedIndex) {
            case 2:
                return this.loadSuggestedOwners();
            case 3:
                return this.assignOwner();
        }
    }
    async loadSuggestedOwners() {
        const fkValue = this.claimGroupService.getFkValue(this.entitlementCdr.column);
        if (this.entitlementFkValue.table === fkValue.table && this.entitlementFkValue.key === fkValue.key) {
            return;
        }
        this.entitlementFkValue.table = fkValue.table;
        this.entitlementFkValue.key = fkValue.key;
        let hasSuggestedOwners = false;
        this.showBusyIndicator();
        try {
            hasSuggestedOwners = await this.claimGroupService.hasSuggestedOwners(this.entitlementFkValue.table, this.entitlementFkValue.key);
        }
        finally {
            this.busyService.hide();
        }
        const display = '#LDS#Designated owner'; // TODO: globalize;
        this.ownershipOptions = [];
        this.ownershipOptions.push({
            title: '#LDS#I want to take ownership of this system entitlement',
            createOwnerCdr: () => undefined,
        });
        if (hasSuggestedOwners) {
            this.ownershipOptions.push({
                title: '#LDS#Select from the suggested possible owners',
                createOwnerCdr: () => new BaseCdr(this.claimGroupService.createColumnSuggestedOwner(this.entitlementFkValue.table, this.entitlementFkValue.key), display),
            });
        }
        this.ownershipOptions.push({
            title: '#LDS#Select another owner',
            createOwnerCdr: () => new BaseCdr(this.personService.createColumnCandidatesPerson(), display),
        });
        this.initOwnerCdr(this.ownershipOptions[0].createOwnerCdr());
    }
    async assignOwner() {
        this.showBusyIndicator();
        try {
            await this.claimGroupService.assignOwner(this.entitlementFkValue.table, this.entitlementFkValue.key, this.ownerCdr ? this.ownerCdr.column.GetValue() : this.user.uid);
            this.ownerAssigned = true;
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        finally {
            this.busyService.hide();
        }
    }
    initEntitlementCdr() {
        Object.keys(this.entitlementForm.controls).forEach((name) => this.entitlementForm.removeControl(name));
        this.entitlementCdr = this.claimGroupService.createCdrSystemEntitlement();
    }
    initOwnerCdr(cdr) {
        Object.keys(this.ownerForm.controls).forEach((name) => this.ownerForm.removeControl(name));
        if (cdr) {
            this.ownerCdr = cdr;
        }
    }
    showBusyIndicator() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
    }
    static ɵfac = function ClaimGroupComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ClaimGroupComponent)(i0.ɵɵdirectiveInject(TargetSystemService), i0.ɵɵdirectiveInject(ClaimGroupService), i0.ɵɵdirectiveInject(i1.PersonService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.AuthenticationService), i0.ɵɵdirectiveInject(i0.ErrorHandler)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ClaimGroupComponent, selectors: [["ng-component"]], decls: 9, vars: 5, consts: [["policyDeactivated", ""], ["stepper", ""], ["specifyOwner", ""], ["disabledDisplay", ""], [1, "mat-headline-5"], [1, "imx-system-entitlement-stepper"], ["orientation", "vertical", 3, "linear", "selectionChange", 4, "ngIf", "ngIfElse"], ["orientation", "vertical", 3, "selectionChange", "linear"], [3, "stepControl", "label", "editable"], [3, "formGroup"], [3, "controlCreated", "cdr"], [1, "imx-button-stepper"], ["mat-flat-button", "", "color", "primary", "matStepperNext", "", 3, "disabled", "click", 4, "ngIf"], [3, "stepControl", "editable"], ["matStepLabel", ""], ["class", "imx-radio-group-flex-column", 3, "change", 4, "ngIf"], [3, "cdr", "controlCreated", 4, "ngIf"], ["mat-stroked-button", "", "matStepperPrevious", ""], [3, "editable"], ["class", "imx-owner-assigned", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "matStepperNext", "", 3, "click", "disabled"], [4, "ngIf", "ngIfElse"], [1, "imx-radio-group-flex-column", 3, "change"], [3, "value", "checked", 4, "ngFor", "ngForOf"], [3, "value", "checked"], [1, "imx-owner-assigned"], ["mat-flat-button", "", "color", "primary", 3, "click"]], template: function ClaimGroupComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "h2", 4)(1, "span");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(4, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "div", 5);
            i0.ɵɵtemplate(6, ClaimGroupComponent_mat_stepper_6_Template, 24, 23, "mat-stepper", 6);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, ClaimGroupComponent_ng_template_7_Template, 3, 3, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            const policyDeactivated_r13 = i0.ɵɵreference(8);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 3, "#LDS#Heading Assign an Owner for a System Entitlement"));
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngIf", ctx.canClaimGroup)("ngIfElse", policyDeactivated_r13);
        } }, dependencies: [i2.CdrEditorComponent, i7.NgForOf, i7.NgIf, i1$2.ɵNgNoValidate, i1$2.NgControlStatusGroup, i8.MatButton, i9.MatRadioGroup, i9.MatRadioButton, i10.MatStep, i10.MatStepLabel, i10.MatStepper, i10.MatStepperNext, i10.MatStepperPrevious, i1$2.FormGroupDirective, i2.HelpContextualComponent, i2.LdsReplacePipe, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{max-width:100%;display:flex;flex-direction:column;height:100%;overflow:hidden}.imx-owner-assigned[_ngcontent-%COMP%]{display:flex;flex-direction:column}.imx-owner-assigned[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:not(:last-child){margin-bottom:10px}.imx-owner-assigned[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]{align-self:flex-end}.imx-system-entitlement-stepper[_ngcontent-%COMP%]{flex:1 1 auto;max-width:100%;overflow:auto;display:flex;flex-direction:column}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ClaimGroupComponent, [{
        type: Component,
        args: [{ template: "<h2 class=\"mat-headline-5\">\n  <span>{{ '#LDS#Heading Assign an Owner for a System Entitlement' | translate }}</span>\n  <imx-help-contextual></imx-help-contextual>\n</h2>\n<div class=\"imx-system-entitlement-stepper\">\n  <mat-stepper\n    orientation=\"vertical\"\n    *ngIf=\"canClaimGroup; else policyDeactivated\"\n    [linear]=\"true\"\n    (selectionChange)=\"stepChange($event)\"\n    #stepper\n  >\n    <mat-step [stepControl]=\"entitlementForm\" label=\"{{ '#LDS#Select a system entitlement' | translate }}\" [editable]=\"!ownerAssigned\">\n      <form [formGroup]=\"entitlementForm\">\n        <imx-cdr-editor\n          [cdr]=\"entitlementCdr\"\n          (controlCreated)=\"entitlementForm.addControl(entitlementCdr.column.ColumnName, $event)\"\n        ></imx-cdr-editor>\n      </form>\n\n      <div class=\"imx-button-stepper\">\n        <button\n          *ngIf=\"entitlementForm\"\n          [disabled]=\"entitlementForm.invalid\"\n          mat-flat-button\n          color=\"primary\"\n          matStepperNext\n          (click)=\"loadSuggestedOwners()\"\n        >\n          {{ '#LDS#Next' | translate }}\n        </button>\n      </div>\n    </mat-step>\n\n    <mat-step [stepControl]=\"ownerForm\" [editable]=\"!ownerAssigned\">\n      <ng-template matStepLabel>\n        <ng-container *ngIf=\"entitlementCdr.column.GetDisplayValue(); else specifyOwner\">\n          {{ '#LDS#Specify the owner for the system entitlement \"{0}\".' | translate | ldsReplace: entitlementCdr.column.GetDisplayValue() }}\n        </ng-container>\n        <ng-template #specifyOwner>\n          {{ '#LDS#Specify the owner' | translate }}\n        </ng-template>\n      </ng-template>\n\n      <p>\n        {{\n          '#LDS#Here you can claim ownership of the system entitlement. If you are not the owner of the system entitlement, you can specify the actual owner (who will be notified and must confirm the ownership).'\n            | translate\n        }}\n      </p>\n\n      <mat-radio-group class=\"imx-radio-group-flex-column\" *ngIf=\"ownershipOptions.length > 1\" (change)=\"ownerCandidateListChange($event)\">\n        <mat-radio-button *ngFor=\"let option of ownershipOptions; let i = index\" [value]=\"option\" [checked]=\"i === 0\">\n          {{ option.title | translate }}\n        </mat-radio-button>\n      </mat-radio-group>\n\n      <form [formGroup]=\"ownerForm\">\n        <imx-cdr-editor\n          *ngIf=\"ownerCdr\"\n          [cdr]=\"ownerCdr\"\n          (controlCreated)=\"ownerForm.addControl(ownerCdr.column.ColumnName, $event)\"\n        ></imx-cdr-editor>\n      </form>\n\n      <div class=\"imx-button-stepper\">\n        <button mat-stroked-button matStepperPrevious>{{ '#LDS#Previous' | translate }}</button>\n        <button *ngIf=\"ownerForm\" [disabled]=\"ownerForm.invalid\" mat-flat-button color=\"primary\" (click)=\"assignOwner()\" matStepperNext>\n          {{ '#LDS#Next' | translate }}\n        </button>\n      </div>\n    </mat-step>\n\n    <mat-step [editable]=\"!ownerAssigned\">\n      <ng-template matStepLabel>\n        <ng-container *ngIf=\"entitlementCdr.column.GetDisplayValue() && ownerDisplay; else disabledDisplay\">\n          {{\n            '#LDS#Assign ownership for the system entitlement \"{0}\" to \"{1}\".'\n              | translate\n              | ldsReplace: entitlementCdr.column.GetDisplayValue() : ownerDisplay\n          }}\n        </ng-container>\n        <ng-template #disabledDisplay>\n          {{ '#LDS#Assign ownership' | translate }}\n        </ng-template>\n      </ng-template>\n\n      <div *ngIf=\"ownerAssigned\" class=\"imx-owner-assigned\">\n        <p>\n          {{ '#LDS#Your changes have been successfully saved. It may take some time for the changes to take effect.' | translate }}\n        </p>\n        <button mat-flat-button color=\"primary\" (click)=\"resetForms(); stepper.reset()\">\n          {{ '#LDS#Assign another system entitlement' | translate }}\n        </button>\n      </div>\n    </mat-step>\n  </mat-stepper>\n</div>\n<ng-template #policyDeactivated>\n  <p>\n    {{\n      '#LDS#You cannot currently assign owners for system entitlements. The system entitlement ownership attestation policy is deactivated.'\n        | translate\n    }}\n  </p>\n</ng-template>\n", styles: [":host{max-width:100%;display:flex;flex-direction:column;height:100%;overflow:hidden}.imx-owner-assigned{display:flex;flex-direction:column}.imx-owner-assigned>*:not(:last-child){margin-bottom:10px}.imx-owner-assigned>button{align-self:flex-end}.imx-system-entitlement-stepper{flex:1 1 auto;max-width:100%;overflow:auto;display:flex;flex-direction:column}\n"] }]
    }], () => [{ type: TargetSystemService }, { type: ClaimGroupService }, { type: i1.PersonService }, { type: i1$1.EuiLoadingService }, { type: i2.AuthenticationService }, { type: i0.ErrorHandler }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ClaimGroupComponent, { className: "ClaimGroupComponent", filePath: "lib\\claim-group\\claim-group.component.ts", lineNumber: 43 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ClaimGroupModule {
    static ɵfac = function ClaimGroupModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ClaimGroupModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ClaimGroupModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CdrModule,
            CommonModule,
            EuiCoreModule,
            FormsModule,
            LdsReplaceModule,
            MatButtonModule,
            MatRadioModule,
            MatStepperModule,
            ReactiveFormsModule,
            TranslateModule,
            HelpContextualModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ClaimGroupModule, [{
        type: NgModule,
        args: [{
                declarations: [ClaimGroupComponent],
                imports: [
                    CdrModule,
                    CommonModule,
                    EuiCoreModule,
                    FormsModule,
                    LdsReplaceModule,
                    MatButtonModule,
                    MatRadioModule,
                    MatStepperModule,
                    ReactiveFormsModule,
                    TranslateModule,
                    HelpContextualModule,
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ClaimGroupModule, { declarations: [ClaimGroupComponent], imports: [CdrModule,
        CommonModule,
        EuiCoreModule,
        FormsModule,
        LdsReplaceModule,
        MatButtonModule,
        MatRadioModule,
        MatStepperModule,
        ReactiveFormsModule,
        TranslateModule,
        HelpContextualModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountsExtService {
    apiService;
    constructor(apiService) {
        this.apiService = apiService;
    }
    get portalPersonAccountsSchema() {
        return this.apiService.typedClient.PortalPersonAccounts.GetSchema();
    }
    getAccounts(uid, parameters) {
        return this.apiService.typedClient.PortalPersonAccounts.Get(uid, parameters);
    }
    static ɵfac = function AccountsExtService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AccountsExtService)(i0.ɵɵinject(TsbApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AccountsExtService, factory: AccountsExtService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsExtService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: TsbApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$4 = () => ["search"];
function AccountsExtComponent_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 10);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵstyleProp("max-width", "500px");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r2.GetEntity().GetDisplay());
} }
function AccountsExtComponent_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "div", 11);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r3.UID_UNSRoot.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r3.UID_DPRNameSpace.Column.GetDisplayValue());
} }
function AccountsExtComponent_ng_template_11_div_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "eui-badge", 13);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4.XMarkedForDeletion.Column.GetDisplayValue());
} }
function AccountsExtComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, AccountsExtComponent_ng_template_11_div_0_Template, 3, 1, "div", 12);
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵproperty("ngIf", item_r4.XMarkedForDeletion.value !== 0);
} }
class AccountsExtComponent {
    settingService;
    accountsService;
    referrer;
    dstSettings;
    DisplayColumns = DisplayColumns;
    entitySchemaAccount;
    busyService = new BusyService();
    displayColumns = [];
    navigationState;
    constructor(settingService, accountsService, dataProvider) {
        this.settingService = settingService;
        this.accountsService = accountsService;
        this.referrer = dataProvider?.data;
        this.navigationState = { PageSize: this.settingService.DefaultPageSize };
        this.entitySchemaAccount = accountsService.portalPersonAccountsSchema;
        /** if you like to add columns, please check {@link DataExplorerAccountsComponent | Accounts Component} as well */
        this.displayColumns = [
            this.entitySchemaAccount.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchemaAccount.Columns.UID_UNSRoot,
            this.entitySchemaAccount.Columns.AccountDisabled,
            this.entitySchemaAccount.Columns.XMarkedForDeletion,
        ];
    }
    async ngOnInit() {
        return this.getData();
    }
    async onNavigationStateChanged(newState) {
        if (newState) {
            this.navigationState = newState;
        }
        await this.getData();
    }
    async onSearch(keywords) {
        this.navigationState.StartIndex = 0;
        this.navigationState.search = keywords;
        await this.getData();
    }
    async getData() {
        const isBusy = this.busyService.beginBusy();
        try {
            const groupsPerIdentity = await this.accountsService.getAccounts(this.referrer.objectuid, this.navigationState);
            this.dstSettings = {
                displayedColumns: this.displayColumns,
                dataSource: groupsPerIdentity,
                entitySchema: this.entitySchemaAccount,
                navigationState: this.navigationState,
            };
        }
        finally {
            isBusy.endBusy();
        }
    }
    static ɵfac = function AccountsExtComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AccountsExtComponent)(i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(AccountsExtService), i0.ɵɵdirectiveInject(i2.DynamicTabDataProviderDirective)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AccountsExtComponent, selectors: [["ng-component"]], inputs: { referrer: "referrer" }, decls: 13, vars: 11, consts: [["dst", ""], [1, "imx-memberships"], [3, "navigationStateChanged", "search", "settings", "options", "busyService"], [1, "imx-membership-table"], ["data-imx-identifier", "identity-memberships-table", "mode", "manual", 3, "dst", "detailViewVisible"], ["width", "500px", 3, "entityColumn"], ["align", "center", 3, "entityColumn"], [3, "entityColumn"], ["alignHeader", "center", "alignContent", "center", 3, "columnName"], [3, "dst"], [1, "imx-ellipse-column"], ["subtitle", ""], [4, "ngIf"], ["color", "gray"]], template: function AccountsExtComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "mat-card", 1)(1, "imx-data-source-toolbar", 2, 0);
            i0.ɵɵlistener("navigationStateChanged", function AccountsExtComponent_Template_imx_data_source_toolbar_navigationStateChanged_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onNavigationStateChanged($event)); })("search", function AccountsExtComponent_Template_imx_data_source_toolbar_search_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSearch($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "div", 3)(4, "imx-data-table", 4)(5, "imx-data-table-column", 5);
            i0.ɵɵtemplate(6, AccountsExtComponent_ng_template_6_Template, 2, 3, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(7, "imx-data-table-column", 6);
            i0.ɵɵelementStart(8, "imx-data-table-column", 7);
            i0.ɵɵtemplate(9, AccountsExtComponent_ng_template_9_Template, 4, 2, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "imx-data-table-generic-column", 8);
            i0.ɵɵtemplate(11, AccountsExtComponent_ng_template_11_Template, 1, 1, "ng-template");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(12, "imx-data-source-paginator", 9);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            const dst_r5 = i0.ɵɵreference(2);
            i0.ɵɵadvance();
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(10, _c0$4))("busyService", ctx.busyService);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", dst_r5)("detailViewVisible", false);
            i0.ɵɵadvance();
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAccount == null ? null : ctx.entitySchemaAccount.Columns == null ? null : ctx.entitySchemaAccount.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAccount == null ? null : ctx.entitySchemaAccount.Columns == null ? null : ctx.entitySchemaAccount.Columns.AccountDisabled);
            i0.ɵɵadvance();
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAccount == null ? null : ctx.entitySchemaAccount.Columns == null ? null : ctx.entitySchemaAccount.Columns.UID_UNSRoot);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("columnName", ctx.entitySchemaAccount == null ? null : ctx.entitySchemaAccount.Columns == null ? null : ctx.entitySchemaAccount.Columns.XMarkedForDeletion == null ? null : ctx.entitySchemaAccount.Columns.XMarkedForDeletion.ColumnName);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", dst_r5);
        } }, dependencies: [i7.NgIf, i1$1.EuiBadgeComponent, i9$1.MatCard, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent], styles: [".data-explorer.data-explorer--accounts[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:nth-child(2){flex:0 0 auto}.data-explorer.data-explorer--accounts[_ngcontent-%COMP%]   .imx-data-explorer-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.eui-dark-theme   [_nghost-%COMP%]{background-color:#2f3233}div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}.imx-ellipse-column[_ngcontent-%COMP%]{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.hidden[_ngcontent-%COMP%]{display:none}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}", "[_nghost-%COMP%]{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-memberships[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-membership-table[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;margin-top:20px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsExtComponent, [{
        type: Component,
        args: [{ template: "<mat-card class=\"imx-memberships\">\n  <imx-data-source-toolbar\n    #dst\n    [settings]=\"dstSettings\"\n    [options]=\"['search']\"\n    [busyService]=\"busyService\"\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\"\n    (search)=\"onSearch($event)\"\n  >\n  </imx-data-source-toolbar>\n\n  <div class=\"imx-membership-table\">\n    <imx-data-table [dst]=\"dst\" [detailViewVisible]=\"false\" data-imx-identifier=\"identity-memberships-table\" mode=\"manual\">\n      <imx-data-table-column width=\"500px\" [entityColumn]=\"entitySchemaAccount?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]\">\n        <ng-template let-item>\n          <div [style.max-width]=\"'500px'\" class=\"imx-ellipse-column\">{{ item.GetEntity().GetDisplay() }}</div>\n        </ng-template>\n      </imx-data-table-column>\n      <imx-data-table-column align=\"center\" [entityColumn]=\"entitySchemaAccount?.Columns?.AccountDisabled\"> </imx-data-table-column>\n      <imx-data-table-column [entityColumn]=\"entitySchemaAccount?.Columns?.UID_UNSRoot\">\n        <ng-template let-item>\n          <div>{{ item.UID_UNSRoot.Column.GetDisplayValue() }}</div>\n          <div subtitle>{{ item.UID_DPRNameSpace.Column.GetDisplayValue() }}</div>\n        </ng-template>\n      </imx-data-table-column>\n      <imx-data-table-generic-column\n        alignHeader=\"center\"\n        alignContent=\"center\"\n        [columnName]=\"entitySchemaAccount?.Columns?.XMarkedForDeletion?.ColumnName\"\n      >\n        <ng-template let-item>\n          <div *ngIf=\"item.XMarkedForDeletion.value !== 0\">\n            <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\n          </div>\n        </ng-template>\n      </imx-data-table-generic-column>\n    </imx-data-table>\n    <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\n  </div>\n</mat-card>\n", styles: [".data-explorer.data-explorer--accounts>:nth-child(2){flex:0 0 auto}.data-explorer.data-explorer--accounts .imx-data-explorer-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.eui-dark-theme :host{background-color:#2f3233}div[subtitle]{font-size:smaller;color:#919799}.imx-ellipse-column{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.hidden{display:none}.eui-contrast-theme :host{background-color:#000}\n", ":host{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-memberships{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-membership-table{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;margin-top:20px}\n"] }]
    }], () => [{ type: i2.SettingsService }, { type: AccountsExtService }, { type: i2.DynamicTabDataProviderDirective }], { referrer: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AccountsExtComponent, { className: "AccountsExtComponent", filePath: "lib\\accounts\\account-ext\\accounts-ext.component.ts", lineNumber: 37 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ContainerTreeDatabaseWrapper {
    busyService;
    dataHelper;
    get targetSystemFilterValue() {
        return this.system;
    }
    set targetSystemFilterValue(value) {
        this.system = value;
        this.entityTreeDatabase = new EntityTreeDatabase((parameters) => this.getEntities(parameters, value), this.busyService);
    }
    selectionEnabled = false;
    entityTreeDatabase;
    system;
    constructor(busyService, dataHelper) {
        this.busyService = busyService;
        this.dataHelper = dataHelper;
        this.entityTreeDatabase = new EntityTreeDatabase((parameters) => this.getEntities(parameters), this.busyService);
    }
    async getEntities(parameters = {}, system = '') {
        const navigationState = { PageSize: 1000, StartIndex: 0, ParentKey: '' };
        if (parameters.ParentKey) {
            navigationState.ParentKey = parameters.ParentKey;
        }
        if (system) {
            navigationState.system = system;
        }
        const containerData = await this.dataHelper.getContainers(navigationState);
        return containerData.Data.map((element) => element.GetEntity());
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class DeHelperService {
    loader;
    tsbClient;
    authorityDataDeleted = new Subject();
    constructor(loader, tsbClient) {
        this.loader = loader;
        this.tsbClient = tsbClient;
    }
    async getAuthorityData(search, skipLoader) {
        const loadParams = { PageSize: 50, StartIndex: 0 };
        if (search) {
            loadParams.search = search;
        }
        const method = this.tsbClient.typedClient.PortalTargetsystemUnsSystem;
        let data;
        if (skipLoader) {
            data = await method.Get(loadParams);
        }
        else {
            data = await this.handlePromiseLoader(method.Get(loadParams));
        }
        return {
            hasAuthorities: data.totalCount > 0,
            authorities: data.Data,
        };
    }
    async getContainers(navigationState) {
        return this.tsbClient.typedClient.PortalTargetsystemUnsContainer.Get(navigationState);
    }
    handlePromiseLoader(promise) {
        const loaderRef = this.loader.show();
        return promise.finally(() => this.loader.hide(loaderRef));
    }
    static ɵfac = function DeHelperService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DeHelperService)(i0.ɵɵinject(i1$1.EuiLoadingService), i0.ɵɵinject(TsbApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: DeHelperService, factory: DeHelperService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DeHelperService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i1$1.EuiLoadingService }, { type: TsbApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountsReportsService {
    tsbClient;
    settings;
    appConfig;
    constructor(tsbClient, settings, appConfig) {
        this.tsbClient = tsbClient;
        this.settings = settings;
        this.appConfig = appConfig;
    }
    accountsReport(historyDays, accountId, tableName) {
        const path = `targetsystem/uns/account/${tableName}/${accountId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    accountsOwnedByPersonReport(historyDays, personId) {
        const path = `targetsystem/uns/account/ownedby/${personId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    accountsOwnedByManagedReport(historyDays, personId) {
        const path = `targetsystem/uns/account/ownedbymanaged/${personId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    accountsByRootReport(historyDays, rootId) {
        const path = `targetsystem/uns/root/${rootId}/accounts/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    accountsByContainerReport(historyDays, containerId) {
        const path = `targetsystem/uns/container/${containerId}/accounts/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    async accountData(search) {
        const options = this.getDefaultDataOptions(search);
        return this.tsbClient.typedClient.PortalTargetsystemUnsAccount.Get(options);
    }
    getDefaultDataOptions(search) {
        const options = {
            PageSize: this.settings.DefaultPageSize,
            StartIndex: 0,
        };
        if (search) {
            options.search = search;
        }
        return options;
    }
    getReportUrl(reportPath) {
        return `${this.appConfig.BaseUrl}/portal/${reportPath}`;
    }
    static ɵfac = function AccountsReportsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AccountsReportsService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.SettingsService), i0.ɵɵinject(i2.AppConfigService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AccountsReportsService, factory: AccountsReportsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsReportsService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: TsbApiService }, { type: i2.SettingsService }, { type: i2.AppConfigService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TargetSystemDynamicMethodService {
    tsbClient;
    dynamicMethod;
    metadata;
    constructor(tsbClient, dynamicMethod, metadata) {
        this.tsbClient = tsbClient;
        this.dynamicMethod = dynamicMethod;
        this.metadata = metadata;
    }
    async getCollection(type, tableName, parameters = {}) {
        const path = '/portal/targetsystem/' + tableName;
        return this.dynamicMethod.get(this.tsbClient.apiClient, { type, path }, parameters);
    }
    async getById(type, dbObjectKeyWrapper) {
        const key = dbObjectKeyWrapper.dbObjectKey.Keys[0];
        const tableName = dbObjectKeyWrapper.dbObjectKey.TableName.toLowerCase();
        const path = '/portal/targetsystem/' + tableName + '/interactive';
        return (await this.dynamicMethod.getInteractive(this.tsbClient.apiClient, { type, key, path }, {
            name: dbObjectKeyWrapper.columnName,
            value: key,
        })).Data[0];
    }
    async get(type, dbObjectKeyWrapper) {
        await this.metadata.updateNonExisting([dbObjectKeyWrapper.dbObjectKey.TableName]);
        const tableMetadata = this.metadata.tables[dbObjectKeyWrapper.dbObjectKey.TableName];
        const filter = [
            {
                ColumnName: dbObjectKeyWrapper.columnName ?? tableMetadata?.PrimaryKeyColumns?.[0] ?? '',
                Type: FilterType.Compare,
                CompareOp: CompareOperator.Equal,
                Value1: dbObjectKeyWrapper.dbObjectKey.Keys[0],
            },
        ];
        return (await this.getCollection(type, dbObjectKeyWrapper.dbObjectKey.TableName, { filter }))?.Data[0];
    }
    async delete(tableName, pathParameterWrapper) {
        const path = '/portal/' + tableName + '/' + pathParameterWrapper.path;
        return this.dynamicMethod.delete(this.tsbClient.apiClient, path, pathParameterWrapper.parameters);
    }
    static ɵfac = function TargetSystemDynamicMethodService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TargetSystemDynamicMethodService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.DynamicMethodService), i0.ɵɵinject(i2.MetadataService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TargetSystemDynamicMethodService, factory: TargetSystemDynamicMethodService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TargetSystemDynamicMethodService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: TsbApiService }, { type: i2.DynamicMethodService }, { type: i2.MetadataService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountTypedEntity extends TypedEntity {
    // TODO fix this: we are in TSB, not ADS
    displayColumn = this.GetEntity().GetColumn(DisplayColumns.DISPLAY_PROPERTYNAME);
    isNeverConnectManualColumn = CdrFactoryService.tryGetColumn(this.GetEntity(), 'IsNeverConnectManual');
    objectKeyManagerColumn = CdrFactoryService.tryGetColumn(this.GetEntity(), 'ObjectKeyManager');
    uidPersonColumn = CdrFactoryService.tryGetColumn(this.GetEntity(), 'UID_Person');
    uidADSDomain = CdrFactoryService.tryGetColumn(this.GetEntity(), 'UID_ADSDomain');
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountsService {
    tsbClient;
    dynamicMethod;
    constructor(tsbClient, dynamicMethod) {
        this.tsbClient = tsbClient;
        this.dynamicMethod = dynamicMethod;
    }
    get accountSchema() {
        return this.tsbClient.typedClient.PortalTargetsystemUnsAccount.GetSchema();
    }
    /**
     * Gets a list of accounts.
     *
     * @param navigationState Page size, start index, search and filtering options etc,.
     *
     * @returns Wrapped list of Accounts.
     */
    async getAccounts(navigationState, signal) {
        return this.tsbClient.typedClient.PortalTargetsystemUnsAccount.Get(navigationState, { signal });
    }
    exportAccounts() {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, navigationState, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_targetsystem_uns_account_get({ ...navigationState, withProperties, PageSize, StartIndex: 0 });
                }
                else {
                    method = factory.portal_targetsystem_uns_account_get({ ...navigationState, withProperties });
                }
                return new MethodDefinition(method);
            },
        };
    }
    async getAccount(dbObjectKey, columnName) {
        return this.dynamicMethod.get(AccountTypedEntity, { dbObjectKey, columnName });
    }
    async getAccountInteractive(dbObjectKey, columnName) {
        return (await this.dynamicMethod.getById(AccountTypedEntity, { dbObjectKey, columnName }));
    }
    /** @deprecated Will be removed. Please load the data model first. */
    async getFilterOptions() {
        return (await this.getDataModel()).Filters ?? [];
    }
    async getDataModel() {
        return this.tsbClient.client.portal_targetsystem_uns_account_datamodel_get(undefined);
    }
    async getFilterTree(parameter) {
        return this.tsbClient.client.portal_targetsystem_uns_account_filtertree_get(parameter);
    }
    static ɵfac = function AccountsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AccountsService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(TargetSystemDynamicMethodService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AccountsService, factory: AccountsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: TsbApiService }, { type: TargetSystemDynamicMethodService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GroupsReportsService {
    tsbClient;
    settings;
    appConfig;
    constructor(tsbClient, settings, appConfig) {
        this.tsbClient = tsbClient;
        this.settings = settings;
        this.appConfig = appConfig;
    }
    groupsByGroupReport(historyDays, groupId) {
        const path = `targetsystem/uns/group/${groupId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    groupsByRootReport(historyDays, rootId) {
        const path = `targetsystem/uns/root/${rootId}/groups/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    groupsByContainerReport(historyDays, containerId) {
        const path = `targetsystem/uns/container/${containerId}/groups/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    groupsOwnedByPersonReport(historyDays, personId) {
        const path = `targetsystem/uns/ownedby/${personId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    async groupData(search) {
        const options = this.getDefaultDataOptions(search);
        return this.tsbClient.typedClient.PortalTargetsystemUnsGroup.Get(options);
    }
    getDefaultDataOptions(search) {
        const options = {
            PageSize: this.settings.DefaultPageSize,
            StartIndex: 0,
        };
        if (search) {
            options.search = search;
        }
        return options;
    }
    getReportUrl(reportPath) {
        return `${this.appConfig.BaseUrl}/portal/${reportPath}`;
    }
    static ɵfac = function GroupsReportsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GroupsReportsService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.SettingsService), i0.ɵɵinject(i2.AppConfigService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: GroupsReportsService, factory: GroupsReportsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupsReportsService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: TsbApiService }, { type: i2.SettingsService }, { type: i2.AppConfigService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GroupTypedEntity extends WriteExtTypedEntity {
    getColumns(showRiskIndex, propertyList) {
        // TODO: for each property, determine from dynamic entity schema (282445)
        if (!propertyList.includes('DisplayName')) {
            propertyList.unshift('DisplayName');
        }
        if (showRiskIndex && !propertyList.includes('RiskIndex')) {
            propertyList.push('RiskIndex');
        }
        return propertyList.map((elem) => CdrFactoryService.tryGetColumn(this.GetEntity(), elem)).filter(Boolean);
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GroupsService {
    tsbClient;
    logger;
    dynamicMethod;
    constructor(tsbClient, logger, dynamicMethod) {
        this.tsbClient = tsbClient;
        this.logger = logger;
        this.dynamicMethod = dynamicMethod;
    }
    unsGroupsSchema(isAdmin) {
        return isAdmin
            ? this.tsbClient.typedClient.PortalTargetsystemUnsGroup.GetSchema()
            : this.tsbClient.typedClient.PortalRespUnsgroup.GetSchema();
    }
    get UnsGroupMembersSchema() {
        return this.tsbClient.typedClient.PortalTargetsystemUnsGroupmembers.GetSchema();
    }
    get UnsGroupDirectMembersSchema() {
        return this.tsbClient.typedClient.PortalTargetsystemUnsDirectmembers.GetSchema();
    }
    get UnsGroupNestedMembersSchema() {
        return this.tsbClient.typedClient.PortalTargetsystemUnsNestedmembers.GetSchema();
    }
    async getFilterTree(options) {
        return this.tsbClient.client.portal_targetsystem_uns_group_filtertree_get(options);
    }
    async getGroups(navigationState, signal) {
        return this.tsbClient.typedClient.PortalTargetsystemUnsGroup.Get(navigationState, { signal });
    }
    exportGroups() {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, navigationState, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_targetsystem_uns_group_get({ ...navigationState, withProperties, PageSize, StartIndex: 0 });
                }
                else {
                    method = factory.portal_targetsystem_uns_group_get({ ...navigationState, withProperties });
                }
                return new MethodDefinition(method);
            },
        };
    }
    async getGroupsResp(navigationState, signal) {
        return this.tsbClient.typedClient.PortalRespUnsgroup.Get(navigationState, { signal });
    }
    exportGroupsResp() {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, navigationState, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_resp_unsgroup_get({ ...navigationState, withProperties, PageSize, StartIndex: 0 });
                }
                else {
                    method = factory.portal_resp_unsgroup_get({ ...navigationState, withProperties });
                }
                return new MethodDefinition(method);
            },
        };
    }
    async getGroupDetails(dbObjectKey) {
        return this.dynamicMethod.get(GroupTypedEntity, { dbObjectKey });
    }
    async getGroupDetailsInteractive(dbObjectKey, columnName) {
        return (await this.dynamicMethod.getById(GroupTypedEntity, { dbObjectKey, columnName }));
    }
    async getGroupServiceItem(key) {
        const filter = [];
        filter.push({
            ColumnName: 'UID_AccProduct',
            Type: FilterType.Compare,
            CompareOp: CompareOperator.Equal,
            Value1: key,
        });
        return (await this.tsbClient.typedClient.PortalTargetsystemUnsGroupServiceitem.Get({ filter })).Data[0];
    }
    async bulkUpdateGroupServiceItems(updateData) {
        return this.tsbClient.client.portal_targetsystem_uns_group_serviceitem_bulk_put(updateData);
    }
    async getGroupDirectMembers(groupId, navigationState, signal) {
        this.logger.debug(this, `Retrieving group direct memberships`);
        this.logger.trace('GroupId', groupId);
        return this.tsbClient.typedClient.PortalTargetsystemUnsDirectmembers.Get(groupId, navigationState, { signal });
    }
    async getGroupNestedMembers(groupId, navigationState, signal) {
        this.logger.debug(this, `Retrieving group nested memberships`);
        this.logger.trace('GroupId', groupId);
        return this.tsbClient.typedClient.PortalTargetsystemUnsNestedmembers.Get(groupId, navigationState, { signal });
    }
    async deleteGroupMembers(dbObjectKey, uidAccountList) {
        this.logger.debug(this, `Deleting group memberships`);
        this.logger.trace(this, 'AccountId', JSON.stringify(uidAccountList));
        // TODO: change to bulk when API supports it
        const groupId = dbObjectKey.Keys[0];
        return Promise.all(uidAccountList.map((accountId) => this.dynamicMethod.delete(dbObjectKey.TableName, {
            path: '{groupId}/memberships/{accountId}',
            parameters: { groupId, accountId },
        })));
    }
    async getGroupsGroupMembers(groupId, navigationState) {
        this.logger.debug(this, `Retrieving groups group memberships`);
        this.logger.trace('GroupId', groupId);
        return this.tsbClient.typedClient.PortalTargetsystemUnsGroupmembers.Get(groupId, navigationState);
    }
    /** @deprecated Will be removed. Please load the data model first.*/
    async getFilterOptions(forAdmin) {
        const filters = forAdmin
            ? (await this.tsbClient.client.portal_targetsystem_uns_group_datamodel_get(undefined)).Filters
            : (await this.tsbClient.client.portal_resp_unsgroup_datamodel_get(undefined)).Filters;
        return filters ?? [];
    }
    async getDataModel(forAdmin) {
        return forAdmin
            ? this.tsbClient.client.portal_targetsystem_uns_group_datamodel_get(undefined)
            : this.tsbClient.client.portal_resp_unsgroup_datamodel_get(undefined);
    }
    async updateMultipleOwner(uidAccProducts, uidPerson) {
        let confirmMessage = '#LDS#The product owner has been successfully assigned.';
        try {
            for (const data of uidAccProducts) {
                const product = await this.getGroupServiceItem(data);
                if (uidPerson.uidPerson) {
                    product.extendedData = {
                        UidPerson: uidPerson.uidPerson,
                        CopyAllMembers: true,
                    };
                    confirmMessage = '#LDS#The product owner has been successfully assigned. It may take some time for the changes to take effect.';
                }
                if (uidPerson.uidRole) {
                    product.UID_OrgRuler.value = uidPerson.uidRole;
                }
                await product.GetEntity().Commit(true);
            }
        }
        catch (exception) {
            confirmMessage = '';
            throw exception;
        }
        return confirmMessage;
    }
    static ɵfac = function GroupsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GroupsService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(TargetSystemDynamicMethodService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: GroupsService, factory: GroupsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupsService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: TsbApiService }, { type: i2.ClassloggerService }, { type: TargetSystemDynamicMethodService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class NewMembershipService {
    itShop;
    qerClient;
    busyService;
    userService;
    constructor(itShop, qerClient, busyService, userService) {
        this.itShop = itShop;
        this.qerClient = qerClient;
        this.busyService = busyService;
        this.userService = userService;
    }
    async requestMembership(members, product) {
        let items = this.getServiceItemsForPersons(product, members);
        await this.itShop.setShops(items);
        if (items.every((elem) => elem.UidITShopOrg == null || elem.UidITShopOrg === '')) {
            return false;
        }
        this.busyService.show();
        try {
            items = items.filter((elem) => elem.UidITShopOrg && elem.UidITShopOrg.length > 0);
            const promises = [];
            for (const item of items) {
                if (item.UidITShopOrg && item.UidPerson) {
                    const entity = this.qerClient.typedClient.PortalCartitem.createEntity();
                    entity.UID_ITShopOrg.value = item.UidITShopOrg;
                    entity.UID_PersonOrdered.value = item.UidPerson;
                    promises.push(this.qerClient.typedClient.PortalCartitem.Post(entity));
                }
            }
            await Promise.all(promises);
            await this.userService.reloadPendingItems();
        }
        finally {
            this.busyService.hide();
        }
        return true;
    }
    getFKRelation() {
        return this.qerClient.typedClient.PortalCartitem.createEntity().UID_PersonOrdered.GetMetadata().GetFkRelations();
    }
    async unsubscribeMembership(item) {
        await this.qerClient.client.portal_itshop_unsubscribe_post({ UidPwo: [item.GetEntity().GetColumn('UID_PersonWantsOrg').GetValue()] });
    }
    getServiceItemsForPersons(serviceItem, recipients) {
        return recipients
            .map((recipient) => ({
            UidPerson: recipient.DataValue,
            UidAccProduct: serviceItem.GetEntity().GetKeys()[0],
            Display: serviceItem.GetEntity().GetDisplay(),
            DisplayRecipient: recipient.DisplayValue,
        }))
            .reduce((a, b) => a.concat(b), []);
    }
    static ɵfac = function NewMembershipService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || NewMembershipService)(i0.ɵɵinject(i1.ShelfService), i0.ɵɵinject(i1.QerApiService), i0.ɵɵinject(i1$1.EuiLoadingService), i0.ɵɵinject(i1.UserModelService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: NewMembershipService, factory: NewMembershipService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(NewMembershipService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1.ShelfService }, { type: i1.QerApiService }, { type: i1$1.EuiLoadingService }, { type: i1.UserModelService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _forTrack0$1 = ($index, $item) => $item.ColumnName;
function GroupMembersComponent_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div")(1, "mat-button-toggle-group", 1, 0);
    i0.ɵɵlistener("change", function GroupMembersComponent_Conditional_0_Template_mat_button_toggle_group_change_1_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onToggleChanged($event)); });
    i0.ɵɵelementStart(3, "mat-button-toggle", 2);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "mat-button-toggle", 3);
    i0.ɵɵpipe(8, "translate");
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "translate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("hideSingleSelectionIndicator", true)("vertical", ctx_r1.isMobile);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(4, 6, ctx_r1.LdsDirectlyAssignedHint));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 8, ctx_r1.LdsDirectlyAssigned), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(8, 10, ctx_r1.LdsIndirectlyAssignedHint));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(10, 12, ctx_r1.LdsIndirectlyAssigned), " ");
} }
function GroupMembersComponent_Conditional_1_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-alert", 14);
    i0.ɵɵlistener("dismissed", function GroupMembersComponent_Conditional_1_Conditional_3_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onWarningDismissed()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 4, ctx_r1.LdsNotUnsubscribableHint));
} }
function GroupMembersComponent_Conditional_1_th_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.entitySchemaGroupDirectMemberships.Columns.UID_Person.Display);
} }
function GroupMembersComponent_Conditional_1_td_9_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 18);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Not effective"));
} }
function GroupMembersComponent_Conditional_1_td_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 16)(1, "div", 17)(2, "div");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, GroupMembersComponent_Conditional_1_td_9_Conditional_4_Template, 3, 3, "eui-badge", 18);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(item_r4.UID_Person.Column.GetDisplayValue());
    i0.ɵɵadvance();
    i0.ɵɵconditional((item_r4.XIsInEffect == null ? null : item_r4.XIsInEffect.value) !== true ? 4 : -1);
} }
function GroupMembersComponent_Conditional_1_For_11_th_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const column_r5 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(column_r5.Display);
} }
function GroupMembersComponent_Conditional_1_For_11_td_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 20);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_13_0;
    const item_r6 = ctx.$implicit;
    const column_r5 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", (tmp_13_0 = item_r6.GetEntity().GetColumn(column_r5.ColumnName)) == null ? null : tmp_13_0.GetDisplayValue(), " ");
} }
function GroupMembersComponent_Conditional_1_For_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0, 9);
    i0.ɵɵtemplate(1, GroupMembersComponent_Conditional_1_For_11_th_1_Template, 2, 1, "th", 10)(2, GroupMembersComponent_Conditional_1_For_11_td_2_Template, 2, 1, "td", 19);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const column_r5 = ctx.$implicit;
    i0.ɵɵproperty("matColumnDef", column_r5.ColumnName);
} }
function GroupMembersComponent_Conditional_1_th_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "th", 15);
} }
function GroupMembersComponent_Conditional_1_td_14_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 21);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r7 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r7.XMarkedForDeletion.Column.GetDisplayValue());
} }
function GroupMembersComponent_Conditional_1_td_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 16)(1, "div");
    i0.ɵɵtemplate(2, GroupMembersComponent_Conditional_1_td_14_Conditional_2_Template, 2, 1, "eui-badge", 21);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r7 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(item_r7.XMarkedForDeletion.value !== 0 ? 2 : -1);
} }
function GroupMembersComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 4);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, GroupMembersComponent_Conditional_1_Conditional_3_Template, 3, 6, "eui-alert", 5);
    i0.ɵɵelement(4, "imx-data-view-toolbar", 6);
    i0.ɵɵelementStart(5, "mat-card", 7)(6, "imx-data-view-auto-table", 8);
    i0.ɵɵelementContainerStart(7, 9);
    i0.ɵɵtemplate(8, GroupMembersComponent_Conditional_1_th_8_Template, 2, 1, "th", 10)(9, GroupMembersComponent_Conditional_1_td_9_Template, 5, 2, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵrepeaterCreate(10, GroupMembersComponent_Conditional_1_For_11_Template, 3, 1, "ng-container", 9, _forTrack0$1);
    i0.ɵɵelementContainerStart(12, 9);
    i0.ɵɵtemplate(13, GroupMembersComponent_Conditional_1_th_13_Template, 1, 0, "th", 10)(14, GroupMembersComponent_Conditional_1_td_14_Template, 3, 1, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementEnd();
    i0.ɵɵelement(15, "imx-data-view-paginator", 12);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(16, "imx-data-view-selection", 13);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", false);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 13, "#LDS#Here you can manage the memberships of the system entitlement. You can request and remove memberships and view the assignment analysis for each membership."), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.showUnsubscribeWarning ? 3 : -1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("dataSource", ctx_r1.dataSourceDirect)("showSettings", false);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("dataSource", ctx_r1.dataSourceDirect)("selectable", true);
    i0.ɵɵadvance();
    i0.ɵɵproperty("matColumnDef", ctx_r1.entitySchemaGroupDirectMemberships.Columns.UID_Person.ColumnName);
    i0.ɵɵadvance(3);
    i0.ɵɵrepeater(ctx_r1.automaticColumnDirect);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("matColumnDef", ctx_r1.entitySchemaGroupDirectMemberships.Columns.XMarkedForDeletion.ColumnName);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("dataSource", ctx_r1.dataSourceDirect);
    i0.ɵɵadvance();
    i0.ɵɵproperty("dataSource", ctx_r1.dataSourceDirect);
} }
function GroupMembersComponent_Conditional_2_th_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.entitySchemaGroupNestedMemberships.Columns.UID_Person.Display);
} }
function GroupMembersComponent_Conditional_2_td_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 16)(1, "div", 17)(2, "div");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const item_r8 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(item_r8.UID_Person.Column.GetDisplayValue());
} }
function GroupMembersComponent_Conditional_2_th_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.entitySchemaGroupNestedMemberships.Columns.UID_UNSGroupChild.Display);
} }
function GroupMembersComponent_Conditional_2_td_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 16)(1, "div", 17)(2, "div");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const item_r9 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(item_r9.UID_UNSGroupChild.Column.GetDisplayValue());
} }
function GroupMembersComponent_Conditional_2_th_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "th", 15);
} }
function GroupMembersComponent_Conditional_2_td_14_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 21);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r10 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r10.XMarkedForDeletion.Column.GetDisplayValue());
} }
function GroupMembersComponent_Conditional_2_td_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 16)(1, "div");
    i0.ɵɵtemplate(2, GroupMembersComponent_Conditional_2_td_14_Conditional_2_Template, 2, 1, "eui-badge", 21);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r10 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(item_r10.XMarkedForDeletion.value !== 0 ? 2 : -1);
} }
function GroupMembersComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 4);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(3, "imx-data-view-toolbar", 6);
    i0.ɵɵelementStart(4, "mat-card", 7)(5, "imx-data-view-auto-table", 22);
    i0.ɵɵelementContainerStart(6, 9);
    i0.ɵɵtemplate(7, GroupMembersComponent_Conditional_2_th_7_Template, 2, 1, "th", 10)(8, GroupMembersComponent_Conditional_2_td_8_Template, 4, 1, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(9, 9);
    i0.ɵɵtemplate(10, GroupMembersComponent_Conditional_2_th_10_Template, 2, 1, "th", 10)(11, GroupMembersComponent_Conditional_2_td_11_Template, 4, 1, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(12, 9);
    i0.ɵɵtemplate(13, GroupMembersComponent_Conditional_2_th_13_Template, 1, 0, "th", 10)(14, GroupMembersComponent_Conditional_2_td_14_Template, 3, 1, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementEnd();
    i0.ɵɵelement(15, "imx-data-view-paginator", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", false);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 11, "#LDS#Here you can get an overview of the memberships of the system entitlement. Additionally, you can view the assignment analysis for each membership."), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("dataSource", ctx_r1.dataSourceNested)("showSettings", false);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("dataSource", ctx_r1.dataSourceNested);
    i0.ɵɵadvance();
    i0.ɵɵproperty("matColumnDef", ctx_r1.entitySchemaGroupNestedMemberships.Columns.UID_Person.ColumnName);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("matColumnDef", ctx_r1.entitySchemaGroupNestedMemberships.Columns.UID_UNSGroupChild.ColumnName);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("matColumnDef", ctx_r1.entitySchemaGroupNestedMemberships.Columns.XMarkedForDeletion.ColumnName);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("dataSource", ctx_r1.dataSourceNested);
} }
class GroupMembersComponent {
    busyService;
    snackBarService;
    sidesheet;
    groupsService;
    confirmationService;
    membershipService;
    translate;
    groupDirectMembershipData;
    groupNestedMembershipData;
    unsGroupDbObjectKey;
    viewDirectMemberships = new UntypedFormControl(true);
    canViewInheritedMemberships = false;
    showUnsubscribeWarning = false;
    entitySchemaGroupDirectMemberships;
    entitySchemaGroupNestedMemberships;
    itemStatus = {
        enabled: (item) => {
            return (!item.IsFromDynamic?.value &&
                ((item.UID_PersonWantsOrg.value !== '' && item.IsRequestCancellable.value) || item.XOrigin.value === 1));
        },
    };
    abortController;
    get selectedItemsCount() {
        return this.dataSourceDirect.selection.selected.length;
    }
    selectedMembershipView = 'direct';
    groupId;
    automaticColumnDirect;
    dataSourceDirect;
    dataSourceNested;
    constructor(busyService, snackBarService, sidesheet, groupsService, confirmationService, membershipService, translate, dataSourceFactory) {
        this.busyService = busyService;
        this.snackBarService = snackBarService;
        this.sidesheet = sidesheet;
        this.groupsService = groupsService;
        this.confirmationService = confirmationService;
        this.membershipService = membershipService;
        this.translate = translate;
        this.abortController = new AbortController();
        this.entitySchemaGroupDirectMemberships = groupsService.UnsGroupDirectMembersSchema;
        this.entitySchemaGroupNestedMemberships = groupsService.UnsGroupNestedMembersSchema;
        this.dataSourceDirect = dataSourceFactory.getDataSource();
        this.dataSourceNested = dataSourceFactory.getDataSource();
        this.automaticColumnDirect = [
            this.entitySchemaGroupDirectMemberships.Columns.UID_UNSAccount,
            this.entitySchemaGroupDirectMemberships.Columns?.XOrigin,
            this.entitySchemaGroupDirectMemberships.Columns.XDateInserted,
            this.entitySchemaGroupDirectMemberships.Columns.OrderState,
            this.entitySchemaGroupDirectMemberships.Columns.ValidUntil,
        ];
    }
    get membershipView() {
        return this.selectedMembershipView;
    }
    get isMobile() {
        return isMobile();
    }
    async ngOnInit() {
        this.groupId = this.unsGroupDbObjectKey.Keys[0];
        this.canViewInheritedMemberships = this.unsGroupDbObjectKey?.TableName === 'ADSGroup';
        await this.navigateDirect();
    }
    canUnsubscribeSelected() {
        return (this.dataSourceDirect.selection.selected != null &&
            this.dataSourceDirect.selection.selected.length > 0 &&
            this.dataSourceDirect.selection.selected.every((elem) => elem.GetEntity().GetColumn('UID_PersonWantsOrg').GetValue() !== '' &&
                elem.GetEntity().GetColumn('IsRequestCancellable').GetValue()));
    }
    canDeleteSelected() {
        return (this.dataSourceDirect.selection.selected != null &&
            this.dataSourceDirect.selection.selected.length > 0 &&
            this.dataSourceDirect.selection.selected.every((elem) => elem.GetEntity().GetColumn('XOrigin').GetValue() === 1));
    }
    async onToggleChanged(change) {
        this.selectedMembershipView = change.value;
        this.abortController.abort();
        if (this.selectedMembershipView === 'direct') {
            await this.navigateDirect();
        }
        else {
            await this.navigateNested();
        }
    }
    async deleteMembers() {
        if (await this.confirmationService.confirm({
            Title: '#LDS#Heading Remove Memberships',
            Message: '#LDS#The removal of memberships may take some time. The displayed data may differ from the actual state. Are you sure you want to remove the selected memberships?',
            identifier: 'group-members-confirm-delete-memberships',
        })) {
            this.handleOpenLoader();
            try {
                console.log(this.dataSourceDirect.selection.selected);
                await this.groupsService.deleteGroupMembers(this.unsGroupDbObjectKey, this.dataSourceDirect.selection.selected.map((i) => i.GetEntity().GetColumn('UID_UNSAccount').GetValue()));
                this.dataSourceDirect.selection.clear();
                this.snackBarService.open({ key: '#LDS#The memberships have been successfully removed.' }, '#LDS#Close');
                await this.navigateDirect();
            }
            finally {
                this.handleCloseLoader();
            }
        }
    }
    async requestMembership(serviceItem) {
        const sidesheetRef = this.sidesheet.open(FkAdvancedPickerComponent, {
            title: await this.translate.instant('#LDS#Heading Request Memberships'),
            subTitle: serviceItem.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(),
            icon: 'usergroup',
            testId: 'systementitlements-reqeust-memberships',
            data: {
                fkRelations: this.membershipService.getFKRelation(),
                isMultiValue: true,
            },
        });
        const result = await sidesheetRef.afterClosed().toPromise();
        if (result && result.candidates.length > 0 && (await this.membershipService.requestMembership(result.candidates, serviceItem))) {
            this.snackBarService.open({
                key: '#LDS#The memberships for "{0}" have been successfully added to the shopping cart.',
                parameters: [serviceItem.GetEntity().GetDisplay()],
            });
        }
    }
    onWarningDismissed() {
        this.showUnsubscribeWarning = false;
    }
    async unsubscribeMembership() {
        // if there is at least 1 item, that is not unsubscribable, show a warning instead
        const notSubscribable = this.dataSourceDirect.selection.selected.some((entity) => entity.GetEntity().GetColumn('IsRequestCancellable').GetValue() === false);
        if (notSubscribable) {
            this.showUnsubscribeWarning = true;
            this.dataSourceDirect.selection.clear();
            return;
        }
        if (await this.confirmationService.confirm({
            Title: '#LDS#Heading Unsubscribe Memberships',
            Message: '#LDS#Are you sure you want to unsubscribe the selected memberships?',
            identifier: 'group-members-confirm-unsubscribe-membership',
        })) {
            this.handleOpenLoader();
            try {
                await Promise.all(this.dataSourceDirect.selection.selected.map((entity) => this.membershipService.unsubscribeMembership(entity)));
                this.snackBarService.open({
                    key: '#LDS#The memberships have been successfully unsubscribed. It may take some time for the changes to take effect. The displayed data may differ from the actual state.',
                });
            }
            finally {
                this.handleCloseLoader();
                this.dataSourceDirect.selection.clear();
                await this.navigateDirect();
            }
        }
    }
    async onShowDetails(item) {
        const data = {
            UID_Person: item.GetEntity().GetColumn('UID_Person').GetValue(),
            Type: SourceDetectiveType.MembershipOfSystemEntitlement,
            UID: this.unsGroupDbObjectKey.Keys[0],
            TableName: this.unsGroupDbObjectKey.TableName,
        };
        this.sidesheet.open(SourceDetectiveSidesheetComponent, {
            title: await this.translate.instant('#LDS#Heading View Assignment Analysis'),
            subTitle: item.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(800, 0.5),
            disableClose: false,
            testId: 'systementitlements-membership-assingment-analysis',
            data,
        });
    }
    async navigateDirect() {
        this.dataSourceDirect.itemStatus = this.itemStatus;
        const columnsToDisplay = [
            this.entitySchemaGroupDirectMemberships.Columns.UID_Person,
            ...this.automaticColumnDirect,
            this.entitySchemaGroupDirectMemberships.Columns.XMarkedForDeletion,
        ];
        const dataViewInitParameters = {
            execute: (params, signal) => {
                return this.groupsService.getGroupDirectMembers(this.groupId, params, signal);
            },
            schema: this.entitySchemaGroupDirectMemberships,
            columnsToDisplay,
            highlightEntity: (identity) => {
                this.onShowDetails(identity);
            },
        };
        await this.dataSourceDirect.init(dataViewInitParameters);
    }
    async navigateNested() {
        this.showUnsubscribeWarning = false;
        const columnsToDisplay = [
            this.entitySchemaGroupNestedMemberships.Columns.UID_Person,
            this.entitySchemaGroupNestedMemberships.Columns.UID_UNSGroupChild,
            this.entitySchemaGroupNestedMemberships.Columns.XMarkedForDeletion,
        ];
        const dataViewInitParameters = {
            execute: (params, signal) => {
                return this.groupsService.getGroupNestedMembers(this.groupId, params, signal);
            },
            schema: this.entitySchemaGroupNestedMemberships,
            columnsToDisplay,
            highlightEntity: (identity) => {
                this.onShowDetails(identity);
            },
        };
        await this.dataSourceNested.init(dataViewInitParameters);
    }
    handleOpenLoader() {
        this.busyService.show();
    }
    handleCloseLoader() {
        this.busyService.hide();
    }
    LdsNotUnsubscribableHint = '#LDS#There is at least one membership you cannot unsubscribe. You can only unsubscribe memberships you have requested.';
    LdsDirectlyAssignedHint = '#LDS#Here you can get an overview of members assigned to the system entitlement itself.';
    LdsIndirectlyAssignedHint = '#LDS#Here you can get an overview of members not assigned to the system entitlement itself, but to a child system entitlement.';
    LdsDirectlyAssigned = '#LDS#Direct memberships';
    LdsIndirectlyAssigned = '#LDS#Inherited memberships';
    static ɵfac = function GroupMembersComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GroupMembersComponent)(i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(GroupsService), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(NewMembershipService), i0.ɵɵdirectiveInject(i7$1.TranslateService), i0.ɵɵdirectiveInject(i2.DataViewSourceFactoryService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GroupMembersComponent, selectors: [["imx-group-members"]], inputs: { groupDirectMembershipData: "groupDirectMembershipData", groupNestedMembershipData: "groupNestedMembershipData", unsGroupDbObjectKey: "unsGroupDbObjectKey" }, features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 3, vars: 2, consts: [["buttonToggle", ""], ["value", "direct", 1, "imx-button-toggle-group-warning", 3, "change", "hideSingleSelectionIndicator", "vertical"], ["value", "direct", 3, "matTooltip"], ["value", "nested", 3, "matTooltip"], ["type", "info", 3, "condensed", "colored", "dismissable"], ["type", "warning", 3, "condensed", "colored", "dismissable"], [3, "dataSource", "showSettings"], [1, "imx-card-fill"], ["mode", "manual", 3, "dataSource", "selectable"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], [3, "dataSource"], [1, "imx-selection-toggle", 3, "dataSource"], ["type", "warning", 3, "dismissed", "condensed", "colored", "dismissable"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], [1, "filled-cell"], ["color", "primary", 1, "imx-margin-left-auto"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], ["mat-cell", "", "role", "gridcell"], ["color", "gray"], ["mode", "manual", 3, "dataSource"]], template: function GroupMembersComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, GroupMembersComponent_Conditional_0_Template, 11, 14, "div")(1, GroupMembersComponent_Conditional_1_Template, 17, 15)(2, GroupMembersComponent_Conditional_2_Template, 16, 13);
        } if (rf & 2) {
            i0.ɵɵconditional(ctx.canViewInheritedMemberships ? 0 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.membershipView === "direct" ? 1 : ctx.membershipView === "nested" && ctx.canViewInheritedMemberships ? 2 : -1);
        } }, dependencies: [i1$1.EuiAlertComponent, i1$1.EuiBadgeComponent, i6.MatButtonToggleGroup, i6.MatButtonToggle, i9$1.MatCard, i8$1.MatHeaderCellDef, i8$1.MatColumnDef, i8$1.MatCellDef, i8$1.MatHeaderCell, i8$1.MatCell, i9$2.MatTooltip, i2.DataViewAutoTableComponent, i2.DataViewPaginatorComponent, i2.DataViewToolbarComponent, i2.DataViewSelectionComponent, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;height:100%;flex-direction:column}.imx-selection-toggle[_ngcontent-%COMP%]{min-height:40px;display:flex}.filled-cell[_ngcontent-%COMP%]{width:100%!important}.mat-button-toggle-group[_ngcontent-%COMP%]{margin-bottom:10px}@media screen and (max-width: 768px){.mat-button-toggle-group[_ngcontent-%COMP%]{width:100%}}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupMembersComponent, [{
        type: Component,
        args: [{ selector: 'imx-group-members', providers: [DataViewSource], template: "@if (canViewInheritedMemberships) {\n  <div>\n    <mat-button-toggle-group\n      #buttonToggle\n      class=\"imx-button-toggle-group-warning\"\n      value=\"direct\"\n      (change)=\"onToggleChanged($event)\"\n      [hideSingleSelectionIndicator]=\"true\"\n      [vertical]=\"isMobile\"\n    >\n      <mat-button-toggle [matTooltip]=\"LdsDirectlyAssignedHint | translate\" value=\"direct\">\n        {{ LdsDirectlyAssigned | translate }}\n      </mat-button-toggle>\n      <mat-button-toggle [matTooltip]=\"LdsIndirectlyAssignedHint | translate\" value=\"nested\">\n        {{ LdsIndirectlyAssigned | translate }}\n      </mat-button-toggle>\n    </mat-button-toggle-group>\n  </div>\n}\n\n@if (membershipView === 'direct') {\n  <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"info\" [dismissable]=\"false\">\n    {{\n      '#LDS#Here you can manage the memberships of the system entitlement. You can request and remove memberships and view the assignment analysis for each membership.'\n        | translate\n    }}\n  </eui-alert>\n  @if (showUnsubscribeWarning) {\n    <eui-alert type=\"warning\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"true\" (dismissed)=\"onWarningDismissed()\">{{\n      LdsNotUnsubscribableHint | translate\n    }}</eui-alert>\n  }\n  <imx-data-view-toolbar [dataSource]=\"dataSourceDirect\" [showSettings]=\"false\"></imx-data-view-toolbar>\n  <mat-card class=\"imx-card-fill\">\n    <imx-data-view-auto-table [dataSource]=\"dataSourceDirect\" mode=\"manual\" [selectable]=\"true\">\n      <ng-container [matColumnDef]=\"entitySchemaGroupDirectMemberships.Columns.UID_Person.ColumnName\">\n        <th mat-header-cell *matHeaderCellDef>{{ entitySchemaGroupDirectMemberships.Columns.UID_Person.Display }}</th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n          <div class=\"filled-cell\">\n            <div>{{ item.UID_Person.Column.GetDisplayValue() }}</div>\n            @if (item.XIsInEffect?.value !== true) {\n              <eui-badge class=\"imx-margin-left-auto\" color=\"primary\">{{ '#LDS#Not effective' | translate }}</eui-badge>\n            }\n          </div>\n        </td>\n      </ng-container>\n\n      @for (column of automaticColumnDirect; track column.ColumnName) {\n        <ng-container [matColumnDef]=\"column.ColumnName\">\n          <th mat-header-cell *matHeaderCellDef>{{ column.Display }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            {{ item.GetEntity().GetColumn(column.ColumnName)?.GetDisplayValue() }}\n          </td>\n        </ng-container>\n      }\n\n      <ng-container [matColumnDef]=\"entitySchemaGroupDirectMemberships.Columns.XMarkedForDeletion.ColumnName\">\n        <th mat-header-cell *matHeaderCellDef></th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n          <div>\n            @if (item.XMarkedForDeletion.value !== 0) {\n              <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\n            }\n          </div>\n        </td>\n      </ng-container>\n    </imx-data-view-auto-table>\n    <imx-data-view-paginator [dataSource]=\"dataSourceDirect\"></imx-data-view-paginator>\n  </mat-card>\n  <imx-data-view-selection [dataSource]=\"dataSourceDirect\" class=\"imx-selection-toggle\"></imx-data-view-selection>\n} @else if (membershipView === 'nested' && canViewInheritedMemberships) {\n  <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"info\" [dismissable]=\"false\">\n    {{\n      '#LDS#Here you can get an overview of the memberships of the system entitlement. Additionally, you can view the assignment analysis for each membership.'\n        | translate\n    }}\n  </eui-alert>\n\n  <imx-data-view-toolbar [dataSource]=\"dataSourceNested\" [showSettings]=\"false\"></imx-data-view-toolbar>\n  <mat-card class=\"imx-card-fill\">\n    <imx-data-view-auto-table [dataSource]=\"dataSourceNested\" mode=\"manual\">\n      <ng-container [matColumnDef]=\"entitySchemaGroupNestedMemberships.Columns.UID_Person.ColumnName\">\n        <th mat-header-cell *matHeaderCellDef>{{ entitySchemaGroupNestedMemberships.Columns.UID_Person.Display }}</th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n          <div class=\"filled-cell\">\n            <div>{{ item.UID_Person.Column.GetDisplayValue() }}</div>\n          </div>\n        </td>\n      </ng-container>\n\n      <ng-container [matColumnDef]=\"entitySchemaGroupNestedMemberships.Columns.UID_UNSGroupChild.ColumnName\">\n        <th mat-header-cell *matHeaderCellDef>{{ entitySchemaGroupNestedMemberships.Columns.UID_UNSGroupChild.Display }}</th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n          <div class=\"filled-cell\">\n            <div>{{ item.UID_UNSGroupChild.Column.GetDisplayValue() }}</div>\n          </div>\n        </td>\n      </ng-container>\n\n      <ng-container [matColumnDef]=\"entitySchemaGroupNestedMemberships.Columns.XMarkedForDeletion.ColumnName\">\n        <th mat-header-cell *matHeaderCellDef></th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n          <div>\n            @if (item.XMarkedForDeletion.value !== 0) {\n              <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\n            }\n          </div>\n        </td>\n      </ng-container>\n    </imx-data-view-auto-table>\n    <imx-data-view-paginator [dataSource]=\"dataSourceNested\"></imx-data-view-paginator>\n  </mat-card>\n}\n", styles: [":host{display:flex;height:100%;flex-direction:column}.imx-selection-toggle{min-height:40px;display:flex}.filled-cell{width:100%!important}.mat-button-toggle-group{margin-bottom:10px}@media screen and (max-width: 768px){.mat-button-toggle-group{width:100%}}\n"] }]
    }], () => [{ type: i1$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i1$1.EuiSidesheetService }, { type: GroupsService }, { type: i2.ConfirmationService }, { type: NewMembershipService }, { type: i7$1.TranslateService }, { type: i2.DataViewSourceFactoryService }], { groupDirectMembershipData: [{
            type: Input
        }], groupNestedMembershipData: [{
            type: Input
        }], unsGroupDbObjectKey: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GroupMembersComponent, { className: "GroupMembersComponent", filePath: "lib\\groups\\group-sidesheet\\group-members\\group-members.component.ts", lineNumber: 60 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$3 = () => ["hiddenFilters"];
const _c1$2 = () => ["namespace"];
class ChildSystemEntitlementsComponent {
    busyService;
    settingsService;
    groupsService;
    groupId;
    isAdmin;
    groupsGroupMembershipData;
    groupsDstSettings;
    navigationState;
    entitySchemaUnsGroupMemberships;
    groupDisplayedColumns = [];
    constructor(busyService, settingsService, groupsService) {
        this.busyService = busyService;
        this.settingsService = settingsService;
        this.groupsService = groupsService;
        this.navigationState = { PageSize: settingsService.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaUnsGroupMemberships = groupsService.UnsGroupMembersSchema;
    }
    async ngOnInit() {
        this.groupDisplayedColumns = [
            this.entitySchemaUnsGroupMemberships.Columns.UID_UNSGroupChild,
            this.entitySchemaUnsGroupMemberships.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchemaUnsGroupMemberships.Columns.XDateInserted,
        ];
        await this.groupNavigate();
    }
    async getData(newState) {
        await this.groupNavigate(newState);
    }
    async groupNavigate(newState) {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            if (newState) {
                this.navigationState = newState;
            }
            this.groupsGroupMembershipData = await this.groupsService.getGroupsGroupMembers(this.groupId, this.navigationState);
            this.groupsDstSettings = {
                displayedColumns: this.groupDisplayedColumns,
                dataSource: this.groupsGroupMembershipData,
                entitySchema: this.entitySchemaUnsGroupMemberships,
                navigationState: this.navigationState,
            };
        }
        finally {
            this.busyService.hide();
        }
    }
    static ɵfac = function ChildSystemEntitlementsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ChildSystemEntitlementsComponent)(i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(GroupsService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ChildSystemEntitlementsComponent, selectors: [["imx-child-system-entitlements"]], inputs: { groupId: "groupId", isAdmin: "isAdmin" }, decls: 4, vars: 8, consts: [["groupsDst", ""], [3, "navigationStateChanged", "settings", "options", "hiddenFilters"], ["noDataText", "#LDS#There are currently no system entitlements.", 3, "dst", "detailViewVisible"], [3, "dst"]], template: function ChildSystemEntitlementsComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "imx-data-source-toolbar", 1, 0);
            i0.ɵɵlistener("navigationStateChanged", function ChildSystemEntitlementsComponent_Template_imx_data_source_toolbar_navigationStateChanged_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.getData($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelement(2, "imx-data-table", 2)(3, "imx-data-source-paginator", 3);
        } if (rf & 2) {
            const groupsDst_r2 = i0.ɵɵreference(1);
            i0.ɵɵproperty("settings", ctx.groupsDstSettings)("options", i0.ɵɵpureFunction0(6, _c0$3))("hiddenFilters", i0.ɵɵpureFunction0(7, _c1$2));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", groupsDst_r2)("detailViewVisible", false);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dst", groupsDst_r2);
        } }, dependencies: [i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent], styles: ["[_nghost-%COMP%]{display:flex;height:100%;flex-direction:column}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChildSystemEntitlementsComponent, [{
        type: Component,
        args: [{ selector: 'imx-child-system-entitlements', template: "<imx-data-source-toolbar\n  #groupsDst\n  (navigationStateChanged)=\"getData($event)\"\n  [settings]=\"groupsDstSettings\"\n  [options]=\"['hiddenFilters']\"\n  [hiddenFilters]=\"['namespace']\"\n>\n</imx-data-source-toolbar>\n\n<imx-data-table [dst]=\"groupsDst\" [detailViewVisible]=\"false\" noDataText=\"#LDS#There are currently no system entitlements.\">\n</imx-data-table>\n<imx-data-source-paginator [dst]=\"groupsDst\"></imx-data-source-paginator>\n", styles: [":host{display:flex;height:100%;flex-direction:column}\n"] }]
    }], () => [{ type: i1$1.EuiLoadingService }, { type: i2.SettingsService }, { type: GroupsService }], { groupId: [{
            type: Input
        }], isAdmin: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ChildSystemEntitlementsComponent, { className: "ChildSystemEntitlementsComponent", filePath: "lib\\groups\\group-sidesheet\\child-system-entitlements\\child-system-entitlements.component.ts", lineNumber: 45 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$2 = ["groupMembers"];
const _c1$1 = ["serviceItemsEditForm"];
function GroupSidesheetComponent_ng_template_2_eui_icon_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 24);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
} }
function GroupSidesheetComponent_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 22);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵelementStart(2, "span", 12);
    i0.ɵɵtext(3, "#LDS#Heading Main Data");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(4, "\u00A0 ");
    i0.ɵɵtemplate(5, GroupSidesheetComponent_ng_template_2_eui_icon_5_Template, 2, 3, "eui-icon", 23);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, ctx_r0.detailsFormGroup.dirty ? "#LDS#You have unsaved changes" : ""));
    i0.ɵɵadvance(5);
    i0.ɵɵproperty("ngIf", ctx_r0.detailsFormGroup.dirty);
} }
function GroupSidesheetComponent_imx_cdr_editor_6_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 25);
    i0.ɵɵlistener("controlCreated", function GroupSidesheetComponent_imx_cdr_editor_6_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.formArray.push($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r3);
} }
function GroupSidesheetComponent_button_13_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 26);
    i0.ɵɵlistener("click", function GroupSidesheetComponent_button_13_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.createServiceItem()); });
    i0.ɵɵelementStart(1, "span", 12);
    i0.ɵɵtext(2, "#LDS#Create service item");
    i0.ɵɵelementEnd()();
} }
function GroupSidesheetComponent_mat_tab_17_ng_template_1_eui_icon_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 24);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
} }
function GroupSidesheetComponent_mat_tab_17_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 22);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵelementStart(2, "span", 12);
    i0.ɵɵtext(3, "#LDS#Heading Service Item");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(4, " \u00A0 ");
    i0.ɵɵtemplate(5, GroupSidesheetComponent_mat_tab_17_ng_template_1_eui_icon_5_Template, 2, 3, "eui-icon", 23);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, ctx_r0.serviceItemFormGroup.dirty ? "#LDS#You have unsaved changes" : ""));
    i0.ɵɵadvance(5);
    i0.ɵɵproperty("ngIf", ctx_r0.serviceItemFormGroup.dirty);
} }
function GroupSidesheetComponent_mat_tab_17_imx_service_items_edit_form_3_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-service-items-edit-form", 29, 0);
    i0.ɵɵlistener("formControlCreated", function GroupSidesheetComponent_mat_tab_17_imx_service_items_edit_form_3_Template_imx_service_items_edit_form_formControlCreated_0_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.siFormArray.push($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("serviceItem", ctx_r0.groupServiceItem);
} }
function GroupSidesheetComponent_mat_tab_17_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-tab");
    i0.ɵɵtemplate(1, GroupSidesheetComponent_mat_tab_17_ng_template_1_Template, 6, 4, "ng-template", 4);
    i0.ɵɵelementStart(2, "div", 5);
    i0.ɵɵtemplate(3, GroupSidesheetComponent_mat_tab_17_imx_service_items_edit_form_3_Template, 2, 1, "imx-service-items-edit-form", 27);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div", 9)(5, "button", 28);
    i0.ɵɵlistener("click", function GroupSidesheetComponent_mat_tab_17_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r5); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.saveGroupServiceItem()); });
    i0.ɵɵelementStart(6, "span", 12);
    i0.ɵɵtext(7, "#LDS#Save");
    i0.ɵɵelementEnd()()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r0.groupServiceItem);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r0.serviceItemFormGroup.dirty || ctx_r0.serviceItemFormGroup.invalid);
} }
function GroupSidesheetComponent_mat_tab_18_ng_template_2_ng_container_4_button_1_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 35);
    i0.ɵɵlistener("click", function GroupSidesheetComponent_mat_tab_18_ng_template_2_ng_container_4_button_1_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r8); const ctx_r0 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r0.requestMembership()); });
    i0.ɵɵelementStart(1, "span", 12);
    i0.ɵɵtext(2, "#LDS#Request memberships");
    i0.ɵɵelementEnd()();
} }
function GroupSidesheetComponent_mat_tab_18_ng_template_2_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, GroupSidesheetComponent_mat_tab_18_ng_template_2_ng_container_4_button_1_Template, 3, 0, "button", 31);
    i0.ɵɵelementStart(2, "button", 32);
    i0.ɵɵlistener("click", function GroupSidesheetComponent_mat_tab_18_ng_template_2_ng_container_4_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r7); const ctx_r0 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r0.onDeleteGroupMembers("delete")); });
    i0.ɵɵelement(3, "eui-icon", 33);
    i0.ɵɵelementStart(4, "span", 12);
    i0.ɵɵtext(5, "#LDS#Remove");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(6, "button", 34);
    i0.ɵɵlistener("click", function GroupSidesheetComponent_mat_tab_18_ng_template_2_ng_container_4_Template_button_click_6_listener() { i0.ɵɵrestoreView(_r7); const ctx_r0 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r0.onDeleteGroupMembers("unsubscribe")); });
    i0.ɵɵelementStart(7, "span", 12);
    i0.ɵɵtext(8, "#LDS#Unsubscribe");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵnextContext();
    const groupMembers_r9 = i0.ɵɵreference(2);
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.isRequestable);
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", groupMembers_r9.selectedItemsCount === 0 || !ctx_r0.canDeleteSelected());
    i0.ɵɵadvance(4);
    i0.ɵɵproperty("disabled", groupMembers_r9.selectedItemsCount === 0 || !ctx_r0.canUnsubscribeSelected());
} }
function GroupSidesheetComponent_mat_tab_18_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵelement(1, "imx-group-members", 30, 1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 9);
    i0.ɵɵtemplate(4, GroupSidesheetComponent_mat_tab_18_ng_template_2_ng_container_4_Template, 9, 3, "ng-container", 16);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const groupMembers_r9 = i0.ɵɵreference(2);
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("unsGroupDbObjectKey", ctx_r0.unsGroupDbObjectKey);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", groupMembers_r9.membershipView === "direct");
} }
function GroupSidesheetComponent_mat_tab_18_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab", 18);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵtemplate(2, GroupSidesheetComponent_mat_tab_18_ng_template_2_Template, 5, 2, "ng-template", 19);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Memberships"));
} }
function GroupSidesheetComponent_ng_template_21_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵelement(1, "imx-child-system-entitlements", 36, 2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("isAdmin", ctx_r0.isAdmin)("groupId", ctx_r0.groupId);
} }
function GroupSidesheetComponent_ng_template_24_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵelement(1, "imx-object-hyperview", 37);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("objectType", ctx_r0.sidesheetData == null ? null : ctx_r0.sidesheetData.group == null ? null : (tmp_1_0 = ctx_r0.sidesheetData.group.GetEntity()) == null ? null : tmp_1_0.TypeName)("objectUid", ctx_r0.sidesheetData == null ? null : ctx_r0.sidesheetData.group == null ? null : (tmp_2_0 = ctx_r0.sidesheetData.group.GetEntity()) == null ? null : (tmp_2_0 = tmp_2_0.GetKeys()) == null ? null : tmp_2_0[0]);
} }
function GroupSidesheetComponent_ng_template_27_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5)(1, "mat-card");
    i0.ɵɵelement(2, "imx-object-history", 38);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("showTitle", false)("objectUid", ctx_r0.groupId);
} }
function GroupSidesheetComponent_ng_container_28_ng_template_3_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function GroupSidesheetComponent_ng_container_28_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 40);
    i0.ɵɵtemplate(1, GroupSidesheetComponent_ng_container_28_ng_template_3_ng_container_1_Template, 1, 0, "ng-container", 41);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const tab_r10 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngComponentOutlet", tab_r10.instance);
} }
function GroupSidesheetComponent_ng_container_28_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "mat-tab", 39);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵtemplate(3, GroupSidesheetComponent_ng_container_28_ng_template_3_Template, 2, 1, "ng-template", 19);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const tab_r10 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("imxDataProvider", ctx_r0.parameters)("label", i0.ɵɵpipeBind1(2, 2, tab_r10.inputData.label));
} }
class GroupSidesheetComponent {
    groups;
    sidesheetData;
    logger;
    busyService;
    snackbar;
    elementalUiConfigService;
    systemInfoService;
    reports;
    configService;
    sidesheetRef;
    tabService;
    confirmation;
    get groupId() {
        return this.sidesheetData.group.GetEntity().GetKeys().join('');
    }
    get isAdmin() {
        return this.sidesheetData?.isAdmin ?? false;
    }
    serviceItemFormGroup;
    detailsFormGroup;
    cdrList = [];
    isRequestable;
    parameters;
    unsGroupDbObjectKey;
    reportDownload;
    buttonBarExtensionReferrer;
    pendingAttestations = { loading: false };
    canCreateServiceItem = false;
    groupMembersComponent;
    serviceItemsEditForm;
    dynamicTabs = [];
    constructor(formBuilder, groups, sidesheetData, logger, busyService, snackbar, elementalUiConfigService, systemInfoService, reports, configService, sidesheetRef, tabService, confirmation) {
        this.groups = groups;
        this.sidesheetData = sidesheetData;
        this.logger = logger;
        this.busyService = busyService;
        this.snackbar = snackbar;
        this.elementalUiConfigService = elementalUiConfigService;
        this.systemInfoService = systemInfoService;
        this.reports = reports;
        this.configService = configService;
        this.sidesheetRef = sidesheetRef;
        this.tabService = tabService;
        this.confirmation = confirmation;
        this.sidesheetRef.closeClicked().subscribe(async () => {
            if (!this.detailsFormGroup.dirty && !this.serviceItemFormGroup.dirty) {
                this.sidesheetRef.close();
                return;
            }
            if (await this.confirmation.confirmLeaveWithUnsavedChanges()) {
                await this.cancelProcess();
            }
        });
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.serviceItemFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.isRequestable = sidesheetData.groupServiceItem != null && !sidesheetData.groupServiceItem.IsInActive.value;
        this.reportDownload = {
            ...this.elementalUiConfigService.Config.downloadOptions,
            url: this.reports.groupsByGroupReport(30, this.groupId),
        };
        this.unsGroupDbObjectKey = this.sidesheetData.unsGroupDbObjectKey;
        if (this.sidesheetData.unsGroupDbObjectKey) {
            this.parameters = {
                objecttable: this.unsGroupDbObjectKey.TableName,
                objectuid: this.unsGroupDbObjectKey.Keys[0],
                display: this.sidesheetData.group.GetEntity().GetDisplay(),
            };
        }
        this.canCreateServiceItem = !sidesheetData.group.GetEntity().GetColumn('XReadOnlyMemberships')?.GetValue();
        this.buttonBarExtensionReferrer = {
            type: this.sidesheetData.unsGroupDbObjectKey.TableName,
            uidGroup: this.sidesheetData.group.GetEntity().GetKeys()[0],
            defaultDownloadOptions: this.elementalUiConfigService.Config.downloadOptions,
        };
    }
    async ngOnInit() {
        this.setup();
    }
    get groupServiceItem() {
        return this.sidesheetData.groupServiceItem;
    }
    get isAadGroup() {
        let isAad = false;
        const xObjKey = this.sidesheetData.unsGroupDbObjectKey;
        isAad = xObjKey ? xObjKey.TableName === 'AADGroup' : false;
        return isAad;
    }
    get formArray() {
        return this.detailsFormGroup.get('formArray');
    }
    get siFormArray() {
        return this.serviceItemFormGroup.get('formArray');
    }
    cancel() {
        this.sidesheetRef.close();
    }
    async createServiceItem() {
        this.sidesheetData.group.extendedData = {
            CreateServiceItem: true,
        };
        await this.saveChanges(this.detailsFormGroup, this.sidesheetData.group, '#LDS#The service item has been successfully created.', true);
    }
    async saveGroup() {
        this.saveChanges(this.detailsFormGroup, this.sidesheetData.group, '#LDS#The system entitlement has been successfully saved.');
    }
    async saveGroupServiceItem() {
        this.serviceItemsEditForm?.saveTags();
        const uidPerson = this.serviceItemsEditForm?.getSelectedUidPerson;
        let confirmMessage = '#LDS#The service item has been successfully saved.';
        if (uidPerson) {
            this.groupServiceItem.extendedData = {
                UidPerson: uidPerson,
                CopyAllMembers: true,
            };
            confirmMessage = '#LDS#The service item has been successfully saved. It may take some time for the changes to take effect.';
        }
        else {
            this.groupServiceItem.extendedData = { CopyAllMembers: false };
        }
        this.saveChanges(this.serviceItemFormGroup, this.groupServiceItem, confirmMessage);
    }
    canUnsubscribeSelected() {
        return this.groupMembersComponent?.canUnsubscribeSelected();
    }
    canDeleteSelected() {
        return this.groupMembersComponent?.canDeleteSelected();
    }
    async onDeleteGroupMembers(mode) {
        return mode === 'delete' ? this.groupMembersComponent.deleteMembers() : this.groupMembersComponent.unsubscribeMembership();
    }
    async requestMembership() {
        return this.groupMembersComponent.requestMembership(this.groupServiceItem);
    }
    async cancelProcess() {
        if (!this.detailsFormGroup.pristine) {
            this.snackbar.open({ key: '#LDS#The changes were discarded.' }, '#LDS#Close');
        }
        this.sidesheetRef.close();
    }
    async setup() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            const systemInfo = await this.systemInfoService.get();
            const config = (await this.configService.getConfig()).OwnershipConfig;
            const type = this.parameters?.objecttable;
            this.dynamicTabs = (await this.tabService.getFittingComponents('groupSidesheet', (ext) => ext.inputData.checkVisibility(this.parameters))).sort((tab1, tab2) => tab1.sortOrder - tab2.sortOrder);
            const cols = this.sidesheetData.group.getColumns(systemInfo?.PreProps?.includes('RISKINDEX') ?? false, config?.EditableFields?.[type] ?? []);
            this.cdrList = cols.map((column) => new BaseCdr(column));
        }
        finally {
            this.busyService.hide();
        }
    }
    async saveChanges(formGroup, objectToSave, confirmationText, reloadServiceItem = false) {
        if (formGroup.valid) {
            this.logger.debug(this, `Saving group changes`);
            const overlayRef = this.busyService.show();
            try {
                await objectToSave.GetEntity().Commit(true);
                if (reloadServiceItem) {
                    this.sidesheetData.uidAccProduct = this.sidesheetData.group.GetEntity().GetColumn('UID_AccProduct').GetValue();
                    this.sidesheetData.groupServiceItem = await this.groups.getGroupServiceItem(this.sidesheetData.uidAccProduct);
                }
                this.isRequestable = !this.groupServiceItem.IsInActive.value;
                formGroup.markAsPristine();
                this.snackbar.open({ key: confirmationText }, '#LDS#Close');
            }
            finally {
                this.busyService.hide(overlayRef);
            }
        }
    }
    static ɵfac = function GroupSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GroupSidesheetComponent)(i0.ɵɵdirectiveInject(i1$2.UntypedFormBuilder), i0.ɵɵdirectiveInject(GroupsService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i2.ElementalUiConfigService), i0.ɵɵdirectiveInject(i2.SystemInfoService), i0.ɵɵdirectiveInject(GroupsReportsService), i0.ɵɵdirectiveInject(i1.ProjectConfigurationService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.ExtService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GroupSidesheetComponent, selectors: [["imx-group-sidesheet"]], viewQuery: function GroupSidesheetComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$2, 5);
            i0.ɵɵviewQuery(_c1$1, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.groupMembersComponent = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.serviceItemsEditForm = _t.first);
        } }, decls: 29, vars: 18, consts: [["serviceItemsEditForm", ""], ["groupMembers", ""], ["childEntitlements", ""], ["mat-stretch-tabs", "false"], ["mat-tab-label", ""], ["eui-sidesheet-content", ""], [1, "imx-tab-card"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], [1, "justify-start", "imx-breakable"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-download-report", 3, "euiDownload"], ["translate", ""], ["id", "buttonBarExtensionComponent", 3, "referrer"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-create-service-item", 3, "click", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-save-group", 3, "click", "disabled"], [4, "ngIf"], [3, "label", 4, "ngIf"], [3, "label"], ["matTabContent", ""], ["data-imx-identifier", "groups-sidesheet-tab-history", 3, "label"], [4, "ngFor", "ngForOf"], [3, "matTooltip"], ["class", "imx-icon-warning", "icon", "save", "size", "s", 4, "ngIf"], ["icon", "save", "size", "s", 1, "imx-icon-warning"], [3, "controlCreated", "cdr"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-create-service-item", 3, "click"], [3, "serviceItem", "formControlCreated", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-save-groupserviceitem", 3, "click", "disabled"], [3, "formControlCreated", "serviceItem"], [3, "unsGroupDbObjectKey"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-membership-new", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "color", "warn", "data-imx-identifier", "group-sidesheet-button-delete-groupmembers", 3, "click", "disabled"], ["icon", "delete"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-delete-groupmembers", 3, "click", "disabled"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-membership-new", 3, "click"], [3, "isAdmin", "groupId"], [3, "objectType", "objectUid"], ["objectType", "UNSGroup", 3, "showTitle", "objectUid"], [3, "imxDataProvider", "label"], [1, "imx-dynamic-content"], [4, "ngComponentOutlet"]], template: function GroupSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group", 3)(1, "mat-tab");
            i0.ɵɵtemplate(2, GroupSidesheetComponent_ng_template_2_Template, 6, 4, "ng-template", 4);
            i0.ɵɵelementStart(3, "div", 5)(4, "mat-card", 6)(5, "form", 7);
            i0.ɵɵtemplate(6, GroupSidesheetComponent_imx_cdr_editor_6_Template, 1, 1, "imx-cdr-editor", 8);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(7, "div", 9)(8, "div", 10)(9, "button", 11)(10, "span", 12);
            i0.ɵɵtext(11, "#LDS#Download report");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(12, "imx-ext", 13);
            i0.ɵɵtemplate(13, GroupSidesheetComponent_button_13_Template, 3, 0, "button", 14);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(14, "button", 15);
            i0.ɵɵlistener("click", function GroupSidesheetComponent_Template_button_click_14_listener() { return ctx.saveGroup(); });
            i0.ɵɵelementStart(15, "span", 12);
            i0.ɵɵtext(16, "#LDS#Save");
            i0.ɵɵelementEnd()()()();
            i0.ɵɵtemplate(17, GroupSidesheetComponent_mat_tab_17_Template, 8, 2, "mat-tab", 16)(18, GroupSidesheetComponent_mat_tab_18_Template, 3, 3, "mat-tab", 17);
            i0.ɵɵelementStart(19, "mat-tab", 18);
            i0.ɵɵpipe(20, "translate");
            i0.ɵɵtemplate(21, GroupSidesheetComponent_ng_template_21_Template, 3, 2, "ng-template", 19);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(22, "mat-tab", 18);
            i0.ɵɵpipe(23, "translate");
            i0.ɵɵtemplate(24, GroupSidesheetComponent_ng_template_24_Template, 2, 2, "ng-template", 19);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(25, "mat-tab", 20);
            i0.ɵɵpipe(26, "translate");
            i0.ɵɵtemplate(27, GroupSidesheetComponent_ng_template_27_Template, 3, 2, "ng-template", 19);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(28, GroupSidesheetComponent_ng_container_28_Template, 4, 4, "ng-container", 21);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("formGroup", ctx.detailsFormGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("euiDownload", ctx.reportDownload);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("referrer", ctx.buttonBarExtensionReferrer);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.groupServiceItem && ctx.canCreateServiceItem);
            i0.ɵɵadvance();
            i0.ɵɵproperty("disabled", !ctx.detailsFormGroup.dirty || ctx.detailsFormGroup.invalid);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.groupServiceItem);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.unsGroupDbObjectKey);
            i0.ɵɵadvance();
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(20, 12, "#LDS#Heading Child System Entitlements"));
            i0.ɵɵadvance(3);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(23, 14, "#LDS#Heading Hyperview"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(26, 16, "#LDS#History"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngForOf", ctx.dynamicTabs);
        } }, dependencies: [i7.NgComponentOutlet, i7.NgForOf, i7.NgIf, i1$2.ɵNgNoValidate, i1$2.NgControlStatusGroup, i1$2.FormGroupDirective, i1$1.EuiIconComponent, i1$1.EuiDownloadDirective, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i8.MatButton, i9$1.MatCard, i10$1.MatTabContent, i10$1.MatTabLabel, i10$1.MatTab, i10$1.MatTabGroup, i9$2.MatTooltip, i2.ExtComponent, i2.CdrEditorComponent, i1.ObjectHyperviewComponent, i1.ServiceItemsEditFormComponent, i7$1.TranslateDirective, i2.DynamicTabDataProviderDirective, i2.ObjectHistoryComponent, GroupMembersComponent, ChildSystemEntitlementsComponent, i7$1.TranslatePipe], styles: [".product-owner-datasource-container[_ngcontent-%COMP%]{margin:10px 0 25px}.product-owner-datasource-container[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:block;font-size:12px;color:#919799;padding-bottom:2px}.product-owner-datasource-container[_ngcontent-%COMP%]   .hidden[_ngcontent-%COMP%]{display:none}.product-owner-datasource-container[_ngcontent-%COMP%]   .imx-icon-info[_ngcontent-%COMP%]{margin-left:5px}.imx-dynamic-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-dynamic-content[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:first-child{height:100%;display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}[_nghost-%COMP%]     .mat-badge-small.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-16px;background:#e36a00}@media screen and (max-width: 769px){.product-owner-datasource-container[_ngcontent-%COMP%]   .imx-icon-info[_ngcontent-%COMP%]{display:none}}.eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type):not(.justify-start){margin-right:10px}.imx-card[_ngcontent-%COMP%]{display:flex;justify-content:flex-end}.imx-card[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-left:10px}.imx-breakable[_ngcontent-%COMP%]{margin-top:-10px}.imx-breakable[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{margin-top:10px}.eui-dark-theme   [_nghost-%COMP%]   .product-owner-datasource-container[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .product-owner-datasource-container[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#fff}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupSidesheetComponent, [{
        type: Component,
        args: [{ selector: 'imx-group-sidesheet', template: "<mat-tab-group mat-stretch-tabs=\"false\">\n  <mat-tab>\n    <ng-template mat-tab-label>\n      <div [matTooltip]=\"(detailsFormGroup.dirty ? '#LDS#You have unsaved changes' : '') | translate\">\n        <span translate>#LDS#Heading Main Data</span>&nbsp;\n        <eui-icon\n          *ngIf=\"detailsFormGroup.dirty\"\n          class=\"imx-icon-warning\"\n          icon=\"save\"\n          size=\"s\"\n          [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"\n        ></eui-icon>\n      </div>\n    </ng-template>\n    <div eui-sidesheet-content>\n      <mat-card class=\"imx-tab-card\">\n        <form [formGroup]=\"detailsFormGroup\">\n          <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"formArray.push($event)\"> </imx-cdr-editor>\n        </form>\n      </mat-card>\n    </div>\n    <div eui-sidesheet-actions>\n      <div class=\"justify-start imx-breakable\">\n        <button\n          mat-stroked-button\n          color=\"primary\"\n          [euiDownload]=\"reportDownload\"\n          data-imx-identifier=\"group-sidesheet-button-download-report\"\n        >\n          <span translate>#LDS#Download report</span>\n        </button>\n        <imx-ext id=\"buttonBarExtensionComponent\" [referrer]=\"buttonBarExtensionReferrer\"></imx-ext>\n        <button\n          *ngIf=\"!groupServiceItem && canCreateServiceItem\"\n          mat-stroked-button\n          color=\"primary\"\n          data-imx-identifier=\"group-sidesheet-button-create-service-item\"\n          (click)=\"createServiceItem()\"\n        >\n          <span translate>#LDS#Create service item</span>\n        </button>\n      </div>\n      <button\n        mat-flat-button\n        color=\"primary\"\n        data-imx-identifier=\"group-sidesheet-button-save-group\"\n        (click)=\"saveGroup()\"\n        [disabled]=\"!detailsFormGroup.dirty || detailsFormGroup.invalid\"\n      >\n        <span translate>#LDS#Save</span>\n      </button>\n    </div>\n  </mat-tab>\n\n  <mat-tab *ngIf=\"groupServiceItem\">\n    <ng-template mat-tab-label>\n      <div [matTooltip]=\"(serviceItemFormGroup.dirty ? '#LDS#You have unsaved changes' : '') | translate\">\n        <span translate>#LDS#Heading Service Item</span>\n        &nbsp;\n        <eui-icon\n          *ngIf=\"serviceItemFormGroup.dirty\"\n          class=\"imx-icon-warning\"\n          icon=\"save\"\n          size=\"s\"\n          [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"\n        ></eui-icon>\n      </div>\n    </ng-template>\n    <div eui-sidesheet-content>\n      <imx-service-items-edit-form\n        #serviceItemsEditForm\n        *ngIf=\"groupServiceItem\"\n        [serviceItem]=\"groupServiceItem\"\n        (formControlCreated)=\"siFormArray.push($event)\"\n      >\n      </imx-service-items-edit-form>\n    </div>\n    <div eui-sidesheet-actions>\n      <button\n        mat-flat-button\n        color=\"primary\"\n        data-imx-identifier=\"group-sidesheet-button-save-groupserviceitem\"\n        (click)=\"saveGroupServiceItem()\"\n        [disabled]=\"!serviceItemFormGroup.dirty || serviceItemFormGroup.invalid\"\n      >\n        <span translate>#LDS#Save</span>\n      </button>\n    </div>\n  </mat-tab>\n\n  <mat-tab [label]=\"'#LDS#Heading Memberships' | translate\" *ngIf=\"unsGroupDbObjectKey\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <imx-group-members #groupMembers [unsGroupDbObjectKey]=\"unsGroupDbObjectKey\"></imx-group-members>\n      </div>\n      <div eui-sidesheet-actions>\n        <ng-container *ngIf=\"groupMembers.membershipView === 'direct'\">\n          <button\n            mat-flat-button\n            color=\"primary\"\n            (click)=\"requestMembership()\"\n            data-imx-identifier=\"group-sidesheet-button-membership-new\"\n            *ngIf=\"isRequestable\"\n          >\n            <span translate>#LDS#Request memberships</span>\n          </button>\n\n          <button\n            mat-stroked-button\n            color=\"warn\"\n            (click)=\"onDeleteGroupMembers('delete')\"\n            [disabled]=\"groupMembers.selectedItemsCount === 0 || !canDeleteSelected()\"\n            data-imx-identifier=\"group-sidesheet-button-delete-groupmembers\"\n          >\n            <eui-icon icon=\"delete\"></eui-icon>\n            <span translate>#LDS#Remove</span>\n          </button>\n          <button\n            mat-flat-button\n            color=\"primary\"\n            (click)=\"onDeleteGroupMembers('unsubscribe')\"\n            [disabled]=\"groupMembers.selectedItemsCount === 0 || !canUnsubscribeSelected()\"\n            data-imx-identifier=\"group-sidesheet-button-delete-groupmembers\"\n          >\n            <span translate>#LDS#Unsubscribe</span>\n          </button>\n        </ng-container>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab [label]=\"'#LDS#Heading Child System Entitlements' | translate\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <imx-child-system-entitlements #childEntitlements [isAdmin]=\"isAdmin\" [groupId]=\"groupId\"> </imx-child-system-entitlements>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab label=\"{{ '#LDS#Heading Hyperview' | translate }}\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <imx-object-hyperview\n          [objectType]=\"sidesheetData?.group?.GetEntity()?.TypeName\"\n          [objectUid]=\"sidesheetData?.group?.GetEntity()?.GetKeys()?.[0]\"\n        >\n        </imx-object-hyperview>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab data-imx-identifier=\"groups-sidesheet-tab-history\" [label]=\"'#LDS#History' | translate\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <mat-card>\n          <imx-object-history objectType=\"UNSGroup\" [showTitle]=\"false\" [objectUid]=\"groupId\"> </imx-object-history>\n        </mat-card>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <ng-container *ngFor=\"let tab of dynamicTabs\">\n    <mat-tab [imxDataProvider]=\"parameters\" [label]=\"tab.inputData.label | translate\">\n      <ng-template matTabContent>\n        <div class=\"imx-dynamic-content\">\n          <ng-container *ngComponentOutlet=\"tab.instance\"></ng-container>\n        </div>\n      </ng-template>\n    </mat-tab>\n  </ng-container>\n</mat-tab-group>\n", styles: [".product-owner-datasource-container{margin:10px 0 25px}.product-owner-datasource-container span{display:block;font-size:12px;color:#919799;padding-bottom:2px}.product-owner-datasource-container .hidden{display:none}.product-owner-datasource-container .imx-icon-info{margin-left:5px}.imx-dynamic-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-dynamic-content :first-child{height:100%;display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}:host ::ng-deep .mat-badge-small.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-16px;background:#e36a00}@media screen and (max-width: 769px){.product-owner-datasource-container .imx-icon-info{display:none}}.eui-sidesheet-actions .justify-start{margin-right:auto}.eui-sidesheet-actions button:not(:last-of-type):not(.justify-start){margin-right:10px}.imx-card{display:flex;justify-content:flex-end}.imx-card button{margin-left:10px}.imx-breakable{margin-top:-10px}.imx-breakable>*{margin-top:10px}.eui-dark-theme :host .product-owner-datasource-container span{color:#dfe4e6}.eui-contrast-theme :host .product-owner-datasource-container span{color:#fff}\n"] }]
    }], () => [{ type: i1$2.UntypedFormBuilder }, { type: GroupsService }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i2.ClassloggerService }, { type: i1$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i2.ElementalUiConfigService }, { type: i2.SystemInfoService }, { type: GroupsReportsService }, { type: i1.ProjectConfigurationService }, { type: i1$1.EuiSidesheetRef }, { type: i2.ExtService }, { type: i2.ConfirmationService }], { groupMembersComponent: [{
            type: ViewChild,
            args: ['groupMembers']
        }], serviceItemsEditForm: [{
            type: ViewChild,
            args: ['serviceItemsEditForm']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GroupSidesheetComponent, { className: "GroupSidesheetComponent", filePath: "lib\\groups\\group-sidesheet\\group-sidesheet.component.ts", lineNumber: 56 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ProductOwnerSidesheetService {
    entityService;
    api;
    constructor(entityService, api) {
        this.entityService = entityService;
        this.api = api;
    }
    buildOrgRulerColumn(ref) {
        const provider = ref.GetFkCandidateProvider().getProviderItem('UID_OrgRuler', 'AERole');
        return this.entityService.createLocalEntityColumn(this.api.typedClient.PortalTargetsystemUnsGroupServiceitem.GetSchema().Columns.UID_OrgRuler, provider ? [provider] : undefined);
    }
    static ɵfac = function ProductOwnerSidesheetService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ProductOwnerSidesheetService)(i0.ɵɵinject(i2.EntityService), i0.ɵɵinject(TsbApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ProductOwnerSidesheetService, factory: ProductOwnerSidesheetService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ProductOwnerSidesheetService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2.EntityService }, { type: TsbApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$1 = ["ownerControl"];
class ProductOwnerSidesheetComponent {
    sidesheetRef;
    productOwnerCdr;
    column;
    prdOwnerControl;
    ownercontrol;
    constructor(sidesheetRef, ownerService, sidesheetData) {
        this.sidesheetRef = sidesheetRef;
        this.column = ownerService.buildOrgRulerColumn(sidesheetData.GetEntity());
    }
    onFormControlCreated(control) {
        setTimeout(() => {
            this.prdOwnerControl = control;
        }, 1000);
    }
    returnProductOwner() {
        this.sidesheetRef.close({ uidPerson: this.ownercontrol.uidPersonSelected, uidRole: this.ownercontrol.uidRoleSelected });
    }
    static ɵfac = function ProductOwnerSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ProductOwnerSidesheetComponent)(i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(ProductOwnerSidesheetService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ProductOwnerSidesheetComponent, selectors: [["ng-component"]], viewQuery: function ProductOwnerSidesheetComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$1, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.ownercontrol = _t.first);
        } }, decls: 7, vars: 1, consts: [["ownerControl", ""], ["eui-sidesheet-content", ""], [3, "formControlCreated", "column"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "color", "primary", 3, "click"], ["translate", ""]], template: function ProductOwnerSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 1)(1, "imx-owner-control", 2, 0);
            i0.ɵɵlistener("formControlCreated", function ProductOwnerSidesheetComponent_Template_imx_owner_control_formControlCreated_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFormControlCreated($event)); });
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(3, "div", 3)(4, "button", 4);
            i0.ɵɵlistener("click", function ProductOwnerSidesheetComponent_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.returnProductOwner()); });
            i0.ɵɵelementStart(5, "span", 5);
            i0.ɵɵtext(6, "#LDS#Apply");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("column", ctx.column);
        } }, dependencies: [i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i8.MatButton, i1.OwnerControlComponent, i7$1.TranslateDirective], styles: [".governance-sidesheet__tab-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:first-child{overflow:auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ProductOwnerSidesheetComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\n  <imx-owner-control #ownerControl [column]=\"column\" (formControlCreated)=\"onFormControlCreated($event)\"></imx-owner-control>\n</div>\n<div eui-sidesheet-actions>\n  <button mat-flat-button color=\"primary\" (click)=\"returnProductOwner()\">\n    <span translate>#LDS#Apply</span>\n  </button>\n</div>\n", styles: [".governance-sidesheet__tab-content{display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body>:first-child{overflow:auto}\n"] }]
    }], () => [{ type: i1$1.EuiSidesheetRef }, { type: ProductOwnerSidesheetService }, { type: i6$1.PortalTargetsystemUnsGroupServiceitem, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }], { ownercontrol: [{
            type: ViewChild,
            args: ['ownerControl']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ProductOwnerSidesheetComponent, { className: "ProductOwnerSidesheetComponent", filePath: "lib\\groups\\product-owner-sidesheet\\product-owner-sidesheet.component.ts", lineNumber: 41 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function DataExplorerGroupsComponent_mat_card_0_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function DataExplorerGroupsComponent_mat_card_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card", 7)(1, "div", 8)(2, "div", 9)(3, "h3", 10);
    i0.ɵɵtext(4, "#LDS#Heading System Entitlements");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(5, "imx-help-contextual", 11);
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(6, DataExplorerGroupsComponent_mat_card_0_ng_container_6_Template, 1, 0, "ng-container", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    const table_r2 = i0.ɵɵreference(5);
    i0.ɵɵadvance(5);
    i0.ɵɵproperty("contextId", ctx_r0.contextId);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", table_r2);
} }
function DataExplorerGroupsComponent_div_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function DataExplorerGroupsComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 13);
    i0.ɵɵtemplate(1, DataExplorerGroupsComponent_div_1_ng_container_1_Template, 1, 0, "ng-container", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵnextContext();
    const actions_r3 = i0.ɵɵreference(7);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", actions_r3);
} }
function DataExplorerGroupsComponent_mat_card_2_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function DataExplorerGroupsComponent_mat_card_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card", 14);
    i0.ɵɵtemplate(1, DataExplorerGroupsComponent_mat_card_2_ng_container_1_Template, 1, 0, "ng-container", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵnextContext();
    const table_r2 = i0.ɵɵreference(5);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", table_r2);
} }
function DataExplorerGroupsComponent_div_3_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function DataExplorerGroupsComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 15);
    i0.ɵɵtemplate(1, DataExplorerGroupsComponent_div_3_ng_container_1_Template, 1, 0, "ng-container", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵnextContext();
    const actions_r3 = i0.ɵɵreference(7);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", actions_r3);
} }
function DataExplorerGroupsComponent_ng_template_4_th_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 26);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchemaUnsGroup == null ? null : ctx_r0.entitySchemaUnsGroup.Columns == null ? null : ctx_r0.entitySchemaUnsGroup.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME] == null ? null : ctx_r0.entitySchemaUnsGroup.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME].Display, " ");
} }
function DataExplorerGroupsComponent_ng_template_4_td_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 27)(1, "div", 28);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 29);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r5.GetEntity().GetDisplay());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r5.Description.Column.GetDisplayValue());
} }
function DataExplorerGroupsComponent_ng_template_4_th_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 26);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchemaUnsGroup == null ? null : ctx_r0.entitySchemaUnsGroup.Columns == null ? null : ctx_r0.entitySchemaUnsGroup.Columns.Requestable == null ? null : ctx_r0.entitySchemaUnsGroup.Columns.Requestable.Display, " ");
} }
function DataExplorerGroupsComponent_ng_template_4_td_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 30)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r6.Requestable.Column.GetDisplayValue());
} }
function DataExplorerGroupsComponent_ng_template_4_ng_container_10_th_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 32);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.entitySchemaUnsGroup == null ? null : ctx_r0.entitySchemaUnsGroup.Columns == null ? null : ctx_r0.entitySchemaUnsGroup.Columns.XMarkedForDeletion == null ? null : ctx_r0.entitySchemaUnsGroup.Columns.XMarkedForDeletion.Display);
} }
function DataExplorerGroupsComponent_ng_template_4_ng_container_10_td_2_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "eui-badge", 34);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r7 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r7.XMarkedForDeletion.Column.GetDisplayValue());
} }
function DataExplorerGroupsComponent_ng_template_4_ng_container_10_td_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 30);
    i0.ɵɵtemplate(1, DataExplorerGroupsComponent_ng_template_4_ng_container_10_td_2_div_1_Template, 3, 1, "div", 33);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r7 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r7.XMarkedForDeletion.value !== 0);
} }
function DataExplorerGroupsComponent_ng_template_4_ng_container_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0, 20);
    i0.ɵɵtemplate(1, DataExplorerGroupsComponent_ng_template_4_ng_container_10_th_1_Template, 2, 1, "th", 31)(2, DataExplorerGroupsComponent_ng_template_4_ng_container_10_td_2_Template, 2, 1, "td", 23);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("matColumnDef", ctx_r0.entitySchemaUnsGroup.Columns.XMarkedForDeletion.ColumnName);
} }
function DataExplorerGroupsComponent_ng_template_4_ng_container_11_th_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 26);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.entitySchemaUnsGroup == null ? null : ctx_r0.entitySchemaUnsGroup.Columns == null ? null : ctx_r0.entitySchemaUnsGroup.Columns.UID_UNSRoot == null ? null : ctx_r0.entitySchemaUnsGroup.Columns.UID_UNSRoot.Display);
} }
function DataExplorerGroupsComponent_ng_template_4_ng_container_11_td_2_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "td", 30)(1, "button", 35);
    i0.ɵɵlistener("click", function DataExplorerGroupsComponent_ng_template_4_ng_container_11_td_2_Template_button_click_1_listener($event) { const item_r9 = i0.ɵɵrestoreView(_r8).$implicit; const ctx_r0 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r0.viewSource($event, item_r9)); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r9 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", !ctx_r0.uidPerson);
    i0.ɵɵattribute("data-imx-identifier", "groups-table-button-view-assignment-analysis" + item_r9.GetEntity().GetKeys().join("_"));
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 3, "#LDS#View assignment analysis"), " ");
} }
function DataExplorerGroupsComponent_ng_template_4_ng_container_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0, 20);
    i0.ɵɵtemplate(1, DataExplorerGroupsComponent_ng_template_4_ng_container_11_th_1_Template, 2, 1, "th", 21)(2, DataExplorerGroupsComponent_ng_template_4_ng_container_11_td_2_Template, 4, 5, "td", 23);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵproperty("matColumnDef", "action");
} }
function DataExplorerGroupsComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-data-view-toolbar", 16);
    i0.ɵɵlistener("updateConfig", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_view_toolbar_updateConfig_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.updateConfig($event)); })("deleteConfigById", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_view_toolbar_deleteConfigById_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.deleteConfigById($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(1, "div", 17)(2, "div", 18)(3, "imx-data-view-auto-table", 19);
    i0.ɵɵlistener("matSortChange", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_view_auto_table_matSortChange_3_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.dataSource == null ? null : ctx_r0.dataSource.sortChange($event)); });
    i0.ɵɵelementContainerStart(4, 20);
    i0.ɵɵtemplate(5, DataExplorerGroupsComponent_ng_template_4_th_5_Template, 2, 1, "th", 21)(6, DataExplorerGroupsComponent_ng_template_4_td_6_Template, 5, 2, "td", 22);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(7, 20);
    i0.ɵɵtemplate(8, DataExplorerGroupsComponent_ng_template_4_th_8_Template, 2, 1, "th", 21)(9, DataExplorerGroupsComponent_ng_template_4_td_9_Template, 3, 1, "td", 23);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵtemplate(10, DataExplorerGroupsComponent_ng_template_4_ng_container_10_Template, 3, 1, "ng-container", 24)(11, DataExplorerGroupsComponent_ng_template_4_ng_container_11_Template, 3, 1, "ng-container", 24);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(12, "imx-data-view-paginator", 25);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("dataSource", ctx_r0.dataSource);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("dataSource", ctx_r0.dataSource)("matSortActive", ctx_r0.dataSource.sortId())("matSortDirection", ctx_r0.dataSource.sortDirection())("selectable", ctx_r0.unsAccountIdFilter ? false : true);
    i0.ɵɵadvance();
    i0.ɵɵproperty("matColumnDef", ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("matColumnDef", ctx_r0.entitySchemaUnsGroup.Columns.Requestable.ColumnName);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r0.entitySchemaUnsGroup == null ? null : ctx_r0.entitySchemaUnsGroup.Columns == null ? null : ctx_r0.entitySchemaUnsGroup.Columns.XMarkedForDeletion);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.unsAccountIdFilter);
    i0.ɵɵadvance();
    i0.ɵɵproperty("dataSource", ctx_r0.dataSource);
} }
function DataExplorerGroupsComponent_ng_template_6_button_14_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 41);
    i0.ɵɵlistener("click", function DataExplorerGroupsComponent_ng_template_6_button_14_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r11); const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.bulkUpdateOwner()); });
    i0.ɵɵelementStart(1, "span", 10);
    i0.ɵɵtext(2, "#LDS#Assign product owner");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("disabled", ctx_r0.selectedGroupsForUpdate.length === 0);
} }
function DataExplorerGroupsComponent_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    const _r10 = i0.ɵɵgetCurrentView();
    i0.ɵɵelement(0, "imx-data-view-selection", 25);
    i0.ɵɵelementStart(1, "button", 36);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelement(3, "eui-icon", 37);
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "mat-menu", 38, 2)(8, "button", 39);
    i0.ɵɵlistener("click", function DataExplorerGroupsComponent_ng_template_6_Template_button_click_8_listener() { i0.ɵɵrestoreView(_r10); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.bulkUpdateSelected(true)); });
    i0.ɵɵelementStart(9, "span", 10);
    i0.ɵɵtext(10, "#LDS#Make requestable");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(11, "button", 39);
    i0.ɵɵlistener("click", function DataExplorerGroupsComponent_ng_template_6_Template_button_click_11_listener() { i0.ɵɵrestoreView(_r10); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.bulkUpdateSelected(false)); });
    i0.ɵɵelementStart(12, "span", 10);
    i0.ɵɵtext(13, "#LDS#Make not requestable");
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(14, DataExplorerGroupsComponent_ng_template_6_button_14_Template, 3, 1, "button", 40);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const actionsMenu_r12 = i0.ɵɵreference(7);
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("dataSource", ctx_r0.dataSource);
    i0.ɵɵadvance();
    i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(2, 7, "#LDS#Actions"));
    i0.ɵɵproperty("matMenuTriggerFor", actionsMenu_r12);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(5, 9, "#LDS#Actions"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵproperty("disabled", ctx_r0.itemsAreRequestable);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("disabled", ctx_r0.itemsAreNotRequestable);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r0.isAdmin);
} }
class DataExplorerGroupsComponent {
    route;
    sideSheet;
    busyServiceElemental;
    logger;
    groupsService;
    viewConfigService;
    dataHelper;
    translate;
    snackbar;
    dataSource;
    unsAccountIdFilter;
    sidesheetWidth = '65%';
    applyIssuesFilter = false;
    issuesFilterMode;
    targetSystemData;
    isAdmin;
    uidPerson = '';
    usedInSidesheet = false;
    contextId;
    filterOptions = [];
    treeDbWrapper;
    requestableBulkUpdateCtrl = new UntypedFormControl(true);
    entitySchemaUnsGroup;
    DisplayColumns = DisplayColumns;
    selectedGroupsForUpdate = [];
    data;
    busyService = new BusyService();
    viewConfigPath;
    viewConfig;
    itemStatus = {
        enabled: (item) => {
            return item.UID_AccProduct?.value !== '';
        },
    };
    displayedColumns = [];
    authorityDataDeleted$;
    dataModel;
    constructor(route, sideSheet, busyServiceElemental, logger, groupsService, viewConfigService, dataHelper, translate, snackbar, dataSource) {
        this.route = route;
        this.sideSheet = sideSheet;
        this.busyServiceElemental = busyServiceElemental;
        this.logger = logger;
        this.groupsService = groupsService;
        this.viewConfigService = viewConfigService;
        this.dataHelper = dataHelper;
        this.translate = translate;
        this.snackbar = snackbar;
        this.dataSource = dataSource;
        this.isAdmin = this.route.snapshot?.url[0]?.path === 'admin';
        this.entitySchemaUnsGroup = this.groupsService.unsGroupsSchema(this.isAdmin);
        this.authorityDataDeleted$ = this.dataHelper.authorityDataDeleted.subscribe(() => this.dataSource.updateState());
        this.treeDbWrapper = new ContainerTreeDatabaseWrapper(this.busyService, dataHelper);
    }
    async ngOnInit() {
        this.entitySchemaUnsGroup = this.groupsService.unsGroupsSchema(this.isAdmin);
        this.displayedColumns = [
            this.entitySchemaUnsGroup.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchemaUnsGroup.Columns.Requestable,
        ];
        if (this.entitySchemaUnsGroup.Columns.XMarkedForDeletion) {
            this.displayedColumns.push(this.entitySchemaUnsGroup.Columns.XMarkedForDeletion);
        }
        if (this.unsAccountIdFilter) {
            this.displayedColumns.push({ ColumnName: 'action', Type: ValType.String });
        }
        const isBusy = this.busyService.beginBusy();
        try {
            this.dataSource.itemStatus = this.itemStatus;
            this.dataModel = await this.groupsService.getDataModel(this.isAdmin);
            this.filterOptions = this.dataModel.Filters ?? [];
            this.viewConfigPath = this.isAdmin || this.unsAccountIdFilter ? 'targetsystem/uns/group' : 'resp/unsgroup';
            this.viewConfig = await this.viewConfigService.getInitialDSTExtension(this.dataModel, this.viewConfigPath);
            const dataViewInitParameters = {
                execute: this.isAdmin || this.unsAccountIdFilter // Wenn wir filtern, muss auch der Admin-Endpoint genutzt werden
                    ? (params, signal) => {
                        if (this.unsAccountIdFilter) {
                            params = { ...params, uid_unsaccount: this.unsAccountIdFilter };
                        }
                        return this.groupsService.getGroups(params, signal);
                    }
                    : (params, signal) => this.groupsService.getGroupsResp(params, signal),
                schema: this.entitySchemaUnsGroup,
                columnsToDisplay: this.displayedColumns,
                dataModel: this.dataModel,
                exportFunction: this.isAdmin || this.unsAccountIdFilter ? this.groupsService.exportGroups() : this.groupsService.exportGroupsResp(),
                viewConfig: this.viewConfig,
                highlightEntity: (identity) => {
                    this.onGroupChanged(identity);
                },
                filterTree: {
                    filterMethode: async (parentkey) => {
                        return this.groupsService.getFilterTree({
                            parentkey,
                            container: this.dataSource.state().container,
                            system: this.dataSource.state().system,
                            uid_unsaccount: this.unsAccountIdFilter,
                        });
                    },
                    multiSelect: false,
                },
                selectionChange: (selection) => this.onGroupSelected(selection),
            };
            this.dataSource.init(dataViewInitParameters);
        }
        finally {
            isBusy.endBusy();
        }
    }
    ngOnDestroy() {
        if (this.authorityDataDeleted$) {
            this.authorityDataDeleted$.unsubscribe();
        }
    }
    async updateConfig(config) {
        await this.viewConfigService.putViewConfig(config);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    async deleteConfigById(id) {
        await this.viewConfigService.deleteViewConfig(id);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    get itemsAreNotRequestable() {
        return this.selectedGroupsForUpdate.every((elem) => !elem.Requestable.value);
    }
    get itemsAreRequestable() {
        return this.selectedGroupsForUpdate.every((elem) => elem.Requestable.value);
    }
    async onGroupChanged(group) {
        if (this.unsAccountIdFilter) {
            return;
        }
        this.logger.debug(this, `Selected group changed`);
        this.logger.trace(this, `New group selected`, group);
        let data;
        const hideOverlayRef = this.busyServiceElemental.show();
        try {
            const objKey = DbObjectKey.FromXml(group.GetEntity().GetColumn('XObjectKey').GetValue());
            const uidAccProduct = group.GetEntity().GetColumn('UID_AccProduct').GetValue();
            data = {
                uidAccProduct,
                unsGroupDbObjectKey: objKey,
                group: await this.groupsService.getGroupDetailsInteractive(objKey, 'UID_AccProduct'),
                groupServiceItem: await this.groupsService.getGroupServiceItem(uidAccProduct),
                isAdmin: this.isAdmin,
            };
        }
        finally {
            this.busyServiceElemental.hide(hideOverlayRef);
        }
        this.viewGroup(data);
    }
    onGroupSelected(selected) {
        this.selectedGroupsForUpdate = selected;
    }
    async viewSource(event, item) {
        event.stopPropagation();
        const uidPerson = this.uidPerson;
        const objKey = DbObjectKey.FromXml(item.XObjectKey.value);
        const data = {
            UID_Person: uidPerson,
            Type: SourceDetectiveType.MembershipOfSystemEntitlement,
            UID: objKey.Keys[0],
            TableName: objKey.TableName,
        };
        this.sideSheet.open(SourceDetectiveSidesheetComponent, {
            title: await this.translate.get('#LDS#Heading View Assignment Analysis').toPromise(),
            subTitle: item.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(),
            disableClose: false,
            testId: 'system-entitlement-role-membership-details',
            data,
        });
    }
    async bulkUpdateSelected(request) {
        const updateData = {
            Keys: [],
            Data: [
                {
                    Name: PortalTargetsystemUnsGroupServiceitem.GetEntitySchema().Columns.IsInActive.ColumnName,
                    // Inverse value as actual property is 'Not available'
                    Value: !request,
                },
            ],
        };
        return this.updateSelectedGroups(updateData);
    }
    async bulkUpdateOwner() {
        const selectedOwner = await this.sideSheet
            .open(ProductOwnerSidesheetComponent, {
            title: await this.translate.get('#LDS#Heading Assign Product Owner').toPromise(),
            subTitle: this.selectedGroupsForUpdate.length === 1 ? this.selectedGroupsForUpdate[0].GetEntity().GetDisplay() : '',
            padding: '0px',
            width: `max(650px, ${this.sidesheetWidth})`,
            icon: 'usergroup',
            testId: 'system-entitlements-assign-product-owner',
            data: await this.groupsService.getGroupServiceItem(this.selectedGroupsForUpdate[0].UID_AccProduct.value),
        })
            .afterClosed()
            .toPromise();
        if (selectedOwner) {
            return this.updateOwnerForSelectedGroups(selectedOwner);
        }
    }
    async updateOwnerForSelectedGroups(selectedOwner) {
        let confirmMessage = '';
        if (this.busyServiceElemental.overlayRefs.length === 0) {
            this.busyServiceElemental.show();
        }
        try {
            confirmMessage = await this.groupsService.updateMultipleOwner(this.selectedGroupsForUpdate.map((elem) => elem.UID_AccProduct.value), selectedOwner);
        }
        finally {
            this.busyServiceElemental.hide();
        }
        if (confirmMessage) {
            this.snackbar.open({ key: confirmMessage });
        }
        return this.dataSource.updateState();
    }
    async updateSelectedGroups(updateData) {
        this.selectedGroupsForUpdate.forEach((group) => {
            const serviceItemUid = group?.UID_AccProduct.value;
            if (serviceItemUid?.length && updateData.Keys) {
                updateData.Keys.push([serviceItemUid]);
            }
        });
        if (this.busyServiceElemental.overlayRefs.length === 0) {
            this.busyServiceElemental.show();
        }
        try {
            await this.groupsService.bulkUpdateGroupServiceItems(updateData);
            await this.dataSource.updateState();
            this.dataSource.selection.clear();
            this.requestableBulkUpdateCtrl.setValue(true, { emitEvent: false });
        }
        finally {
            this.busyServiceElemental.hide();
        }
    }
    async viewGroup(data) {
        const sidesheetRef = this.sideSheet.open(GroupSidesheetComponent, {
            title: await this.translate.get('#LDS#Heading Edit System Entitlement').toPromise(),
            subTitle: data.group.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(1250, 0.7),
            icon: 'usergroup',
            data,
            testId: 'edit-system-entitlement-sidesheet',
            disableClose: true,
        });
        // After the sidesheet closes, reload the current data to refresh any changes that might have been made
        sidesheetRef.afterClosed().subscribe(() => this.dataSource.updateState());
    }
    static ɵfac = function DataExplorerGroupsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DataExplorerGroupsComponent)(i0.ɵɵdirectiveInject(i1$3.ActivatedRoute), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(GroupsService), i0.ɵɵdirectiveInject(i1.ViewConfigService), i0.ɵɵdirectiveInject(DeHelperService), i0.ɵɵdirectiveInject(i7$1.TranslateService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i2.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataExplorerGroupsComponent, selectors: [["imx-data-explorer-groups"]], inputs: { unsAccountIdFilter: "unsAccountIdFilter", sidesheetWidth: "sidesheetWidth", applyIssuesFilter: "applyIssuesFilter", issuesFilterMode: "issuesFilterMode", targetSystemData: "targetSystemData", isAdmin: "isAdmin", uidPerson: "uidPerson", usedInSidesheet: "usedInSidesheet", contextId: "contextId" }, features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 8, vars: 4, consts: [["table", ""], ["actions", ""], ["actionsMenu", "matMenu"], ["class", "data-explorer data-explorer--groups imx-card-fill", 4, "ngIf"], ["class", "imx-button-bar-transparent", 4, "ngIf"], ["class", "imx-card-fill imx-tab-card", 4, "ngIf"], ["eui-sidesheet-actions", "", 4, "ngIf"], [1, "data-explorer", "data-explorer--groups", "imx-card-fill"], [1, "imx-card-data-explorer-header"], [1, "imx-card-data-explorer-header-bg"], ["translate", ""], [3, "contextId"], [4, "ngTemplateOutlet"], [1, "imx-button-bar-transparent"], [1, "imx-card-fill", "imx-tab-card"], ["eui-sidesheet-actions", ""], [3, "updateConfig", "deleteConfigById", "dataSource"], [1, "imx-data-explorer-content"], [1, "data-explorer-table"], ["mode", "manual", "matSort", "", 3, "matSortChange", "dataSource", "matSortActive", "matSortDirection", "selectable"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], [3, "matColumnDef", 4, "ngIf"], [3, "dataSource"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], ["data-imx-identifier", "groups-tabledata-display"], ["subtitle", "", "data-imx-identifier", "groups-tabledata-description"], ["mat-cell", "", "role", "gridcell"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], ["mat-header-cell", "", "mat-sort-header", ""], [4, "ngIf"], ["color", "gray"], ["mat-button", "", "color", "primary", 3, "click", "disabled"], ["mat-stroked-button", "", "data-imx-identifier", "groups-button-actions", 3, "title", "matMenuTriggerFor"], ["icon", "ellipsisvertical"], ["yPosition", "above", "xPosition", "before", "data-imx-identifier", "attestations-actions-menu"], ["mat-menu-item", "", "color", "primary", 3, "click", "disabled"], ["mat-menu-item", "", "class", "imx-right-button", 3, "disabled", "click", 4, "ngIf"], ["mat-menu-item", "", 1, "imx-right-button", 3, "click", "disabled"]], template: function DataExplorerGroupsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, DataExplorerGroupsComponent_mat_card_0_Template, 7, 2, "mat-card", 3)(1, DataExplorerGroupsComponent_div_1_Template, 2, 1, "div", 4)(2, DataExplorerGroupsComponent_mat_card_2_Template, 2, 1, "mat-card", 5)(3, DataExplorerGroupsComponent_div_3_Template, 2, 1, "div", 6)(4, DataExplorerGroupsComponent_ng_template_4_Template, 13, 10, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor)(6, DataExplorerGroupsComponent_ng_template_6_Template, 15, 11, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", !ctx.usedInSidesheet);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.usedInSidesheet);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.usedInSidesheet);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.usedInSidesheet && (ctx.unsAccountIdFilter ? false : true));
        } }, dependencies: [i7.NgIf, i7.NgTemplateOutlet, i1$1.EuiBadgeComponent, i1$1.EuiIconComponent, i1$1.EuiSidesheetActionsDirective, i8.MatButton, i9$1.MatCard, i11.MatMenu, i11.MatMenuItem, i11.MatMenuTrigger, i12.MatSort, i12.MatSortHeader, i8$1.MatHeaderCellDef, i8$1.MatColumnDef, i8$1.MatCellDef, i8$1.MatHeaderCell, i8$1.MatCell, i7$1.TranslateDirective, i2.HelpContextualComponent, i2.DataViewAutoTableComponent, i2.DataViewPaginatorComponent, i2.DataViewToolbarComponent, i2.DataViewSelectionComponent, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{overflow:hidden;height:100%}.data-explorer--groups[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:nth-child(2){flex:0 0 auto}.imx-data-explorer-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.data-explorer-table[_ngcontent-%COMP%]{display:flex;flex-direction:column}.data-explorer-table[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:first-child{flex:1 1 auto}.hidden[_ngcontent-%COMP%]{display:none}imx-selected-elements[_ngcontent-%COMP%]{margin-left:10px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataExplorerGroupsComponent, [{
        type: Component,
        args: [{ selector: 'imx-data-explorer-groups', providers: [DataViewSource], template: "<mat-card *ngIf=\"!usedInSidesheet\" class=\"data-explorer data-explorer--groups imx-card-fill\">\n  <div class=\"imx-card-data-explorer-header\">\n    <div class=\"imx-card-data-explorer-header-bg\">\n      <h3 translate>#LDS#Heading System Entitlements</h3>\n      <imx-help-contextual [contextId]=\"contextId\"></imx-help-contextual>\n    </div>\n  </div>\n  <ng-container *ngTemplateOutlet=\"table\"> </ng-container>\n</mat-card>\n<div *ngIf=\"!usedInSidesheet\" class=\"imx-button-bar-transparent\">\n  <ng-container *ngTemplateOutlet=\"actions\"> </ng-container>\n</div>\n\n<mat-card *ngIf=\"usedInSidesheet\" class=\"imx-card-fill imx-tab-card\">\n  <ng-container *ngTemplateOutlet=\"table\"> </ng-container>\n</mat-card>\n<div *ngIf=\"usedInSidesheet && (unsAccountIdFilter ? false : true)\" eui-sidesheet-actions>\n  <ng-container *ngTemplateOutlet=\"actions\"> </ng-container>\n</div>\n\n<ng-template #table>\n  <imx-data-view-toolbar\n    [dataSource]=\"dataSource\"\n    (updateConfig)=\"updateConfig($event)\"\n    (deleteConfigById)=\"deleteConfigById($event)\"\n  ></imx-data-view-toolbar>\n  <div class=\"imx-data-explorer-content\">\n    <div class=\"data-explorer-table\">\n      <imx-data-view-auto-table\n        [dataSource]=\"dataSource\"\n        mode=\"manual\"\n        matSort\n        (matSortChange)=\"dataSource?.sortChange($event)\"\n        [matSortActive]=\"dataSource.sortId()\"\n        [matSortDirection]=\"dataSource.sortDirection()\"\n        [selectable]=\"unsAccountIdFilter ? false : true\"\n      >\n        <ng-container [matColumnDef]=\"DisplayColumns.DISPLAY_PROPERTYNAME\">\n          <th mat-header-cell *matHeaderCellDef>\n            {{ entitySchemaUnsGroup?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]?.Display }}\n          </th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n            <div data-imx-identifier=\"groups-tabledata-display\">{{ item.GetEntity().GetDisplay() }}</div>\n            <div subtitle data-imx-identifier=\"groups-tabledata-description\">{{ item.Description.Column.GetDisplayValue() }}</div>\n          </td>\n        </ng-container>\n        <ng-container [matColumnDef]=\"entitySchemaUnsGroup.Columns.Requestable.ColumnName\">\n          <th mat-header-cell *matHeaderCellDef>\n            {{ entitySchemaUnsGroup?.Columns?.Requestable?.Display }}\n          </th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <div>{{ item.Requestable.Column.GetDisplayValue() }}</div>\n          </td>\n        </ng-container>\n        <ng-container\n          [matColumnDef]=\"entitySchemaUnsGroup.Columns.XMarkedForDeletion.ColumnName\"\n          *ngIf=\"entitySchemaUnsGroup?.Columns?.XMarkedForDeletion\"\n        >\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{ entitySchemaUnsGroup?.Columns?.XMarkedForDeletion?.Display }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <div *ngIf=\"item.XMarkedForDeletion.value !== 0\">\n              <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\n            </div>\n          </td>\n        </ng-container>\n        <ng-container [matColumnDef]=\"'action'\" *ngIf=\"unsAccountIdFilter\">\n          <th mat-header-cell *matHeaderCellDef>{{ entitySchemaUnsGroup?.Columns?.UID_UNSRoot?.Display }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <button\n              mat-button\n              color=\"primary\"\n              [attr.data-imx-identifier]=\"'groups-table-button-view-assignment-analysis' + item.GetEntity().GetKeys().join('_')\"\n              [disabled]=\"!uidPerson\"\n              (click)=\"viewSource($event, item)\"\n            >\n              {{ '#LDS#View assignment analysis' | translate }}\n            </button>\n          </td>\n        </ng-container>\n      </imx-data-view-auto-table>\n      <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #actions>\n  <imx-data-view-selection [dataSource]=\"dataSource\"></imx-data-view-selection>\n  <button\n    mat-stroked-button\n    data-imx-identifier=\"groups-button-actions\"\n    title=\"{{ '#LDS#Actions' | translate }}\"\n    [matMenuTriggerFor]=\"actionsMenu\"\n  >\n    <eui-icon icon=\"ellipsisvertical\"></eui-icon>\n    {{ '#LDS#Actions' | translate }}\n  </button>\n  <mat-menu yPosition=\"above\" xPosition=\"before\" data-imx-identifier=\"attestations-actions-menu\" #actionsMenu=\"matMenu\">\n    <button mat-menu-item color=\"primary\" [disabled]=\"itemsAreRequestable\" (click)=\"bulkUpdateSelected(true)\">\n      <span translate>#LDS#Make requestable</span>\n    </button>\n    <button mat-menu-item color=\"primary\" [disabled]=\"itemsAreNotRequestable\" (click)=\"bulkUpdateSelected(false)\">\n      <span translate>#LDS#Make not requestable</span>\n    </button>\n    <button\n      *ngIf=\"isAdmin\"\n      [disabled]=\"selectedGroupsForUpdate.length === 0\"\n      mat-menu-item\n      (click)=\"bulkUpdateOwner()\"\n      class=\"imx-right-button\"\n    >\n      <span translate>#LDS#Assign product owner</span>\n    </button>\n  </mat-menu>\n</ng-template>\n", styles: [":host{overflow:hidden;height:100%}.data-explorer--groups>:nth-child(2){flex:0 0 auto}.imx-data-explorer-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.data-explorer-table{display:flex;flex-direction:column}.data-explorer-table>:first-child{flex:1 1 auto}.hidden{display:none}imx-selected-elements{margin-left:10px}\n"] }]
    }], () => [{ type: i1$3.ActivatedRoute }, { type: i1$1.EuiSidesheetService }, { type: i1$1.EuiLoadingService }, { type: i2.ClassloggerService }, { type: GroupsService }, { type: i1.ViewConfigService }, { type: DeHelperService }, { type: i7$1.TranslateService }, { type: i2.SnackBarService }, { type: i2.DataViewSource }], { unsAccountIdFilter: [{
            type: Input
        }], sidesheetWidth: [{
            type: Input
        }], applyIssuesFilter: [{
            type: Input
        }], issuesFilterMode: [{
            type: Input
        }], targetSystemData: [{
            type: Input
        }], isAdmin: [{
            type: Input
        }], uidPerson: [{
            type: Input
        }], usedInSidesheet: [{
            type: Input
        }], contextId: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DataExplorerGroupsComponent, { className: "DataExplorerGroupsComponent", filePath: "lib\\groups\\groups.component.ts", lineNumber: 78 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function AccountSidesheetComponent_ng_template_3_imx_cdr_editor_3_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 14);
    i0.ɵɵlistener("controlCreated", function AccountSidesheetComponent_ng_template_3_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.formArray.push($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r4 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r4);
} }
function AccountSidesheetComponent_ng_template_3_div_4_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 17)(1, "span", 11);
    i0.ɵɵtext(2, "#LDS#The manager assigned to this user account differs from the manager assigned to the listed identity.");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
} }
function AccountSidesheetComponent_ng_template_3_div_4_eui_alert_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 17)(1, "span", 11);
    i0.ɵɵtext(2, "#LDS#There is no manager assigned to this user account.");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
} }
function AccountSidesheetComponent_ng_template_3_div_4_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, AccountSidesheetComponent_ng_template_3_div_4_eui_alert_1_Template, 3, 2, "eui-alert", 15)(2, AccountSidesheetComponent_ng_template_3_div_4_eui_alert_2_Template, 3, 2, "eui-alert", 15);
    i0.ɵɵelementStart(3, "mat-slide-toggle", 16);
    i0.ɵɵlistener("change", function AccountSidesheetComponent_ng_template_3_div_4_Template_mat_slide_toggle_change_3_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.syncToIdentityManager($event)); });
    i0.ɵɵelementStart(4, "span", 11);
    i0.ɵɵtext(5, "#LDS#Synchronize the user account's manager with the listed identity");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.initialAccountManagerValue && (!ctx_r2.identityManagerMatchesAccountManager || ctx_r2.unsavedSyncChanges));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r2.initialAccountManagerValue);
    i0.ɵɵadvance();
    i0.ɵɵproperty("checked", ctx_r2.identityManagerMatchesAccountManager);
} }
function AccountSidesheetComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 4)(1, "mat-card", 5)(2, "form", 6);
    i0.ɵɵtemplate(3, AccountSidesheetComponent_ng_template_3_imx_cdr_editor_3_Template, 1, 1, "imx-cdr-editor", 7)(4, AccountSidesheetComponent_ng_template_3_div_4_Template, 6, 3, "div", 8);
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(5, "div", 9)(6, "button", 10)(7, "span", 11);
    i0.ɵɵtext(8, "#LDS#Download report");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(9, "button", 12);
    i0.ɵɵlistener("click", function AccountSidesheetComponent_ng_template_3_Template_button_click_9_listener() { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.cancel()); });
    i0.ɵɵelementStart(10, "span", 11);
    i0.ɵɵtext(11, "#LDS#Cancel");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(12, "button", 13);
    i0.ɵɵlistener("click", function AccountSidesheetComponent_ng_template_3_Template_button_click_12_listener() { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.save()); });
    i0.ɵɵelementStart(13, "span", 11);
    i0.ɵɵtext(14, "#LDS#Save");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("formGroup", ctx_r2.detailsFormGroup);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.cdrList);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.accountManagerIsEditable && ctx_r2.linkedIdentitiesManager && (!ctx_r2.identityManagerMatchesAccountManager || ctx_r2.unsavedSyncChanges));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("euiDownload", ctx_r2.reportDownload);
    i0.ɵɵadvance(6);
    i0.ɵɵproperty("disabled", ctx_r2.detailsFormGroup.pristine || ctx_r2.detailsFormGroup.invalid);
} }
function AccountSidesheetComponent_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 18);
    i0.ɵɵelement(1, "imx-data-explorer-groups", 19);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("usedInSidesheet", true)("unsAccountIdFilter", ctx_r2.sidesheetData.unsAccountId)("uidPerson", ctx_r2.sidesheetData.uidPerson);
} }
function AccountSidesheetComponent_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 4);
    i0.ɵɵelement(1, "imx-object-hyperview", 20);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("objectUid", ctx_r2.sidesheetData.unsAccountId);
} }
function AccountSidesheetComponent_ng_container_10_ng_template_3_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function AccountSidesheetComponent_ng_container_10_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 22)(1, "div", 23);
    i0.ɵɵtemplate(2, AccountSidesheetComponent_ng_container_10_ng_template_3_ng_container_2_Template, 1, 0, "ng-container", 24);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const tab_r6 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngComponentOutlet", tab_r6.instance);
} }
function AccountSidesheetComponent_ng_container_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "mat-tab", 21);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵtemplate(3, AccountSidesheetComponent_ng_container_10_ng_template_3_Template, 3, 1, "ng-template", 2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const tab_r6 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("imxDataProvider", ctx_r2.parameters)("label", i0.ɵɵpipeBind1(2, 2, tab_r6.inputData.label));
} }
class AccountSidesheetComponent {
    sidesheetData;
    logger;
    busyService;
    snackbar;
    sidesheetRef;
    elementalUiConfigService;
    configService;
    identitiesService;
    accountsService;
    reports;
    tabService;
    cdrFactory;
    detailsFormGroup;
    cdrList = [];
    linkedIdentitiesManager;
    unsavedSyncChanges = false;
    initialAccountManagerValue;
    reportDownload;
    neverConnectFormControl = new UntypedFormControl();
    parameters;
    dynamicTabs = [];
    constructor(formBuilder, sidesheetData, logger, busyService, snackbar, sidesheetRef, elementalUiConfigService, configService, identitiesService, accountsService, reports, tabService, cdrFactory) {
        this.sidesheetData = sidesheetData;
        this.logger = logger;
        this.busyService = busyService;
        this.snackbar = snackbar;
        this.sidesheetRef = sidesheetRef;
        this.elementalUiConfigService = elementalUiConfigService;
        this.configService = configService;
        this.identitiesService = identitiesService;
        this.accountsService = accountsService;
        this.reports = reports;
        this.tabService = tabService;
        this.cdrFactory = cdrFactory;
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.parameters = {
            objecttable: sidesheetData.unsDbObjectKey?.TableName,
            objectuid: sidesheetData.unsDbObjectKey?.Keys.join(','),
            display: this.sidesheetData.selectedAccount.GetEntity().GetDisplay(),
        };
        this.reportDownload = {
            ...this.elementalUiConfigService.Config.downloadOptions,
            url: this.reports.accountsReport(30, this.selectedAccount.GetEntity().GetKeys()[0], this.sidesheetData.tableName),
        };
    }
    ngOnInit() {
        this.setup();
    }
    cancel() {
        this.sidesheetRef.close();
    }
    async save() {
        if (this.detailsFormGroup.valid) {
            this.logger.debug(this, `Saving identity change`);
            const overlayRef = this.busyService.show();
            try {
                await this.selectedAccount.GetEntity().Commit(true);
                this.detailsFormGroup.markAsPristine();
                this.snackbar.open({ key: '#LDS#The user account has been successfully saved.' });
                this.sidesheetRef.close(true);
            }
            finally {
                this.unsavedSyncChanges = false;
                this.busyService.hide(overlayRef);
            }
        }
    }
    get selectedAccount() {
        return this.sidesheetData.selectedAccount;
    }
    get formArray() {
        return this.detailsFormGroup.get('formArray');
    }
    get identityManagerMatchesAccountManager() {
        let isMatch = false;
        const objectKeyManager = this.selectedAccount?.objectKeyManagerColumn?.GetValue();
        if (this.linkedIdentitiesManager && objectKeyManager?.length) {
            isMatch = objectKeyManager === this.linkedIdentitiesManager.ToXmlString();
        }
        return isMatch;
    }
    get accountManagerIsEditable() {
        return this.selectedAccount.objectKeyManagerColumn?.GetMetadata().CanEdit() ?? false;
    }
    async syncToIdentityManager(event) {
        const objectKeyManagerColumn = this.selectedAccount.objectKeyManagerColumn;
        if (objectKeyManagerColumn && this.linkedIdentitiesManager && event.checked) {
            await objectKeyManagerColumn.PutValue(this.linkedIdentitiesManager.ToXmlString());
            this.detailsFormGroup.markAsDirty();
            this.unsavedSyncChanges = true;
        }
    }
    async setup() {
        const cols = (await this.configService.getConfig())?.OwnershipConfig?.EditableFields?.[this.parameters.objecttable] ?? [];
        this.cdrList = this.cdrFactory.buildCdrFromColumnList(this.selectedAccount.GetEntity(), cols);
        this.dynamicTabs = (await this.tabService.getFittingComponents('accountSidesheet', (ext) => ext.inputData.checkVisibility(this.parameters))).sort((tab1, tab2) => tab1.sortOrder - tab2.sortOrder);
        this.setupIdentityManagerSync();
    }
    async setupIdentityManagerSync() {
        this.initialAccountManagerValue = this.selectedAccount.objectKeyManagerColumn?.GetValue();
        const linkedIdentityId = this.selectedAccount.uidPersonColumn?.GetValue();
        if (linkedIdentityId) {
            this.linkedIdentitiesManager = await this.getLinkedIdentitiesManager(linkedIdentityId, this.sidesheetData.unsDbObjectKey.TableName);
        }
    }
    async getLinkedIdentitiesManager(linkedIdentityId, tableName) {
        const identityData = await this.identitiesService.getPerson(linkedIdentityId);
        if (identityData?.UID_PersonHead.value) {
            const managerAccountData = await this.accountsService.getAccount({
                TableName: tableName,
                Keys: [identityData.UID_PersonHead.value],
            }, 'UID_Person');
            if (managerAccountData) {
                return new DbObjectKey(tableName, managerAccountData.GetEntity().GetKeys());
            }
        }
        return undefined;
    }
    static ɵfac = function AccountSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AccountSidesheetComponent)(i0.ɵɵdirectiveInject(i1$2.UntypedFormBuilder), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.ElementalUiConfigService), i0.ɵɵdirectiveInject(i1.ProjectConfigurationService), i0.ɵɵdirectiveInject(i1.IdentitiesService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(AccountsReportsService), i0.ɵɵdirectiveInject(i2.ExtService), i0.ɵɵdirectiveInject(i2.CdrFactoryService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AccountSidesheetComponent, selectors: [["imx-account-sidesheet"]], decls: 11, vars: 10, consts: [["mat-stretch-tabs", "false"], [3, "label"], ["matTabContent", ""], [4, "ngFor", "ngForOf"], ["eui-sidesheet-content", ""], [1, "imx-tab-card"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [4, "ngIf"], ["eui-sidesheet-actions", "", 1, "imx-sidesheet-actions__buttons-margin"], ["mat-stroked-button", "", "color", "primary", 1, "justify-start", "imx-margin-right-auto", 3, "euiDownload"], ["translate", ""], ["mat-button", "", 3, "click"], ["mat-flat-button", "", "color", "primary", 3, "click", "disabled"], [3, "controlCreated", "cdr"], ["type", "info", 3, "condensed", "colored", 4, "ngIf"], [3, "change", "checked"], ["type", "info", 3, "condensed", "colored"], ["eui-sidesheet-content", "", 1, "imx-sidesheet-content-padding-0"], ["sidesheetWidth", "55%", 3, "usedInSidesheet", "unsAccountIdFilter", "uidPerson"], ["objectType", "UNSAccount", 3, "objectUid"], [3, "imxDataProvider", "label"], ["eui-sidesheet-content", "", 1, "governance-sidesheet__tab-content"], [1, "governance-sidesheet__tab-content-body"], [4, "ngComponentOutlet"]], template: function AccountSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group", 0)(1, "mat-tab", 1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵtemplate(3, AccountSidesheetComponent_ng_template_3_Template, 15, 5, "ng-template", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-tab", 1);
            i0.ɵɵpipe(5, "translate");
            i0.ɵɵtemplate(6, AccountSidesheetComponent_ng_template_6_Template, 2, 3, "ng-template", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-tab", 1);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵtemplate(9, AccountSidesheetComponent_ng_template_9_Template, 2, 1, "ng-template", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(10, AccountSidesheetComponent_ng_container_10_Template, 4, 4, "ng-container", 3);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 4, "#LDS#Heading Main Data"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(5, 6, "#LDS#Memberships"));
            i0.ɵɵadvance(3);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(8, 8, "#LDS#Heading Hyperview"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngForOf", ctx.dynamicTabs);
        } }, dependencies: [i7.NgComponentOutlet, i7.NgForOf, i7.NgIf, i1$2.ɵNgNoValidate, i1$2.NgControlStatusGroup, DataExplorerGroupsComponent, i1$2.FormGroupDirective, i1$1.EuiAlertComponent, i1$1.EuiDownloadDirective, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i8.MatButton, i9$1.MatCard, i11$1.MatSlideToggle, i10$1.MatTabContent, i10$1.MatTab, i10$1.MatTabGroup, i2.CdrEditorComponent, i1.ObjectHyperviewComponent, i7$1.TranslateDirective, i2.DynamicTabDataProviderDirective, i7$1.TranslatePipe], styles: [".imx-entitlements-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column}.mat-mdc-checkbox[_ngcontent-%COMP%]{display:flex;margin-bottom:15px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountSidesheetComponent, [{
        type: Component,
        args: [{ selector: 'imx-account-sidesheet', template: "<mat-tab-group mat-stretch-tabs=\"false\">\n  <mat-tab [label]=\"'#LDS#Heading Main Data' | translate\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <mat-card class=\"imx-tab-card\">\n          <form [formGroup]=\"detailsFormGroup\">\n            <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"formArray.push($event)\"> </imx-cdr-editor>\n            <div\n              *ngIf=\"accountManagerIsEditable && linkedIdentitiesManager && (!identityManagerMatchesAccountManager || unsavedSyncChanges)\"\n            >\n              <eui-alert\n                type=\"info\"\n                [condensed]=\"true\"\n                [colored]=\"true\"\n                *ngIf=\"initialAccountManagerValue && (!identityManagerMatchesAccountManager || unsavedSyncChanges)\"\n              >\n                <span translate\n                  >#LDS#The manager assigned to this user account differs from the manager assigned to the listed identity.</span\n                >\n              </eui-alert>\n              <eui-alert type=\"info\" [condensed]=\"true\" [colored]=\"true\" *ngIf=\"!initialAccountManagerValue\">\n                <span translate>#LDS#There is no manager assigned to this user account.</span>\n              </eui-alert>\n              <mat-slide-toggle [checked]=\"identityManagerMatchesAccountManager\" (change)=\"syncToIdentityManager($event)\">\n                <span translate>#LDS#Synchronize the user account's manager with the listed identity</span>\n              </mat-slide-toggle>\n            </div>\n          </form>\n        </mat-card>\n      </div>\n      <div eui-sidesheet-actions class=\"imx-sidesheet-actions__buttons-margin\">\n        <button mat-stroked-button color=\"primary\" [euiDownload]=\"reportDownload\" class=\"justify-start imx-margin-right-auto\">\n          <span translate>#LDS#Download report</span>\n        </button>\n        <button mat-button (click)=\"cancel()\">\n          <span translate>#LDS#Cancel</span>\n        </button>\n        <button mat-flat-button color=\"primary\" (click)=\"save()\" [disabled]=\"detailsFormGroup.pristine || detailsFormGroup.invalid\">\n          <span translate>#LDS#Save</span>\n        </button>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab [label]=\"'#LDS#Memberships' | translate\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content class=\"imx-sidesheet-content-padding-0\">\n        <imx-data-explorer-groups\n          [usedInSidesheet]=\"true\"\n          [unsAccountIdFilter]=\"sidesheetData.unsAccountId\"\n          [uidPerson]=\"sidesheetData.uidPerson\"\n          sidesheetWidth=\"55%\"\n        >\n        </imx-data-explorer-groups>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab label=\"{{ '#LDS#Heading Hyperview' | translate }}\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <imx-object-hyperview objectType=\"UNSAccount\" [objectUid]=\"sidesheetData.unsAccountId\"></imx-object-hyperview>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <ng-container *ngFor=\"let tab of dynamicTabs\">\n    <mat-tab [imxDataProvider]=\"parameters\" [label]=\"tab.inputData.label | translate\">\n      <ng-template matTabContent>\n        <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\n          <div class=\"governance-sidesheet__tab-content-body\">\n            <ng-container *ngComponentOutlet=\"tab.instance\"></ng-container>\n          </div>\n        </div>\n      </ng-template>\n    </mat-tab>\n  </ng-container>\n</mat-tab-group>\n", styles: [".imx-entitlements-card{flex:1 1 auto;display:flex;flex-direction:column}.mat-mdc-checkbox{display:flex;margin-bottom:15px}\n"] }]
    }], () => [{ type: i1$2.UntypedFormBuilder }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i2.ClassloggerService }, { type: i1$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i1$1.EuiSidesheetRef }, { type: i2.ElementalUiConfigService }, { type: i1.ProjectConfigurationService }, { type: i1.IdentitiesService }, { type: AccountsService }, { type: AccountsReportsService }, { type: i2.ExtService }, { type: i2.CdrFactoryService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AccountSidesheetComponent, { className: "AccountSidesheetComponent", filePath: "lib\\accounts\\account-sidesheet\\account-sidesheet.component.ts", lineNumber: 52 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function TargetSystemReportComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-alert", 7);
    i0.ɵɵlistener("dismissed", function TargetSystemReportComponent_eui_alert_1_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onHelperDismissed()); });
    i0.ɵɵelementStart(1, "div", 8);
    i0.ɵɵtext(2, "#LDS#Select a target system. All user accounts of this target system will be included in the report.");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
} }
function TargetSystemReportComponent_imx_data_tree_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-data-tree", 9, 0);
    i0.ɵɵlistener("nodeSelected", function TargetSystemReportComponent_imx_data_tree_3_Template_imx_data_tree_nodeSelected_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onNodeSelected($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("withSelectedNodeHighlight", true)("hideSelection", true)("withMultiSelect", false)("database", ctx_r1.database);
} }
class TargetSystemReportComponent {
    busyService;
    entityWrapper;
    accountsService;
    accountReport;
    elementalUiConfigService;
    http;
    injector;
    overlay;
    downloadService;
    showHelperAlert = true;
    database;
    selectedEntity;
    constructor(busyService, entityWrapper, accountsService, accountReport, elementalUiConfigService, http, injector, overlay, downloadService) {
        this.busyService = busyService;
        this.entityWrapper = entityWrapper;
        this.accountsService = accountsService;
        this.accountReport = accountReport;
        this.elementalUiConfigService = elementalUiConfigService;
        this.http = http;
        this.injector = injector;
        this.overlay = overlay;
        this.downloadService = downloadService;
    }
    async ngOnInit() {
        this.database = new FilterTreeDatabase(this.entityWrapper, async (parentkey) => {
            return this.accountsService.getFilterTree({
                parentkey,
                filter: undefined,
            });
        }, this.busyService);
    }
    onHelperDismissed() {
        this.showHelperAlert = false;
    }
    onNodeSelected(entity) {
        this.selectedEntity = entity;
    }
    loadReport() {
        let url;
        const val = this.selectedEntity?.GetColumn('Filter')?.GetValue();
        if (!val) {
            return;
        }
        const columnName = val.ColumnName;
        if (columnName === 'UID_UNSRoot') {
            url = this.accountReport.accountsByRootReport(30, val.Value1);
        }
        else if (columnName === 'UID_UNSContainer') {
            url = this.accountReport.accountsByContainerReport(30, val.Value1);
        }
        else {
            return;
        }
        const directive = new EuiDownloadDirective(new ElementRef('') /* no element */, this.http, this.overlay, this.injector, this.downloadService);
        if (directive && url !== '') {
            directive.downloadOptions = {
                ...this.elementalUiConfigService.Config.downloadOptions,
                url,
                fileName: `${this.selectedEntity.GetDisplay()}.pdf`,
                disableElement: false,
            };
            directive.onClick();
        }
    }
    static ɵfac = function TargetSystemReportComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TargetSystemReportComponent)(i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.FilterTreeEntityWrapperService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(AccountsReportsService), i0.ɵɵdirectiveInject(i2.ElementalUiConfigService), i0.ɵɵdirectiveInject(i5.HttpClient), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i6$2.Overlay), i0.ɵɵdirectiveInject(i1$1.EuiDownloadService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TargetSystemReportComponent, selectors: [["imx-target-system-report"]], decls: 8, vars: 6, consts: [["tree", ""], ["eui-sidesheet-content", ""], ["type", "info", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [1, "imx-content-card"], ["data-imx-identifier", "target-system-report-data-tree", 3, "withSelectedNodeHighlight", "hideSelection", "withMultiSelect", "database", "nodeSelected", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["color", "primary", "mat-flat-button", "", 3, "click", "disabled"], ["type", "info", 3, "dismissed", "condensed", "colored", "dismissable"], ["translate", ""], ["data-imx-identifier", "target-system-report-data-tree", 3, "nodeSelected", "withSelectedNodeHighlight", "hideSelection", "withMultiSelect", "database"]], template: function TargetSystemReportComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵtemplate(1, TargetSystemReportComponent_eui_alert_1_Template, 3, 3, "eui-alert", 2);
            i0.ɵɵelementStart(2, "mat-card", 3);
            i0.ɵɵtemplate(3, TargetSystemReportComponent_imx_data_tree_3_Template, 2, 4, "imx-data-tree", 4);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(4, "div", 5)(5, "button", 6);
            i0.ɵɵlistener("click", function TargetSystemReportComponent_Template_button_click_5_listener() { return ctx.loadReport(); });
            i0.ɵɵtext(6);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showHelperAlert);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.database);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.selectedEntity == null);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 4, "#LDS#Download report"), " ");
        } }, dependencies: [i7.NgIf, i1$1.EuiAlertComponent, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i8.MatButton, i9$1.MatCard, i7$1.TranslateDirective, i2.DataTreeComponent, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{overflow:hidden;display:flex}.imx-content-card[_ngcontent-%COMP%]{margin-top:10px;flex:1 1 auto;overflow:auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TargetSystemReportComponent, [{
        type: Component,
        args: [{ selector: 'imx-target-system-report', template: "<div eui-sidesheet-content>\n  <eui-alert *ngIf=\"showHelperAlert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"true\" (dismissed)=\"onHelperDismissed()\">\n    <div translate>#LDS#Select a target system. All user accounts of this target system will be included in the report.</div>\n  </eui-alert>\n  <mat-card class=\"imx-content-card\">\n    <imx-data-tree\n      [withSelectedNodeHighlight]=\"true\"\n      data-imx-identifier=\"target-system-report-data-tree\"\n      #tree\n      [hideSelection]=\"true\"\n      *ngIf=\"database\"\n      [withMultiSelect]=\"false\"\n      [database]=\"database\"\n      (nodeSelected)=\"onNodeSelected($event)\"\n    >\n    </imx-data-tree>\n  </mat-card>\n</div>\n<div eui-sidesheet-actions>\n  <button [disabled]=\"selectedEntity == null\" color=\"primary\" mat-flat-button (click)=\"loadReport()\">\n    {{ '#LDS#Download report' | translate }}\n  </button>\n</div>\n", styles: [":host{overflow:hidden;display:flex}.imx-content-card{margin-top:10px;flex:1 1 auto;overflow:auto}\n"] }]
    }], () => [{ type: i1$1.EuiLoadingService }, { type: i2.FilterTreeEntityWrapperService }, { type: AccountsService }, { type: AccountsReportsService }, { type: i2.ElementalUiConfigService }, { type: i5.HttpClient }, { type: i0.Injector }, { type: i6$2.Overlay }, { type: i1$1.EuiDownloadService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TargetSystemReportComponent, { className: "TargetSystemReportComponent", filePath: "lib\\accounts\\target-system-report\\target-system-report.component.ts", lineNumber: 42 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function DataExplorerAccountsComponent_th_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 21);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchemaUnsAccount == null ? null : ctx_r0.entitySchemaUnsAccount.Columns == null ? null : ctx_r0.entitySchemaUnsAccount.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME] == null ? null : ctx_r0.entitySchemaUnsAccount.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME].Display, " ");
} }
function DataExplorerAccountsComponent_td_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22)(1, "div", 23);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("max-width", "500px");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r2.GetEntity().GetDisplay());
} }
function DataExplorerAccountsComponent_th_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 24);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchemaUnsAccount == null ? null : ctx_r0.entitySchemaUnsAccount.Columns == null ? null : ctx_r0.entitySchemaUnsAccount.Columns.UID_Person == null ? null : ctx_r0.entitySchemaUnsAccount.Columns.UID_Person.Display, " ");
} }
function DataExplorerAccountsComponent_td_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22)(1, "div", 23);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("max-width", "300px");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", item_r3.UID_Person.Column.GetDisplayValue(), " ");
} }
function DataExplorerAccountsComponent_th_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 25);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.entitySchemaUnsAccount == null ? null : ctx_r0.entitySchemaUnsAccount.Columns == null ? null : ctx_r0.entitySchemaUnsAccount.Columns.AccountDisabled == null ? null : ctx_r0.entitySchemaUnsAccount.Columns.AccountDisabled.Display);
} }
function DataExplorerAccountsComponent_td_18_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22)(1, "div", 23);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4.AccountDisabled.Column.GetDisplayValue());
} }
function DataExplorerAccountsComponent_th_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 26);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.entitySchemaUnsAccount == null ? null : ctx_r0.entitySchemaUnsAccount.Columns == null ? null : ctx_r0.entitySchemaUnsAccount.Columns.UID_UNSRoot == null ? null : ctx_r0.entitySchemaUnsAccount.Columns.UID_UNSRoot.Display);
} }
function DataExplorerAccountsComponent_td_21_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 27)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 28);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r5.UID_UNSRoot.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r5.UID_DPRNameSpace.Column.GetDisplayValue());
} }
function DataExplorerAccountsComponent_th_23_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "th", 25);
} }
function DataExplorerAccountsComponent_td_24_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "eui-badge", 30);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r6 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r6.XMarkedForDeletion.Column.GetDisplayValue());
} }
function DataExplorerAccountsComponent_td_24_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22);
    i0.ɵɵtemplate(1, DataExplorerAccountsComponent_td_24_div_1_Template, 3, 1, "div", 29);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r6.XMarkedForDeletion.value !== 0);
} }
class DataExplorerAccountsComponent {
    translateProvider;
    sideSheet;
    logger;
    accountsService;
    dataHelper;
    viewConfigService;
    settingsService;
    busyServiceElemental;
    dataSource;
    /**
     * Page size, start index, search and filtering options etc.
     */
    navigationState;
    filterOptions = [];
    treeDbWrapper;
    entitySchemaUnsAccount;
    DisplayColumns = DisplayColumns;
    data;
    busyService = new BusyService();
    contextId = HELP_CONTEXTUAL.DataExplorerAccounts;
    displayedColumns = [];
    authorityDataDeleted$;
    tableName = computed(() => this.dataSource.collectionData().tableName || '');
    dataModel;
    viewConfigPath = 'targetsystem/uns/account';
    viewConfig;
    constructor(translateProvider, sideSheet, logger, accountsService, dataHelper, viewConfigService, settingsService, busyServiceElemental, dataSource) {
        this.translateProvider = translateProvider;
        this.sideSheet = sideSheet;
        this.logger = logger;
        this.accountsService = accountsService;
        this.dataHelper = dataHelper;
        this.viewConfigService = viewConfigService;
        this.settingsService = settingsService;
        this.busyServiceElemental = busyServiceElemental;
        this.dataSource = dataSource;
        this.navigationState = { PageSize: settingsService.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaUnsAccount = accountsService.accountSchema;
        this.authorityDataDeleted$ = this.dataHelper.authorityDataDeleted.subscribe(() => this.dataSource.updateState());
        this.treeDbWrapper = new ContainerTreeDatabaseWrapper(this.busyService, dataHelper);
    }
    async ngOnInit() {
        /** if you like to add columns, please check {@link AccountsExtComponent | Account Extension Component} as well */
        this.displayedColumns = [
            this.entitySchemaUnsAccount.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchemaUnsAccount.Columns.UID_Person,
            this.entitySchemaUnsAccount.Columns.UID_UNSRoot,
            this.entitySchemaUnsAccount.Columns.AccountDisabled,
            this.entitySchemaUnsAccount.Columns.XMarkedForDeletion,
        ];
        const isBusy = this.busyService.beginBusy();
        try {
            this.dataModel = await this.accountsService.getDataModel();
            this.viewConfig = await this.viewConfigService.getInitialDSTExtension(this.dataModel, this.viewConfigPath);
            const dataViewInitParameters = {
                execute: (params, signal) => this.accountsService.getAccounts(params, signal),
                schema: this.entitySchemaUnsAccount,
                columnsToDisplay: this.displayedColumns,
                dataModel: this.dataModel,
                exportFunction: this.accountsService.exportAccounts(),
                viewConfig: this.viewConfig,
                highlightEntity: (identity) => {
                    this.onAccountChanged(identity);
                },
                filterTree: {
                    filterMethode: async (parentkey) => {
                        return this.accountsService.getFilterTree({
                            parentkey,
                            filter: this.dataSource.state().filter,
                        });
                    },
                    multiSelect: false,
                },
            };
            this.dataSource.init(dataViewInitParameters);
        }
        finally {
            isBusy.endBusy();
        }
    }
    ngOnDestroy() {
        if (this.authorityDataDeleted$) {
            this.authorityDataDeleted$.unsubscribe();
        }
    }
    async updateConfig(config) {
        await this.viewConfigService.putViewConfig(config);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    async deleteConfigById(id) {
        await this.viewConfigService.deleteViewConfig(id);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    async onAccountChanged(unsAccount) {
        this.logger.debug(this, `Selected UNS account changed`);
        this.logger.trace(this, `New UNS account selected`, unsAccount);
        let data;
        const hideOverlayRef = this.busyServiceElemental.show();
        try {
            const unsDbObjectKey = DbObjectKey.FromXml(unsAccount.GetEntity().GetColumn('XObjectKey').GetValue());
            data = {
                unsAccountId: unsAccount.GetEntity().GetColumn('UID_UNSAccount').GetValue(),
                unsDbObjectKey,
                selectedAccount: await this.accountsService.getAccountInteractive(unsDbObjectKey, 'UID_UNSAccount'),
                uidPerson: unsAccount.GetEntity().GetColumn('UID_Person').GetValue(),
                tableName: this.tableName(),
            };
        }
        finally {
            this.busyServiceElemental.hide(hideOverlayRef);
        }
        await this.viewAccount(data);
    }
    async openReportOptionsSidesheet() {
        this.sideSheet.open(TargetSystemReportComponent, {
            title: await this.translateProvider.get('#LDS#Heading Download Target System Report').toPromise(),
            icon: 'download',
            padding: '0px',
            width: calculateSidesheetWidth(700, 0.4),
            testId: 'accounts-report-sidesheet',
        });
    }
    async viewAccount(data) {
        this.logger.debug(this, `Viewing account`);
        this.logger.trace(this, `Account selected`, data.selectedAccount);
        const sidesheetRef = this.sideSheet.open(AccountSidesheetComponent, {
            title: await this.translateProvider.get('#LDS#Heading Edit User Account').toPromise(),
            subTitle: data.selectedAccount.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(),
            icon: 'account',
            testId: 'edit-user-account-sidesheet',
            data,
        });
        sidesheetRef.afterClosed().subscribe((dataRefreshRequired) => {
            if (dataRefreshRequired) {
                this.dataSource.updateState();
            }
        });
    }
    static ɵfac = function DataExplorerAccountsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DataExplorerAccountsComponent)(i0.ɵɵdirectiveInject(i7$1.TranslateService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(DeHelperService), i0.ɵɵdirectiveInject(i1.ViewConfigService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataExplorerAccountsComponent, selectors: [["imx-data-explorer-accounts"]], features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 31, vars: 14, consts: [[1, "data-explorer", "data-explorer--accounts"], [1, "imx-card-data-explorer-header"], [1, "imx-card-data-explorer-header-bg"], ["translate", ""], [3, "contextId"], [3, "updateConfig", "deleteConfigById", "dataSource"], [1, "imx-data-explorer-content"], [1, "data-explorer-table"], ["mode", "manual", "matSort", "", 3, "matSortChange", "dataSource", "matSortActive", "matSortDirection"], [3, "matColumnDef"], ["mat-header-cell", "", "width", "500px", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], ["mat-header-cell", "", "width", "300px", 4, "matHeaderCellDef"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], ["alignHeader", "center", "alignContent", "center", 3, "matColumnDef"], [3, "dataSource"], [1, "imx-button-bar-transparent"], ["mat-stroked-button", "", "data-imx-identifier", "accounts-button-show-report-for-targetsystem", 3, "click"], ["icon", "reports"], ["mat-header-cell", "", "width", "500px"], ["mat-cell", "", "role", "gridcell"], [1, "imx-ellipse-column"], ["mat-header-cell", "", "width", "300px"], ["mat-header-cell", "", "mat-sort-header", ""], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], ["subtitle", ""], [4, "ngIf"], ["color", "gray"]], template: function DataExplorerAccountsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card", 0)(1, "div", 1)(2, "div", 2)(3, "h3", 3);
            i0.ɵɵtext(4, "#LDS#Heading User Accounts");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(5, "imx-help-contextual", 4);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(6, "imx-data-view-toolbar", 5);
            i0.ɵɵlistener("updateConfig", function DataExplorerAccountsComponent_Template_imx_data_view_toolbar_updateConfig_6_listener($event) { return ctx.updateConfig($event); })("deleteConfigById", function DataExplorerAccountsComponent_Template_imx_data_view_toolbar_deleteConfigById_6_listener($event) { return ctx.deleteConfigById($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div", 6)(8, "div", 7)(9, "imx-data-view-auto-table", 8);
            i0.ɵɵlistener("matSortChange", function DataExplorerAccountsComponent_Template_imx_data_view_auto_table_matSortChange_9_listener($event) { return ctx.dataSource == null ? null : ctx.dataSource.sortChange($event); });
            i0.ɵɵelementContainerStart(10, 9);
            i0.ɵɵtemplate(11, DataExplorerAccountsComponent_th_11_Template, 2, 1, "th", 10)(12, DataExplorerAccountsComponent_td_12_Template, 3, 3, "td", 11);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(13, 9);
            i0.ɵɵtemplate(14, DataExplorerAccountsComponent_th_14_Template, 2, 1, "th", 12)(15, DataExplorerAccountsComponent_td_15_Template, 3, 3, "td", 11);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(16, 9);
            i0.ɵɵtemplate(17, DataExplorerAccountsComponent_th_17_Template, 2, 1, "th", 13)(18, DataExplorerAccountsComponent_td_18_Template, 3, 1, "td", 11);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(19, 9);
            i0.ɵɵtemplate(20, DataExplorerAccountsComponent_th_20_Template, 2, 1, "th", 14)(21, DataExplorerAccountsComponent_td_21_Template, 5, 2, "td", 15);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(22, 16);
            i0.ɵɵtemplate(23, DataExplorerAccountsComponent_th_23_Template, 1, 0, "th", 13)(24, DataExplorerAccountsComponent_td_24_Template, 2, 1, "td", 11);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd();
            i0.ɵɵelement(25, "imx-data-view-paginator", 17);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(26, "div", 18)(27, "button", 19);
            i0.ɵɵlistener("click", function DataExplorerAccountsComponent_Template_button_click_27_listener() { return ctx.openReportOptionsSidesheet(); });
            i0.ɵɵelement(28, "eui-icon", 20);
            i0.ɵɵtext(29);
            i0.ɵɵpipe(30, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("contextId", ctx.contextId);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("matSortActive", ctx.dataSource.sortId())("matSortDirection", ctx.dataSource.sortDirection());
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.DisplayColumns.DISPLAY_PROPERTYNAME);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchemaUnsAccount.Columns.UID_Person.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchemaUnsAccount.Columns.AccountDisabled.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchemaUnsAccount.Columns.UID_UNSRoot.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchemaUnsAccount.Columns.XMarkedForDeletion.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(30, 12, "#LDS#Download target system report"), " ");
        } }, dependencies: [i7.NgIf, i1$1.EuiBadgeComponent, i1$1.EuiIconComponent, i8.MatButton, i9$1.MatCard, i12.MatSort, i12.MatSortHeader, i8$1.MatHeaderCellDef, i8$1.MatColumnDef, i8$1.MatCellDef, i8$1.MatHeaderCell, i8$1.MatCell, i7$1.TranslateDirective, i2.HelpContextualComponent, i2.DataViewAutoTableComponent, i2.DataViewPaginatorComponent, i2.DataViewToolbarComponent, i7$1.TranslatePipe], styles: [".data-explorer.data-explorer--accounts[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:nth-child(2){flex:0 0 auto}.data-explorer.data-explorer--accounts[_ngcontent-%COMP%]   .imx-data-explorer-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.eui-dark-theme   [_nghost-%COMP%]{background-color:#2f3233}div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}.imx-ellipse-column[_ngcontent-%COMP%]{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.hidden[_ngcontent-%COMP%]{display:none}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataExplorerAccountsComponent, [{
        type: Component,
        args: [{ selector: 'imx-data-explorer-accounts', providers: [DataViewSource], template: "<mat-card class=\"data-explorer data-explorer--accounts\">\n  <div class=\"imx-card-data-explorer-header\">\n    <div class=\"imx-card-data-explorer-header-bg\">\n      <h3 translate>#LDS#Heading User Accounts</h3>\n      <imx-help-contextual [contextId]=\"contextId\"></imx-help-contextual>\n    </div>\n  </div>\n  <imx-data-view-toolbar\n    [dataSource]=\"dataSource\"\n    (updateConfig)=\"updateConfig($event)\"\n    (deleteConfigById)=\"deleteConfigById($event)\"\n  ></imx-data-view-toolbar>\n  <div class=\"imx-data-explorer-content\">\n    <div class=\"data-explorer-table\">\n      <imx-data-view-auto-table\n        [dataSource]=\"dataSource\"\n        mode=\"manual\"\n        matSort\n        (matSortChange)=\"dataSource?.sortChange($event)\"\n        [matSortActive]=\"dataSource.sortId()\"\n        [matSortDirection]=\"dataSource.sortDirection()\"\n      >\n        <ng-container [matColumnDef]=\"this.DisplayColumns.DISPLAY_PROPERTYNAME\">\n          <th mat-header-cell *matHeaderCellDef width=\"500px\">\n            {{ entitySchemaUnsAccount?.Columns?.[this.DisplayColumns.DISPLAY_PROPERTYNAME]?.Display }}\n          </th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <div [style.max-width]=\"'500px'\" class=\"imx-ellipse-column\">{{ item.GetEntity().GetDisplay() }}</div>\n          </td>\n        </ng-container>\n        <ng-container [matColumnDef]=\"entitySchemaUnsAccount.Columns.UID_Person.ColumnName\">\n          <th mat-header-cell *matHeaderCellDef width=\"300px\">\n            {{ entitySchemaUnsAccount?.Columns?.UID_Person?.Display }}\n          </th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <div [style.max-width]=\"'300px'\" class=\"imx-ellipse-column\">\n              {{ item.UID_Person.Column.GetDisplayValue() }}\n            </div>\n          </td>\n        </ng-container>\n        <ng-container [matColumnDef]=\"entitySchemaUnsAccount.Columns.AccountDisabled.ColumnName\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{ entitySchemaUnsAccount?.Columns?.AccountDisabled?.Display }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <div class=\"imx-ellipse-column\">{{ item.AccountDisabled.Column.GetDisplayValue() }}</div>\n          </td>\n        </ng-container>\n        <ng-container [matColumnDef]=\"entitySchemaUnsAccount.Columns.UID_UNSRoot.ColumnName\">\n          <th mat-header-cell *matHeaderCellDef>{{ entitySchemaUnsAccount?.Columns?.UID_UNSRoot?.Display }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n            <div>{{ item.UID_UNSRoot.Column.GetDisplayValue() }}</div>\n            <div subtitle>{{ item.UID_DPRNameSpace.Column.GetDisplayValue() }}</div>\n          </td>\n        </ng-container>\n        <ng-container\n          [matColumnDef]=\"entitySchemaUnsAccount.Columns.XMarkedForDeletion.ColumnName\"\n          alignHeader=\"center\"\n          alignContent=\"center\"\n        >\n          <th mat-header-cell *matHeaderCellDef mat-sort-header></th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <div *ngIf=\"item.XMarkedForDeletion.value !== 0\">\n              <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\n            </div>\n          </td>\n        </ng-container>\n      </imx-data-view-auto-table>\n      <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n    </div>\n  </div>\n</mat-card>\n<div class=\"imx-button-bar-transparent\">\n  <button mat-stroked-button data-imx-identifier=\"accounts-button-show-report-for-targetsystem\" (click)=\"openReportOptionsSidesheet()\">\n    <eui-icon icon=\"reports\"></eui-icon>\n    {{ '#LDS#Download target system report' | translate }}\n  </button>\n</div>\n", styles: [".data-explorer.data-explorer--accounts>:nth-child(2){flex:0 0 auto}.data-explorer.data-explorer--accounts .imx-data-explorer-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.eui-dark-theme :host{background-color:#2f3233}div[subtitle]{font-size:smaller;color:#919799}.imx-ellipse-column{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.hidden{display:none}.eui-contrast-theme :host{background-color:#000}\n"] }]
    }], () => [{ type: i7$1.TranslateService }, { type: i1$1.EuiSidesheetService }, { type: i2.ClassloggerService }, { type: AccountsService }, { type: DeHelperService }, { type: i1.ViewConfigService }, { type: i2.SettingsService }, { type: i1$1.EuiLoadingService }, { type: i2.DataViewSource }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DataExplorerAccountsComponent, { className: "DataExplorerAccountsComponent", filePath: "lib\\accounts\\accounts.component.ts", lineNumber: 69 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isTsbNameSpaceAdminBase(groups) {
    return groups.find((item) => item && item.toUpperCase() === 'TSB_4_NAMESPACEADMIN_BASE') != null;
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GroupMembershipsExtService {
    apiService;
    constructor(apiService) {
        this.apiService = apiService;
    }
    get portalPersonGroupmembershipsSchema() {
        return this.apiService.typedClient.PortalPersonGroupmemberships.GetSchema();
    }
    getGroupMemberships(uid, parameters, signal) {
        return this.apiService.typedClient.PortalPersonGroupmemberships.Get(uid, parameters, { signal });
    }
    static ɵfac = function GroupMembershipsExtService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GroupMembershipsExtService)(i0.ɵɵinject(TsbApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: GroupMembershipsExtService, factory: GroupMembershipsExtService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupMembershipsExtService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: TsbApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _forTrack0 = ($index, $item) => $item.ColumnName;
function GroupMembershipsExtComponent_th_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 8);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME] == null ? null : ctx_r0.entitySchema.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME].Display, " ");
} }
function GroupMembershipsExtComponent_td_9_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 12);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Not effective"));
} }
function GroupMembershipsExtComponent_td_9_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 13);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", item_r2.GetEntity().GetDisplayLong(), " ");
} }
function GroupMembershipsExtComponent_td_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 9)(1, "div", 10)(2, "div", 11);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, GroupMembershipsExtComponent_td_9_Conditional_4_Template, 3, 3, "eui-badge", 12);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(5, GroupMembershipsExtComponent_td_9_Conditional_5_Template, 2, 1, "div", 13);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(item_r2.GetEntity().GetDisplay());
    i0.ɵɵadvance();
    i0.ɵɵconditional((item_r2.XIsInEffect == null ? null : item_r2.XIsInEffect.value) !== true ? 4 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r2.GetEntity().GetDisplay() !== item_r2.GetEntity().GetDisplayLong() ? 5 : -1);
} }
function GroupMembershipsExtComponent_For_11_th_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 8);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const column_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(column_r3.Display);
} }
function GroupMembershipsExtComponent_For_11_td_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_12_0;
    const item_r4 = ctx.$implicit;
    const column_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", (tmp_12_0 = item_r4.GetEntity().GetColumn(column_r3.ColumnName)) == null ? null : tmp_12_0.GetDisplayValue(), " ");
} }
function GroupMembershipsExtComponent_For_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0, 4);
    i0.ɵɵtemplate(1, GroupMembershipsExtComponent_For_11_th_1_Template, 2, 1, "th", 5)(2, GroupMembershipsExtComponent_For_11_td_2_Template, 2, 1, "td", 14);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const column_r3 = ctx.$implicit;
    i0.ɵɵproperty("matColumnDef", column_r3.ColumnName);
} }
class GroupMembershipsExtComponent {
    groupService;
    translate;
    sidesheet;
    dataSource;
    referrer;
    dstSettings;
    DisplayColumns = DisplayColumns;
    entitySchema;
    displayColumns = [];
    displayedColumnsWithDisplay = [];
    navigationState;
    busyService = new BusyService();
    constructor(groupService, translate, sidesheet, dataProvider, dataSource) {
        this.groupService = groupService;
        this.translate = translate;
        this.sidesheet = sidesheet;
        this.dataSource = dataSource;
        this.referrer = dataProvider?.data;
        this.entitySchema = groupService.portalPersonGroupmembershipsSchema;
        this.displayColumns = [
            this.entitySchema.Columns?.XOrigin,
            this.entitySchema.Columns.XDateInserted,
            this.entitySchema.Columns.OrderState,
            this.entitySchema.Columns.ValidUntil,
        ];
        this.displayedColumnsWithDisplay = [this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME], ...this.displayColumns];
    }
    async ngOnInit() {
        return this.getData();
    }
    async onShowDetails(entity) {
        const unsGroupId = DbObjectKey.FromXml(entity.GetEntity().GetColumn('ObjectKeyGroup').GetValue());
        const data = {
            UID_Person: this.referrer.objectuid,
            Type: SourceDetectiveType.MembershipOfSystemEntitlement,
            UID: unsGroupId.Keys[0],
            TableName: unsGroupId.TableName,
        };
        this.sidesheet.open(SourceDetectiveSidesheetComponent, {
            title: await this.translate.get('#LDS#Heading View Assignment Analysis').toPromise(),
            subTitle: entity.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(800, 0.5),
            disableClose: false,
            testId: 'group-membership-assingment-analysis',
            data,
        });
    }
    async getData() {
        const isBusy = this.busyService.beginBusy();
        try {
            const dataViewInitParameters = {
                execute: (params, signal) => {
                    return this.groupService.getGroupMemberships(this.referrer.objectuid, params, signal);
                },
                schema: this.entitySchema,
                columnsToDisplay: this.displayedColumnsWithDisplay,
                highlightEntity: (identity) => {
                    this.onShowDetails(identity);
                },
            };
            await this.dataSource.init(dataViewInitParameters);
        }
        finally {
            isBusy.endBusy();
        }
    }
    static ɵfac = function GroupMembershipsExtComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GroupMembershipsExtComponent)(i0.ɵɵdirectiveInject(GroupMembershipsExtService), i0.ɵɵdirectiveInject(i7$1.TranslateService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.DynamicTabDataProviderDirective), i0.ɵɵdirectiveInject(i2.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GroupMembershipsExtComponent, selectors: [["ng-component"]], inputs: { referrer: "referrer" }, features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 13, vars: 15, consts: [["type", "info", 1, "imx-margin-top-20", 3, "condensed", "colored", "dismissable"], [1, "imx-memberships"], [3, "dataSource", "showSettings"], ["mode", "manual", 3, "dataSource", "noDataText", "noDataIcon"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], [3, "dataSource"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], [1, "fill-cell"], ["data-imx-identifier", "group-memberships-ext-tabledata-display"], ["color", "primary", 1, "imx-margin-left-auto"], ["subtitle", ""], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], ["mat-cell", "", "role", "gridcell"]], template: function GroupMembershipsExtComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "eui-alert", 0);
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card", 1);
            i0.ɵɵelement(4, "imx-data-view-toolbar", 2);
            i0.ɵɵelementStart(5, "imx-data-view-auto-table", 3);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementContainerStart(7, 4);
            i0.ɵɵtemplate(8, GroupMembershipsExtComponent_th_8_Template, 2, 1, "th", 5)(9, GroupMembershipsExtComponent_td_9_Template, 6, 3, "td", 6);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵrepeaterCreate(10, GroupMembershipsExtComponent_For_11_Template, 3, 1, "ng-container", 4, _forTrack0);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(12, "imx-data-view-paginator", 7);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", false);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 11, "#LDS#Here you can get an overview of the memberships of the identity. Additionally, you can view the assignment analysis for each membership."), "\n");
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("showSettings", false);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource)("noDataText", i0.ɵɵpipeBind1(6, 13, "#LDS#No data"))("noDataIcon", "table");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("matColumnDef", ctx.DisplayColumns.DISPLAY_PROPERTYNAME);
            i0.ɵɵadvance(3);
            i0.ɵɵrepeater(ctx.displayColumns);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
        } }, dependencies: [i1$1.EuiAlertComponent, i1$1.EuiBadgeComponent, i9$1.MatCard, i8$1.MatHeaderCellDef, i8$1.MatColumnDef, i8$1.MatCellDef, i8$1.MatHeaderCell, i8$1.MatCell, i2.DataViewAutoTableComponent, i2.DataViewPaginatorComponent, i2.DataViewToolbarComponent, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-memberships[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-membership-table[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;margin-top:20px}.fill-cell[_ngcontent-%COMP%]{width:100%;display:flex;flex-direction:row}.fill-cell[_ngcontent-%COMP%]   eui-badge[_ngcontent-%COMP%]{align-self:flex-end}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupMembershipsExtComponent, [{
        type: Component,
        args: [{ providers: [DataViewSource], template: "<eui-alert class=\"imx-margin-top-20\" [condensed]=\"true\" [colored]=\"true\" type=\"info\" [dismissable]=\"false\">\n  {{\n    '#LDS#Here you can get an overview of the memberships of the identity. Additionally, you can view the assignment analysis for each membership.'\n      | translate\n  }}\n</eui-alert>\n<mat-card class=\"imx-memberships\">\n  <imx-data-view-toolbar [dataSource]=\"dataSource\" [showSettings]=\"false\"></imx-data-view-toolbar>\n  <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\" [noDataText]=\"'#LDS#No data' | translate\" [noDataIcon]=\"'table'\">\n    <ng-container [matColumnDef]=\"DisplayColumns.DISPLAY_PROPERTYNAME\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ entitySchema?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n        <div class=\"fill-cell\">\n          <div data-imx-identifier=\"group-memberships-ext-tabledata-display\">{{ item.GetEntity().GetDisplay() }}</div>\n          @if (item.XIsInEffect?.value !== true) {\n            <eui-badge class=\"imx-margin-left-auto\" color=\"primary\">{{ '#LDS#Not effective' | translate }}</eui-badge>\n          }\n        </div>\n        @if (item.GetEntity().GetDisplay() !== item.GetEntity().GetDisplayLong()) {\n          <div subtitle>\n            {{ item.GetEntity().GetDisplayLong() }}\n          </div>\n        }\n      </td>\n    </ng-container>\n\n    @for (column of displayColumns; track column.ColumnName) {\n      <ng-container [matColumnDef]=\"column.ColumnName\">\n        <th mat-header-cell *matHeaderCellDef>{{ column.Display }}</th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          {{ item.GetEntity().GetColumn(column.ColumnName)?.GetDisplayValue() }}\n        </td>\n      </ng-container>\n    }\n  </imx-data-view-auto-table>\n  <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n</mat-card>\n", styles: [":host{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-memberships{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-membership-table{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;margin-top:20px}.fill-cell{width:100%;display:flex;flex-direction:row}.fill-cell eui-badge{align-self:flex-end}\n"] }]
    }], () => [{ type: GroupMembershipsExtService }, { type: i7$1.TranslateService }, { type: i1$1.EuiSidesheetService }, { type: i2.DynamicTabDataProviderDirective }, { type: i2.DataViewSource }], { referrer: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GroupMembershipsExtComponent, { className: "GroupMembershipsExtComponent", filePath: "lib\\groups\\group-memberships-ext\\group-memberships-ext.component.ts", lineNumber: 57 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportButtonExtComponent {
    elementalUiConfigService;
    service;
    http;
    injector;
    overlay;
    downloadService;
    downloadOptions;
    referrer;
    isAvailable;
    constructor(elementalUiConfigService, service, http, injector, overlay, downloadService) {
        this.elementalUiConfigService = elementalUiConfigService;
        this.service = service;
        this.http = http;
        this.injector = injector;
        this.overlay = overlay;
        this.downloadService = downloadService;
    }
    async ngOnInit() {
        const url = this.service.accountsOwnedByManagedReport(30, this.referrer);
        this.downloadOptions = {
            ...this.elementalUiConfigService.Config.downloadOptions,
            url,
        };
    }
    viewReport() {
        const directive = new EuiDownloadDirective(new ElementRef('') /* no element */, this.http, this.overlay, this.injector, this.downloadService);
        directive.downloadOptions = {
            ...this.downloadOptions,
            disableElement: false,
        };
        directive.onClick();
    }
    static ɵfac = function ReportButtonExtComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ReportButtonExtComponent)(i0.ɵɵdirectiveInject(i2.ElementalUiConfigService), i0.ɵɵdirectiveInject(AccountsReportsService), i0.ɵɵdirectiveInject(i5.HttpClient), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i6$2.Overlay), i0.ɵɵdirectiveInject(i1$1.EuiDownloadService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ReportButtonExtComponent, selectors: [["imx-report-button-ext"]], decls: 3, vars: 4, consts: [["mat-menu-item", "", "data-imx-identifier", "report-button-ext-menu-item", 3, "euiDownload"]], template: function ReportButtonExtComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("euiDownload", ctx.downloadOptions);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#View user accounts of identities you are directly responsible for"), "\n");
        } }, dependencies: [i11.MatMenuItem, i1$1.EuiDownloadDirective, i7$1.TranslatePipe] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportButtonExtComponent, [{
        type: Component,
        args: [{ selector: 'imx-report-button-ext', template: "<button mat-menu-item data-imx-identifier=\"report-button-ext-menu-item\" [euiDownload]=\"downloadOptions\">\n  {{ '#LDS#View user accounts of identities you are directly responsible for' | translate }}\n</button>\n" }]
    }], () => [{ type: i2.ElementalUiConfigService }, { type: AccountsReportsService }, { type: i5.HttpClient }, { type: i0.Injector }, { type: i6$2.Overlay }, { type: i1$1.EuiDownloadService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ReportButtonExtComponent, { className: "ReportButtonExtComponent", filePath: "lib\\report-button-ext\\report-button-ext.component.ts", lineNumber: 40 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    router;
    dataExplorerRegistryService;
    entlTypeService;
    tsbApiService;
    dynamicMethodService;
    menuService;
    extService;
    cacheService;
    myResponsibilitiesRegistryService;
    cachedUnsConfig;
    constructor(router, dataExplorerRegistryService, entlTypeService, tsbApiService, dynamicMethodService, menuService, extService, cacheService, myResponsibilitiesRegistryService) {
        this.router = router;
        this.dataExplorerRegistryService = dataExplorerRegistryService;
        this.entlTypeService = entlTypeService;
        this.tsbApiService = tsbApiService;
        this.dynamicMethodService = dynamicMethodService;
        this.menuService = menuService;
        this.extService = extService;
        this.cacheService = cacheService;
        this.myResponsibilitiesRegistryService = myResponsibilitiesRegistryService;
    }
    async onInit(routes) {
        this.cachedUnsConfig = this.cacheService.buildCache(() => this.tsbApiService.client.portal_uns_config_get());
        this.extService.register('identityReportsManager', {
            instance: ReportButtonExtComponent,
            inputData: {
                caption: '#LDS#View user accounts of identities you are directly responsible for',
            },
        });
        this.extService.register('identityAssignment', {
            instance: AccountsExtComponent,
            inputData: {
                id: 'userAccounts',
                label: '#LDS#User accounts',
                checkVisibility: async (_) => true,
            },
            sortOrder: 10,
        });
        this.extService.register('identityAssignment', {
            instance: GroupMembershipsExtComponent,
            inputData: {
                id: 'groups',
                label: '#LDS#System entitlements',
                checkVisibility: async (_) => true,
            },
            sortOrder: 10,
        });
        this.addRoutes(routes);
        this.setupMenu();
        this.entlTypeService.Register(() => this.loadUnsTypes());
        this.dataExplorerRegistryService.registerFactory((preProps, features, projectConfig, groups) => {
            if (!preProps.includes('ITSHOP') || !isTsbNameSpaceAdminBase(groups)) {
                return;
            }
            return {
                instance: DataExplorerAccountsComponent,
                sortOrder: 2,
                name: 'accounts',
                caption: '#LDS#User accounts',
                icon: 'account',
            };
        }, (preProps, features, projectConfig, groups) => {
            if (!preProps.includes('ITSHOP') || !isTsbNameSpaceAdminBase(groups)) {
                return;
            }
            return {
                instance: DataExplorerGroupsComponent,
                sortOrder: 3,
                name: 'groups',
                caption: '#LDS#System entitlements',
                icon: 'usergroup',
                contextId: HELP_CONTEXTUAL.DataExplorerGroups,
            };
        });
        this.entlTypeService.Register(async () => [
            new RequestableEntitlementType('TSBAccountDef', this.tsbApiService.apiClient, 'UID_TSBAccountDef', this.dynamicMethodService),
        ]);
        this.myResponsibilitiesRegistryService.registerFactory((preProps, features) => ({
            instance: DataExplorerGroupsComponent,
            sortOrder: 3,
            name: 'UNSGroup',
            caption: '#LDS#System entitlements',
            icon: 'usergroup',
            contextId: HELP_CONTEXTUAL.MyResponsibilitiesGroups,
        }));
    }
    async loadUnsTypes() {
        const config = await this.cachedUnsConfig.get();
        const types = [];
        if (!config.ShopAssign) {
            return types;
        }
        for (const key of Object.keys(config.ShopAssign)) {
            if (config.ShopAssign[key]?.GroupColumnName) {
                types.push(new RequestableEntitlementType(key, this.tsbApiService.apiClient, config.ShopAssign[key].GroupColumnName, this.dynamicMethodService));
            }
        }
        return types;
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, __) => {
            if (!preProps.includes('ITSHOP')) {
                return undefined;
            }
            return {
                id: 'ROOT_Responsibilities',
                title: '#LDS#Responsibilities',
                sorting: '30',
                items: [
                    {
                        id: 'QER_Responsibilities_AssignOwnership',
                        route: 'claimgroup',
                        title: '#LDS#Menu Entry System entitlement ownership',
                        sorting: '30-20',
                    },
                ],
            };
        }, (preProps, features, projectConfig, groups) => {
            if (!preProps.includes('ITSHOP') || !isTsbNameSpaceAdminBase(groups)) {
                return undefined;
            }
            return {
                id: 'ROOT_Data',
                title: '#LDS#Data administration',
                sorting: '40',
                items: [
                    {
                        id: 'QER_DataExplorer',
                        navigationCommands: { commands: ['admin', 'dataexplorer'] },
                        title: '#LDS#Menu Entry Data Explorer',
                        sorting: '40-10',
                    },
                ],
            };
        });
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i1$3.Router), i0.ɵɵinject(i1.DataExplorerRegistryService), i0.ɵɵinject(i1.RequestableEntitlementTypeService), i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.DynamicMethodService), i0.ɵɵinject(i2.MenuService), i0.ɵɵinject(i2.ExtService), i0.ɵɵinject(i2.CacheService), i0.ɵɵinject(i1.MyResponsibilitiesRegistryService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i1$3.Router }, { type: i1.DataExplorerRegistryService }, { type: i1.RequestableEntitlementTypeService }, { type: TsbApiService }, { type: i2.DynamicMethodService }, { type: i2.MenuService }, { type: i2.ExtService }, { type: i2.CacheService }, { type: i1.MyResponsibilitiesRegistryService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0 = ["tsSelect"];
const _c1 = ["containerSelect"];
const _c2 = a0 => ({ "container-search--hidden": a0 });
function DataExplorerFiltersComponent_div_3_button_2_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 19);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(3);
    i0.ɵɵproperty("matTooltip", ctx_r2.selectedTreeNodeFilterDisplay);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r2.selectedTreeNodeFilterDisplay);
} }
function DataExplorerFiltersComponent_div_3_button_2_ng_template_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 20);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r2.DataExplorerFilterTypes.Container);
} }
function DataExplorerFiltersComponent_div_3_button_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "button", 15)(1, "span", 16);
    i0.ɵɵtext(2, "#LDS#Filter by");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(3, "\u00A0 ");
    i0.ɵɵtemplate(4, DataExplorerFiltersComponent_div_3_button_2_span_4_Template, 2, 2, "span", 17)(5, DataExplorerFiltersComponent_div_3_button_2_ng_template_5_Template, 2, 1, "ng-template", null, 3, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelement(7, "eui-icon", 18);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const noselection_r4 = i0.ɵɵreference(6);
    const ctx_r2 = i0.ɵɵnextContext(2);
    const containerFilterMenu_r5 = i0.ɵɵreference(6);
    i0.ɵɵproperty("disabled", !ctx_r2.treeDbWrapper.selectionEnabled || !ctx_r2.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable)("matMenuTriggerFor", containerFilterMenu_r5);
    i0.ɵɵadvance(4);
    i0.ɵɵproperty("ngIf", ctx_r2.selectedTreeNodeFilterDisplay.length)("ngIfElse", noselection_r4);
} }
function DataExplorerFiltersComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 8);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵlistener("click", function DataExplorerFiltersComponent_div_3_Template_div_click_0_listener($event) { i0.ɵɵrestoreView(_r2); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵtemplate(2, DataExplorerFiltersComponent_div_3_button_2_Template, 8, 4, "button", 9);
    i0.ɵɵelementStart(3, "span", 10)(4, "div", 11);
    i0.ɵɵlistener("click", function DataExplorerFiltersComponent_div_3_Template_div_click_4_listener($event) { i0.ɵɵrestoreView(_r2); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementStart(5, "eui-select", 12, 2);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵlistener("searchFieldChange", function DataExplorerFiltersComponent_div_3_Template_eui_select_searchFieldChange_5_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onSearchChange(ctx_r2.DataExplorerFilterTypes.Container, $event)); })("selectionChange", function DataExplorerFiltersComponent_div_3_Template_eui_select_selectionChange_5_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.setSelectedContainer($event)); })("optionsClear", function DataExplorerFiltersComponent_div_3_Template_eui_select_optionsClear_5_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.clearContainerFilterSelection(false)); });
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(8, "button", 13);
    i0.ɵɵpipe(9, "translate");
    i0.ɵɵlistener("click", function DataExplorerFiltersComponent_div_3_Template_button_click_8_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.toggleContainerSearch()); });
    i0.ɵɵelement(10, "eui-icon", 14);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 12, ctx_r2.containerFilterWrapperTooltip));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", !ctx_r2.containerSearchMode);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(18, _c2, !ctx_r2.containerSearchMode));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r2.treeDbWrapper.selectionEnabled || !ctx_r2.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable)("hideClearButton", true)("label", i0.ɵɵpipeBind1(7, 14, "#LDS#Select a container"))("filterFunction", ctx_r2.paramListFilter)("options", ctx_r2.containerSelectOptions)("isPending", ctx_r2.pendingAsyncApiCall);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("disabled", !ctx_r2.treeDbWrapper.selectionEnabled || !ctx_r2.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable)("matTooltip", i0.ɵɵpipeBind1(9, 16, ctx_r2.containerToggleTooltip));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("icon", !ctx_r2.containerSearchMode && !ctx_r2.treeNodeSelected ? "search" : "close");
} }
function DataExplorerFiltersComponent_div_7_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 16);
    i0.ɵɵtext(1, "#LDS#No filters available");
    i0.ɵɵelementEnd();
} }
function DataExplorerFiltersComponent_div_7_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, DataExplorerFiltersComponent_div_7_span_1_Template, 2, 0, "span", 21);
    i0.ɵɵelementStart(2, "imx-data-tree", 22);
    i0.ɵɵlistener("nodeSelected", function DataExplorerFiltersComponent_div_7_Template_imx_data_tree_nodeSelected_2_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onTreeNodeSelected($event)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r2.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable);
    i0.ɵɵadvance();
    i0.ɵɵproperty("database", ctx_r2.treeDbWrapper.entityTreeDatabase);
} }
var DataExplorerFilterTypes;
(function (DataExplorerFilterTypes) {
    DataExplorerFilterTypes["TargetSystem"] = "targetsystem";
    DataExplorerFilterTypes["Container"] = "container";
})(DataExplorerFilterTypes || (DataExplorerFilterTypes = {}));
class DataExplorerFiltersComponent {
    dataHelper;
    targetSystemOptions = [];
    selectedTargetSystemUid;
    dstTargetSystemFilterRef;
    selectedContainerUid;
    dstContainerFilterRef;
    containerSelectOptions = [];
    DataExplorerFilterTypes = DataExplorerFilterTypes;
    pendingAsyncApiCall = false;
    containerSearchMode = false;
    treeNodeSelected = false;
    selectedTsOption;
    tsIssueMode = '';
    tsSelect;
    containerSelect;
    targetSystemData;
    dst;
    treeDbWrapper;
    selectedFiltersChanged = new EventEmitter();
    skipSelectionEmitMode = false;
    constructor(dataHelper) {
        this.dataHelper = dataHelper;
    }
    get selectedTreeNodeFilterDisplay() {
        let display = '';
        if (this.selectedContainerUid) {
            display = `Container: ${this.dstContainerFilterRef.selectedOption?.Display}`;
        }
        return display;
    }
    get containerFilterWrapperTooltip() {
        let display = '';
        if (!this.treeDbWrapper?.selectionEnabled) {
            display = '#LDS#Select a domain first';
        }
        else if (this.treeDbWrapper?.selectionEnabled && !this.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable) {
            display = '#LDS#No containers available';
        }
        return display;
    }
    get containerToggleTooltip() {
        let display = '';
        if (this.treeNodeSelected) {
            display = '#LDS#Clear';
        }
        else if (this.treeDbWrapper?.selectionEnabled && this.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable) {
            display = '#LDS#Toggle search';
        }
        return display;
    }
    get showTsSyncStatus() {
        let show = false;
        if (this.selectedTsOption && this.selectedTsOption.value) {
            show = !this.selectedTsOption.hasData;
        }
        return show;
    }
    get showTsSyncAlert() {
        let show = false;
        if (this.selectedTsOption && this.selectedTsOption.value) {
            show = this.selectedTsOption.hasData && !this.selectedTsOption.hasSync;
        }
        return show;
    }
    ngOnInit() {
        if (this.targetSystemData) {
            this.setupTsSelectOptions(this.targetSystemData);
        }
        else {
            this.getTargetSystemOptions();
        }
    }
    targetSystemSelected(chosen) {
        const selected = Array.isArray(chosen) ? chosen[0] : chosen;
        this.selectedTargetSystemUid = selected.value;
        this.updateDataSyncStateForTs(selected);
        if (this.treeDbWrapper) {
            this.treeDbWrapper.selectionEnabled = this.selectedTargetSystemUid?.length > 0 ? true : false;
            this.treeDbWrapper.targetSystemFilterValue = this.selectedTargetSystemUid;
        }
        if (this.dst) {
            // First clear any previosuly selected dst selectedFilter
            this.clearTargetSystemFilterSelection(false);
            if (selected.value && selected.value.length > 0) {
                this.dstTargetSystemFilterRef = {
                    selectedOption: { Value: selected.value, Display: selected.display },
                    filter: { Name: DataExplorerFilterTypes.TargetSystem },
                    isCustom: true,
                };
                this.dst.selectedFilters.push(this.dstTargetSystemFilterRef);
            }
        }
        if (!this.skipSelectionEmitMode) {
            // Trigger a new api call to reflect filter removal
            this.selectedFiltersChanged.emit(this.selectedTargetSystemUid);
        }
    }
    /**
     * Used to override the eui-select's default filtering
     * Filtering is provided through an async api call
     */
    paramListFilter() {
        return true;
    }
    async onSearchChange(filterType, search) {
        const method = filterType === DataExplorerFilterTypes.TargetSystem ? this.getTargetSystemOptions : this.getContainers;
        this.pendingAsyncApiCall = true;
        try {
            await method.call(this, search);
        }
        finally {
            this.pendingAsyncApiCall = false;
        }
    }
    clearTargetSystemFilterSelection(clearSelectControl) {
        if (clearSelectControl) {
            this.tsSelect.searchInput.clearSearch();
            this.tsSelect.clearSelectionsInside();
        }
        // Also clear container selection if a value is set
        if (this.selectedContainerUid) {
            // Don't emit a change to container un-select in this context because it
            // will be emitted as part of target system change anyway
            this.skipSelectionEmitMode = true;
            this.clearContainerFilterSelection(true);
            this.skipSelectionEmitMode = false;
        }
        this.clearDstSelectedFilter(this.dstTargetSystemFilterRef);
    }
    clearContainerFilterSelection(clearSelectControl) {
        if (this.containerSelect && clearSelectControl) {
            this.containerSelect.searchInput.clearSearch();
            this.containerSelect.clearSelectionsInside();
        }
        this.treeNodeSelected = false;
    }
    clearAllSelectedFilters() {
        this.skipSelectionEmitMode = true;
        this.clearContainerFilterSelection(true);
        this.clearTargetSystemFilterSelection(true);
        this.skipSelectionEmitMode = false;
        this.selectedFiltersChanged.emit();
    }
    /**
     * @ignore Used internally.
     * Is called when a value is selection on the optional filter tree structure
     * Updates and emits the new navigationState to include any filter query params.
     */
    async onTreeNodeSelected(entity) {
        this.treeNodeSelected = true;
        const selectedValue = entity.GetKeys()[0];
        // Set the selected value on the search control as well
        this.containerSelect.writeValue(selectedValue);
        this.setSelectedContainer({ value: selectedValue, display: entity.GetDisplay() });
    }
    setSelectedContainer(chosen) {
        const selected = Array.isArray(chosen) ? chosen[0] : chosen;
        this.selectedContainerUid = selected.value;
        if (this.dst) {
            // First clear any previosuly selected dst selectedFilter
            this.clearDstSelectedFilter(this.dstContainerFilterRef);
            if (selected.value && selected.value.length > 0) {
                this.dstContainerFilterRef = {
                    selectedOption: { Value: selected.value, Display: selected.display },
                    filter: { Name: DataExplorerFilterTypes.Container },
                    isCustom: true,
                };
                this.dst.selectedFilters.push(this.dstContainerFilterRef);
            }
        }
        if (!this.skipSelectionEmitMode) {
            this.selectedFiltersChanged.emit(this.selectedContainerUid);
        }
    }
    toggleContainerSearch() {
        if (this.treeNodeSelected) {
            this.clearContainerFilterSelection(true);
            return;
        }
        this.containerSearchMode = !this.containerSearchMode;
        if (this.containerSearchMode) {
            if (this.treeDbWrapper?.entityTreeDatabase?.topLevelEntities) {
                this.containerSelectOptions = this.treeDbWrapper.entityTreeDatabase.topLevelEntities.map((d) => this.convertEntityToEuiSelectOption(d));
            }
            else {
                this.getContainers();
            }
        }
        else if (this.selectedContainerUid) {
            // If a value is set then clear it when toggling out of search mode
            this.clearContainerFilterSelection(true);
        }
    }
    /**
     * Responds to a custom filter (or all filters) being removed from outside of the context of
     * this component
     */
    onCustomFilterClearedExternally(sf) {
        setTimeout(() => {
            if (!sf) {
                // If no singular filter is supplied, then all have been cleared
                this.clearAllSelectedFilters();
            }
            else if (sf.filter?.Name === DataExplorerFilterTypes.TargetSystem) {
                this.clearTargetSystemFilterSelection(true);
            }
            else if (sf.filter?.Name === DataExplorerFilterTypes.Container) {
                this.clearContainerFilterSelection(true);
            }
        });
    }
    updateDataSyncStateForTs(selectedOption) {
        this.selectedTsOption = selectedOption;
        this.tsIssueMode = '';
        if (this.showTsSyncStatus) {
            if (!this.selectedTsOption.hasSync) {
                this.tsIssueMode = 'no-sync';
            }
            else if (!this.selectedTsOption.hasData) {
                this.tsIssueMode = 'no-data';
            }
        }
    }
    clearDstSelectedFilter(selectedFilterRef) {
        if (this.dst && selectedFilterRef && selectedFilterRef.selectedOption?.Value) {
            // Remove the 'isCustom' property to avoid an event being triggered in dst code
            selectedFilterRef.isCustom = undefined;
            // Then make call to remove selected filter
            this.dst.removeSelectedFilter(selectedFilterRef.filter, false, selectedFilterRef.selectedOption.Value, selectedFilterRef);
        }
    }
    async getTargetSystemOptions(search) {
        const data = await this.dataHelper.getAuthorityData(search, true);
        if (data.authorities) {
            this.setupTsSelectOptions(data.authorities);
        }
    }
    async getContainers(search) {
        const navState = { PageSize: 1000, StartIndex: 0, ParentKey: '' };
        navState.search = search ? search : undefined;
        navState.system = this.selectedTargetSystemUid ? this.selectedTargetSystemUid : undefined;
        const data = await this.dataHelper.getContainers(navState);
        this.containerSelectOptions = data?.Data.map((d) => this.convertEntityToEuiSelectOption(d.GetEntity()));
    }
    setupTsSelectOptions(targetSystems) {
        this.targetSystemOptions = targetSystems.map((d) => this.convertTsToEuiSelectOption(d));
    }
    convertTsToEuiSelectOption(tEntity) {
        const option = this.convertEntityToEuiSelectOption(tEntity.GetEntity());
        option.hasSync = tEntity.HasSync?.value;
        option.hasData = tEntity.HasData?.value;
        return option;
    }
    convertEntityToEuiSelectOption(entity) {
        return { display: entity.GetDisplay(), value: entity.GetKeys()[0] };
    }
    static ɵfac = function DataExplorerFiltersComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DataExplorerFiltersComponent)(i0.ɵɵdirectiveInject(DeHelperService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataExplorerFiltersComponent, selectors: [["imx-target-system-filter"]], viewQuery: function DataExplorerFiltersComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0, 5);
            i0.ɵɵviewQuery(_c1, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.tsSelect = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerSelect = _t.first);
        } }, inputs: { targetSystemData: "targetSystemData", dst: "dst", treeDbWrapper: "treeDbWrapper" }, outputs: { selectedFiltersChanged: "selectedFiltersChanged" }, decls: 8, vars: 8, consts: [["tsSelect", ""], ["containerFilterMenu", ""], ["containerSelect", ""], ["noselection", ""], [1, "imx-margin-bottom-15", 3, "searchFieldChange", "selectionChange", "optionsClear", "label", "filterFunction", "options", "isPending"], ["class", "imx-de-container-tree-filter", 3, "matTooltip", "click", 4, "ngIf"], ["xPosition", "before", 1, "container-filter-menu"], [4, "ngIf"], [1, "imx-de-container-tree-filter", 3, "click", "matTooltip"], ["mat-button", "", "data-imx-identifier", "dst-button-filter", 3, "disabled", "matMenuTriggerFor", 4, "ngIf"], [3, "ngClass"], ["imx-data-source-toolbar-custom-filter-search", "", 3, "click"], [1, "imx-container-search", 3, "searchFieldChange", "selectionChange", "optionsClear", "disabled", "hideClearButton", "label", "filterFunction", "options", "isPending"], ["matSuffix", "", "mat-icon-button", "", 3, "click", "disabled", "matTooltip"], ["matSuffix", "", "size", "18px", 3, "icon"], ["mat-button", "", "data-imx-identifier", "dst-button-filter", 3, "disabled", "matMenuTriggerFor"], ["translate", ""], ["class", "tree-filter-name", 3, "matTooltip", 4, "ngIf", "ngIfElse"], ["icon", "scrolldown", "size", "16px"], [1, "tree-filter-name", 3, "matTooltip"], [1, "tree-filter-name"], ["translate", "", 4, "ngIf"], [3, "nodeSelected", "database"]], template: function DataExplorerFiltersComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "eui-select", 4, 0);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵlistener("searchFieldChange", function DataExplorerFiltersComponent_Template_eui_select_searchFieldChange_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSearchChange(ctx.DataExplorerFilterTypes.TargetSystem, $event)); })("selectionChange", function DataExplorerFiltersComponent_Template_eui_select_selectionChange_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.targetSystemSelected($event)); })("optionsClear", function DataExplorerFiltersComponent_Template_eui_select_optionsClear_0_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.clearTargetSystemFilterSelection(false)); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(3, DataExplorerFiltersComponent_div_3_Template, 11, 20, "div", 5);
            i0.ɵɵelement(4, "mat-divider");
            i0.ɵɵelementStart(5, "mat-menu", 6, 1);
            i0.ɵɵtemplate(7, DataExplorerFiltersComponent_div_7_Template, 3, 2, "div", 7);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 6, "#LDS#Select a domain"))("filterFunction", ctx.paramListFilter)("options", ctx.targetSystemOptions)("isPending", ctx.pendingAsyncApiCall);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.treeDbWrapper);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngIf", ctx.treeDbWrapper == null ? null : ctx.treeDbWrapper.entityTreeDatabase);
        } }, dependencies: [i7.NgClass, i7.NgIf, i1$1.EuiIconComponent, i1$1.EuiSelectComponent, i8.MatButton, i8.MatIconButton, i5$1.MatDivider, i6$3.MatSuffix, i11.MatMenu, i11.MatMenuTrigger, i9$2.MatTooltip, i7$1.TranslateDirective, i2.DataTreeComponent, i7$1.TranslatePipe], styles: [".imx-de-container-tree-filter[_ngcontent-%COMP%]{display:flex;align-items:center;margin-bottom:15px}.imx-de-container-tree-filter[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{margin-left:4px}.imx-de-container-tree-filter[_ngcontent-%COMP%]   .tree-filter-name[_ngcontent-%COMP%]{text-transform:capitalize;max-width:140px;display:inline-block;overflow:hidden;text-overflow:ellipsis}  .mat-mdc-menu-panel.container-filter-menu{min-width:250px;max-width:400px;max-height:600px;padding:0 10px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataExplorerFiltersComponent, [{
        type: Component,
        args: [{ selector: 'imx-target-system-filter', template: "<eui-select\n  [label]=\"'#LDS#Select a domain' | translate\"\n  (searchFieldChange)=\"onSearchChange(DataExplorerFilterTypes.TargetSystem, $event)\"\n  [filterFunction]=\"paramListFilter\"\n  (selectionChange)=\"targetSystemSelected($event)\"\n  (optionsClear)=\"clearTargetSystemFilterSelection(false)\"\n  [options]=\"targetSystemOptions\"\n  [isPending]=\"pendingAsyncApiCall\"\n  class=\"imx-margin-bottom-15\"\n  #tsSelect\n>\n</eui-select>\n\n<div\n  class=\"imx-de-container-tree-filter\"\n  *ngIf=\"treeDbWrapper\"\n  (click)=\"$event.stopPropagation()\"\n  [matTooltip]=\"containerFilterWrapperTooltip | translate\"\n>\n  <button\n    *ngIf=\"!containerSearchMode\"\n    [disabled]=\"!treeDbWrapper.selectionEnabled || !treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable\"\n    mat-button\n    [matMenuTriggerFor]=\"containerFilterMenu\"\n    data-imx-identifier=\"dst-button-filter\"\n  >\n    <span translate>#LDS#Filter by</span>&nbsp;\n    <span\n      *ngIf=\"selectedTreeNodeFilterDisplay.length; else noselection\"\n      [matTooltip]=\"selectedTreeNodeFilterDisplay\"\n      class=\"tree-filter-name\"\n      >{{ selectedTreeNodeFilterDisplay }}</span\n    >\n    <ng-template #noselection\n      ><span class=\"tree-filter-name\">{{ DataExplorerFilterTypes.Container }}</span></ng-template\n    >\n    <eui-icon icon=\"scrolldown\" size=\"16px\"></eui-icon>\n  </button>\n  <span [ngClass]=\"{ 'container-search--hidden': !containerSearchMode }\">\n    <div imx-data-source-toolbar-custom-filter-search (click)=\"$event.stopPropagation()\">\n      <eui-select\n        [disabled]=\"!treeDbWrapper.selectionEnabled || !treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable\"\n        [hideClearButton]=\"true\"\n        [label]=\"'#LDS#Select a container' | translate\"\n        (searchFieldChange)=\"onSearchChange(DataExplorerFilterTypes.Container, $event)\"\n        [filterFunction]=\"paramListFilter\"\n        (selectionChange)=\"setSelectedContainer($event)\"\n        (optionsClear)=\"clearContainerFilterSelection(false)\"\n        [options]=\"containerSelectOptions\"\n        [isPending]=\"pendingAsyncApiCall\"\n        class=\"imx-container-search\"\n        #containerSelect\n      >\n      </eui-select>\n    </div>\n  </span>\n  <button\n    [disabled]=\"!treeDbWrapper.selectionEnabled || !treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable\"\n    [matTooltip]=\"containerToggleTooltip | translate\"\n    matSuffix\n    mat-icon-button\n    (click)=\"toggleContainerSearch()\"\n  >\n    <eui-icon matSuffix [icon]=\"!containerSearchMode && !treeNodeSelected ? 'search' : 'close'\" size=\"18px\"></eui-icon>\n  </button>\n</div>\n\n<mat-divider></mat-divider>\n\n<mat-menu #containerFilterMenu class=\"container-filter-menu\" xPosition=\"before\">\n  <div *ngIf=\"treeDbWrapper?.entityTreeDatabase\">\n    <span *ngIf=\"!treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable\" translate>#LDS#No filters available</span>\n    <imx-data-tree [database]=\"treeDbWrapper.entityTreeDatabase\" (nodeSelected)=\"onTreeNodeSelected($event)\"></imx-data-tree>\n  </div>\n</mat-menu>\n", styles: [".imx-de-container-tree-filter{display:flex;align-items:center;margin-bottom:15px}.imx-de-container-tree-filter .eui-icon{margin-left:4px}.imx-de-container-tree-filter .tree-filter-name{text-transform:capitalize;max-width:140px;display:inline-block;overflow:hidden;text-overflow:ellipsis}::ng-deep .mat-mdc-menu-panel.container-filter-menu{min-width:250px;max-width:400px;max-height:600px;padding:0 10px}\n"] }]
    }], () => [{ type: DeHelperService }], { tsSelect: [{
            type: ViewChild,
            args: ['tsSelect', { static: false }]
        }], containerSelect: [{
            type: ViewChild,
            args: ['containerSelect', { static: false }]
        }], targetSystemData: [{
            type: Input
        }], dst: [{
            type: Input
        }], treeDbWrapper: [{
            type: Input
        }], selectedFiltersChanged: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DataExplorerFiltersComponent, { className: "DataExplorerFiltersComponent", filePath: "lib\\data-filters\\data-explorer-filters.component.ts", lineNumber: 45 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class DataFiltersModule {
    static ɵfac = function DataFiltersModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DataFiltersModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: DataFiltersModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            EuiCoreModule,
            EuiMaterialModule,
            CdrModule,
            RouterModule,
            MatExpansionModule,
            MatIconModule,
            MatSidenavModule,
            TranslateModule,
            DataSourceToolbarModule,
            DataTableModule,
            LdsReplaceModule,
            DataTreeModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataFiltersModule, [{
        type: NgModule,
        args: [{
                declarations: [DataExplorerFiltersComponent],
                imports: [
                    CommonModule,
                    FormsModule,
                    ReactiveFormsModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    CdrModule,
                    RouterModule,
                    MatExpansionModule,
                    MatIconModule,
                    MatSidenavModule,
                    TranslateModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    LdsReplaceModule,
                    DataTreeModule,
                ],
                providers: [],
                exports: [DataExplorerFiltersComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(DataFiltersModule, { declarations: [DataExplorerFiltersComponent], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        CdrModule,
        RouterModule,
        MatExpansionModule,
        MatIconModule,
        MatSidenavModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule,
        LdsReplaceModule,
        DataTreeModule], exports: [DataExplorerFiltersComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function DataExplorerNoDataComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵelement(1, "eui-icon", 2);
    i0.ɵɵelementStart(2, "h2", 3);
    i0.ɵɵtext(3, "#LDS#Heading No Synchronization Configured");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 3);
    i0.ɵɵtext(5, "#LDS#Please configure a synchronization using the Synchronization Editor.");
    i0.ɵɵelementEnd()();
} }
function DataExplorerNoDataComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵelement(1, "eui-icon", 4);
    i0.ɵɵelementStart(2, "h2", 3);
    i0.ɵɵtext(3, "#LDS#Heading No Data Synchronized");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 3);
    i0.ɵɵtext(5, "#LDS#A synchronization has been configured in the Synchronization Editor, but not run yet.");
    i0.ɵɵelementEnd()();
} }
class DataExplorerNoDataComponent {
    mode;
    static ɵfac = function DataExplorerNoDataComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DataExplorerNoDataComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataExplorerNoDataComponent, selectors: [["imx-data-explorer-no-data"]], inputs: { mode: "mode" }, decls: 3, vars: 2, consts: [[1, "data-explorer-sync-status"], [4, "ngIf"], ["icon", "sync", "size", "150px"], ["translate", ""], ["icon", "database", "size", "150px"]], template: function DataExplorerNoDataComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, DataExplorerNoDataComponent_div_1_Template, 6, 0, "div", 1)(2, DataExplorerNoDataComponent_div_2_Template, 6, 0, "div", 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.mode === "no-sync");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.mode === "no-data");
        } }, dependencies: [i7.NgIf, i1$1.EuiIconComponent, i7$1.TranslateDirective], styles: [".data-explorer-sync-status[_ngcontent-%COMP%]{height:100%}.data-explorer-sync-status[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0 16px}.data-explorer-sync-status[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#919799;margin-bottom:30px}.data-explorer-sync-status[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{font-size:32px;font-weight:400}.data-explorer-sync-status[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:18px;margin-top:10px;margin-bottom:75px;color:#919799}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataExplorerNoDataComponent, [{
        type: Component,
        args: [{ selector: 'imx-data-explorer-no-data', template: "<div class=\"data-explorer-sync-status\">\n  <div *ngIf=\"mode === 'no-sync'\">\n    <eui-icon icon=\"sync\" size=\"150px\"></eui-icon>\n    <h2 translate>#LDS#Heading No Synchronization Configured</h2>\n    <p translate>#LDS#Please configure a synchronization using the Synchronization Editor.</p>\n  </div>\n  <div *ngIf=\"mode === 'no-data'\">\n    <eui-icon icon=\"database\" size=\"150px\"></eui-icon>\n    <h2 translate>#LDS#Heading No Data Synchronized</h2>\n    <p translate>#LDS#A synchronization has been configured in the Synchronization Editor, but not run yet.</p>\n  </div>\n</div>\n", styles: [".data-explorer-sync-status{height:100%}.data-explorer-sync-status>div{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0 16px}.data-explorer-sync-status .eui-icon{color:#919799;margin-bottom:30px}.data-explorer-sync-status h2{font-size:32px;font-weight:400}.data-explorer-sync-status p{font-size:18px;margin-top:10px;margin-bottom:75px;color:#919799}\n"] }]
    }], null, { mode: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DataExplorerNoDataComponent, { className: "DataExplorerNoDataComponent", filePath: "lib\\no-data\\no-data.component.ts", lineNumber: 34 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class NoDataModule {
    static ɵfac = function NoDataModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || NoDataModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: NoDataModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, EuiCoreModule, TranslateModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(NoDataModule, [{
        type: NgModule,
        args: [{
                declarations: [DataExplorerNoDataComponent],
                exports: [DataExplorerNoDataComponent],
                imports: [CommonModule, EuiCoreModule, TranslateModule],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(NoDataModule, { declarations: [DataExplorerNoDataComponent], imports: [CommonModule, EuiCoreModule, TranslateModule], exports: [DataExplorerNoDataComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GroupsModule {
    static ɵfac = function GroupsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GroupsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: GroupsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            EuiCoreModule,
            EuiMaterialModule,
            ExtModule,
            CdrModule,
            RouterModule,
            ObjectHyperviewModule,
            OwnerControlModule,
            BusyIndicatorModule,
            ServiceItemsEditFormModule,
            TranslateModule,
            DataSourceToolbarModule,
            DataTableModule,
            LdsReplaceModule,
            DataFiltersModule,
            NoDataModule,
            DataTreeModule,
            DynamicTabsModule,
            ObjectHistoryModule,
            IdentityRoleMembershipsModule,
            SelectedElementsModule,
            HelpContextualModule,
            DataViewModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupsModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    DataExplorerGroupsComponent,
                    GroupSidesheetComponent,
                    GroupMembersComponent,
                    ChildSystemEntitlementsComponent,
                    ProductOwnerSidesheetComponent,
                    GroupMembershipsExtComponent,
                ],
                imports: [
                    CommonModule,
                    FormsModule,
                    ReactiveFormsModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    ExtModule,
                    CdrModule,
                    RouterModule,
                    ObjectHyperviewModule,
                    OwnerControlModule,
                    BusyIndicatorModule,
                    ServiceItemsEditFormModule,
                    TranslateModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    LdsReplaceModule,
                    DataFiltersModule,
                    NoDataModule,
                    DataTreeModule,
                    DynamicTabsModule,
                    ObjectHistoryModule,
                    IdentityRoleMembershipsModule,
                    SelectedElementsModule,
                    HelpContextualModule,
                    DataViewModule,
                ],
                exports: [DataExplorerGroupsComponent, ChildSystemEntitlementsComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(GroupsModule, { declarations: [DataExplorerGroupsComponent,
        GroupSidesheetComponent,
        GroupMembersComponent,
        ChildSystemEntitlementsComponent,
        ProductOwnerSidesheetComponent,
        GroupMembershipsExtComponent], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        ExtModule,
        CdrModule,
        RouterModule,
        ObjectHyperviewModule,
        OwnerControlModule,
        BusyIndicatorModule,
        ServiceItemsEditFormModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule,
        LdsReplaceModule,
        DataFiltersModule,
        NoDataModule,
        DataTreeModule,
        DynamicTabsModule,
        ObjectHistoryModule,
        IdentityRoleMembershipsModule,
        SelectedElementsModule,
        HelpContextualModule,
        DataViewModule], exports: [DataExplorerGroupsComponent, ChildSystemEntitlementsComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountsModule {
    static ɵfac = function AccountsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AccountsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: AccountsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [DataFiltersModule,
            NoDataModule,
            CommonModule,
            FormsModule,
            GroupsModule,
            BusyIndicatorModule,
            ReactiveFormsModule,
            EuiCoreModule,
            EuiMaterialModule,
            CdrModule,
            RouterModule,
            MatExpansionModule,
            MatIconModule,
            MatSidenavModule,
            MatCardModule,
            MatButtonModule,
            ObjectHyperviewModule,
            TranslateModule,
            DataSourceToolbarModule,
            DataTableModule,
            LdsReplaceModule,
            DataTreeModule,
            ExtModule,
            DynamicTabsModule,
            HelpContextualModule,
            DataViewModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsModule, [{
        type: NgModule,
        args: [{
                declarations: [DataExplorerAccountsComponent, AccountSidesheetComponent, AccountsExtComponent, TargetSystemReportComponent],
                imports: [
                    DataFiltersModule,
                    NoDataModule,
                    CommonModule,
                    FormsModule,
                    GroupsModule,
                    BusyIndicatorModule,
                    ReactiveFormsModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    CdrModule,
                    RouterModule,
                    MatExpansionModule,
                    MatIconModule,
                    MatSidenavModule,
                    MatCardModule,
                    MatButtonModule,
                    ObjectHyperviewModule,
                    TranslateModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    LdsReplaceModule,
                    DataTreeModule,
                    ExtModule,
                    DynamicTabsModule,
                    HelpContextualModule,
                    DataViewModule,
                ],
                exports: [DataExplorerAccountsComponent, AccountsExtComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(AccountsModule, { declarations: [DataExplorerAccountsComponent, AccountSidesheetComponent, AccountsExtComponent, TargetSystemReportComponent], imports: [DataFiltersModule,
        NoDataModule,
        CommonModule,
        FormsModule,
        GroupsModule,
        BusyIndicatorModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        CdrModule,
        RouterModule,
        MatExpansionModule,
        MatIconModule,
        MatSidenavModule,
        MatCardModule,
        MatButtonModule,
        ObjectHyperviewModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule,
        LdsReplaceModule,
        DataTreeModule,
        ExtModule,
        DynamicTabsModule,
        HelpContextualModule,
        DataViewModule], exports: [DataExplorerAccountsComponent, AccountsExtComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TsbPermissionsService {
    userService;
    constructor(userService) {
        this.userService = userService;
    }
    async isTsbNameSpaceAdminBase() {
        return isTsbNameSpaceAdminBase((await this.userService.getGroups()).map((userGroupInfo) => userGroupInfo.Name));
    }
    static ɵfac = function TsbPermissionsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TsbPermissionsService)(i0.ɵɵinject(i1.UserModelService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TsbPermissionsService, factory: TsbPermissionsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TsbPermissionsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1.UserModelService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TsbNamespaceAdminGuardService {
    authentication;
    permissionService;
    appConfig;
    router;
    onSessionResponse;
    constructor(authentication, permissionService, appConfig, router) {
        this.authentication = authentication;
        this.permissionService = permissionService;
        this.appConfig = appConfig;
        this.router = router;
    }
    canActivate(route, _) {
        return new Observable((observer) => {
            this.onSessionResponse = this.authentication.onSessionResponse.subscribe(async (sessionState) => {
                if (sessionState.IsLoggedIn) {
                    // TODO Later: Berechtigungen sind noch nicht genau genug, non-admin-Pages lassen sich im Moment immer ansteuern
                    const navigateToAdmin = route.url[0].path === 'admin';
                    const userIsAdmin = await this.permissionService.isTsbNameSpaceAdminBase();
                    if (navigateToAdmin && !userIsAdmin) {
                        this.router.navigate([this.appConfig.Config?.routeConfig?.start], { queryParams: {} });
                    }
                    observer.next(!navigateToAdmin || userIsAdmin);
                    observer.complete();
                }
            });
        });
    }
    ngOnDestroy() {
        if (this.onSessionResponse) {
            this.onSessionResponse.unsubscribe();
        }
    }
    static ɵfac = function TsbNamespaceAdminGuardService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TsbNamespaceAdminGuardService)(i0.ɵɵinject(i2.AuthenticationService), i0.ɵɵinject(TsbPermissionsService), i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i1$3.Router)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TsbNamespaceAdminGuardService, factory: TsbNamespaceAdminGuardService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TsbNamespaceAdminGuardService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2.AuthenticationService }, { type: TsbPermissionsService }, { type: i2.AppConfigService }, { type: i1$3.Router }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportButtonExtModule {
    static ɵfac = function ReportButtonExtModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ReportButtonExtModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ReportButtonExtModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, MatMenuModule, EuiCoreModule, TranslateModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportButtonExtModule, [{
        type: NgModule,
        args: [{
                declarations: [ReportButtonExtComponent],
                imports: [CommonModule, MatMenuModule, EuiCoreModule, TranslateModule],
                exports: [ReportButtonExtComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ReportButtonExtModule, { declarations: [ReportButtonExtComponent], imports: [CommonModule, MatMenuModule, EuiCoreModule, TranslateModule], exports: [ReportButtonExtComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'claimgroup',
        component: ClaimGroupComponent,
        canActivate: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.ClaimGroup,
        },
    },
    {
        path: 'resp/UNSGroup',
        component: DataExplorerGroupsComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService],
    },
];
class TsbConfigModule {
    initializer;
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 TSB loaded with claimgroup');
        this.initializer.onInit(routes);
        console.log('▶️ TSB initialized');
    }
    static ɵfac = function TsbConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TsbConfigModule)(i0.ɵɵinject(InitService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: TsbConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [TsbNamespaceAdminGuardService], imports: [AccountsModule,
            BusinessownerAddonTileModule,
            BusinessownerOverviewTileModule,
            CdrModule,
            CommonModule,
            GroupsModule,
            RouterModule.forChild(routes),
            MatIconModule,
            MatListModule,
            TileModule,
            TranslateModule,
            ReportButtonExtModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TsbConfigModule, [{
        type: NgModule,
        args: [{
                declarations: [],
                imports: [
                    AccountsModule,
                    BusinessownerAddonTileModule,
                    BusinessownerOverviewTileModule,
                    CdrModule,
                    CommonModule,
                    GroupsModule,
                    RouterModule.forChild(routes),
                    MatIconModule,
                    MatListModule,
                    TileModule,
                    TranslateModule,
                    ReportButtonExtModule,
                ],
                providers: [TsbNamespaceAdminGuardService],
            }]
    }], () => [{ type: InitService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(TsbConfigModule, { imports: [AccountsModule,
        BusinessownerAddonTileModule,
        BusinessownerOverviewTileModule,
        CdrModule,
        CommonModule,
        GroupsModule, i1$3.RouterModule, MatIconModule,
        MatListModule,
        TileModule,
        TranslateModule,
        ReportButtonExtModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of tsb
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AccountSidesheetComponent, AccountsExtComponent, AccountsModule, AccountsReportsService, AccountsService, ChildSystemEntitlementsComponent, ClaimGroupModule, DataExplorerAccountsComponent, DataExplorerFiltersComponent, DataExplorerGroupsComponent, DataExplorerNoDataComponent, DataFiltersModule, DeHelperService, GroupSidesheetComponent, GroupsModule, GroupsReportsService, GroupsService, NoDataModule, TsbApiService, TsbConfigModule };
//# sourceMappingURL=tsb.mjs.map
