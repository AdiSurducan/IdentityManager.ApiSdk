export interface PathParameterWrapper {
    path: string;
    parameters: {
        [name: string]: any;
    };
}
