import { DbObjectKey } from '@imx-modules/imx-qbm-dbts';
export type DbObjectKeyBase = {
    TableName: string;
    Keys: ReadonlyArray<string>;
} | DbObjectKey;
export interface DbObjectKeyWrapper {
    dbObjectKey: DbObjectKeyBase;
    columnName?: string;
}
