import { ExtendedTypedEntityCollection, IEntity, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { DynamicCollectionLoadParameters, DynamicMethodService, MetadataService } from 'qbm';
import { TsbApiService } from '../tsb-api-client.service';
import { DbObjectKeyWrapper } from './db-object-key-wrapper.interface';
import { PathParameterWrapper } from './path-parameter-wrapper';
import * as i0 from "@angular/core";
export declare class TargetSystemDynamicMethodService {
    private readonly tsbClient;
    private readonly dynamicMethod;
    private readonly metadata;
    constructor(tsbClient: TsbApiService, dynamicMethod: DynamicMethodService, metadata: MetadataService);
    getCollection<TEntity extends TypedEntity, TExtendedData = any>(type: new (e: IEntity) => TEntity, tableName: string, parameters?: DynamicCollectionLoadParameters): Promise<ExtendedTypedEntityCollection<TEntity, TExtendedData>>;
    getById<TEntity extends TypedEntity, TExtendedData = any>(type: new (e: IEntity) => TEntity, dbObjectKeyWrapper: DbObjectKeyWrapper): Promise<TypedEntity>;
    get<TEntity extends TypedEntity, TExtendedData = any>(type: new (e: IEntity) => TEntity, dbObjectKeyWrapper: DbObjectKeyWrapper): Promise<TEntity>;
    delete(tableName: string, pathParameterWrapper: PathParameterWrapper): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TargetSystemDynamicMethodService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TargetSystemDynamicMethodService>;
}
