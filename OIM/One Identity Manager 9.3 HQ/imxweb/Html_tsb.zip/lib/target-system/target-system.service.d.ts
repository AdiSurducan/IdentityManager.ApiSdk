import { TsbUserConfig } from '@imx-modules/imx-api-tsb';
import { TsbApiService } from '../tsb-api-client.service';
import * as i0 from "@angular/core";
export declare class TargetSystemService {
    private readonly apiService;
    constructor(apiService: TsbApiService);
    getUserConfig(): Promise<TsbUserConfig>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TargetSystemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TargetSystemService>;
}
