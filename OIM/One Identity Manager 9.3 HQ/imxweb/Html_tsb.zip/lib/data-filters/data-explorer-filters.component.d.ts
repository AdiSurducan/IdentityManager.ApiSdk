import { EventEmitter, OnInit } from '@angular/core';
import { EuiSelectComponent, EuiSelectOption } from '@elemental-ui/core';
import { PortalTargetsystemUnsSystem } from '@imx-modules/imx-api-tsb';
import { IEntity } from '@imx-modules/imx-qbm-dbts';
import { DataSourceToolbarComponent, DataSourceToolbarSelectedFilter } from 'qbm';
import { ContainerTreeDatabaseWrapper } from '../container-list/container-tree-database-wrapper';
import { DeHelperService } from '../de-helper.service';
import * as i0 from "@angular/core";
export declare enum DataExplorerFilterTypes {
    TargetSystem = "targetsystem",
    Container = "container"
}
export declare class DataExplorerFiltersComponent implements OnInit {
    private readonly dataHelper;
    targetSystemOptions: EuiSelectOption[];
    selectedTargetSystemUid: string;
    dstTargetSystemFilterRef: DataSourceToolbarSelectedFilter;
    selectedContainerUid: string;
    dstContainerFilterRef: DataSourceToolbarSelectedFilter;
    containerSelectOptions: EuiSelectOption[];
    DataExplorerFilterTypes: typeof DataExplorerFilterTypes;
    pendingAsyncApiCall: boolean;
    containerSearchMode: boolean;
    treeNodeSelected: boolean;
    selectedTsOption: EuiSelectOption;
    tsIssueMode: string;
    tsSelect: EuiSelectComponent;
    containerSelect: EuiSelectComponent;
    targetSystemData: PortalTargetsystemUnsSystem[];
    dst?: DataSourceToolbarComponent;
    treeDbWrapper: ContainerTreeDatabaseWrapper;
    selectedFiltersChanged: EventEmitter<string>;
    private skipSelectionEmitMode;
    constructor(dataHelper: DeHelperService);
    get selectedTreeNodeFilterDisplay(): string;
    get containerFilterWrapperTooltip(): string;
    get containerToggleTooltip(): string;
    get showTsSyncStatus(): boolean;
    get showTsSyncAlert(): boolean;
    ngOnInit(): void;
    targetSystemSelected(chosen: EuiSelectOption | EuiSelectOption[]): void;
    /**
     * Used to override the eui-select's default filtering
     * Filtering is provided through an async api call
     */
    paramListFilter(): boolean;
    onSearchChange(filterType: DataExplorerFilterTypes, search?: string): Promise<void>;
    clearTargetSystemFilterSelection(clearSelectControl?: boolean): void;
    clearContainerFilterSelection(clearSelectControl?: boolean): void;
    clearAllSelectedFilters(): void;
    /**
     * @ignore Used internally.
     * Is called when a value is selection on the optional filter tree structure
     * Updates and emits the new navigationState to include any filter query params.
     */
    onTreeNodeSelected(entity: IEntity): Promise<void>;
    setSelectedContainer(chosen: EuiSelectOption | EuiSelectOption[]): void;
    toggleContainerSearch(): void;
    /**
     * Responds to a custom filter (or all filters) being removed from outside of the context of
     * this component
     */
    onCustomFilterClearedExternally(sf?: DataSourceToolbarSelectedFilter): void;
    private updateDataSyncStateForTs;
    private clearDstSelectedFilter;
    private getTargetSystemOptions;
    private getContainers;
    private setupTsSelectOptions;
    private convertTsToEuiSelectOption;
    private convertEntityToEuiSelectOption;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataExplorerFiltersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataExplorerFiltersComponent, "imx-target-system-filter", never, { "targetSystemData": { "alias": "targetSystemData"; "required": false; }; "dst": { "alias": "dst"; "required": false; }; "treeDbWrapper": { "alias": "treeDbWrapper"; "required": false; }; }, { "selectedFiltersChanged": "selectedFiltersChanged"; }, never, never, false, never>;
}
