import { Injector, OnInit } from '@angular/core';
import { EuiDownloadOptions, EuiDownloadService } from '@elemental-ui/core';
import { Overlay } from '@angular/cdk/overlay';
import { HttpClient } from '@angular/common/http';
import { ElementalUiConfigService } from 'qbm';
import { AccountsReportsService } from '../accounts/accounts-reports.service';
import * as i0 from "@angular/core";
export declare class ReportButtonExtComponent implements OnInit {
    private readonly elementalUiConfigService;
    private readonly service;
    private readonly http;
    private readonly injector;
    private readonly overlay;
    private readonly downloadService;
    downloadOptions: EuiDownloadOptions;
    referrer: string;
    isAvailable: boolean;
    constructor(elementalUiConfigService: ElementalUiConfigService, service: AccountsReportsService, http: HttpClient, injector: Injector, overlay: Overlay, downloadService: EuiDownloadService);
    ngOnInit(): Promise<void>;
    viewReport(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReportButtonExtComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReportButtonExtComponent, "imx-report-button-ext", never, {}, {}, never, never, false, never>;
}
