import { EntityWriteDataBulk, PortalRespUnsgroup, PortalTargetsystemUnsDirectmembers, PortalTargetsystemUnsGroup, PortalTargetsystemUnsGroupServiceitem, PortalTargetsystemUnsGroupmembers, PortalTargetsystemUnsNestedmembers } from '@imx-modules/imx-api-tsb';
import { CollectionLoadParameters, DataModel, DataModelFilter, EntitySchema, FilterTreeData, TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { ClassloggerService, DataSourceToolbarExportMethod } from 'qbm';
import { DbObjectKeyBase } from '../target-system/db-object-key-wrapper.interface';
import { TargetSystemDynamicMethodService } from '../target-system/target-system-dynamic-method.service';
import { TsbApiService } from '../tsb-api-client.service';
import { GroupTypedEntity } from './group-typed-entity';
import { GetGroupsOptionalParameters, GroupsFilterTreeParameters } from './groups.models';
import * as i0 from "@angular/core";
export declare class GroupsService {
    private readonly tsbClient;
    private readonly logger;
    private readonly dynamicMethod;
    constructor(tsbClient: TsbApiService, logger: ClassloggerService, dynamicMethod: TargetSystemDynamicMethodService);
    unsGroupsSchema(isAdmin: boolean): EntitySchema;
    get UnsGroupMembersSchema(): EntitySchema;
    get UnsGroupDirectMembersSchema(): EntitySchema;
    get UnsGroupNestedMembersSchema(): EntitySchema;
    getFilterTree(options: GroupsFilterTreeParameters): Promise<FilterTreeData>;
    getGroups(navigationState: GetGroupsOptionalParameters, signal: AbortSignal): Promise<TypedEntityCollectionData<PortalTargetsystemUnsGroup>>;
    exportGroups(): DataSourceToolbarExportMethod;
    getGroupsResp(navigationState: GetGroupsOptionalParameters, signal: AbortSignal): Promise<TypedEntityCollectionData<PortalRespUnsgroup>>;
    exportGroupsResp(): DataSourceToolbarExportMethod;
    getGroupDetails(dbObjectKey: DbObjectKeyBase): Promise<GroupTypedEntity>;
    getGroupDetailsInteractive(dbObjectKey: DbObjectKeyBase, columnName: string): Promise<GroupTypedEntity>;
    getGroupServiceItem(key: string): Promise<PortalTargetsystemUnsGroupServiceitem>;
    bulkUpdateGroupServiceItems(updateData: EntityWriteDataBulk): Promise<void>;
    getGroupDirectMembers(groupId: string, navigationState: CollectionLoadParameters, signal?: AbortSignal): Promise<TypedEntityCollectionData<PortalTargetsystemUnsDirectmembers>>;
    getGroupNestedMembers(groupId: string, navigationState: CollectionLoadParameters, signal?: AbortSignal): Promise<TypedEntityCollectionData<PortalTargetsystemUnsNestedmembers>>;
    deleteGroupMembers(dbObjectKey: DbObjectKeyBase, uidAccountList: string[]): Promise<any[]>;
    getGroupsGroupMembers(groupId: string, navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemUnsGroupmembers>>;
    /** @deprecated Will be removed. Please load the data model first.*/
    getFilterOptions(forAdmin: boolean): Promise<DataModelFilter[]>;
    getDataModel(forAdmin: boolean): Promise<DataModel>;
    updateMultipleOwner(uidAccProducts: string[], uidPerson: {
        uidPerson?: string;
        uidRole?: string;
    }): Promise<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GroupsService>;
}
