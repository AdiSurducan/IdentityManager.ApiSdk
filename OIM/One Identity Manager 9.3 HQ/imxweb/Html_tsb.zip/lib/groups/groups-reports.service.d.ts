import { TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { PortalTargetsystemUnsGroup } from '@imx-modules/imx-api-tsb';
import { AppConfigService, SettingsService } from 'qbm';
import { TsbApiService } from '../tsb-api-client.service';
import * as i0 from "@angular/core";
export declare class GroupsReportsService {
    private tsbClient;
    private readonly settings;
    private appConfig;
    constructor(tsbClient: TsbApiService, settings: SettingsService, appConfig: AppConfigService);
    groupsByGroupReport(historyDays: number, groupId: string): string;
    groupsByRootReport(historyDays: number, rootId: string): string;
    groupsByContainerReport(historyDays: number, containerId: string): string;
    groupsOwnedByPersonReport(historyDays: number, personId: string): string;
    groupData(search?: string): Promise<TypedEntityCollectionData<PortalTargetsystemUnsGroup>>;
    private getDefaultDataOptions;
    private getReportUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupsReportsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GroupsReportsService>;
}
