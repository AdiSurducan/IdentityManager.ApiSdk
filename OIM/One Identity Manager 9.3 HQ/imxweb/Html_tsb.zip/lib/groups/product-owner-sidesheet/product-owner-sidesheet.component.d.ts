import { AbstractControl } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { PortalTargetsystemUnsGroupServiceitem } from '@imx-modules/imx-api-tsb';
import { IEntityColumn } from '@imx-modules/imx-qbm-dbts';
import { BaseCdr } from 'qbm';
import { OwnerControlComponent } from 'qer';
import { ProductOwnerSidesheetService } from './product-owner-sidesheet.service';
import * as i0 from "@angular/core";
export declare class ProductOwnerSidesheetComponent {
    private readonly sidesheetRef;
    productOwnerCdr: BaseCdr;
    column: IEntityColumn;
    prdOwnerControl: AbstractControl;
    ownercontrol: OwnerControlComponent;
    constructor(sidesheetRef: EuiSidesheetRef, ownerService: ProductOwnerSidesheetService, sidesheetData: PortalTargetsystemUnsGroupServiceitem);
    onFormControlCreated(control: AbstractControl): void;
    returnProductOwner(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductOwnerSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductOwnerSidesheetComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
