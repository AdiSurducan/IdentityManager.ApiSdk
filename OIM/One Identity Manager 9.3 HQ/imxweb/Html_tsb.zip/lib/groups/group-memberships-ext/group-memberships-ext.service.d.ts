import { PortalPersonGroupmemberships, portal_person_groupmemberships_get_args } from '@imx-modules/imx-api-tsb';
import { EntitySchema, ExtendedTypedEntityCollection } from '@imx-modules/imx-qbm-dbts';
import { TsbApiService } from '../../tsb-api-client.service';
import * as i0 from "@angular/core";
export declare class GroupMembershipsExtService {
    private readonly apiService;
    constructor(apiService: TsbApiService);
    get portalPersonGroupmembershipsSchema(): EntitySchema;
    getGroupMemberships(uid: string, parameters: portal_person_groupmemberships_get_args, signal: AbortSignal): Promise<ExtendedTypedEntityCollection<PortalPersonGroupmemberships, unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupMembershipsExtService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GroupMembershipsExtService>;
}
