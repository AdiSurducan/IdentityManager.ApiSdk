import { OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PortalPersonGroupmemberships } from '@imx-modules/imx-api-tsb';
import { DisplayColumns, EntitySchema, IClientProperty, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { BusyService, DataSourceToolbarSettings, DataViewSource, DynamicTabDataProviderDirective } from 'qbm';
import { GroupMembershipsExtService } from './group-memberships-ext.service';
import * as i0 from "@angular/core";
export declare class GroupMembershipsExtComponent implements OnInit {
    private readonly groupService;
    private readonly translate;
    private readonly sidesheet;
    dataSource: DataViewSource<PortalPersonGroupmemberships>;
    referrer: {
        objecttable: string;
        objectuid: string;
        tablename?: string;
    };
    dstSettings: DataSourceToolbarSettings;
    readonly DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    displayColumns: IClientProperty[];
    private displayedColumnsWithDisplay;
    private navigationState;
    busyService: BusyService;
    constructor(groupService: GroupMembershipsExtService, translate: TranslateService, sidesheet: EuiSidesheetService, dataProvider: DynamicTabDataProviderDirective, dataSource: DataViewSource<PortalPersonGroupmemberships>);
    ngOnInit(): Promise<void>;
    onShowDetails(entity: TypedEntity): Promise<void>;
    private getData;
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupMembershipsExtComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GroupMembershipsExtComponent, "ng-component", never, { "referrer": { "alias": "referrer"; "required": false; }; }, {}, never, never, false, never>;
}
