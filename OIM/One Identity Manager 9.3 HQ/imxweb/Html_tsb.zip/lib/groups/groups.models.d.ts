import { PortalTargetsystemUnsGroupServiceitem } from '@imx-modules/imx-api-tsb';
import { CollectionLoadParameters } from '@imx-modules/imx-qbm-dbts';
import { DbObjectKeyBase } from '../target-system/db-object-key-wrapper.interface';
import { GroupTypedEntity } from './group-typed-entity';
export interface GetGroupsOptionalParameters extends CollectionLoadParameters {
    uid_unsaccount?: string;
    published?: string;
    withowner?: string;
    system?: string;
    container?: string;
}
export interface GroupSidesheetData {
    uidAccProduct: string;
    unsGroupDbObjectKey: DbObjectKeyBase;
    group: GroupTypedEntity;
    groupServiceItem: PortalTargetsystemUnsGroupServiceitem;
    isAdmin?: boolean;
}
export interface GroupsFilterTreeParameters {
    container: string | undefined;
    system: string | undefined;
    uid_unsaccount: string | undefined;
    parentkey: string;
}
