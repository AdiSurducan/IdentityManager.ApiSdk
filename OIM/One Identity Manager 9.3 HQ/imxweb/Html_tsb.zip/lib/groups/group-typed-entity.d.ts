import { IEntityColumn, WriteExtTypedEntity } from '@imx-modules/imx-qbm-dbts';
export declare class GroupTypedEntity extends WriteExtTypedEntity<any> {
    getColumns(showRiskIndex: boolean, propertyList: string[]): ReadonlyArray<IEntityColumn>;
}
