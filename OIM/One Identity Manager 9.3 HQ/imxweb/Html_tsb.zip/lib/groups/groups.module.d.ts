import * as i0 from "@angular/core";
import * as i1 from "./groups.component";
import * as i2 from "./group-sidesheet/group-sidesheet.component";
import * as i3 from "./group-sidesheet/group-members/group-members.component";
import * as i4 from "./group-sidesheet/child-system-entitlements/child-system-entitlements.component";
import * as i5 from "./product-owner-sidesheet/product-owner-sidesheet.component";
import * as i6 from "./group-memberships-ext/group-memberships-ext.component";
import * as i7 from "@angular/common";
import * as i8 from "@angular/forms";
import * as i9 from "@elemental-ui/core";
import * as i10 from "qbm";
import * as i11 from "@angular/router";
import * as i12 from "qer";
import * as i13 from "@ngx-translate/core";
import * as i14 from "../data-filters/data-filters.module";
import * as i15 from "../no-data/no-data.module";
export declare class GroupsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GroupsModule, [typeof i1.DataExplorerGroupsComponent, typeof i2.GroupSidesheetComponent, typeof i3.GroupMembersComponent, typeof i4.ChildSystemEntitlementsComponent, typeof i5.ProductOwnerSidesheetComponent, typeof i6.GroupMembershipsExtComponent], [typeof i7.CommonModule, typeof i8.FormsModule, typeof i8.ReactiveFormsModule, typeof i9.EuiCoreModule, typeof i9.EuiMaterialModule, typeof i10.ExtModule, typeof i10.CdrModule, typeof i11.RouterModule, typeof i12.ObjectHyperviewModule, typeof i12.OwnerControlModule, typeof i10.BusyIndicatorModule, typeof i12.ServiceItemsEditFormModule, typeof i13.TranslateModule, typeof i10.DataSourceToolbarModule, typeof i10.DataTableModule, typeof i10.LdsReplaceModule, typeof i14.DataFiltersModule, typeof i15.NoDataModule, typeof i10.DataTreeModule, typeof i10.DynamicTabsModule, typeof i10.ObjectHistoryModule, typeof i12.IdentityRoleMembershipsModule, typeof i10.SelectedElementsModule, typeof i10.HelpContextualModule, typeof i10.DataViewModule], [typeof i1.DataExplorerGroupsComponent, typeof i4.ChildSystemEntitlementsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GroupsModule>;
}
