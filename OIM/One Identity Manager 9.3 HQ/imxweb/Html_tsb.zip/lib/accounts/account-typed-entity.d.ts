import { IEntityColumn, TypedEntity } from '@imx-modules/imx-qbm-dbts';
export declare class AccountTypedEntity extends TypedEntity {
    readonly displayColumn: IEntityColumn;
    readonly isNeverConnectManualColumn: IEntityColumn | undefined;
    readonly objectKeyManagerColumn: IEntityColumn | undefined;
    readonly uidPersonColumn: IEntityColumn | undefined;
    readonly uidADSDomain: IEntityColumn | undefined;
}
