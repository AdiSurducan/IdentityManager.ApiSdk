import { CollectionLoadParameters, DbObjectKey, FilterData } from '@imx-modules/imx-qbm-dbts';
import { AccountTypedEntity } from './account-typed-entity';
export interface AccountSidesheetData {
    unsAccountId: string;
    unsDbObjectKey: DbObjectKey;
    selectedAccount: AccountTypedEntity;
    tableName: string;
    uidPerson: string;
}
export interface GetAccountsOptionalParameters extends CollectionLoadParameters {
    orphaned?: string;
    inactive?: string;
    managerdiscrepancy?: string;
    system?: string;
    container?: string;
}
export interface AcountsFilterTreeParameters {
    parentkey: string;
    filter: FilterData[] | undefined;
}
