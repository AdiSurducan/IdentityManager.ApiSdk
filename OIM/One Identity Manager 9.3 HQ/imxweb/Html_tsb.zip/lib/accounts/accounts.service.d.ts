import { PortalTargetsystemUnsAccount } from '@imx-modules/imx-api-tsb';
import { CollectionLoadParameters, DataModel, DataModelFilter, EntitySchema, FilterTreeData, TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { DataSourceToolbarExportMethod } from 'qbm';
import { DbObjectKeyBase } from '../target-system/db-object-key-wrapper.interface';
import { TargetSystemDynamicMethodService } from '../target-system/target-system-dynamic-method.service';
import { TsbApiService } from '../tsb-api-client.service';
import { AccountTypedEntity } from './account-typed-entity';
import { AcountsFilterTreeParameters as AccountsFilterTreeParameters } from './accounts.models';
import * as i0 from "@angular/core";
export declare class AccountsService {
    private readonly tsbClient;
    private readonly dynamicMethod;
    constructor(tsbClient: TsbApiService, dynamicMethod: TargetSystemDynamicMethodService);
    get accountSchema(): EntitySchema;
    /**
     * Gets a list of accounts.
     *
     * @param navigationState Page size, start index, search and filtering options etc,.
     *
     * @returns Wrapped list of Accounts.
     */
    getAccounts(navigationState: CollectionLoadParameters, signal: AbortSignal): Promise<TypedEntityCollectionData<PortalTargetsystemUnsAccount>>;
    exportAccounts(): DataSourceToolbarExportMethod;
    getAccount(dbObjectKey: DbObjectKeyBase, columnName?: string): Promise<AccountTypedEntity>;
    getAccountInteractive(dbObjectKey: DbObjectKeyBase, columnName: string): Promise<AccountTypedEntity>;
    /** @deprecated Will be removed. Please load the data model first. */
    getFilterOptions(): Promise<DataModelFilter[]>;
    getDataModel(): Promise<DataModel>;
    getFilterTree(parameter: AccountsFilterTreeParameters): Promise<FilterTreeData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountsService>;
}
