import { TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { PortalTargetsystemUnsAccount } from '@imx-modules/imx-api-tsb';
import { AppConfigService, SettingsService } from 'qbm';
import { TsbApiService } from '../tsb-api-client.service';
import * as i0 from "@angular/core";
export declare class AccountsReportsService {
    private tsbClient;
    private readonly settings;
    private appConfig;
    constructor(tsbClient: TsbApiService, settings: SettingsService, appConfig: AppConfigService);
    accountsReport(historyDays: number, accountId: string, tableName: string): string;
    accountsOwnedByPersonReport(historyDays: number, personId: string): string;
    accountsOwnedByManagedReport(historyDays: number, personId: string): string;
    accountsByRootReport(historyDays: number, rootId: string): string;
    accountsByContainerReport(historyDays: number, containerId: string): string;
    accountData(search?: string): Promise<TypedEntityCollectionData<PortalTargetsystemUnsAccount>>;
    private getDefaultDataOptions;
    private getReportUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountsReportsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountsReportsService>;
}
