import { OnDestroy, OnInit } from '@angular/core';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { ViewConfigData } from '@imx-modules/imx-api-qer';
import { PortalTargetsystemUnsAccount } from '@imx-modules/imx-api-tsb';
import { CollectionLoadParameters, DisplayColumns, EntitySchema } from '@imx-modules/imx-qbm-dbts';
import { BusyService, ClassloggerService, DataSourceToolbarFilter, DataViewSource, SettingsService, SideNavigationComponent } from 'qbm';
import { ViewConfigService } from 'qer';
import { ContainerTreeDatabaseWrapper } from '../container-list/container-tree-database-wrapper';
import { DeHelperService } from '../de-helper.service';
import { AccountsService } from './accounts.service';
import * as i0 from "@angular/core";
export declare class DataExplorerAccountsComponent implements OnInit, OnDestroy, SideNavigationComponent {
    translateProvider: TranslateService;
    private readonly sideSheet;
    private readonly logger;
    private readonly accountsService;
    private readonly dataHelper;
    private viewConfigService;
    readonly settingsService: SettingsService;
    private readonly busyServiceElemental;
    dataSource: DataViewSource<PortalTargetsystemUnsAccount>;
    /**
     * Page size, start index, search and filtering options etc.
     */
    navigationState: CollectionLoadParameters;
    filterOptions: DataSourceToolbarFilter[];
    treeDbWrapper: ContainerTreeDatabaseWrapper;
    readonly entitySchemaUnsAccount: EntitySchema;
    readonly DisplayColumns: typeof DisplayColumns;
    data: any;
    busyService: BusyService;
    contextId: "data-explorer-accounts";
    private displayedColumns;
    private authorityDataDeleted$;
    private tableName;
    private dataModel;
    private viewConfigPath;
    private viewConfig;
    constructor(translateProvider: TranslateService, sideSheet: EuiSidesheetService, logger: ClassloggerService, accountsService: AccountsService, dataHelper: DeHelperService, viewConfigService: ViewConfigService, settingsService: SettingsService, busyServiceElemental: EuiLoadingService, dataSource: DataViewSource<PortalTargetsystemUnsAccount>);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    updateConfig(config: ViewConfigData): Promise<void>;
    deleteConfigById(id: string): Promise<void>;
    onAccountChanged(unsAccount: PortalTargetsystemUnsAccount): Promise<void>;
    openReportOptionsSidesheet(): Promise<void>;
    private viewAccount;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataExplorerAccountsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataExplorerAccountsComponent, "imx-data-explorer-accounts", never, {}, {}, never, never, false, never>;
}
