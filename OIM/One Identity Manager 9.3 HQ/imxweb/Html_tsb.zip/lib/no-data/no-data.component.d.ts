import * as i0 from "@angular/core";
export declare class DataExplorerNoDataComponent {
    mode: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataExplorerNoDataComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataExplorerNoDataComponent, "imx-data-explorer-no-data", never, { "mode": { "alias": "mode"; "required": false; }; }, {}, never, never, false, never>;
}
