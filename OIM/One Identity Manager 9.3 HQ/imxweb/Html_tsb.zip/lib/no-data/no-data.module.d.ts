import * as i0 from "@angular/core";
import * as i1 from "./no-data.component";
import * as i2 from "@angular/common";
import * as i3 from "@elemental-ui/core";
import * as i4 from "@ngx-translate/core";
export declare class NoDataModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NoDataModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NoDataModule, [typeof i1.DataExplorerNoDataComponent], [typeof i2.CommonModule, typeof i3.EuiCoreModule, typeof i4.TranslateModule], [typeof i1.DataExplorerNoDataComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NoDataModule>;
}
