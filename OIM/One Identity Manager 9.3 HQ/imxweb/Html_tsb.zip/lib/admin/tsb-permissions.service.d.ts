import { UserModelService } from 'qer';
import * as i0 from "@angular/core";
export declare class TsbPermissionsService {
    private readonly userService;
    constructor(userService: UserModelService);
    isTsbNameSpaceAdminBase(): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TsbPermissionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TsbPermissionsService>;
}
