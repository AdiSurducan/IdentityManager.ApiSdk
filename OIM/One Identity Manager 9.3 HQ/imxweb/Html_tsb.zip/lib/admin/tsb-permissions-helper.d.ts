export declare function isTsbNameSpaceAdminBase(groups: (string | undefined)[]): boolean;
