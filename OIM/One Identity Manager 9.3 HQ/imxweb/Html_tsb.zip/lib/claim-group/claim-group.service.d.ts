import { IEntityColumn } from '@imx-modules/imx-qbm-dbts';
import { BaseCdr, EntityService } from 'qbm';
import { TsbApiService } from '../tsb-api-client.service';
import * as i0 from "@angular/core";
export declare class ClaimGroupService {
    private readonly apiService;
    private readonly entityService;
    constructor(apiService: TsbApiService, entityService: EntityService);
    hasSuggestedOwners(tableName: string, key: string): Promise<boolean>;
    assignOwner(tableName: string, key: string, uidOwner: string): Promise<any>;
    getFkValue(column: IEntityColumn): {
        table: string;
        key: string;
    };
    createCdrSystemEntitlement(): BaseCdr;
    createColumnSuggestedOwner(tableName: string, key: string): IEntityColumn;
    private createColumn;
    private getOwnerCandidates;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClaimGroupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClaimGroupService>;
}
