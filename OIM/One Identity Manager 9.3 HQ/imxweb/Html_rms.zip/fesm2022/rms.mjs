import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import { V2Client, TypedClient, PortalRespEset, PortalAdminRoleEset, V2ApiClientMethodFactory, PortalPersonRolemembershipsEset } from '@imx-modules/imx-api-rms';
import { CompareOperator, FilterType, WriteExtTypedEntity, MethodDefinition } from '@imx-modules/imx-qbm-dbts';
import * as i1 from 'qbm';
import { GenericTypedEntity, HELP_CONTEXTUAL } from 'qbm';
import * as i4 from 'qer';
import { BaseMembership, isRoleAdmin, isRoleStatistics, isAuditor, RolesOverviewComponent } from 'qer';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EsetDataModel {
    api;
    constructor(api) {
        this.api = api;
    }
    async getModel(filter, isAdmin) {
        return isAdmin
            ? this.api.client.portal_admin_role_eset_datamodel_get({ filter: filter })
            : this.api.client.portal_resp_eset_datamodel_get({ filter: filter });
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EsetEntitlements {
    api;
    translator;
    entitlementFkName = 'Entitlement'; // column name in ESetHasEntitlement
    constructor(api, translator) {
        this.api = api;
        this.translator = translator;
    }
    async getCollection(id, navigationState, objectKeyForFiltering) {
        return this.api.typedClient.PortalRolesConfigEntitlementsEset.Get(id, {
            ...navigationState,
            filter: objectKeyForFiltering
                ? [
                    {
                        ColumnName: 'Entitlement',
                        CompareOp: CompareOperator.Equal,
                        Type: FilterType.Compare,
                        Value1: objectKeyForFiltering,
                    },
                ]
                : undefined,
        });
    }
    getEntitlementTypes(role) {
        return this.api.client.portal_roles_config_classes_ESet_get();
    }
    async delete(roleId, entity) {
        const esethasentl = entity.GetKeys()[0];
        await this.api.client.portal_roles_config_entitlements_ESet_delete(roleId, esethasentl);
    }
    createEntitlementAssignmentEntity(role) {
        const uidESet = role.GetKeys()[0];
        return this.api.typedClient.PortalRolesConfigEntitlementsEset.createEntity({ Columns: { UID_ESet: { Value: uidESet } } }).GetEntity();
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EsetMembership extends BaseMembership {
    api;
    session;
    translator;
    supportsDynamicMemberships = false;
    constructor(api, session, translator) {
        super(api, session, translator);
        this.api = api;
        this.session = session;
        this.translator = translator;
        this.setRoleName('ESet', 'UID_ESet');
    }
    async delete(role, identity) {
        return this.api.client.portal_roles_config_membership_ESet_delete(role, identity);
    }
    hasPrimaryMemberships() {
        return false;
    }
    getPrimaryMembers(uid, navigationstate) {
        throw new Error('System roles do not allow primary memberships.');
    }
    getPrimaryMembersSchema() {
        throw new Error('System roles do not allow primary memberships.');
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestableSystemRoleType {
    dynamicMethodService;
    rmsApi;
    constructor(dynamicMethodService, rmsApi) {
        this.dynamicMethodService = dynamicMethodService;
        this.rmsApi = rmsApi;
        this.schema = this.createAssignmentEntity('dummy').GetEntity().GetSchema();
    }
    getTableName() {
        return 'ESet';
    }
    getFkColumnName() {
        return 'UID_ESet';
    }
    schema;
    getSchema() {
        return this.schema;
    }
    addEntitlementSelections(shelfId, values) {
        const promises = [];
        values.forEach((value) => {
            const e = this.createAssignmentEntity(shelfId).GetEntity();
            promises.push(e
                .GetColumn(this.getFkColumnName())
                .PutValue(value)
                .then(() => e.Commit()));
        });
        return Promise.all(promises);
    }
    createAssignmentEntity(shelfId) {
        const entityColl = this.dynamicMethodService.createEntity(this.rmsApi.apiClient, {
            path: '/portal/shop/config/entitlements/' + shelfId + '/' + this.getTableName(),
            type: GenericTypedEntity,
            schemaPath: 'portal/shop/config/entitlements/{UID_ITShopOrg}/' + this.getTableName(),
        }, {
            Columns: {
                UID_ITShopOrg: {
                    Value: shelfId,
                },
            },
        });
        return entityColl.Data[0];
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RmsApiService {
    config;
    logger;
    entlTypeService;
    dynamicMethodService;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, entlTypeService, dynamicMethodService, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.entlTypeService = entlTypeService;
        this.dynamicMethodService = dynamicMethodService;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing RMS API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
            this.entlTypeService.Register(() => this.GetSystemRoleType());
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    async GetSystemRoleType() {
        var types = [];
        types.push(new RequestableSystemRoleType(this.dynamicMethodService, this));
        return types;
    }
    static ɵfac = function RmsApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RmsApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i4.RequestableEntitlementTypeService), i0.ɵɵinject(i1.DynamicMethodService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RmsApiService, factory: RmsApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RmsApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i4.RequestableEntitlementTypeService }, { type: i1.DynamicMethodService }, { type: i1.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    router;
    api;
    session;
    translator;
    dataExplorerRegistryService;
    menuService;
    roleService;
    identityRoleMembershipService;
    myResponsibilitiesRegistryService;
    esetTag = 'ESet';
    constructor(router, api, session, translator, dataExplorerRegistryService, menuService, roleService, identityRoleMembershipService, myResponsibilitiesRegistryService) {
        this.router = router;
        this.api = api;
        this.session = session;
        this.translator = translator;
        this.dataExplorerRegistryService = dataExplorerRegistryService;
        this.menuService = menuService;
        this.roleService = roleService;
        this.identityRoleMembershipService = identityRoleMembershipService;
        this.myResponsibilitiesRegistryService = myResponsibilitiesRegistryService;
    }
    onInit(routes) {
        this.addRoutes(routes);
        // wrapper class for interactive methods
        // eslint-disable-next-line max-classes-per-file
        class ApiWrapper {
            getByIdApi;
            constructor(getByIdApi) {
                this.getByIdApi = getByIdApi;
            }
            async Get() {
                if (!this.getByIdApi.Get) {
                    throw new Error('Creation of new system roles is not yet supported.');
                }
                const data = await this.getByIdApi.Get();
                const result = {
                    ...data,
                    Data: data.Data.map((d) => new WriteExtTypedEntity(d.GetEntity())),
                };
                return result;
            }
            GetSchema() {
                return this.getByIdApi.GetSchema();
            }
            async Get_byid(id) {
                const data = await this.getByIdApi.Get_byid(id);
                const result = {
                    ...data,
                    Data: data.Data.map((d) => new WriteExtTypedEntity(d.GetEntity())),
                };
                return result;
            }
        }
        this.roleService.targetMap.set(this.esetTag, {
            canBeSplitTarget: false,
            canBeSplitSource: false,
            table: this.esetTag,
            respType: PortalRespEset,
            resp: this.api.typedClient.PortalRespEset,
            adminType: PortalAdminRoleEset,
            admin: {
                get: async (parameter) => this.api.client.portal_admin_role_eset_get({
                    OrderBy: parameter.OrderBy,
                    StartIndex: parameter.StartIndex,
                    PageSize: parameter.PageSize,
                    filter: parameter.filter,
                    search: parameter.search,
                    risk: parameter.risk,
                    esettype: parameter.esettype,
                    withProperties: parameter.withProperties,
                }),
            },
            adminSchema: this.api.typedClient.PortalAdminRoleEset.GetSchema(),
            dataModel: new EsetDataModel(this.api),
            adminCanCreate: async () => {
                return (await this.api.client.portal_roles_config_systemroles_get()).EnableNewESet;
            },
            respCanCreate: async () => {
                return (await this.api.client.portal_roles_config_systemroles_get()).EnableNewESet;
            },
            interactiveResp: new ApiWrapper(this.api.typedClient.PortalRespEsetInteractive),
            interactiveAdmin: new ApiWrapper(this.api.typedClient.PortalAdminRoleEsetInteractive),
            entitlements: new EsetEntitlements(this.api, this.translator),
            membership: new EsetMembership(this.api, this.session, this.translator),
            canUseRecommendations: true,
            exportMethod: (isAdmin) => {
                const factory = new V2ApiClientMethodFactory();
                return {
                    getMethod: (withProperties, navigationState, PageSize) => {
                        let method;
                        if (PageSize) {
                            method = isAdmin
                                ? factory.portal_admin_role_eset_get({ ...navigationState, withProperties, PageSize, StartIndex: 0 })
                                : factory.portal_resp_eset_get({ ...navigationState, withProperties, PageSize, StartIndex: 0 });
                        }
                        else {
                            method = isAdmin
                                ? factory.portal_admin_role_eset_get({ ...navigationState, withProperties })
                                : factory.portal_resp_eset_get({ ...navigationState, withProperties });
                        }
                        return new MethodDefinition(method);
                    },
                };
            },
            translateKeys: {
                create: '#LDS#Create system role',
                createHeading: '#LDS#Heading Create System Role',
                editHeading: '#LDS#Heading Edit System Role',
                createSnackbar: '#LDS#The system role has been successfully created.',
            },
            adminHelpContextId: HELP_CONTEXTUAL.DataExplorerSystemRolesRoleEntitlements,
            respHelpContextId: HELP_CONTEXTUAL.MyResponsibilitiesSystemRolesRoleEntitlements,
        });
        this.identityRoleMembershipService.addTarget({
            table: this.esetTag,
            type: PortalPersonRolemembershipsEset,
            entitySchema: this.api.typedClient.PortalPersonRolemembershipsEset.GetSchema(),
            controlInfo: {
                label: '#LDS#Menu Entry System roles',
                index: 80,
            },
            get: async (uidPerson, parameter) => this.api.client.portal_person_rolememberships_ESet_get(uidPerson, parameter),
            withAnalysis: true,
        });
        this.setupMenu();
        this.dataExplorerRegistryService.registerFactory((preProps, features, projectConfig, groups) => {
            if (!isRoleAdmin(features) && !isRoleStatistics(features) && !isAuditor(groups)) {
                return undefined;
            }
            return {
                instance: RolesOverviewComponent,
                data: {
                    TableName: this.esetTag,
                    Count: 0,
                },
                contextId: HELP_CONTEXTUAL.DataExplorerSystemRoles,
                sortOrder: 8,
                name: 'systemroles',
                caption: '#LDS#Menu Entry System roles',
            };
        });
        this.myResponsibilitiesRegistryService.registerFactory((preProps, features) => ({
            instance: RolesOverviewComponent,
            sortOrder: 8,
            name: this.esetTag,
            caption: '#LDS#Menu Entry System roles',
            data: {
                TableName: this.esetTag,
                Count: 0,
            },
            contextId: HELP_CONTEXTUAL.MyResponsibilitiesSystemRoles,
        }));
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features, projectConfig, groups) => {
            if (!isRoleAdmin(features) && !isRoleStatistics(features) && !isAuditor(groups)) {
                return undefined;
            }
            return {
                id: 'ROOT_Data',
                title: '#LDS#Data administration',
                sorting: '40',
                items: [
                    {
                        id: 'QER_DataExplorer',
                        navigationCommands: { commands: ['admin', 'dataexplorer'] },
                        title: '#LDS#Menu Entry Data Explorer',
                        sorting: '40-10',
                    },
                ],
            };
        });
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i1$1.Router), i0.ɵɵinject(RmsApiService), i0.ɵɵinject(i1.imx_SessionService), i0.ɵɵinject(i1.ImxTranslationProviderService), i0.ɵɵinject(i4.DataExplorerRegistryService), i0.ɵɵinject(i1.MenuService), i0.ɵɵinject(i4.RoleService), i0.ɵɵinject(i4.IdentityRoleMembershipsService), i0.ɵɵinject(i4.MyResponsibilitiesRegistryService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i1$1.Router }, { type: RmsApiService }, { type: i1.imx_SessionService }, { type: i1.ImxTranslationProviderService }, { type: i4.DataExplorerRegistryService }, { type: i1.MenuService }, { type: i4.RoleService }, { type: i4.IdentityRoleMembershipsService }, { type: i4.MyResponsibilitiesRegistryService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [];
class RmsConfigModule {
    initializer;
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 RMS loaded');
        this.initializer.onInit(routes);
        console.log('▶️ RMS initialized');
    }
    static ɵfac = function RmsConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RmsConfigModule)(i0.ɵɵinject(InitService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RmsConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [RouterModule.forChild(routes)] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RmsConfigModule, [{
        type: NgModule,
        args: [{
                imports: [RouterModule.forChild(routes)],
            }]
    }], () => [{ type: InitService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RmsConfigModule, { imports: [i1$1.RouterModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of rms
 */

/**
 * Generated bundle index. Do not edit.
 */

export { RmsConfigModule };
//# sourceMappingURL=rms.mjs.map
