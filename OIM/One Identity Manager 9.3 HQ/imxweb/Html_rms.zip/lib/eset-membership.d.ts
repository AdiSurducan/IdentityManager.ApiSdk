import { CollectionLoadParameters, EntityCollectionData, EntitySchema, ExtendedTypedEntityCollection, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { ImxTranslationProviderService, imx_SessionService } from 'qbm';
import { BaseMembership } from 'qer';
import { RmsApiService } from './rms-api-client.service';
export declare class EsetMembership extends BaseMembership {
    private readonly api;
    private readonly session;
    private readonly translator;
    supportsDynamicMemberships: boolean;
    constructor(api: RmsApiService, session: imx_SessionService, translator: ImxTranslationProviderService);
    delete(role: string, identity: string): Promise<EntityCollectionData>;
    hasPrimaryMemberships(): boolean;
    getPrimaryMembers(uid: string, navigationstate: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<TypedEntity, any>>;
    getPrimaryMembersSchema(): EntitySchema;
}
