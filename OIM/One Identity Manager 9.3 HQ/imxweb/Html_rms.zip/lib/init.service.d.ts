import { Route, Router } from '@angular/router';
import { ImxTranslationProviderService, MenuService, imx_SessionService } from 'qbm';
import { DataExplorerRegistryService, IdentityRoleMembershipsService, MyResponsibilitiesRegistryService, RoleService } from 'qer';
import { RmsApiService } from './rms-api-client.service';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly router;
    private readonly api;
    private readonly session;
    private readonly translator;
    private readonly dataExplorerRegistryService;
    private readonly menuService;
    private readonly roleService;
    private readonly identityRoleMembershipService;
    private readonly myResponsibilitiesRegistryService;
    private esetTag;
    constructor(router: Router, api: RmsApiService, session: imx_SessionService, translator: ImxTranslationProviderService, dataExplorerRegistryService: DataExplorerRegistryService, menuService: MenuService, roleService: RoleService, identityRoleMembershipService: IdentityRoleMembershipsService, myResponsibilitiesRegistryService: MyResponsibilitiesRegistryService);
    onInit(routes: Route[]): void;
    private setupMenu;
    private addRoutes;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
