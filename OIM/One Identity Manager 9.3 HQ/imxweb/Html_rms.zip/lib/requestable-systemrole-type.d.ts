import { EntitySchema, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { DynamicMethodService } from 'qbm';
import { IRequestableEntitlementType } from 'qer';
import { RmsApiService } from './rms-api-client.service';
export declare class RequestableSystemRoleType implements IRequestableEntitlementType {
    private readonly dynamicMethodService;
    private readonly rmsApi;
    constructor(dynamicMethodService: DynamicMethodService, rmsApi: RmsApiService);
    getTableName(): string;
    getFkColumnName(): string;
    private schema;
    getSchema(): EntitySchema;
    addEntitlementSelections(shelfId: string, values: string[]): Promise<any>;
    createAssignmentEntity(shelfId: string): TypedEntity;
}
