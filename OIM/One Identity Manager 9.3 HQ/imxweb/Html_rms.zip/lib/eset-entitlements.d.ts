import { RoleAssignmentData } from '@imx-modules/imx-api-qer';
import { CollectionLoadParameters, ExtendedTypedEntityCollection, IEntity, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { ImxTranslationProviderService } from 'qbm';
import { IRoleEntitlements } from 'qer';
import { RmsApiService } from './rms-api-client.service';
export declare class EsetEntitlements implements IRoleEntitlements {
    private readonly api;
    protected readonly translator: ImxTranslationProviderService;
    entitlementFkName: string;
    constructor(api: RmsApiService, translator: ImxTranslationProviderService);
    getCollection(id: string, navigationState?: CollectionLoadParameters, objectKeyForFiltering?: string): Promise<ExtendedTypedEntityCollection<TypedEntity, unknown>>;
    getEntitlementTypes(role: IEntity): Promise<RoleAssignmentData[]>;
    delete(roleId: string, entity: IEntity): Promise<void>;
    createEntitlementAssignmentEntity(role: IEntity): IEntity;
}
