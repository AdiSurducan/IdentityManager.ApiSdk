import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/router";
export declare class RmsConfigModule {
    private readonly initializer;
    constructor(initializer: InitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<RmsConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RmsConfigModule, never, [typeof i1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RmsConfigModule>;
}
