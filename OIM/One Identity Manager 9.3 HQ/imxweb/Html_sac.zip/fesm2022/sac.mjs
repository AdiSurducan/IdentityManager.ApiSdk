import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, Input, ViewChild, NgModule } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import * as i1$1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i1 from 'qbm';
import { DataSourceToolbarModule, DataTableModule, DataTreeWrapperModule } from 'qbm';
import { V2Client, TypedClient } from '@imx-modules/imx-api-sac';
import * as i3 from '@elemental-ui/core';
import { EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i4$1 from '@angular/material/core';
import * as i5$1 from '@angular/material/chips';
import { MatChipsModule } from '@angular/material/chips';
import * as i6$1 from '@angular/material/form-field';
import * as i7$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i8$1 from '@angular/material/select';
import { TypedEntity, ValType, DisplayColumns, TypedEntityBuilder } from '@imx-modules/imx-qbm-dbts';
import * as i4 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import { FlatTreeControl } from '@angular/cdk/tree';
import { FormControl } from '@angular/forms';
import * as i6 from '@angular/material/sort';
import { MatSort, MatSortModule } from '@angular/material/sort';
import * as i7 from '@angular/material/table';
import { MatTableDataSource } from '@angular/material/table';
import { MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';
import * as i3$1 from '@angular/material/button';
import * as i5 from '@angular/material/icon';
import * as i8 from '@angular/material/tooltip';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SapComplianceApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function SapComplianceApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SapComplianceApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: SapComplianceApiService, factory: SapComplianceApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SapComplianceApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i1.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
var SapSelectionTypeEnum;
(function (SapSelectionTypeEnum) {
    SapSelectionTypeEnum["ROLE"] = "ROLE";
    SapSelectionTypeEnum["ABILITY"] = "ABILITY";
})(SapSelectionTypeEnum || (SapSelectionTypeEnum = {}));

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SapComplianceByAbilityEntity extends TypedEntity {
    Ident_SAPProfile = this.GetEntityValue('Ident_SAPProfile');
    Ident_SAPAuthObject = this.GetEntityValue('Ident_SAPAuthObject');
    Ident_SAPField = this.GetEntityValue('Ident_SAPField');
    LowerLimit = this.GetEntityValue('LowerLimit');
    UpperLimit = this.GetEntityValue('UpperLimit');
    UID_SAPFunctionInstance = this.GetEntityValue('UID_SAPFunctionInstance');
    DisplaySapFunctionInstance = this.GetEntityValue('DisplaySapFunctionInstance');
    DisplaySapTransaction = this.GetEntityValue('DisplaySapTransaction');
    static GetEntitySchema() {
        const columns = {
            Ident_SAPProfile: {
                Type: ValType.String,
                ColumnName: 'Ident_SAPProfile',
            },
            Ident_SAPAuthObject: {
                Type: ValType.String,
                ColumnName: 'Ident_SAPAuthObject',
            },
            Ident_SAPField: {
                Type: ValType.String,
                ColumnName: 'Ident_SAPField',
            },
            LowerLimit: {
                Type: ValType.String,
                ColumnName: 'LowerLimit',
            },
            UpperLimit: {
                Type: ValType.String,
                ColumnName: 'UpperLimit',
            },
            UID_SAPFunctionInstance: {
                Type: ValType.String,
                ColumnName: 'UID_SAPFunctionInstance',
            },
            DisplaySapFunctionInstance: {
                Type: ValType.String,
                ColumnName: 'DisplaySapFunctionInstance',
            },
            DisplaySapTransaction: {
                Type: ValType.String,
                ColumnName: 'DisplaySapTransaction',
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        return { Columns: columns };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SapComplianceByAbilityBuilder {
    entitySchema = SapComplianceByAbilityEntity.GetEntitySchema();
    builder = new TypedEntityBuilder(SapComplianceByAbilityEntity);
    build(entityCollectionData) {
        return this.builder.buildReadWriteEntities(entityCollectionData, this.entitySchema);
    }
    buildEntityCollectionData(items) {
        const entities = items.map((elem) => this.buildEntityData(elem));
        return { Entities: entities, TotalCount: items.length };
    }
    buildEntityData(item) {
        return {
            Columns: {
                Ident_SAPProfile: { Value: item.Ident_SAPProfile },
                Ident_SAPAuthObject: { Value: item.Ident_SAPAuthObject },
                Ident_SAPField: { Value: item.Ident_SAPField },
                LowerLimit: { Value: item.LowerLimit },
                UpperLimit: { Value: item.UpperLimit },
                DisplaySapFunctionInstance: { Value: item.DisplaySapFunctionInstance },
                DisplaySapTransaction: { Value: item.DisplaySapTransaction },
                UID_SAPFunctionInstance: { Value: item.UID_SAPFunctionInstance },
            },
            Keys: [
                'Ident_SAPProfile',
                'Ident_SAPAuthObject',
                'Ident_SAPField',
                'LowerLimit',
                'UpperLimit',
                'DisplaySapFunctionInstance',
                'DisplaySapTransaction',
                'UID_SAPFunctionInstance',
            ],
        };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$1 = () => ["search", "groupBy"];
function SapComplianceViolationViewsByAbilityComponent_div_18_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8);
    i0.ɵɵelement(1, "eui-icon", 9);
    i0.ɵɵelementStart(2, "p");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("icon", "table");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#No data"));
} }
class SapComplianceViolationViewsByAbilityComponent {
    translateService;
    set resultByAbility(value) {
        this._resultByAbility = value;
        if (!!value?.Data) {
            this.buildDataSource(value.Data);
        }
    }
    get resultByAbility() {
        return this._resultByAbility;
    }
    _resultByAbility = { Data: [] };
    dstSettings;
    entitySchema;
    dataSource;
    groupData = {};
    defaultData;
    sapComplianceByAbilityBuilder = new SapComplianceByAbilityBuilder();
    constructor(translateService) {
        this.translateService = translateService;
        this.entitySchema = SapComplianceByAbilityEntity.GetEntitySchema();
    }
    /**
     * Called when search action is emitted.
     * @param searchValue current search param
     */
    onSearch(searchValue) {
        if (searchValue) {
            searchValue = searchValue.toLocaleLowerCase();
            const Data = this.defaultData.filter((profile) => profile.Ident_SAPProfile.value.toLocaleLowerCase().includes(searchValue) ||
                profile.Ident_SAPAuthObject.value.toLocaleLowerCase().includes(searchValue) ||
                profile.Ident_SAPField.value.toLocaleLowerCase().includes(searchValue) ||
                profile.LowerLimit.value.toLocaleLowerCase().includes(searchValue) ||
                profile.UpperLimit.value.toLocaleLowerCase().includes(searchValue));
            this.dstSettings.dataSource = {
                Data,
                totalCount: Data.length,
            };
        }
        else {
            this.dstSettings.dataSource = {
                Data: this.defaultData,
                totalCount: this.defaultData.length,
            };
        }
        this.dstSettings = { ...this.dstSettings, navigationState: { ...this.dstSettings.navigationState, search: searchValue } };
    }
    /**
     * Updates the selected group data. Called when group action is emitted.
     * @param groupKey selected grouping key
     */
    onGroupingChange(groupKey) {
        const groupedData = this.groupData[groupKey];
        if (groupedData.navigationState?.filter) {
            groupedData.data = this.getFilteredData(groupedData.navigationState.filter[0]);
        }
        groupedData.settings = {
            displayedColumns: this.dstSettings.displayedColumns,
            dataModel: this.dstSettings.dataModel,
            dataSource: {
                Data: groupedData.data,
                totalCount: groupedData.data.length,
            },
            entitySchema: this.dstSettings.entitySchema,
            navigationState: groupedData.navigationState ?? {},
        };
    }
    /**
     * Called when navigaiton state changed. Here is called when search badge is removed.
     */
    onNavigationStateChanged(params) {
        this.onSearch(params.search);
    }
    /**
     * Build the data source and the data source toolbar settings.
     */
    buildDataSource(items) {
        this.dataSource = this.sapComplianceByAbilityBuilder.build(this.sapComplianceByAbilityBuilder.buildEntityCollectionData(items));
        this.defaultData = this.dataSource.Data;
        this.dstSettings = {
            dataSource: this.dataSource,
            entitySchema: this.entitySchema,
            navigationState: {},
            displayedColumns: [
                this.entitySchema.Columns.Ident_SAPProfile,
                this.entitySchema.Columns.Ident_SAPAuthObject,
                this.entitySchema.Columns.Ident_SAPField,
                this.entitySchema.Columns.LowerLimit,
                this.entitySchema.Columns.UpperLimit,
                this.entitySchema.Columns.DisplaySapFunctionInstance,
            ],
            groupData: this.createGroupData(),
        };
    }
    /**
     * Creating data source toolbar group setting.
     * @returns Data source toolbar group setting.
     */
    createGroupData() {
        const groups = [
            {
                property: {
                    Property: {
                        Type: ValType.String,
                        ColumnName: 'DisplaySapFunctionInstance',
                    },
                    Display: this.translateService.instant('#LDS#SAP function instance'),
                },
                getData: async () => await this.groupingData('DisplaySapFunctionInstance'),
            },
            {
                property: {
                    Property: {
                        Type: ValType.String,
                        ColumnName: 'DisplaySapTransaction',
                    },
                    Display: this.translateService.instant('#LDS#SAP transaction'),
                },
                getData: async () => await this.groupingData('DisplaySapTransaction'),
            },
        ];
        return { groups };
    }
    /**
     * The method generating the group info data from the group column key.
     * @param groupColumn
     * @returns Generated group info data.
     */
    async groupingData(groupColumn) {
        const Groups = [];
        this.dataSource.Data?.map((item, index) => {
            if (Groups.every((groupItem) => item[groupColumn].value !== (groupItem?.Display?.[0]?.Display ?? ''))) {
                const groupItems = this.dataSource.Data.filter((row) => row[groupColumn].value === item[groupColumn].value);
                Groups.push({
                    Display: [{ Display: item[groupColumn].value }],
                    Filters: [{ ColumnName: groupColumn, Values: groupItems.map((groupItem) => groupItem[groupColumn].value) }],
                    Count: groupItems.length,
                });
            }
        });
        return {
            TotalCount: Groups.length,
            Groups,
        };
    }
    /**
     * The method filter the data source with the filter column name.
     * @param filter
     * @returns Filtered data source.
     */
    getFilteredData(filter) {
        return this.dataSource.Data.filter((dataRow) => (filter?.Values?.indexOf(dataRow?.[filter.ColumnName ?? '']?.value) ?? -1) >= 0);
    }
    static ɵfac = function SapComplianceViolationViewsByAbilityComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SapComplianceViolationViewsByAbilityComponent)(i0.ɵɵdirectiveInject(i1$1.TranslateService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SapComplianceViolationViewsByAbilityComponent, selectors: [["imx-sap-compliance-violation-views-by-ability"]], inputs: { resultByAbility: "resultByAbility" }, decls: 19, vars: 36, consts: [["dst", ""], [1, "sap-analysis"], [1, "sap-analysis__table"], ["data-imx-identifier", "role-recommendation-result-data-source-toolbar", 3, "search", "navigationStateChanged", "settings", "options"], [1, "imx-data-table-container"], ["data-imx-identifier", "role-recommendation-result-data-table", 3, "groupDataChanged", "selectable", "showSelectionInfo", "showSelectedItemsMenu", "showGroupPaginator", "dst", "groupData", "mode", "detailViewVisible"], [3, "entityColumn", "columnLabel"], ["class", "no-results", 4, "ngIf"], [1, "no-results"], [3, "icon"]], template: function SapComplianceViolationViewsByAbilityComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "mat-card", 1)(1, "div", 2)(2, "imx-data-source-toolbar", 3, 0);
            i0.ɵɵlistener("search", function SapComplianceViolationViewsByAbilityComponent_Template_imx_data_source_toolbar_search_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSearch($event)); })("navigationStateChanged", function SapComplianceViolationViewsByAbilityComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onNavigationStateChanged($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "div", 4)(5, "imx-data-table", 5);
            i0.ɵɵlistener("groupDataChanged", function SapComplianceViolationViewsByAbilityComponent_Template_imx_data_table_groupDataChanged_5_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onGroupingChange($event)); });
            i0.ɵɵelement(6, "imx-data-table-column", 6);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelement(8, "imx-data-table-column", 6);
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵelement(10, "imx-data-table-column", 6);
            i0.ɵɵpipe(11, "translate");
            i0.ɵɵelement(12, "imx-data-table-column", 6);
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelement(14, "imx-data-table-column", 6);
            i0.ɵɵpipe(15, "translate");
            i0.ɵɵelement(16, "imx-data-table-column", 6);
            i0.ɵɵpipe(17, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(18, SapComplianceViolationViewsByAbilityComponent_div_18_Template, 5, 4, "div", 7);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            const dst_r2 = i0.ɵɵreference(3);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(35, _c0$1));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("selectable", false)("showSelectionInfo", false)("showSelectedItemsMenu", false)("showGroupPaginator", false)("dst", dst_r2)("groupData", ctx.groupData)("mode", "manual")("detailViewVisible", false);
            i0.ɵɵadvance();
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.Ident_SAPProfile)("columnLabel", i0.ɵɵpipeBind1(7, 23, "#LDS#Authentication"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.Ident_SAPAuthObject)("columnLabel", i0.ɵɵpipeBind1(9, 25, "#LDS#Object"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.Ident_SAPField)("columnLabel", i0.ɵɵpipeBind1(11, 27, "#LDS#Field"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.LowerLimit)("columnLabel", i0.ɵɵpipeBind1(13, 29, "#LDS#Lower limit"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UpperLimit)("columnLabel", i0.ɵɵpipeBind1(15, 31, "#LDS#Upper limit"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.DisplaySapFunctionInstance)("columnLabel", i0.ɵɵpipeBind1(17, 33, "#LDS#SAP function instance"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.dataSource.Data.length == 0);
        } }, dependencies: [i2.NgIf, i3.EuiIconComponent, i4.MatCard, i1.DataSourceToolbarComponent, i1.DataTableComponent, i1.DataTableColumnComponent, i1$1.TranslatePipe], styles: [".sap-analysis[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%;justify-content:space-between;gap:16px}.sap-analysis__table[_ngcontent-%COMP%]{overflow:hidden auto;flex-grow:1}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SapComplianceViolationViewsByAbilityComponent, [{
        type: Component,
        args: [{ selector: 'imx-sap-compliance-violation-views-by-ability', template: "<mat-card class=\"sap-analysis\">\n  <div class=\"sap-analysis__table\">\n    <imx-data-source-toolbar\n      #dst\n      data-imx-identifier=\"role-recommendation-result-data-source-toolbar\"\n      [settings]=\"dstSettings\"\n      [options]=\"['search', 'groupBy']\"\n      (search)=\"onSearch($event)\"\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\"\n    >\n    </imx-data-source-toolbar>\n    <div class=\"imx-data-table-container\">\n      <imx-data-table\n        [selectable]=\"false\"\n        [showSelectionInfo]=\"false\"\n        [showSelectedItemsMenu]=\"false\"\n        [showGroupPaginator]=\"false\"\n        [dst]=\"dst\"\n        [groupData]=\"groupData\"\n        [mode]=\"'manual'\"\n        data-imx-identifier=\"role-recommendation-result-data-table\"\n        [detailViewVisible]=\"false\"\n        (groupDataChanged)=\"onGroupingChange($event)\"\n      >\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.Ident_SAPProfile\" [columnLabel]=\"'#LDS#Authentication' | translate\">\n        </imx-data-table-column>\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.Ident_SAPAuthObject\" [columnLabel]=\"'#LDS#Object' | translate\">\n        </imx-data-table-column>\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.Ident_SAPField\" [columnLabel]=\"'#LDS#Field' | translate\">\n        </imx-data-table-column>\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.LowerLimit\" [columnLabel]=\"'#LDS#Lower limit' | translate\">\n        </imx-data-table-column>\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UpperLimit\" [columnLabel]=\"'#LDS#Upper limit' | translate\">\n        </imx-data-table-column>\n        <imx-data-table-column\n          [entityColumn]=\"entitySchema.Columns.DisplaySapFunctionInstance\"\n          [columnLabel]=\"'#LDS#SAP function instance' | translate\"\n        >\n        </imx-data-table-column>\n      </imx-data-table>\n    </div>\n    <div *ngIf=\"dataSource.Data.length == 0\" class=\"no-results\">\n      <eui-icon [icon]=\"'table'\"></eui-icon>\n      <p>{{ '#LDS#No data' | translate }}</p>\n    </div>\n  </div>\n</mat-card>\n", styles: [".sap-analysis{display:flex;flex-direction:column;height:100%;justify-content:space-between;gap:16px}.sap-analysis__table{overflow:hidden auto;flex-grow:1}\n"] }]
    }], () => [{ type: i1$1.TranslateService }], { resultByAbility: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SapComplianceViolationViewsByAbilityComponent, { className: "SapComplianceViolationViewsByAbilityComponent", filePath: "lib\\sap-compliance-violation\\sap-compliance-violation-views-by-ability\\sap-compliance-violation-views-by-ability.component.ts", lineNumber: 47 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0 = a0 => ({ "mat-mdc-card--decreased": a0 });
const _c1 = a0 => ({ "sap-analysis-table-row-highlighted": a0 });
function SapComplianceViolationViewsByRoleComponent_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 8);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵlistener("click", function SapComplianceViolationViewsByRoleComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.toggleRoleExpand()); });
    i0.ɵɵelement(2, "eui-icon", 9);
    i0.ɵɵelementStart(3, "h3");
    i0.ɵɵtext(4, "SAP Analysis Roles");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 1, ctx_r1.extendRole ? "#LDS#Hide roles" : "#LDS#Show roles"));
} }
function SapComplianceViolationViewsByRoleComponent_table_8_th_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 19)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("padding-left", 40, "px");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 3, "#LDS#Group name"));
} }
function SapComplianceViolationViewsByRoleComponent_table_8_td_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "td", 20)(1, "button", 21);
    i0.ɵɵlistener("click", function SapComplianceViolationViewsByRoleComponent_table_8_td_3_Template_button_click_1_listener() { const data_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.treeControl.toggle(data_r4)); });
    i0.ɵɵelementStart(2, "mat-icon", 22);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r4 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("visibility", !data_r4.expandable ? "hidden" : "")("margin-left", data_r4.level * 16, "px");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r1.treeControl.isExpanded(data_r4) ? "expand_more" : "chevron_right", " ");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", data_r4.GroupName, " ");
} }
function SapComplianceViolationViewsByRoleComponent_table_8_th_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 19);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Description"));
} }
function SapComplianceViolationViewsByRoleComponent_table_8_td_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 23)(1, "span", 24);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const data_r5 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵpropertyInterpolate("title", data_r5.Description);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(data_r5.Description);
} }
function SapComplianceViolationViewsByRoleComponent_table_8_th_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 19);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Group type"));
} }
function SapComplianceViolationViewsByRoleComponent_table_8_td_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r6 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(data_r6.GroupType);
} }
function SapComplianceViolationViewsByRoleComponent_table_8_tr_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "tr", 25);
} }
function SapComplianceViolationViewsByRoleComponent_table_8_tr_11_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "tr", 26);
    i0.ɵɵlistener("click", function SapComplianceViolationViewsByRoleComponent_table_8_tr_11_Template_tr_click_0_listener() { const row_r8 = i0.ɵɵrestoreView(_r7).$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.updateProfiles(row_r8)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r8 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(1, _c1, ctx_r1.hasProfiles(row_r8)));
} }
function SapComplianceViolationViewsByRoleComponent_table_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "table", 10);
    i0.ɵɵelementContainerStart(1, 11);
    i0.ɵɵtemplate(2, SapComplianceViolationViewsByRoleComponent_table_8_th_2_Template, 4, 5, "th", 12)(3, SapComplianceViolationViewsByRoleComponent_table_8_td_3_Template, 5, 6, "td", 13);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(4, 14);
    i0.ɵɵtemplate(5, SapComplianceViolationViewsByRoleComponent_table_8_th_5_Template, 3, 3, "th", 12)(6, SapComplianceViolationViewsByRoleComponent_table_8_td_6_Template, 3, 2, "td", 15);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(7, 16);
    i0.ɵɵtemplate(8, SapComplianceViolationViewsByRoleComponent_table_8_th_8_Template, 3, 3, "th", 12)(9, SapComplianceViolationViewsByRoleComponent_table_8_td_9_Template, 2, 1, "td", 15);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵtemplate(10, SapComplianceViolationViewsByRoleComponent_table_8_tr_10_Template, 1, 0, "tr", 17)(11, SapComplianceViolationViewsByRoleComponent_table_8_tr_11_Template, 1, 3, "tr", 18);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("dataSource", ctx_r1.dataSource);
    i0.ɵɵadvance(10);
    i0.ɵɵproperty("matHeaderRowDef", ctx_r1.displayedColumns)("matHeaderRowDefSticky", true);
    i0.ɵɵadvance();
    i0.ɵɵproperty("matRowDefColumns", ctx_r1.displayedColumns);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_th_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Authentication"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_td_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r10 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(data_r10.Ident_SAPProfile);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_th_19_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Objects"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_td_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r11 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(data_r11.Objects);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_th_22_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Field"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_td_23_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r12 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(data_r12.Field);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_th_25_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#From"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_td_26_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r13 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(data_r13.LowerLimit);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_th_28_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#To"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_td_29_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r14 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(data_r14.UpperLimit);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_tr_30_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "tr", 25);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_tr_31_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "tr", 40);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_div_32_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 41);
    i0.ɵɵelement(1, "eui-icon", 42);
    i0.ɵɵelementStart(2, "p");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("icon", "table");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#No data"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_9_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 1)(1, "div", 2)(2, "button", 8);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵlistener("click", function SapComplianceViolationViewsByRoleComponent_mat_card_9_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r9); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.toggleProfilesExpand()); });
    i0.ɵɵelement(4, "eui-icon", 27);
    i0.ɵɵelementStart(5, "h3");
    i0.ɵɵtext(6);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(8, "h3", 28);
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(11, "eui-search", 29);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵelementStart(13, "div", 5)(14, "table", 30);
    i0.ɵɵelementContainerStart(15, 31);
    i0.ɵɵtemplate(16, SapComplianceViolationViewsByRoleComponent_mat_card_9_th_16_Template, 3, 3, "th", 32)(17, SapComplianceViolationViewsByRoleComponent_mat_card_9_td_17_Template, 2, 1, "td", 15);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(18, 33);
    i0.ɵɵtemplate(19, SapComplianceViolationViewsByRoleComponent_mat_card_9_th_19_Template, 3, 3, "th", 32)(20, SapComplianceViolationViewsByRoleComponent_mat_card_9_td_20_Template, 2, 1, "td", 15);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(21, 34);
    i0.ɵɵtemplate(22, SapComplianceViolationViewsByRoleComponent_mat_card_9_th_22_Template, 3, 3, "th", 32)(23, SapComplianceViolationViewsByRoleComponent_mat_card_9_td_23_Template, 2, 1, "td", 15);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(24, 35);
    i0.ɵɵtemplate(25, SapComplianceViolationViewsByRoleComponent_mat_card_9_th_25_Template, 3, 3, "th", 32)(26, SapComplianceViolationViewsByRoleComponent_mat_card_9_td_26_Template, 2, 1, "td", 15);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(27, 36);
    i0.ɵɵtemplate(28, SapComplianceViolationViewsByRoleComponent_mat_card_9_th_28_Template, 3, 3, "th", 32)(29, SapComplianceViolationViewsByRoleComponent_mat_card_9_td_29_Template, 2, 1, "td", 15);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵtemplate(30, SapComplianceViolationViewsByRoleComponent_mat_card_9_tr_30_Template, 1, 0, "tr", 17)(31, SapComplianceViolationViewsByRoleComponent_mat_card_9_tr_31_Template, 1, 0, "tr", 37);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(32, SapComplianceViolationViewsByRoleComponent_mat_card_9_div_32_Template, 5, 4, "div", 38);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(20, _c0, !ctx_r1.extendProfiles));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(3, 12, ctx_r1.extendProfiles ? "#LDS#Hide profiles" : "#LDS#Show profiles"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(7, 14, "#LDS#Profiles"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate2(" ", i0.ɵɵpipeBind1(10, 16, "#LDS#Heading Selected Role"), ": ", ctx_r1.selectedRole == null ? null : ctx_r1.selectedRole.GroupName, " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("placeholder", i0.ɵɵpipeBind1(12, 18, "#LDS#Search"))("searchControl", ctx_r1.profileSearchControl);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("dataSource", ctx_r1.profileDataSource);
    i0.ɵɵadvance(16);
    i0.ɵɵproperty("matHeaderRowDef", ctx_r1.displayedProfileColumns)("matHeaderRowDefSticky", true);
    i0.ɵɵadvance();
    i0.ɵɵproperty("matRowDefColumns", ctx_r1.displayedProfileColumns);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.profileDataSource.data.length == 0);
} }
class SapComplianceViolationViewsByRoleComponent {
    cdref;
    set resultByRole(value) {
        this._resultByRole = value;
        if (!!value?.Elements) {
            this.dataSource.data = value.Elements;
        }
    }
    get resultByRole() {
        return this._resultByRole;
    }
    sort;
    displayedColumns = ['GroupName', 'Description', 'GroupType'];
    displayedProfileColumns = ['Ident_SAPProfile', 'Objects', 'Field', 'LowerLimit', 'UpperLimit'];
    transformer = (node, level) => {
        return {
            expandable: !!node.ChildElements && node.ChildElements.length > 0,
            level: level,
            GroupName: node.GroupName,
            Description: node.Description,
            GroupFlag: node.GroupFlag,
            GroupType: node.GroupType,
            ChildElements: node.ChildElements,
            Prof: node.Prof,
        };
    };
    treeControl = new FlatTreeControl((node) => node.level, (node) => node.expandable);
    treeFlattener = new MatTreeFlattener(this.transformer, (node) => node.level, (node) => node.expandable, (node) => node.ChildElements);
    dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
    selectedProfiles = [];
    profileDataSource = new MatTableDataSource();
    extendRole = true;
    extendProfiles = true;
    showProfiles = false;
    selectedRole;
    profileSearchControl = new FormControl('', { nonNullable: true });
    _resultByRole;
    constructor(cdref) {
        this.cdref = cdref;
    }
    ngOnInit() {
        this.profileSearchControl.valueChanges.subscribe((searchValue) => this.searchProfiles(searchValue));
    }
    hasChild(_, node) {
        return node.expandable;
    }
    hasProfiles(node) {
        return !!node.Prof && node.Prof.length > 0;
    }
    updateProfiles(node) {
        if (!!node?.Prof) {
            this.showProfiles = true;
            this.selectedProfiles = node.Prof;
            this.profileDataSource.data = node.Prof;
            this.selectedRole = node;
            this.cdref.detectChanges();
            this.profileDataSource.sort = this.sort;
        }
    }
    toggleRoleExpand() {
        this.extendRole = !this.extendRole;
        if (!this.extendRole) {
            this.extendProfiles = true;
        }
    }
    toggleProfilesExpand() {
        this.extendProfiles = !this.extendProfiles;
        if (!this.extendProfiles) {
            this.extendRole = true;
        }
    }
    searchProfiles(searchValue) {
        if (!!searchValue) {
            searchValue = searchValue.toLocaleLowerCase();
            this.profileDataSource.data = this.selectedProfiles.filter((profile) => profile.Ident_SAPProfile?.toLocaleLowerCase().includes(searchValue) ||
                profile.Objects?.toLocaleLowerCase().includes(searchValue) ||
                profile.Field?.toLocaleLowerCase().includes(searchValue) ||
                profile.LowerLimit?.toLocaleLowerCase().includes(searchValue) ||
                profile.UpperLimit?.toLocaleLowerCase().includes(searchValue));
        }
        else {
            this.profileDataSource.data = this.selectedProfiles;
        }
    }
    static ɵfac = function SapComplianceViolationViewsByRoleComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SapComplianceViolationViewsByRoleComponent)(i0.ɵɵdirectiveInject(i0.ChangeDetectorRef)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SapComplianceViolationViewsByRoleComponent, selectors: [["imx-sap-compliance-violation-views-by-role"]], viewQuery: function SapComplianceViolationViewsByRoleComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(MatSort, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.sort = _t.first);
        } }, inputs: { resultByRole: "resultByRole" }, decls: 10, vars: 9, consts: [[1, "sap-analysis"], [3, "ngClass"], [1, "mat-mdc-card__header"], [1, "mat-mdc-card__header__title"], ["data-imx-identifier", "sidenav-tree-expand-toggle", "mat-button", "", "color", "primary", 3, "matTooltip", "click", 4, "ngIf"], [1, "sap-analysis__table"], ["mat-table", "", 3, "dataSource", 4, "ngIf"], [3, "ngClass", 4, "ngIf"], ["data-imx-identifier", "sidenav-tree-expand-toggle", "mat-button", "", "color", "primary", 3, "click", "matTooltip"], ["icon", "collapseleft"], ["mat-table", "", 3, "dataSource"], ["matColumnDef", "GroupName"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "class", "td--no-wrap", 4, "matCellDef"], ["matColumnDef", "Description"], ["mat-cell", "", 4, "matCellDef"], ["matColumnDef", "GroupType"], ["mat-header-row", "", 4, "matHeaderRowDef", "matHeaderRowDefSticky"], ["mat-row", "", 3, "ngClass", "click", 4, "matRowDef", "matRowDefColumns"], ["mat-header-cell", ""], ["mat-cell", "", 1, "td--no-wrap"], ["mat-icon-button", "", 3, "click"], [1, "mat-icon-rtl-mirror"], ["mat-cell", ""], [1, "imx-table-column-ellipsis", 3, "title"], ["mat-header-row", ""], ["mat-row", "", 3, "click", "ngClass"], ["icon", "collapseright"], [1, "mat-mdc-card__header__title", "mat-mdc-card__header__title--wide"], ["size", "s", "width", "100%", 3, "placeholder", "searchControl"], ["mat-table", "", "matSort", "", 3, "dataSource"], ["matColumnDef", "Ident_SAPProfile"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], ["matColumnDef", "Objects"], ["matColumnDef", "Field"], ["matColumnDef", "LowerLimit"], ["matColumnDef", "UpperLimit"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["class", "no-results", 4, "ngIf"], ["mat-header-cell", "", "mat-sort-header", ""], ["mat-row", ""], [1, "no-results"], [3, "icon"]], template: function SapComplianceViolationViewsByRoleComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card", 1)(2, "div", 2)(3, "h3", 3);
            i0.ɵɵtext(4);
            i0.ɵɵpipe(5, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(6, SapComplianceViolationViewsByRoleComponent_button_6_Template, 5, 3, "button", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div", 5);
            i0.ɵɵtemplate(8, SapComplianceViolationViewsByRoleComponent_table_8_Template, 12, 4, "table", 6);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(9, SapComplianceViolationViewsByRoleComponent_mat_card_9_Template, 33, 22, "mat-card", 7);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(7, _c0, !ctx.extendRole));
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 5, "#LDS#Heading Rule Analysis by Role"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.selectedProfiles.length > 0);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.dataSource.data.length > 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showProfiles);
        } }, dependencies: [i2.NgClass, i2.NgIf, i3.EuiIconComponent, i3.EuiSearchComponent, i3$1.MatButton, i3$1.MatIconButton, i4.MatCard, i5.MatIcon, i6.MatSort, i6.MatSortHeader, i7.MatTable, i7.MatHeaderCellDef, i7.MatHeaderRowDef, i7.MatColumnDef, i7.MatCellDef, i7.MatRowDef, i7.MatHeaderCell, i7.MatCell, i7.MatHeaderRow, i7.MatRow, i8.MatTooltip, i1$1.TranslatePipe], styles: [".sap-analysis[_ngcontent-%COMP%]{display:flex;gap:16px;height:100%;justify-content:space-between}.sap-analysis__table[_ngcontent-%COMP%]{overflow:hidden auto;flex-grow:1}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;transition:width .4s ease;gap:20px}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card--decreased[_ngcontent-%COMP%]{padding:0;width:48px}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card--decreased[_ngcontent-%COMP%]   .mat-mdc-card__header[_ngcontent-%COMP%]{height:100%}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card--decreased[_ngcontent-%COMP%]   .mat-mdc-card__header__title[_ngcontent-%COMP%]{display:none}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card--decreased[_ngcontent-%COMP%]   .mat-mdc-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{width:48px;padding:20px 0;min-width:unset;height:100%}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card--decreased[_ngcontent-%COMP%]   .mat-mdc-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]     .mdc-button__label{height:100%;display:flex;flex-direction:column}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card--decreased[_ngcontent-%COMP%]   .mat-mdc-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{display:block;margin:auto 0;rotate:-90deg;text-wrap:nowrap}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card--decreased[_ngcontent-%COMP%]   .mat-mdc-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{rotate:180deg}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card--decreased[_ngcontent-%COMP%]   .sap-analysis__table[_ngcontent-%COMP%], .sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card--decreased[_ngcontent-%COMP%]   eui-search[_ngcontent-%COMP%]{display:none}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card__header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card__header__title--wide[_ngcontent-%COMP%]{margin:auto}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{padding:0;min-width:32px}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{display:none}.sap-analysis[_ngcontent-%COMP%]   .mat-mdc-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{transition:rotate .4s ease}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SapComplianceViolationViewsByRoleComponent, [{
        type: Component,
        args: [{ selector: 'imx-sap-compliance-violation-views-by-role', template: "<div class=\"sap-analysis\">\n  <mat-card [ngClass]=\"{ 'mat-mdc-card--decreased': !extendRole }\">\n    <div class=\"mat-mdc-card__header\">\n      <h3 class=\"mat-mdc-card__header__title\">{{ '#LDS#Heading Rule Analysis by Role' | translate }}</h3>\n      <button\n        data-imx-identifier=\"sidenav-tree-expand-toggle\"\n        mat-button\n        color=\"primary\"\n        (click)=\"toggleRoleExpand()\"\n        [matTooltip]=\"(extendRole ? '#LDS#Hide roles' : '#LDS#Show roles') | translate\"\n        *ngIf=\"selectedProfiles.length > 0\"\n      >\n        <eui-icon icon=\"collapseleft\"></eui-icon>\n        <h3>SAP Analysis Roles</h3>\n      </button>\n    </div>\n    <div class=\"sap-analysis__table\">\n      <table mat-table [dataSource]=\"dataSource\" *ngIf=\"dataSource.data.length > 0\">\n        <ng-container matColumnDef=\"GroupName\">\n          <th mat-header-cell *matHeaderCellDef>\n            <span [style.paddingLeft.px]=\"40\">{{ '#LDS#Group name' | translate }}</span>\n          </th>\n          <td mat-cell *matCellDef=\"let data\" class=\"td--no-wrap\">\n            <button\n              mat-icon-button\n              [style.visibility]=\"!data.expandable ? 'hidden' : ''\"\n              [style.marginLeft.px]=\"data.level * 16\"\n              (click)=\"treeControl.toggle(data)\"\n            >\n              <mat-icon class=\"mat-icon-rtl-mirror\">\n                {{ treeControl.isExpanded(data) ? 'expand_more' : 'chevron_right' }}\n              </mat-icon>\n            </button>\n\n            {{ data.GroupName }}\n          </td>\n        </ng-container>\n        <ng-container matColumnDef=\"Description\">\n          <th mat-header-cell *matHeaderCellDef>{{ '#LDS#Description' | translate }}</th>\n          <td mat-cell *matCellDef=\"let data\">\n            <span class=\"imx-table-column-ellipsis\" title=\"{{ data.Description }}\">{{ data.Description }}</span>\n          </td>\n        </ng-container>\n        <ng-container matColumnDef=\"GroupType\">\n          <th mat-header-cell *matHeaderCellDef>{{ '#LDS#Group type' | translate }}</th>\n          <td mat-cell *matCellDef=\"let data\">{{ data.GroupType }}</td>\n        </ng-container>\n        <tr mat-header-row *matHeaderRowDef=\"displayedColumns; sticky: true\"></tr>\n        <tr\n          mat-row\n          *matRowDef=\"let row; columns: displayedColumns\"\n          [ngClass]=\"{ 'sap-analysis-table-row-highlighted': hasProfiles(row) }\"\n          (click)=\"updateProfiles(row)\"\n        ></tr>\n      </table>\n    </div>\n  </mat-card>\n  <mat-card *ngIf=\"showProfiles\" [ngClass]=\"{ 'mat-mdc-card--decreased': !extendProfiles }\">\n    <div class=\"mat-mdc-card__header\">\n      <button\n        data-imx-identifier=\"sidenav-tree-expand-toggle\"\n        mat-button\n        color=\"primary\"\n        (click)=\"toggleProfilesExpand()\"\n        [matTooltip]=\"(extendProfiles ? '#LDS#Hide profiles' : '#LDS#Show profiles') | translate\"\n      >\n        <eui-icon icon=\"collapseright\"></eui-icon>\n        <h3>{{ '#LDS#Profiles' | translate }}</h3>\n      </button>\n      <h3 class=\"mat-mdc-card__header__title mat-mdc-card__header__title--wide\">\n        {{ '#LDS#Heading Selected Role' | translate }}: {{ selectedRole?.GroupName }}\n      </h3>\n    </div>\n    <eui-search [placeholder]=\"'#LDS#Search' | translate\" [searchControl]=\"profileSearchControl\" size=\"s\" width=\"100%\"> </eui-search>\n    <div class=\"sap-analysis__table\">\n      <table mat-table matSort [dataSource]=\"profileDataSource\">\n        <ng-container matColumnDef=\"Ident_SAPProfile\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{ '#LDS#Authentication' | translate }}</th>\n          <td mat-cell *matCellDef=\"let data\">{{ data.Ident_SAPProfile }}</td>\n        </ng-container>\n        <ng-container matColumnDef=\"Objects\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{ '#LDS#Objects' | translate }}</th>\n          <td mat-cell *matCellDef=\"let data\">{{ data.Objects }}</td>\n        </ng-container>\n        <ng-container matColumnDef=\"Field\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{ '#LDS#Field' | translate }}</th>\n          <td mat-cell *matCellDef=\"let data\">{{ data.Field }}</td>\n        </ng-container>\n        <ng-container matColumnDef=\"LowerLimit\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{ '#LDS#From' | translate }}</th>\n          <td mat-cell *matCellDef=\"let data\">{{ data.LowerLimit }}</td>\n        </ng-container>\n        <ng-container matColumnDef=\"UpperLimit\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{ '#LDS#To' | translate }}</th>\n          <td mat-cell *matCellDef=\"let data\">{{ data.UpperLimit }}</td>\n        </ng-container>\n        <tr mat-header-row *matHeaderRowDef=\"displayedProfileColumns; sticky: true\"></tr>\n        <tr mat-row *matRowDef=\"let row; columns: displayedProfileColumns\"></tr>\n      </table>\n      <div *ngIf=\"profileDataSource.data.length == 0\" class=\"no-results\">\n        <eui-icon [icon]=\"'table'\"></eui-icon>\n        <p>{{ '#LDS#No data' | translate }}</p>\n      </div>\n    </div>\n  </mat-card>\n</div>\n", styles: [".sap-analysis{display:flex;gap:16px;height:100%;justify-content:space-between}.sap-analysis__table{overflow:hidden auto;flex-grow:1}.sap-analysis .mat-mdc-card{display:flex;flex-direction:column;width:100%;transition:width .4s ease;gap:20px}.sap-analysis .mat-mdc-card--decreased{padding:0;width:48px}.sap-analysis .mat-mdc-card--decreased .mat-mdc-card__header{height:100%}.sap-analysis .mat-mdc-card--decreased .mat-mdc-card__header__title{display:none}.sap-analysis .mat-mdc-card--decreased .mat-mdc-card__header button{width:48px;padding:20px 0;min-width:unset;height:100%}.sap-analysis .mat-mdc-card--decreased .mat-mdc-card__header button ::ng-deep .mdc-button__label{height:100%;display:flex;flex-direction:column}.sap-analysis .mat-mdc-card--decreased .mat-mdc-card__header button h3{display:block;margin:auto 0;rotate:-90deg;text-wrap:nowrap}.sap-analysis .mat-mdc-card--decreased .mat-mdc-card__header button .eui-icon{rotate:180deg}.sap-analysis .mat-mdc-card--decreased .sap-analysis__table,.sap-analysis .mat-mdc-card--decreased eui-search{display:none}.sap-analysis .mat-mdc-card__header{display:flex;align-items:center;justify-content:space-between}.sap-analysis .mat-mdc-card__header__title--wide{margin:auto}.sap-analysis .mat-mdc-card__header button{padding:0;min-width:32px}.sap-analysis .mat-mdc-card__header button h3{display:none}.sap-analysis .mat-mdc-card__header button .eui-icon{transition:rotate .4s ease}\n"] }]
    }], () => [{ type: i0.ChangeDetectorRef }], { resultByRole: [{
            type: Input
        }], sort: [{
            type: ViewChild,
            args: [MatSort]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SapComplianceViolationViewsByRoleComponent, { className: "SapComplianceViolationViewsByRoleComponent", filePath: "lib\\sap-compliance-violation\\sap-compliance-violation-views-by-role\\sap-compliance-violation-views-by-role.component.ts", lineNumber: 41 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function SapComplianceViolationComponent_div_1_mat_form_field_1_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-option", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const account_r3 = ctx.$implicit;
    i0.ɵɵproperty("value", account_r3);
    i0.ɵɵattribute("data-imx-identifier", "sap-user-option-" + account_r3.GetEntity().GetDisplay());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", account_r3.GetEntity().GetDisplay(), " ");
} }
function SapComplianceViolationComponent_div_1_mat_form_field_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-form-field", 8)(1, "mat-label");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-select", 9);
    i0.ɵɵlistener("selectionChange", function SapComplianceViolationComponent_div_1_mat_form_field_1_Template_mat_select_selectionChange_4_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onUserOptionSelected()); });
    i0.ɵɵtwoWayListener("valueChange", function SapComplianceViolationComponent_div_1_mat_form_field_1_Template_mat_select_valueChange_4_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); i0.ɵɵtwoWayBindingSet(ctx_r1.selectedAccount, $event) || (ctx_r1.selectedAccount = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵtemplate(5, SapComplianceViolationComponent_div_1_mat_form_field_1_mat_option_5_Template, 2, 3, "mat-option", 10);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 4, "#LDS#SAP user account"));
    i0.ɵɵadvance(2);
    i0.ɵɵtwoWayProperty("value", ctx_r1.selectedAccount);
    i0.ɵɵproperty("disabled", ctx_r1.loading);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r1.accounts);
} }
function SapComplianceViolationComponent_div_1_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(2, 1, "#LDS#Rule analysis"), ":");
} }
function SapComplianceViolationComponent_div_1_mat_chip_listbox_3_mat_chip_option_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-chip-option", 13);
    i0.ɵɵlistener("click", function SapComplianceViolationComponent_div_1_mat_chip_listbox_3_mat_chip_option_1_Template_mat_chip_option_click_0_listener() { const option_r5 = i0.ɵɵrestoreView(_r4).$implicit; const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.onSelectionChange(option_r5)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r5 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵproperty("selected", ctx_r1.isOptionSelected(option_r5.value))("disabled", ctx_r1.loading);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, option_r5.label), " ");
} }
function SapComplianceViolationComponent_div_1_mat_chip_listbox_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-chip-listbox");
    i0.ɵɵtemplate(1, SapComplianceViolationComponent_div_1_mat_chip_listbox_3_mat_chip_option_1_Template, 3, 5, "mat-chip-option", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r1.selectionOptions);
} }
function SapComplianceViolationComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 6);
    i0.ɵɵtemplate(1, SapComplianceViolationComponent_div_1_mat_form_field_1_Template, 6, 6, "mat-form-field", 7)(2, SapComplianceViolationComponent_div_1_span_2_Template, 3, 3, "span", 2)(3, SapComplianceViolationComponent_div_1_mat_chip_listbox_3_Template, 2, 1, "mat-chip-listbox", 2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !!(ctx_r1.accounts == null ? null : ctx_r1.accounts.length) && ctx_r1.accounts.length > 1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r1.hideChips);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r1.hideChips);
} }
function SapComplianceViolationComponent_mat_spinner_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner");
} }
function SapComplianceViolationComponent_imx_sap_compliance_violation_views_by_role_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-sap-compliance-violation-views-by-role", 14);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("resultByRole", ctx_r1.resultByRole);
} }
function SapComplianceViolationComponent_imx_sap_compliance_violation_views_by_ability_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-sap-compliance-violation-views-by-ability", 15);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("resultByAbility", ctx_r1.resultByAbility);
} }
function SapComplianceViolationComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 16);
    i0.ɵɵelement(1, "eui-icon", 17);
    i0.ɵɵelementStart(2, "p");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("icon", "table");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#No data"));
} }
class SapComplianceViolationComponent {
    api;
    data;
    accounts = [];
    resultByRole = { Elements: [] };
    resultByAbility = { Data: [] };
    selectionOptions = [
        { value: SapSelectionTypeEnum.ROLE, label: '#LDS#By role' },
        { value: SapSelectionTypeEnum.ABILITY, label: '#LDS#By ability' },
    ];
    selectedOption = SapSelectionTypeEnum.ROLE;
    loading = false;
    sapSelectionTypeEnum = SapSelectionTypeEnum;
    selectedAccount;
    constructor(api) {
        this.api = api;
    }
    async ngOnInit() {
        this.loading = true;
        const uidPerson = this.data.selectedRulesViolation.UID_Person.value;
        this.accounts = (await this.api.typedClient.PortalTargetsystemSapuser.Get({
            UID_PersonAssociated: uidPerson,
        })).Data;
        if (this.accounts.length > 0 && !!this.data.complianceRule?.EntityKeysData?.Keys?.[0]) {
            this.selectedAccount = this.accounts[0];
            await this.loadResult();
        }
        this.loading = false;
    }
    onSelectionChange(option) {
        this.selectedOption = option.value;
    }
    isOptionSelected(value) {
        return value === this.selectedOption;
    }
    onUserOptionSelected() {
        this.loadResult();
    }
    get showNoData() {
        const roleLength = this.resultByRole?.Elements?.length || 0;
        const abilityLength = this.resultByAbility?.Data?.length || 0;
        return (!this.loading &&
            ((this.isOptionSelected(this.sapSelectionTypeEnum.ROLE) && roleLength == 0) ||
                (this.isOptionSelected(this.sapSelectionTypeEnum.ABILITY) && abilityLength == 0)));
    }
    get hideChips() {
        return this.resultByRole?.Elements?.length == 0 && this.resultByAbility?.Data?.length == 0;
    }
    async loadResult() {
        this.loading = true;
        const uidsapuser = this.selectedAccount.GetEntity().GetKeys()[0];
        this.resultByAbility = await this.api.client.portal_sap_ruleanalysis_fld_get(uidsapuser, this.data.complianceRule?.EntityKeysData?.Keys?.[0] ?? '');
        this.resultByRole = await this.api.client.portal_sap_ruleanalysis_byrole_get(uidsapuser, this.data.complianceRule?.EntityKeysData?.Keys?.[0] ?? '');
        this.loading = false;
    }
    static ɵfac = function SapComplianceViolationComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SapComplianceViolationComponent)(i0.ɵɵdirectiveInject(SapComplianceApiService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SapComplianceViolationComponent, selectors: [["ng-component"]], decls: 6, vars: 5, consts: [["eui-sidesheet-content", ""], ["class", "imx-sap-compliance-selection", 4, "ngIf"], [4, "ngIf"], [3, "resultByRole", 4, "ngIf"], [3, "resultByAbility", 4, "ngIf"], ["class", "imx-no-results", 4, "ngIf"], [1, "imx-sap-compliance-selection"], ["appearance", "outline", "class", "namespace-selector", 4, "ngIf"], ["appearance", "outline", 1, "namespace-selector"], ["required", "", "data-imx-identifier", "sap-user-select", 3, "selectionChange", "valueChange", "value", "disabled"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], ["color", "primary", 3, "selected", "disabled", "click", 4, "ngFor", "ngForOf"], ["color", "primary", 3, "click", "selected", "disabled"], [3, "resultByRole"], [3, "resultByAbility"], [1, "imx-no-results"], [3, "icon"]], template: function SapComplianceViolationComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, SapComplianceViolationComponent_div_1_Template, 4, 3, "div", 1)(2, SapComplianceViolationComponent_mat_spinner_2_Template, 1, 0, "mat-spinner", 2)(3, SapComplianceViolationComponent_imx_sap_compliance_violation_views_by_role_3_Template, 1, 1, "imx-sap-compliance-violation-views-by-role", 3)(4, SapComplianceViolationComponent_imx_sap_compliance_violation_views_by_ability_4_Template, 1, 1, "imx-sap-compliance-violation-views-by-ability", 4)(5, SapComplianceViolationComponent_div_5_Template, 5, 4, "div", 5);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.loading);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.loading);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.loading && ctx.isOptionSelected(ctx.sapSelectionTypeEnum.ROLE) && ctx.resultByRole.Elements);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.loading && ctx.isOptionSelected(ctx.sapSelectionTypeEnum.ABILITY) && ctx.resultByAbility.Data);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.loading && ctx.showNoData);
        } }, dependencies: [i2.NgForOf, i2.NgIf, i3.EuiIconComponent, i3.EuiSidesheetContentDirective, i4$1.MatOption, i5$1.MatChipListbox, i5$1.MatChipOption, i6$1.MatFormField, i6$1.MatLabel, i7$1.MatProgressSpinner, i8$1.MatSelect, SapComplianceViolationViewsByAbilityComponent, SapComplianceViolationViewsByRoleComponent, i1$1.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}.eui-sidesheet-content[_ngcontent-%COMP%]   imx-sap-compliance-violation-views-by-role[_ngcontent-%COMP%], .eui-sidesheet-content[_ngcontent-%COMP%]   imx-sap-compliance-violation-views-by-ability[_ngcontent-%COMP%]{display:block;overflow:hidden;flex-grow:1}.eui-sidesheet-content[_ngcontent-%COMP%]   .mat-mdc-chip[_ngcontent-%COMP%]{cursor:pointer}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-sap-compliance-selection[_ngcontent-%COMP%]{display:flex;align-items:center;font-size:14px;gap:20px;padding-bottom:20px}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-no-results[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px;color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SapComplianceViolationComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\n  <div class=\"imx-sap-compliance-selection\" *ngIf=\"!loading\">\n    <mat-form-field appearance=\"outline\" class=\"namespace-selector\" *ngIf=\"!!accounts?.length && accounts.length > 1\">\n      <mat-label>{{ '#LDS#SAP user account' | translate }}</mat-label>\n      <mat-select\n        required\n        (selectionChange)=\"onUserOptionSelected()\"\n        [(value)]=\"selectedAccount\"\n        [disabled]=\"loading\"\n        data-imx-identifier=\"sap-user-select\"\n      >\n        <mat-option\n          *ngFor=\"let account of accounts\"\n          [value]=\"account\"\n          [attr.data-imx-identifier]=\"'sap-user-option-' + account.GetEntity().GetDisplay()\"\n        >\n          {{ account.GetEntity().GetDisplay() }}\n        </mat-option>\n      </mat-select>\n    </mat-form-field>\n    <span *ngIf=\"!hideChips\">{{ '#LDS#Rule analysis' | translate }}:</span>\n    <mat-chip-listbox *ngIf=\"!hideChips\">\n      <mat-chip-option\n        *ngFor=\"let option of selectionOptions\"\n        (click)=\"onSelectionChange(option)\"\n        [selected]=\"isOptionSelected(option.value)\"\n        color=\"primary\"\n        [disabled]=\"loading\"\n      >\n        {{ option.label | translate }}\n      </mat-chip-option>\n    </mat-chip-listbox>\n  </div>\n  <mat-spinner *ngIf=\"loading\"></mat-spinner>\n  <imx-sap-compliance-violation-views-by-role\n    [resultByRole]=\"resultByRole\"\n    *ngIf=\"!loading && isOptionSelected(sapSelectionTypeEnum.ROLE) && resultByRole.Elements\"\n  ></imx-sap-compliance-violation-views-by-role>\n  <imx-sap-compliance-violation-views-by-ability\n    [resultByAbility]=\"resultByAbility\"\n    *ngIf=\"!loading && isOptionSelected(sapSelectionTypeEnum.ABILITY) && resultByAbility.Data\"\n  ></imx-sap-compliance-violation-views-by-ability>\n  <div *ngIf=\"!loading && showNoData\" class=\"imx-no-results\">\n    <eui-icon [icon]=\"'table'\"></eui-icon>\n    <p>{{ '#LDS#No data' | translate }}</p>\n  </div>\n</div>\n", styles: [".eui-sidesheet-content{display:flex;flex-direction:column}.eui-sidesheet-content imx-sap-compliance-violation-views-by-role,.eui-sidesheet-content imx-sap-compliance-violation-views-by-ability{display:block;overflow:hidden;flex-grow:1}.eui-sidesheet-content .mat-mdc-chip{cursor:pointer}.eui-sidesheet-content .imx-sap-compliance-selection{display:flex;align-items:center;font-size:14px;gap:20px;padding-bottom:20px}.eui-sidesheet-content .imx-no-results{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}.eui-sidesheet-content .imx-no-results p{margin:0;font-size:18px;color:#2f3233}.eui-dark-theme :host .imx-no-results p{color:#dfe4e6}\n"] }]
    }], () => [{ type: SapComplianceApiService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SapComplianceViolationComponent, { className: "SapComplianceViolationComponent", filePath: "lib\\sap-compliance-violation\\sap-compliance-violation.component.ts", lineNumber: 37 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    extService;
    constructor(extService) {
        this.extService = extService;
    }
    onInit() {
        this.extService.register('RuleViolationsTab', {
            instance: SapComplianceViolationComponent,
            inputData: { label: '#LDS#Heading SAP Functions' },
        });
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i1.ExtService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i1.ExtService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SacConfigModule {
    initservice;
    logger;
    constructor(initservice, logger) {
        this.initservice = initservice;
        this.logger = logger;
        this.logger.info(this, '🔥 SAC loaded');
        this.initservice.onInit();
        this.logger.info(this, '▶️ SAC initialized');
    }
    static ɵfac = function SacConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SacConfigModule)(i0.ɵɵinject(InitService), i0.ɵɵinject(i1.ClassloggerService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: SacConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            TranslateModule,
            EuiCoreModule,
            EuiMaterialModule,
            MatTabsModule,
            MatCardModule,
            MatChipsModule,
            MatProgressSpinnerModule,
            MatSortModule,
            DataSourceToolbarModule,
            DataTableModule,
            DataTreeWrapperModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SacConfigModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    SapComplianceViolationComponent,
                    SapComplianceViolationViewsByAbilityComponent,
                    SapComplianceViolationViewsByRoleComponent,
                ],
                imports: [
                    CommonModule,
                    TranslateModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    MatTabsModule,
                    MatCardModule,
                    MatChipsModule,
                    MatProgressSpinnerModule,
                    MatSortModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    DataTreeWrapperModule,
                ],
            }]
    }], () => [{ type: InitService }, { type: i1.ClassloggerService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(SacConfigModule, { declarations: [SapComplianceViolationComponent,
        SapComplianceViolationViewsByAbilityComponent,
        SapComplianceViolationViewsByRoleComponent], imports: [CommonModule,
        TranslateModule,
        EuiCoreModule,
        EuiMaterialModule,
        MatTabsModule,
        MatCardModule,
        MatChipsModule,
        MatProgressSpinnerModule,
        MatSortModule,
        DataSourceToolbarModule,
        DataTableModule,
        DataTreeWrapperModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of sac
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SacConfigModule };
//# sourceMappingURL=sac.mjs.map
