import { TypedEntity, EntitySchema, IReadValue } from '@imx-modules/imx-qbm-dbts';
export declare class SapComplianceByAbilityEntity extends TypedEntity {
    readonly Ident_SAPProfile: IReadValue<string>;
    readonly Ident_SAPAuthObject: IReadValue<string>;
    readonly Ident_SAPField: IReadValue<string>;
    readonly LowerLimit: IReadValue<string>;
    readonly UpperLimit: IReadValue<string>;
    readonly UID_SAPFunctionInstance: IReadValue<string>;
    readonly DisplaySapFunctionInstance: IReadValue<string>;
    readonly DisplaySapTransaction: IReadValue<string>;
    static GetEntitySchema(): EntitySchema;
}
