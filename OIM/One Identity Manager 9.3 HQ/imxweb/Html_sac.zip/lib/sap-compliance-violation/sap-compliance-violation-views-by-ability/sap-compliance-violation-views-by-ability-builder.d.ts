import { EntityCollectionData, EntityData, TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { SapComplianceByAbilityEntity } from './sap-compliance-violation-views-by-ability-entity';
import { SAPUserFunctionSrcFLD } from '@imx-modules/imx-api-sac';
export declare class SapComplianceByAbilityBuilder {
    readonly entitySchema: import("@imx-modules/imx-qbm-dbts").EntitySchema;
    private readonly builder;
    build(entityCollectionData: EntityCollectionData): TypedEntityCollectionData<SapComplianceByAbilityEntity>;
    buildEntityCollectionData(items: SAPUserFunctionSrcFLD[]): EntityCollectionData;
    buildEntityData(item: SAPUserFunctionSrcFLD): EntityData;
}
