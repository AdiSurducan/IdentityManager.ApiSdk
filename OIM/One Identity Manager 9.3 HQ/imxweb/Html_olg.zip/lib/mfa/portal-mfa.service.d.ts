import { ActivateFactorData, AuthFactors, VerifyPollingResult } from '@imx-modules/imx-api-olg';
import { OlgApiService } from '../olg-api-client.service';
import * as i0 from "@angular/core";
export declare class PortalMfaService {
    private readonly api;
    constructor(api: OlgApiService);
    activateFactor(workflowActionId: string, deviceId: string): Promise<ActivateFactorData>;
    verifyWithVerificationId(workflowActionId: string, verificationId: string, code: string, deviceId?: string): Promise<boolean>;
    verifyWithPolling(workflowActionId: string, verificationId: string): Promise<VerifyPollingResult>;
    getFactors(): Promise<AuthFactors>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PortalMfaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PortalMfaService>;
}
