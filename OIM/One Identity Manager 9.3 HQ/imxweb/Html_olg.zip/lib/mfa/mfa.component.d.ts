import { ChangeDetectorRef, OnDestroy } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { BusyService } from 'qbm';
import * as i0 from "@angular/core";
/**
 * Form information for the typed authetification form
 */
interface AuthForm {
    authenticator: FormControl<boolean>;
}
/**
 * Component, that provides a list of OneLogin authentication factors
 *
 * Can be displayed in a side sheet, that will be closed, if one authentication method was successful
 */
export declare class MfaComponent implements OnDestroy {
    readonly data: {
        workflowActionId: string;
    };
    authForm: FormGroup<AuthForm>;
    /** Indicates whether the user has authenticators defined or not */
    hasAuthenticators: boolean;
    /** Indicates whether the control is loading or not */
    isLoading: boolean;
    /** busy service used in the authentication control and its sub controls */
    busyService: BusyService;
    private subscriptions;
    constructor(data: {
        workflowActionId: string;
    }, sideSheetRef: EuiSidesheetRef, change: ChangeDetectorRef);
    /**
     * unsubscribes all subscriptions, when the component is destroyed
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MfaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MfaComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
export {};
