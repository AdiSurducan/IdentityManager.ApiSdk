import { EventEmitter, OnInit } from '@angular/core';
import { ControlValueAccessor, FormControl } from '@angular/forms';
import { ActivateFactorData, AuthFactor } from '@imx-modules/imx-api-olg';
import { BusyService, ColumnDependentReference, EntityService } from 'qbm';
import { AuthenticationFactors } from 'qer';
import { PortalMfaService } from '../mfa/portal-mfa.service';
import * as i0 from "@angular/core";
/**
 * Information that are used to handle each authentication factor
 */
interface AuthFactorInfo {
    factor: AuthFactor;
    authCdr?: ColumnDependentReference;
    showCdr?: boolean;
    authMessage?: string;
    loading?: boolean;
    activating?: boolean;
}
/**
 * Represents a list of OneLogin authentication factors as a FormControl<boolean> instance
 * The initial value of the FormControl is false, and changes to true, if one log in method was sucessful
 */
export declare class MfaFormControlComponent implements OnInit, ControlValueAccessor, AuthenticationFactors {
    private readonly mfa;
    private readonly entityService;
    /** Array, that stores auth factor information */
    authFactorInfo: AuthFactorInfo[];
    /** currently activated factor */
    activatedFactor: ActivateFactorData | undefined;
    /**
     * Gets whether the user is authenticated or not
     */
    get isAuthenticated(): boolean;
    /** on change function for the ControlValueAccessor */
    onChange: (event: boolean) => void;
    /** on touch function for the ControlValueAccessor */
    onTouch: (event: boolean) => void;
    /** The form control associated with this control */
    readonly formControl: FormControl<boolean>;
    /** The id of the object that is tested*/
    itemId: string;
    /** BusyService for loading */
    busyService: BusyService;
    /** emmits, if all controls have been loaded */
    loaded: EventEmitter<boolean>;
    private ldsLoginFail;
    constructor(mfa: PortalMfaService, entityService: EntityService);
    /**
     * Updates the value of the form control
     * @param authenticated value that should be set
     */
    writeValue(authenticated: boolean): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    ngOnInit(): Promise<void>;
    /**
     * Checks, if the factor is a one time password
     * @param factorName name of the factor to check
     * @returns true, if  one time password is used
     */
    isOTP(factorName: string | undefined): boolean;
    /**
     * Checks, if the factor is using the OneLogin protectopr app
     * @param factorName name of the factor to check
     * @returns true, if the OneLogin protectopr app is used
     */
    isProtect(factorName: string | undefined): boolean;
    /**
     * Checks, if the factor is using the authenticator or
     * @param factorName name of the factor to check
     * @returns true, if authenticator app is used
     */
    isAuthenticator(factorName: string | undefined): boolean;
    /** Checks, if a cdr is valid */
    isCDRValid(cdr: ColumnDependentReference | undefined): boolean;
    /** Checks, if a factor is activated */
    get isActivated(): boolean;
    /** resets the state of an authenticator */
    resetState(index: number): void;
    /**
     * Activates a factor and shows its cdr. Then the user is able to add information
     * @param factorName  the name of the factor that needs to be activated
     * @param deviceId the id for the device that should be used
     * @param index the number of the factor in the factor information array
     */
    activateFactor(factorName: string | undefined, deviceId: string | undefined, index: number): Promise<void>;
    /**
     * Verfies, if a one time password is correct
     * @param index the index of the factor in the factor information array
     */
    verifyWithOTP(index: number): Promise<void>;
    /**
     * Verfies, if a one time password is correct and the device is correct as well
     * @param index the index of the factor in the factor information array
     */
    verifyWithOTPAndDevice(index: number): Promise<void>;
    /**
     * Verfies the authentication using polling
     * @param index the index of the factor in the factor information array
     */
    verifyPoll(index: number): Promise<void>;
    /**
     * Initializes the factor information array
     */
    private initFacorInfo;
    static ɵfac: i0.ɵɵFactoryDeclaration<MfaFormControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MfaFormControlComponent, "imx-mfa-form-control", never, { "itemId": { "alias": "itemId"; "required": false; }; "busyService": { "alias": "busyService"; "required": false; }; }, { "loaded": "loaded"; }, never, never, false, never>;
}
export {};
