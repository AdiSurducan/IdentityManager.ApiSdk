import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, EventEmitter, forwardRef, Component, Input, Output, Inject, NgModule } from '@angular/core';
import * as i3$1 from '@angular/forms';
import { FormControl, NG_VALUE_ACCESSOR, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i5 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i4 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import * as i6 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i2 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i1$1 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule } from '@elemental-ui/core';
import * as i7 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i1 from 'qbm';
import { BaseCdr, BusyService, CdrModule, BusyIndicatorModule } from 'qbm';
import { V2Client, TypedClient, VerifyPollingResult } from '@imx-modules/imx-api-olg';
import { ValType } from '@imx-modules/imx-qbm-dbts';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class OlgApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function OlgApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OlgApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: OlgApiService, factory: OlgApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OlgApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i1.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PortalMfaService {
    api;
    constructor(api) {
        this.api = api;
    }
    activateFactor(workflowActionId, deviceId) {
        return this.api.client.portal_onelogin_mfa_activate_post(workflowActionId, deviceId);
    }
    verifyWithVerificationId(workflowActionId, verificationId, code, deviceId) {
        return this.api.client.portal_onelogin_mfa_verifyotpwithverificationid_post(workflowActionId, verificationId, code, {
            deviceid: deviceId,
        });
    }
    verifyWithPolling(workflowActionId, verificationId) {
        return this.api.client.portal_onelogin_mfa_poll_get(workflowActionId, verificationId);
    }
    getFactors() {
        return this.api.client.portal_onelogin_mfa_factors_get();
    }
    static ɵfac = function PortalMfaService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PortalMfaService)(i0.ɵɵinject(OlgApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PortalMfaService, factory: PortalMfaService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PortalMfaService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: OlgApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MfaFormControlComponent_div_0_mat_card_1_ng_container_7_p_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 10);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#To authenticate, use the one-time password."));
} }
function MfaFormControlComponent_div_0_mat_card_1_ng_container_7_p_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 10);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#To authenticate, use either the push notification or the one-time password of your OneLogin Protector app."), " ");
} }
function MfaFormControlComponent_div_0_mat_card_1_ng_container_7_p_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 10);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#To authenticate, use the one-time password of your authentication app."), " ");
} }
function MfaFormControlComponent_div_0_mat_card_1_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, MfaFormControlComponent_div_0_mat_card_1_ng_container_7_p_1_Template, 3, 3, "p", 8)(2, MfaFormControlComponent_div_0_mat_card_1_ng_container_7_p_2_Template, 3, 3, "p", 8)(3, MfaFormControlComponent_div_0_mat_card_1_ng_container_7_p_3_Template, 3, 3, "p", 8);
    i0.ɵɵelement(4, "imx-cdr-editor", 9);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const info_r2 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.isOTP(info_r2.factor.Name));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.isProtect(info_r2.factor.Name));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.isAuthenticator(info_r2.factor.Name));
    i0.ɵɵadvance();
    i0.ɵɵproperty("cdr", info_r2.authCdr);
} }
function MfaFormControlComponent_div_0_mat_card_1_ng_container_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "p", 11);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const info_r2 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 1, info_r2.authMessage));
} }
function MfaFormControlComponent_div_0_mat_card_1_mat_spinner_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner", 12);
} }
function MfaFormControlComponent_div_0_mat_card_1_mat_spinner_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner", 13);
} }
function MfaFormControlComponent_div_0_mat_card_1_button_16_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 14);
    i0.ɵɵlistener("click", function MfaFormControlComponent_div_0_mat_card_1_button_16_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r6); const i_r5 = i0.ɵɵnextContext().index; const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.verifyWithOTP(i_r5)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const info_r2 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("disabled", ctx_r2.isAuthenticated || !ctx_r2.isCDRValid(info_r2.authCdr) || info_r2.loading);
    i0.ɵɵattribute("data-imx-identifier", "otp-factor-action-" + info_r2.factor.Display);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, "#LDS#Authenticate"), " ");
} }
function MfaFormControlComponent_div_0_mat_card_1_button_17_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 14);
    i0.ɵɵlistener("click", function MfaFormControlComponent_div_0_mat_card_1_button_17_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r7); const i_r5 = i0.ɵɵnextContext().index; const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.verifyWithOTPAndDevice(i_r5)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const info_r2 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("disabled", ctx_r2.isAuthenticated || !ctx_r2.isCDRValid(info_r2.authCdr) || info_r2.loading);
    i0.ɵɵattribute("data-imx-identifier", "otp-factor-action-" + info_r2.factor.Display);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, "#LDS#Authenticate"), " ");
} }
function MfaFormControlComponent_div_0_mat_card_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 2)(1, "mat-card-header")(2, "mat-card-title");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-card-subtitle");
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(6, "mat-card-content");
    i0.ɵɵtemplate(7, MfaFormControlComponent_div_0_mat_card_1_ng_container_7_Template, 5, 4, "ng-container", 0)(8, MfaFormControlComponent_div_0_mat_card_1_ng_container_8_Template, 4, 3, "ng-container", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(9, "mat-card-actions")(10, "button", 3);
    i0.ɵɵlistener("click", function MfaFormControlComponent_div_0_mat_card_1_Template_button_click_10_listener() { const ctx_r3 = i0.ɵɵrestoreView(_r1); const info_r2 = ctx_r3.$implicit; const i_r5 = ctx_r3.index; const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.activateFactor(info_r2.factor.Name, info_r2.factor.Id, i_r5)); });
    i0.ɵɵtext(11);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(13, MfaFormControlComponent_div_0_mat_card_1_mat_spinner_13_Template, 1, 0, "mat-spinner", 4);
    i0.ɵɵelement(14, "span", 5);
    i0.ɵɵtemplate(15, MfaFormControlComponent_div_0_mat_card_1_mat_spinner_15_Template, 1, 0, "mat-spinner", 6)(16, MfaFormControlComponent_div_0_mat_card_1_button_16_Template, 3, 5, "button", 7)(17, MfaFormControlComponent_div_0_mat_card_1_button_17_Template, 3, 5, "button", 7);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const info_r2 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(info_r2.factor.Display);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(info_r2.factor.Name);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", info_r2.showCdr);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", info_r2.authMessage && info_r2.authMessage.length > 0);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r2.isAuthenticated || info_r2.factor.Id === (ctx_r2.activatedFactor == null ? null : ctx_r2.activatedFactor.device_id));
    i0.ɵɵattribute("data-imx-identifier", "activate-factor-" + info_r2.factor.Display);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(12, 11, "#LDS#Use authentication method"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", info_r2.activating);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", info_r2.showCdr && info_r2.loading);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.isOTP(info_r2.factor.Name));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.isProtect(info_r2.factor.Name) || ctx_r2.isAuthenticator(info_r2.factor.Name));
} }
function MfaFormControlComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, MfaFormControlComponent_div_0_mat_card_1_Template, 18, 13, "mat-card", 1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.authFactorInfo);
} }
/**
 * Represents a list of OneLogin authentication factors as a FormControl<boolean> instance
 * The initial value of the FormControl is false, and changes to true, if one log in method was sucessful
 */
class MfaFormControlComponent {
    mfa;
    entityService;
    /** Array, that stores auth factor information */
    authFactorInfo = [];
    /** currently activated factor */
    activatedFactor;
    /**
     * Gets whether the user is authenticated or not
     */
    get isAuthenticated() {
        return this.formControl.value;
    }
    /** on change function for the ControlValueAccessor */
    onChange;
    /** on touch function for the ControlValueAccessor */
    onTouch;
    /** The form control associated with this control */
    formControl = new FormControl(false, { nonNullable: true });
    /** The id of the object that is tested*/
    itemId;
    /** BusyService for loading */
    busyService;
    /** emmits, if all controls have been loaded */
    loaded = new EventEmitter();
    ldsLoginFail = '#LDS#Authentication failed. Please try again.';
    constructor(mfa, entityService) {
        this.mfa = mfa;
        this.entityService = entityService;
    }
    // ---------begin methods from value accessor-----------------
    /**
     * Updates the value of the form control
     * @param authenticated value that should be set
     */
    writeValue(authenticated) {
        this.formControl.setValue(authenticated);
        if (this.onChange) {
            this.onChange(authenticated);
        }
        if (this.onTouch) {
            this.onTouch(authenticated);
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouch = fn;
    }
    // ---------end methods from value accessor-----------------
    async ngOnInit() {
        const isBusy = this.busyService?.beginBusy();
        try {
            await this.initFacorInfo();
        }
        finally {
            isBusy?.endBusy();
        }
    }
    /**
     * Checks, if the factor is a one time password
     * @param factorName name of the factor to check
     * @returns true, if  one time password is used
     */
    isOTP(factorName) {
        return factorName ? ['OneLogin Email', 'SMS'].includes(factorName) : false;
    }
    /**
     * Checks, if the factor is using the OneLogin protectopr app
     * @param factorName name of the factor to check
     * @returns true, if the OneLogin protectopr app is used
     */
    isProtect(factorName) {
        return factorName === 'OneLogin';
    }
    /**
     * Checks, if the factor is using the authenticator or
     * @param factorName name of the factor to check
     * @returns true, if authenticator app is used
     */
    isAuthenticator(factorName) {
        return factorName === 'Google Authenticator';
    }
    /** Checks, if a cdr is valid */
    isCDRValid(cdr) {
        return cdr?.column.GetValue().length > 0;
    }
    /** Checks, if a factor is activated */
    get isActivated() {
        if (this.activatedFactor) {
            return true;
        }
        return false;
    }
    /** resets the state of an authenticator */
    resetState(index) {
        this.authFactorInfo[index].authCdr?.column.PutValue('');
        this.authFactorInfo.forEach((elem) => (elem.showCdr = false));
        this.activatedFactor = undefined;
    }
    /**
     * Activates a factor and shows its cdr. Then the user is able to add information
     * @param factorName  the name of the factor that needs to be activated
     * @param deviceId the id for the device that should be used
     * @param index the number of the factor in the factor information array
     */
    async activateFactor(factorName, deviceId, index) {
        if (!deviceId) {
            throw Error('This factor has an incorrect deviceId');
            return;
        }
        this.authFactorInfo[index].activating = true;
        try {
            this.authFactorInfo.forEach((elem) => {
                elem.showCdr = false;
                elem.authMessage = '';
            });
            this.activatedFactor = await this.mfa.activateFactor(this.itemId, deviceId);
            this.authFactorInfo[index].showCdr = true;
            if (this.isProtect(factorName)) {
                this.verifyPoll(index);
            }
        }
        finally {
            this.authFactorInfo[index].activating = false;
        }
    }
    /**
     * Verfies, if a one time password is correct
     * @param index the index of the factor in the factor information array
     */
    async verifyWithOTP(index) {
        this.authFactorInfo[index].loading = true;
        try {
            const result = this.activatedFactor && this.activatedFactor.id
                ? await this.mfa.verifyWithVerificationId(this.itemId, this.activatedFactor.id, this.authFactorInfo[index].authCdr?.column.GetValue())
                : null;
            if (result) {
                this.writeValue(true);
            }
            else {
                this.authFactorInfo[index].authMessage = this.ldsLoginFail;
                this.resetState(index);
            }
        }
        finally {
            this.authFactorInfo[index].loading = false;
        }
    }
    /**
     * Verfies, if a one time password is correct and the device is correct as well
     * @param index the index of the factor in the factor information array
     */
    async verifyWithOTPAndDevice(index) {
        this.authFactorInfo[index].loading = true;
        try {
            const result = this.activatedFactor && this.activatedFactor.id
                ? await this.mfa.verifyWithVerificationId(this.itemId, this.activatedFactor.id, this.authFactorInfo[index].authCdr?.column.GetValue(), this.activatedFactor.device_id)
                : null;
            if (result) {
                this.writeValue(true);
            }
            else {
                this.authFactorInfo[index].authMessage = this.ldsLoginFail;
                this.resetState(index);
            }
        }
        finally {
            this.authFactorInfo[index].loading = true;
        }
    }
    /**
     * Verfies the authentication using polling
     * @param index the index of the factor in the factor information array
     */
    async verifyPoll(index) {
        this.authFactorInfo[index].loading = true;
        try {
            const pollResult = this.activatedFactor && this.activatedFactor.id ? await this.mfa.verifyWithPolling(this.itemId, this.activatedFactor.id) : null;
            if (pollResult === VerifyPollingResult.Accepted) {
                this.writeValue(true);
            }
            else {
                this.authFactorInfo[index].authMessage = this.ldsLoginFail;
                this.resetState(index);
            }
        }
        finally {
            this.authFactorInfo[index].loading = true;
        }
    }
    /**
     * Initializes the factor information array
     */
    async initFacorInfo() {
        const factors = await this.mfa.getFactors();
        factors?.Factors?.forEach((factor) => {
            this.authFactorInfo.push({
                factor,
                authCdr: new BaseCdr(this.entityService.createLocalEntityColumn({
                    ColumnName: 'OTP',
                    Type: ValType.Text,
                    MinLen: 1,
                }), '#LDS#One-Time Password'),
                showCdr: false,
                authMessage: '',
                activating: false,
                loading: false,
            });
        });
        this.loaded.emit(this.authFactorInfo.length > 0);
    }
    static ɵfac = function MfaFormControlComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MfaFormControlComponent)(i0.ɵɵdirectiveInject(PortalMfaService), i0.ɵɵdirectiveInject(i1.EntityService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MfaFormControlComponent, selectors: [["imx-mfa-form-control"]], inputs: { itemId: "itemId", busyService: "busyService" }, outputs: { loaded: "loaded" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => MfaFormControlComponent),
                    multi: true,
                },
            ])], decls: 1, vars: 1, consts: [[4, "ngIf"], ["class", "auth-factor", 4, "ngFor", "ngForOf"], [1, "auth-factor"], ["mat-stroked-button", "", 3, "click", "disabled"], ["diameter", "30", "class", "imx-margin-horizontal-15", 4, "ngIf"], [1, "imx-spacer"], ["diameter", "30", 4, "ngIf"], ["class", "auth-button", "mat-flat-button", "", "color", "primary", 3, "disabled", "click", 4, "ngIf"], ["class", "auth-text", 4, "ngIf"], [3, "cdr"], [1, "auth-text"], [1, "auth-text", "failed"], ["diameter", "30", 1, "imx-margin-horizontal-15"], ["diameter", "30"], ["mat-flat-button", "", "color", "primary", 1, "auth-button", 3, "click", "disabled"]], template: function MfaFormControlComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, MfaFormControlComponent_div_0_Template, 2, 1, "div", 0);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.authFactorInfo.length > 0);
        } }, dependencies: [i3.NgForOf, i3.NgIf, i4.MatCard, i4.MatCardActions, i4.MatCardContent, i4.MatCardHeader, i4.MatCardSubtitle, i4.MatCardTitle, i5.MatButton, i1.CdrEditorComponent, i6.MatProgressSpinner, i7.TranslatePipe], styles: ["[_nghost-%COMP%]{overflow:auto}[_nghost-%COMP%]     .eui-alert{margin-bottom:20px}[_nghost-%COMP%]     .mat-card-header-text{margin:0}[_nghost-%COMP%]   .mat-mdc-card-actions[_ngcontent-%COMP%]{display:flex}[_nghost-%COMP%]   .imx-spacer[_ngcontent-%COMP%]{flex:1 1 auto}[_nghost-%COMP%]   .auth-text[_ngcontent-%COMP%]{font-size:14px}[_nghost-%COMP%]   .auth-factor[_ngcontent-%COMP%]{margin-bottom:20px}[_nghost-%COMP%]   .auth-button[_ngcontent-%COMP%]{display:flex;flex-direction:row}.eui-light-theme   [_nghost-%COMP%]   .auth-text[_ngcontent-%COMP%]{color:#919799}.eui-light-theme   [_nghost-%COMP%]   .failed[_ngcontent-%COMP%]{color:#db2534}.eui-dark-theme   [_nghost-%COMP%]   .auth-text[_ngcontent-%COMP%]{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .failed[_ngcontent-%COMP%]{color:#f29d99}.eui-contrast-theme   [_nghost-%COMP%]   .auth-text[_ngcontent-%COMP%]{color:#c4cacc}.eui-contrast-theme   [_nghost-%COMP%]   .failed[_ngcontent-%COMP%]{color:#db2534}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MfaFormControlComponent, [{
        type: Component,
        args: [{ selector: 'imx-mfa-form-control', providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => MfaFormControlComponent),
                        multi: true,
                    },
                ], template: "<div *ngIf=\"authFactorInfo.length > 0\">\n  <mat-card class=\"auth-factor\" *ngFor=\"let info of authFactorInfo; index as i\">\n    <mat-card-header>\n      <mat-card-title>{{ info.factor.Display }}</mat-card-title>\n      <mat-card-subtitle>{{ info.factor.Name }}</mat-card-subtitle>\n    </mat-card-header>\n    <mat-card-content>\n      <ng-container *ngIf=\"info.showCdr\">\n        <p class=\"auth-text\" *ngIf=\"isOTP(info.factor.Name)\">{{ '#LDS#To authenticate, use the one-time password.' | translate }}</p>\n        <p class=\"auth-text\" *ngIf=\"isProtect(info.factor.Name)\">\n          {{\n            '#LDS#To authenticate, use either the push notification or the one-time password of your OneLogin Protector app.' | translate\n          }}\n        </p>\n        <p class=\"auth-text\" *ngIf=\"isAuthenticator(info.factor.Name)\">\n          {{ '#LDS#To authenticate, use the one-time password of your authentication app.' | translate }}\n        </p>\n        <imx-cdr-editor [cdr]=\"info.authCdr\"></imx-cdr-editor>\n      </ng-container>\n      <ng-container *ngIf=\"info.authMessage && info.authMessage.length > 0\">\n        <p class=\"auth-text failed\">{{ info.authMessage | translate }}</p>\n      </ng-container>\n    </mat-card-content>\n    <mat-card-actions>\n      <button\n        mat-stroked-button\n        [attr.data-imx-identifier]=\"'activate-factor-' + info.factor.Display\"\n        (click)=\"activateFactor(info.factor.Name, info.factor.Id, i)\"\n        [disabled]=\"isAuthenticated || info.factor.Id === activatedFactor?.device_id\"\n      >\n        {{ '#LDS#Use authentication method' | translate }}\n      </button>\n      <mat-spinner diameter=\"30\" class=\"imx-margin-horizontal-15\" *ngIf=\"info.activating\"></mat-spinner>\n\n      <span class=\"imx-spacer\"></span>\n      <mat-spinner diameter=\"30\" *ngIf=\"info.showCdr && info.loading\"></mat-spinner>\n      <button\n        class=\"auth-button\"\n        *ngIf=\"isOTP(info.factor.Name)\"\n        mat-flat-button\n        [attr.data-imx-identifier]=\"'otp-factor-action-' + info.factor.Display\"\n        color=\"primary\"\n        [disabled]=\"isAuthenticated || !isCDRValid(info.authCdr) || info.loading\"\n        (click)=\"verifyWithOTP(i)\"\n      >\n        {{ '#LDS#Authenticate' | translate }}\n      </button>\n      <button\n        class=\"auth-button\"\n        *ngIf=\"isProtect(info.factor.Name) || isAuthenticator(info.factor.Name)\"\n        mat-flat-button\n        [attr.data-imx-identifier]=\"'otp-factor-action-' + info.factor.Display\"\n        color=\"primary\"\n        [disabled]=\"isAuthenticated || !isCDRValid(info.authCdr) || info.loading\"\n        (click)=\"verifyWithOTPAndDevice(i)\"\n      >\n        {{ '#LDS#Authenticate' | translate }}\n      </button>\n    </mat-card-actions>\n  </mat-card>\n</div>\n", styles: [":host{overflow:auto}:host ::ng-deep .eui-alert{margin-bottom:20px}:host ::ng-deep .mat-card-header-text{margin:0}:host .mat-mdc-card-actions{display:flex}:host .imx-spacer{flex:1 1 auto}:host .auth-text{font-size:14px}:host .auth-factor{margin-bottom:20px}:host .auth-button{display:flex;flex-direction:row}.eui-light-theme :host .auth-text{color:#919799}.eui-light-theme :host .failed{color:#db2534}.eui-dark-theme :host .auth-text{color:#c4cacc}.eui-dark-theme :host .failed{color:#f29d99}.eui-contrast-theme :host .auth-text{color:#c4cacc}.eui-contrast-theme :host .failed{color:#db2534}\n"] }]
    }], () => [{ type: PortalMfaService }, { type: i1.EntityService }], { itemId: [{
            type: Input
        }], busyService: [{
            type: Input
        }], loaded: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MfaFormControlComponent, { className: "MfaFormControlComponent", filePath: "lib\\mfa-form-control\\mfa-form-control.component.ts", lineNumber: 64 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MfaComponent_imx_busy_indicator_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-busy-indicator");
} }
function MfaComponent_eui_alert_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 6);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, "#LDS#There are no authentication methods defined for you. Contact your administrator."), " ");
} }
/**
 * Component, that provides a list of OneLogin authentication factors
 *
 * Can be displayed in a side sheet, that will be closed, if one authentication method was successful
 */
class MfaComponent {
    data;
    authForm = new FormGroup({
        authenticator: new FormControl(false, { nonNullable: true }),
    });
    /** Indicates whether the user has authenticators defined or not */
    hasAuthenticators = false;
    /** Indicates whether the control is loading or not */
    isLoading = false;
    /** busy service used in the authentication control and its sub controls */
    busyService = new BusyService();
    subscriptions = [];
    constructor(data, sideSheetRef, change) {
        this.data = data;
        this.subscriptions.push(this.busyService.busyStateChanged.subscribe((state) => {
            this.isLoading = state;
            change.detectChanges();
        }));
        this.subscriptions.push(this.authForm.controls.authenticator.valueChanges.subscribe((value) => {
            if (!!value) {
                sideSheetRef.close(true);
            }
        }));
    }
    /**
     * unsubscribes all subscriptions, when the component is destroyed
     */
    ngOnDestroy() {
        this.subscriptions.forEach((sub) => sub.unsubscribe());
    }
    static ɵfac = function MfaComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MfaComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MfaComponent, selectors: [["ng-component"]], decls: 10, vars: 10, consts: [["eui-sidesheet-content", "", 1, "imx-flex-sheet"], ["type", "info", 1, "imx-info", 3, "condensed", "colored"], [4, "ngIf"], ["type", "error", 3, "condensed", "colored", 4, "ngIf"], [3, "formGroup"], ["formControlName", "authenticator", 3, "loaded", "busyService", "itemId"], ["type", "error", 3, "condensed", "colored"]], template: function MfaComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "eui-alert", 1)(2, "span");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "mat-card");
            i0.ɵɵtemplate(6, MfaComponent_imx_busy_indicator_6_Template, 1, 0, "imx-busy-indicator", 2)(7, MfaComponent_eui_alert_7_Template, 3, 5, "eui-alert", 3);
            i0.ɵɵelementStart(8, "form", 4)(9, "imx-mfa-form-control", 5);
            i0.ɵɵlistener("loaded", function MfaComponent_Template_imx_mfa_form_control_loaded_9_listener($event) { return ctx.hasAuthenticators = $event; });
            i0.ɵɵelementEnd()()()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("condensed", true)("colored", true);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 8, "#LDS#You must authenticate before you can proceed. To do this, use one of the following multi-factor authentication methods."));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.isLoading);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.isLoading && !ctx.hasAuthenticators);
            i0.ɵɵadvance();
            i0.ɵɵproperty("formGroup", ctx.authForm);
            i0.ɵɵadvance();
            i0.ɵɵproperty("busyService", ctx.busyService)("itemId", ctx.data.workflowActionId);
        } }, dependencies: [i3.NgIf, i3$1.ɵNgNoValidate, i3$1.NgControlStatus, i3$1.NgControlStatusGroup, i3$1.FormGroupDirective, i3$1.FormControlName, i4.MatCard, i1$1.EuiAlertComponent, i1$1.EuiSidesheetContentDirective, i1.BusyIndicatorComponent, MfaFormControlComponent, i7.TranslatePipe], styles: [".imx-flex-sheet[_ngcontent-%COMP%]{display:flex;flex-direction:column}imx-busy-indicator[_ngcontent-%COMP%]{align-self:center;justify-self:center}eui-alert[_ngcontent-%COMP%]{margin-bottom:20px}.mat-mdc-card[_ngcontent-%COMP%]{display:flex;flex-direction:column}.imx-info[_ngcontent-%COMP%]{margin-bottom:20px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MfaComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content class=\"imx-flex-sheet\">\n  <eui-alert class=\"imx-info\" type=\"info\" [condensed]=\"true\" [colored]=\"true\">\n    <span>{{\n      '#LDS#You must authenticate before you can proceed. To do this, use one of the following multi-factor authentication methods.'\n        | translate\n    }}</span>\n  </eui-alert>\n  <mat-card>\n    <imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\n    <eui-alert type=\"error\" [condensed]=\"true\" [colored]=\"true\" *ngIf=\"!isLoading && !hasAuthenticators\">\n      {{ '#LDS#There are no authentication methods defined for you. Contact your administrator.' | translate }}\n    </eui-alert>\n    <form [formGroup]=\"authForm\">\n      <imx-mfa-form-control\n        formControlName=\"authenticator\"\n        [busyService]=\"busyService\"\n        [itemId]=\"data.workflowActionId\"\n        (loaded)=\"hasAuthenticators = $event\"\n      ></imx-mfa-form-control>\n    </form>\n  </mat-card>\n</div>\n", styles: [".imx-flex-sheet{display:flex;flex-direction:column}imx-busy-indicator{align-self:center;justify-self:center}eui-alert{margin-bottom:20px}.mat-mdc-card{display:flex;flex-direction:column}.imx-info{margin-bottom:20px}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1$1.EuiSidesheetRef }, { type: i0.ChangeDetectorRef }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MfaComponent, { className: "MfaComponent", filePath: "lib\\mfa\\mfa.component.ts", lineNumber: 50 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    extService;
    router;
    constructor(extService, router) {
        this.extService = extService;
        this.router = router;
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register('mfaComponent', {
            instance: MfaComponent,
        });
        this.extService.register('authenticator', {
            instance: MfaFormControlComponent,
        });
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i1.ExtService), i0.ɵɵinject(i2.Router)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1.ExtService }, { type: i2.Router }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [];
class OlgConfigModule {
    initializer;
    logger;
    constructor(initializer, logger) {
        this.initializer = initializer;
        this.logger = logger;
        this.logger.info(this, '🔥 OLG loaded');
        this.initializer.onInit(routes);
        this.logger.info(this, '▶️ OLG initialized');
    }
    static ɵfac = function OlgConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OlgConfigModule)(i0.ɵɵinject(InitService), i0.ɵɵinject(i1.ClassloggerService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: OlgConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [PortalMfaService], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            MatFormFieldModule,
            MatInputModule,
            MatCardModule,
            MatButtonModule,
            MatDividerModule,
            RouterModule.forChild(routes),
            TranslateModule,
            EuiCoreModule,
            CdrModule,
            BusyIndicatorModule,
            MatProgressSpinnerModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OlgConfigModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule,
                    FormsModule,
                    ReactiveFormsModule,
                    MatFormFieldModule,
                    MatInputModule,
                    MatCardModule,
                    MatButtonModule,
                    MatDividerModule,
                    RouterModule.forChild(routes),
                    TranslateModule,
                    EuiCoreModule,
                    CdrModule,
                    BusyIndicatorModule,
                    MatProgressSpinnerModule,
                ],
                declarations: [MfaComponent, MfaFormControlComponent],
                providers: [PortalMfaService],
                exports: [MfaFormControlComponent],
            }]
    }], () => [{ type: InitService }, { type: i1.ClassloggerService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(OlgConfigModule, { declarations: [MfaComponent, MfaFormControlComponent], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatCardModule,
        MatButtonModule,
        MatDividerModule, i2.RouterModule, TranslateModule,
        EuiCoreModule,
        CdrModule,
        BusyIndicatorModule,
        MatProgressSpinnerModule], exports: [MfaFormControlComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MfaComponent, MfaFormControlComponent, OlgConfigModule, PortalMfaService };
//# sourceMappingURL=olg.mjs.map
