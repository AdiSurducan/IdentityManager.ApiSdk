import * as i0 from "@angular/core";
import * as i1 from "./column-info.component";
import * as i2 from "../application-property/application-property.module";
import * as i3 from "@angular/common";
import * as i4 from "qbm";
import * as i5 from "@elemental-ui/core";
import * as i6 from "@ngx-translate/core";
import * as i7 from "@angular/forms";
import * as i8 from "@angular/material/button";
import * as i9 from "@angular/material/form-field";
import * as i10 from "@angular/material/input";
export declare class ColumnInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ColumnInfoModule, [typeof i1.ColumnInfoComponent], [typeof i2.ApplicationPropertyModule, typeof i3.CommonModule, typeof i4.DisableControlModule, typeof i5.EuiCoreModule, typeof i4.QbmModule, typeof i6.TranslateModule, typeof i7.ReactiveFormsModule, typeof i8.MatButtonModule, typeof i9.MatFormFieldModule, typeof i10.MatInputModule], [typeof i1.ColumnInfoComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ColumnInfoModule>;
}
