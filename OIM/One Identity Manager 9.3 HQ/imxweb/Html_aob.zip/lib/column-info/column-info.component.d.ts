import { EntityValue } from '@imx-modules/imx-qbm-dbts';
import * as i0 from "@angular/core";
export declare class ColumnInfoComponent<T> {
    property: EntityValue<T>;
    icon: string;
    placeholder: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnInfoComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColumnInfoComponent<any>, "imx-column-info", never, { "property": { "alias": "property"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; }, {}, never, never, false, never>;
}
