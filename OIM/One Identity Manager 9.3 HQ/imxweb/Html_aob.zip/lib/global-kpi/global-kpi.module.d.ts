import * as i0 from "@angular/core";
import * as i1 from "./global-kpi.component";
import * as i2 from "./kpi-tile/kpi-tile.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/material/card";
import * as i5 from "@angular/material/button";
import * as i6 from "@angular/material/dialog";
import * as i7 from "@elemental-ui/core";
import * as i8 from "@ngx-translate/core";
import * as i9 from "qer";
export declare class GlobalKpiModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalKpiModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GlobalKpiModule, [typeof i1.GlobalKpiComponent, typeof i2.KpiTileComponent], [typeof i3.CommonModule, typeof i4.MatCardModule, typeof i5.MatButtonModule, typeof i6.MatDialogModule, typeof i7.EuiCoreModule, typeof i8.TranslateModule, typeof i9.TilesModule], [typeof i1.GlobalKpiComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GlobalKpiModule>;
}
