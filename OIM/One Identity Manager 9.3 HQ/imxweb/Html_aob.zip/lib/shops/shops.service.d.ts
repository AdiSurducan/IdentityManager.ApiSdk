import { PortalApplication, PortalApplicationinshop, PortalShops } from '@imx-modules/imx-api-aob';
import { CollectionLoadParameters, TypedEntity, TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { ApiClientService, ClassloggerService } from 'qbm';
import { AobApiService } from '../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class ShopsService {
    private readonly aobClient;
    private readonly logger;
    private readonly apiProvider;
    get display(): string;
    constructor(aobClient: AobApiService, logger: ClassloggerService, apiProvider: ApiClientService);
    get(parameters?: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalShops> | undefined>;
    getApplicationInShop(application: string, parameters?: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalApplicationinshop> | undefined>;
    getFirstAndCount(uidApplication: string): Promise<{
        first: TypedEntity | undefined;
        count: number;
    }>;
    updateApplicationInShops(application: PortalApplication, changeSet: {
        add: PortalShops[];
        remove: PortalShops[];
    }): Promise<boolean>;
    private addShops;
    private removeShops;
    static isAssigned(shop: PortalShops, shopsAssigned: PortalApplicationinshop[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShopsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ShopsService>;
}
