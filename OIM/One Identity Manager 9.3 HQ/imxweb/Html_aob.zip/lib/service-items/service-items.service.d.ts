import { PortalEntitlement, PortalEntitlementServiceitem } from '@imx-modules/imx-api-aob';
import { CollectionLoadParameters, ExtendedTypedEntityCollection } from '@imx-modules/imx-qbm-dbts';
import { ApiClientService } from 'qbm';
import { AobApiService } from '../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class ServiceItemsService {
    private readonly aobClient;
    private readonly apiProvider;
    constructor(aobClient: AobApiService, apiProvider: ApiClientService);
    get(entitlement: PortalEntitlement, parameters?: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalEntitlementServiceitem, unknown> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceItemsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServiceItemsService>;
}
