import { OnChanges, SimpleChanges } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { PortalApplication } from '@imx-modules/imx-api-aob';
import { CollectionLoadParameters, DisplayColumns, EntitySchema, IClientProperty, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { TranslateService } from '@ngx-translate/core';
import { BusyService, DataSourceToolbarSettings, DataTableComponent, DataTileMenuItem } from 'qbm';
import { IdentityService } from './identity.service';
import * as i0 from "@angular/core";
export declare class IdentitiesComponent implements OnChanges {
    private readonly identityService;
    private readonly sidesheetService;
    private readonly translateService;
    /**
     * The {@link PortalApplication | application} associated with the idenitities
     */
    application: PortalApplication;
    dataTable: DataTableComponent<any>;
    dstSettings: DataSourceToolbarSettings;
    navigationState: CollectionLoadParameters;
    selectedView: string;
    DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    displayedColumns: IClientProperty[];
    busyService: BusyService;
    constructor(identityService: IdentityService, sidesheetService: EuiSidesheetService, translateService: TranslateService);
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    onNavigationStateChanged(navigationState: CollectionLoadParameters): Promise<void>;
    onViewSelectionChanged(selectedView: string): void;
    /**
     * Method that is triggered by the (search) output of the data table
     * Reinits the data source
     * @param keywords the search value
     */
    onSearch(keywords: string): Promise<void>;
    /**
     * Method that is triggered by the (highlightedEntityChanged) output of the data table
     * opens the details
     * @param selectedItem the TypedEntity that is selected
     */
    onHighlightedEntityChanged(selectedItem: TypedEntity): Promise<void>;
    /**
     * Method that is triggered by the (actionSelected) output of the data tile component
     * opens the details
     * @param selectedItem the TypedEntity that is selected
     */
    onSelectedTileChanged(selectedItem: DataTileMenuItem): Promise<void>;
    /**
     * Opens a side sheet that displays identity details
     * @param item the identity, that details should be opened
     */
    onOpenDetails(item?: TypedEntity): Promise<void>;
    /**
     * Loads the data for the table
     * @returns an {@link ExtendedTypedEntityCollection | extended typed entity collection} of {@link PortalApplicationIdentities | application identities}
     */
    private getData;
    private setDst;
    private initNavigationState;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdentitiesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IdentitiesComponent, "imx-aob-identities", never, { "application": { "alias": "application"; "required": false; }; }, {}, never, never, false, never>;
}
