import { OnInit } from '@angular/core';
import { PortalApplicationIdentitiesbyidentity } from '@imx-modules/imx-api-aob';
import { CollectionLoadParameters, DisplayColumns, EntitySchema, IClientProperty } from '@imx-modules/imx-qbm-dbts';
import { DataSourceToolbarSettings, DataViewSource, ImxTranslationProviderService } from 'qbm';
import { IdentityDetailData } from '../identity-detail-data';
import { IdentityService } from '../identity.service';
import * as i0 from "@angular/core";
export declare class IdentityDetailComponent implements OnInit {
    data: IdentityDetailData;
    private readonly identityService;
    readonly translateProvider: ImxTranslationProviderService;
    dataSource: DataViewSource<PortalApplicationIdentitiesbyidentity>;
    dstSettings: DataSourceToolbarSettings;
    navigationState: CollectionLoadParameters;
    DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    displayedColumns: IClientProperty[];
    constructor(data: IdentityDetailData, identityService: IdentityService, translateProvider: ImxTranslationProviderService, dataSource: DataViewSource<PortalApplicationIdentitiesbyidentity>);
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdentityDetailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IdentityDetailComponent, "imx-identity-detail", never, {}, {}, never, never, false, never>;
}
