import { PortalApplication } from '@imx-modules/imx-api-aob';
import { TypedEntity } from '@imx-modules/imx-qbm-dbts';
export interface IdentityDetailData {
    application: PortalApplication;
    selectedItem: TypedEntity | undefined;
}
