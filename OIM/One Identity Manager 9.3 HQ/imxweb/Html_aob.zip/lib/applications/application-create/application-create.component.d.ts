import { OnDestroy } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { PortalApplicationNew } from '@imx-modules/imx-api-aob';
import { IEntityColumn, ValueStruct } from '@imx-modules/imx-qbm-dbts';
import { TranslateService } from '@ngx-translate/core';
import { ColumnDependentReference, ConfirmationService } from 'qbm';
import * as i0 from "@angular/core";
export declare class ApplicationCreateComponent implements OnDestroy {
    private readonly sidesheetRef;
    private readonly translateService;
    readonly form: UntypedFormGroup;
    name: ColumnDependentReference;
    readonly description: ColumnDependentReference;
    readonly serviceCategory: ColumnDependentReference;
    readonly manager: ColumnDependentReference;
    readonly owner: ColumnDependentReference;
    readonly imageColumn: IEntityColumn;
    private readonly nameColumn;
    private readonly subscriptions;
    constructor(data: {
        application: PortalApplicationNew;
    }, sidesheetRef: EuiSidesheetRef, translateService: TranslateService, confirmation: ConfirmationService);
    ngOnDestroy(): void;
    updateName(value: ValueStruct<string>): Promise<void>;
    save(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationCreateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApplicationCreateComponent, "imx-application-create", never, {}, {}, never, never, false, never>;
}
