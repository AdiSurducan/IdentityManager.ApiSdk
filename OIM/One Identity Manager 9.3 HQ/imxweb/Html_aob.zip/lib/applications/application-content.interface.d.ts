import { PortalApplication, PortalApplicationNew } from '@imx-modules/imx-api-aob';
import { Subject } from 'rxjs';
export interface ApplicationContent {
    application: PortalApplication | PortalApplicationNew | undefined;
    totalCount?: number;
    keywords?: string;
    loadingSubject?: Subject<boolean>;
}
