import { AfterViewInit, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { IEntityColumn } from '@imx-modules/imx-qbm-dbts';
import { Base64ImageService, EntityColumnContainer } from 'qbm';
import * as i0 from "@angular/core";
export declare class ApplicationImageSelectComponent implements OnChanges, AfterViewInit {
    private readonly dialog;
    private readonly imageProvider;
    readonly control: UntypedFormControl;
    readonly columnContainer: EntityColumnContainer<string>;
    column: IEntityColumn;
    controlCreated: EventEmitter<UntypedFormControl>;
    private readonly icons;
    private readonly defaultIcon;
    constructor(dialog: MatDialog, imageProvider: Base64ImageService);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    openEditDialog(): Promise<void>;
    private updateControlValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationImageSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApplicationImageSelectComponent, "imx-application-image-select", never, { "column": { "alias": "column"; "required": false; }; }, { "controlCreated": "controlCreated"; }, never, never, false, never>;
}
