/**
 * Parameters for the {@link ImageSelectorDialogComponent|ImageSelectorDialogComponent}
 */
export interface ImageSelectorDialogParameter {
    /**
     * the header caption of the dialog
     */
    title: string;
    /**
     * the predefined list of icons
     */
    icons: {
        [name: string]: string;
    };
    /**
     * the default icon to select
     */
    defaultIcon: string;
    /**
     * the currently assigned/uploaded image url
     */
    imageUrl?: string;
}
