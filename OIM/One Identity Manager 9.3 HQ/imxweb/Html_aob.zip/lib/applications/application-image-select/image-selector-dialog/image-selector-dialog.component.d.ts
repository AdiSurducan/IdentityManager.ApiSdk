import { OnDestroy } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Base64ImageService, ClassloggerService, FileSelectorService } from 'qbm';
import { ImageSelectorDialogParameter } from './image-selector-dialog-parameter.interface';
import * as i0 from "@angular/core";
/**
 * A dialog to select an icon from a predefined list or upload an own one.
 */
export declare class ImageSelectorDialogComponent implements OnDestroy {
    dialogRef: MatDialogRef<ImageSelectorDialogComponent>;
    readonly imageHandler: Base64ImageService;
    private logger;
    private readonly fileSelector;
    get imageIsSelected(): boolean;
    imageUrl: string;
    fileFormatError: boolean;
    readonly iconNames: string[];
    readonly title: string;
    private selectedIconName;
    private readonly icons;
    private readonly subscriptions;
    constructor(dialogRef: MatDialogRef<ImageSelectorDialogComponent>, imageHandler: Base64ImageService, logger: ClassloggerService, data: ImageSelectorDialogParameter, fileSelector: FileSelectorService);
    ngOnDestroy(): void;
    onSave(): void;
    iconIsSelected(name: string): boolean;
    selectImage(newImageUrl?: string): void;
    selectIcon(name: string): void;
    emitFiles(event: EventTarget | null): void;
    resetFileFormatErrorState(): void;
    private getIconUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageSelectorDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageSelectorDialogComponent, "imx-image-selector-dialog", never, {}, {}, never, never, false, never>;
}
