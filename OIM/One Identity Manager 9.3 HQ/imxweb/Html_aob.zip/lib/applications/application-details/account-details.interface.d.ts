import { TypedEntity } from '@imx-modules/imx-qbm-dbts';
export interface AccountDetails {
    count: number;
    first: TypedEntity | undefined;
    uidApplication: string;
}
