import { EuiLoadingService } from '@elemental-ui/core';
import { CollectionLoadParameters } from '@imx-modules/imx-qbm-dbts';
import { SettingsService, TreeDatabase, TreeNodeResultParameter } from 'qbm';
import { ServiceCategoryService } from './service-category.service';
/** Provider of servicecategory-data for the imx-data-tree */
export declare class ServiceCategoryTreeDatabase extends TreeDatabase {
    private readonly loadingServiceElemental;
    private readonly settings;
    private readonly serviceCategoriesProvider;
    private readonly uidRootElement;
    constructor(loadingServiceElemental: EuiLoadingService, settings: SettingsService, serviceCategoriesProvider: ServiceCategoryService, uidRootElement: string);
    getData(showLoading: boolean, parameters?: CollectionLoadParameters): Promise<TreeNodeResultParameter>;
    private loadRoot;
    private loadData;
}
