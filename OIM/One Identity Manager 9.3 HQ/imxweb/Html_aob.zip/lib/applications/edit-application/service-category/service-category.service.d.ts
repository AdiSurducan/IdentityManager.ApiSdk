import { PortalServicecategories } from '@imx-modules/imx-api-qer';
import { CollectionLoadParameters, EntityCollectionData, EntitySchema, IEntity, TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { QerApiService } from 'qer';
import * as i0 from "@angular/core";
export declare class ServiceCategoryService {
    private readonly apiClient;
    constructor(apiClient: QerApiService);
    get serviceCategorySchema(): EntitySchema;
    get(parameters?: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalServicecategories>>;
    createChild(): IEntity;
    delete(uid: string): Promise<EntityCollectionData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceCategoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServiceCategoryService>;
}
