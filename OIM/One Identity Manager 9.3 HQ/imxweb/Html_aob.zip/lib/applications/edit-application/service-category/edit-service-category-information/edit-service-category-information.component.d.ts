import { OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { IEntity } from '@imx-modules/imx-qbm-dbts';
import { CdrFactoryService, ColumnDependentReference, ConfirmationService } from 'qbm';
import { ServiceCategoryService } from '../service-category.service';
import * as i0 from "@angular/core";
interface ServiceItemForm {
    cdrArray: FormArray;
}
export declare class EditServiceCategoryInformationComponent implements OnInit {
    private readonly categoryProvider;
    private readonly confirm;
    private readonly ref;
    private readonly cdrFactoryService;
    data: {
        serviceCategory: IEntity;
        isNew: boolean;
    };
    cdrList: (ColumnDependentReference | undefined)[];
    readonly formGroup: FormGroup<ServiceItemForm>;
    get formArray(): FormArray;
    constructor(categoryProvider: ServiceCategoryService, confirm: ConfirmationService, ref: EuiSidesheetRef, cdrFactoryService: CdrFactoryService, data: {
        serviceCategory: IEntity;
        isNew: boolean;
    });
    ngOnInit(): Promise<void>;
    save(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditServiceCategoryInformationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditServiceCategoryInformationComponent, "imx-edit-service-category-information", never, {}, {}, never, never, false, never>;
}
export {};
