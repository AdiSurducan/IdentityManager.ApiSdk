import * as i0 from "@angular/core";
export declare class ApplicationPropertyComponent {
    display: string;
    icon: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationPropertyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApplicationPropertyComponent, "imx-application-property", never, { "display": { "alias": "display"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; }, {}, never, ["*"], false, never>;
}
