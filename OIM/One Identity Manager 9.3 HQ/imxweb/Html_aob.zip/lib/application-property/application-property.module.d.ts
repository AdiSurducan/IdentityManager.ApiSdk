import * as i0 from "@angular/core";
import * as i1 from "./application-property.component";
import * as i2 from "@angular/common";
import * as i3 from "@elemental-ui/core";
export declare class ApplicationPropertyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationPropertyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ApplicationPropertyModule, [typeof i1.ApplicationPropertyComponent], [typeof i2.CommonModule, typeof i3.EuiCoreModule], [typeof i1.ApplicationPropertyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ApplicationPropertyModule>;
}
