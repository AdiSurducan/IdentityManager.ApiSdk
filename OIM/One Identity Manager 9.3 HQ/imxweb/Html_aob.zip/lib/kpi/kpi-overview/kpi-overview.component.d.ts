import { OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { ChartDto, PortalApplication } from '@imx-modules/imx-api-aob';
import { BusyService, ClassloggerService } from 'qbm';
import { KpiOverviewService } from './kpi-overview.service';
import * as i0 from "@angular/core";
/**
 * A component, that displays key Performance Indicators (KPIs) for an application
 *
 * @example
 * <imx-kpi-overview [application]="application"></imx-kpi-overview>
 */
export declare class KpiOverviewComponent implements OnChanges {
    readonly translateService: TranslateService;
    private kpiOverviewProvider;
    private logger;
    private matDialog;
    /**
     * @ignore internally used KPIs, that passes
     */
    chartDataPass: ChartDto[];
    /**
     * @ignore internally used KPIs, that failed
     */
    chartDataFail: ChartDto[];
    /**
     * @ignore columns for the mat-table that is shown, if a KPI has only one dataPoint
     */
    displayedColumns: string[];
    /**
     * The AobApplication, which KPI data should be displayed
     */
    application: PortalApplication;
    /**
     * @ignore the template used for the datail Dialog
     */
    chartDialog: TemplateRef<any>;
    private errorThreshhold;
    busyService: BusyService;
    isLoading: boolean;
    constructor(translateService: TranslateService, kpiOverviewProvider: KpiOverviewService, logger: ClassloggerService, matDialog: MatDialog);
    /**
     * Displays a busyIndicator and initializes the data, when the OnChanges life cycle hook is called
     */
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    /**
     * @ignore Opens a dialog that shows the details of a KPI
     * @param chart the data of a single chart
     */
    showDetails(chart: ChartDto, isFail: boolean): void;
    /**
     * @ignore determines whether a chart has detailed data
     * @param chart the data of a single chart
     */
    hasDetails(chart: ChartDto): boolean;
    /**
     * @ignore determines whether an application has chart data or not
     * @returns true, if there are failed or passed KPIs else it returns false
     */
    hasKpis(): boolean;
    /**
     * @ignore get an unified display for a date string
     * @param date a date string as represented in the chart
     * @returns the local date string for a date represented by an other string
     */
    getDateDisplay(date: string): string;
    /**
     * @ignore determines whether a chart has more then one data point
     * @param chart the data of a single chart
     * @returns true, if the chart has multiple points else it return false
     */
    private hasMultipleDataPoints;
    /**
     * @irgnore Builds an object, that could be passed to the detail dialog
     * @param chart the data of a single chart
     * @returns a dictionary, that can be display on the details dialog
     */
    private getChartData;
    /**
     * @ignore Build the ChartOptions that can be displayed with billboard.js
     * @param chart the data of a single chart
     * @returns a ChartOptions object, that can be used by billboard.js
     */
    private buildOptions;
    private accumulateTicks;
    static ɵfac: i0.ɵɵFactoryDeclaration<KpiOverviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KpiOverviewComponent, "imx-kpi-overview", never, { "application": { "alias": "application"; "required": false; }; }, {}, never, never, false, never>;
}
