import { ChartDto } from '@imx-modules/imx-api-aob';
import { ApiClientService } from 'qbm';
import { AobApiService } from '../../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class KpiOverviewService {
    private readonly aobClient;
    private readonly apiProvider;
    constructor(aobClient: AobApiService, apiProvider: ApiClientService);
    get(uidapplication: string): Promise<ChartDto[] | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<KpiOverviewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KpiOverviewService>;
}
