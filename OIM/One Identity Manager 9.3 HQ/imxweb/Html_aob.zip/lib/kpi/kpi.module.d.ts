import * as i0 from "@angular/core";
import * as i1 from "./kpi-overview/kpi-overview.component";
import * as i2 from "@angular/common";
import * as i3 from "@ngx-translate/core";
import * as i4 from "@angular/material/card";
import * as i5 from "@angular/material/button";
import * as i6 from "@angular/material/tooltip";
import * as i7 from "@elemental-ui/core";
import * as i8 from "qbm";
export declare class KpiModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<KpiModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<KpiModule, [typeof i1.KpiOverviewComponent], [typeof i2.CommonModule, typeof i3.TranslateModule, typeof i4.MatCardModule, typeof i5.MatButtonModule, typeof i6.MatTooltipModule, typeof i7.EuiCoreModule, typeof i7.EuiMaterialModule, typeof i8.ClassloggerModule, typeof i8.BusyIndicatorModule], [typeof i1.KpiOverviewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<KpiModule>;
}
