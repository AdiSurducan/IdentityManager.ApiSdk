import { PortalEntitlement, PortalApplicationinshop, PortalApplication } from '@imx-modules/imx-api-aob';
import { LifecycleAction } from './lifecycle-action.enum';
/**
 * Interface for the {@link MAT_DIALOG_DATA|MAT_DIALOG_DATA} of the {@link LifecycleActionComponent|LifecycleActionComponent}
 */
export interface LifecycleActionParameter {
    /** The mode to show the dialog. */
    action: LifecycleAction;
    type: 'AobEntitlement' | 'AobApplication';
    /** The list of elements which the {@link LifecycleActionComponent|LifecycleActionComponent} should show. */
    elements: PortalEntitlement[] | PortalApplication[];
    /** The list of shops for publishing the {@link PortalApplication|PortalApplication} or the {@link PortalEntitlement|PortalEntitlements} */
    shops: PortalApplicationinshop[];
}
