import { Platform } from '@angular/cdk/platform';
import { OnDestroy, OnInit } from '@angular/core';
import { FormGroup, UntypedFormControl } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { DisplayColumns, EntitySchema } from '@imx-modules/imx-qbm-dbts';
import { ClassloggerService, DataViewSource, LdsReplacePipe, MetadataService } from 'qbm';
import { AobApiService } from '../aob-api-client.service';
import { LifecycleActionParameter } from './lifecycle-action-parameter.interface';
import * as i0 from "@angular/core";
/**
 * A component that represents a dialog for submitting an {@link LifecycleAction|action} on the
 * given {@link PortalApplication|PortalApplication} or {@link PortalEntitlement|PortalEntitlements}.
 *
 */
export declare class LifecycleActionComponent implements OnDestroy, OnInit {
    dialogRef: MatDialogRef<LifecycleActionComponent>;
    readonly data: LifecycleActionParameter;
    private readonly logger;
    private readonly ldsReplace;
    private readonly translateService;
    private readonly metadataProvider;
    private readonly aobApiService;
    private readonly platform;
    dataSource: DataViewSource;
    readonly DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    /** The caption for the button with the corresponding action for specified {@link LifecycleAction|action} */
    actionButtonText: string;
    /** The caption for the heading title of this dialog. */
    dialogTitle: string;
    /** The display value for the specified type. */
    tableDisplay: string;
    /** the mininum date for the datepicker */
    readonly minDate: any;
    publishFuture: boolean;
    readonly publishDateForm: FormGroup<{
        datepickerFormControl: UntypedFormControl;
        whenToPublish: UntypedFormControl;
    }>;
    readonly datepickerFormControl: UntypedFormControl;
    readonly browserCulture: string;
    whenToPublish: 'now' | 'future';
    get dateString(): string;
    get timeString(): string;
    /**
     * @ignore
     * List of subscriptions.
     */
    private subscriptions;
    /** The list of colums to display in the dialog. */
    private displayedColumns;
    constructor(dialogRef: MatDialogRef<LifecycleActionComponent>, data: LifecycleActionParameter, logger: ClassloggerService, ldsReplace: LdsReplacePipe, translateService: TranslateService, metadataProvider: MetadataService, aobApiService: AobApiService, platform: Platform, dataSource: DataViewSource);
    /**
     * @ignore Used internally.
     */
    ngOnInit(): Promise<void>;
    /**
     * @ignore Used internally.
     * Unsubscribes all listeners.
     */
    ngOnDestroy(): void;
    /**
     * Closes the {@link MatDialog|dialog} and returns the publish-data (in the publish-mode) or true (for all modes).
     */
    submitData(): void;
    submitDataIe(): void;
    /** Returns true, if the dialog is used for unassigning items. */
    isUnassign(): boolean;
    /** Returns true, if the dialog is used for publishing items. */
    isPublish(): boolean;
    /** Returns true, if the dialog is used for unpublishing items. */
    isUnpublish(): boolean;
    /** Returns true, if the dialog is used for {@link PortalApplication|PortalApplication}. */
    isApplication(): boolean;
    /** Returns true, if the dialog is used for {@link PortalEntitlement|PortalEntitlements}. */
    isEntitlement(): boolean;
    private initCaptions;
    private validateDate;
    static ɵfac: i0.ɵɵFactoryDeclaration<LifecycleActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LifecycleActionComponent, "imx-entitlements-action", never, {}, {}, never, never, false, never>;
}
