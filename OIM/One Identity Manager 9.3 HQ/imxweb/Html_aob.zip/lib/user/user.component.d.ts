import { OnChanges } from '@angular/core';
import { SafeUrl } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { IReadValue, IWriteValue } from '@imx-modules/imx-qbm-dbts';
import { ClassloggerService } from 'qbm';
import * as i0 from "@angular/core";
export declare class UserComponent implements OnChanges {
    private readonly translateService;
    private readonly logger;
    uid: IReadValue<any> | IWriteValue<any>;
    role: string;
    noUserText: string;
    size: 'default' | 'large';
    imageUrl: SafeUrl;
    primaryValue: string;
    secondaryValue: string;
    hasUser: boolean;
    constructor(translateService: TranslateService, logger: ClassloggerService);
    ngOnChanges(): void;
    private hasValidUser;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserComponent, "imx-user", never, { "uid": { "alias": "uid"; "required": false; }; "role": { "alias": "role"; "required": false; }; "noUserText": { "alias": "noUserText"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, false, never>;
}
