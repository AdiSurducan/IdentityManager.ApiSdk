import * as i0 from "@angular/core";
import * as i1 from "./user.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/icon";
import * as i4 from "qer";
export declare class AobUserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AobUserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AobUserModule, [typeof i1.UserComponent], [typeof i2.CommonModule, typeof i3.MatIconModule, typeof i4.UserModule], [typeof i1.UserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AobUserModule>;
}
