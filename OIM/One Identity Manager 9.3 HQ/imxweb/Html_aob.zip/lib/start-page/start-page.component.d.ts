import * as i0 from "@angular/core";
export declare class StartPageComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<StartPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StartPageComponent, "imx-start", never, {}, {}, never, never, false, never>;
}
