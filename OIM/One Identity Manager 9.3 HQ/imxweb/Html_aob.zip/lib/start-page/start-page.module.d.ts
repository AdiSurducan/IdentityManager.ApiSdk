import * as i0 from "@angular/core";
import * as i1 from "./start-page.component";
import * as i2 from "@angular/common";
import * as i3 from "qbm";
import * as i4 from "@angular/material/button";
import * as i5 from "@angular/material/card";
import * as i6 from "@angular/material/icon";
import * as i7 from "@ngx-translate/core";
import * as i8 from "../user/user.module";
import * as i9 from "@angular/router";
import * as i10 from "../global-kpi/global-kpi.module";
export declare class StartPageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StartPageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StartPageModule, [typeof i1.StartPageComponent], [typeof i2.CommonModule, typeof i3.LdsReplaceModule, typeof i4.MatButtonModule, typeof i5.MatCardModule, typeof i6.MatIconModule, typeof i7.TranslateModule, typeof i3.ClassloggerModule, typeof i8.AobUserModule, typeof i3.QbmModule, typeof i9.RouterModule, typeof i10.GlobalKpiModule], [typeof i1.StartPageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StartPageModule>;
}
