import { Route, Router } from '@angular/router';
import { ExtService, MenuService } from 'qbm';
import * as i0 from "@angular/core";
export declare class AobService {
    private readonly router;
    private readonly extService;
    private readonly menuService;
    constructor(router: Router, extService: ExtService, menuService: MenuService);
    onInit(routes: Route[]): void;
    private addRoutes;
    private setupMenu;
    static ɵfac: i0.ɵɵFactoryDeclaration<AobService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AobService>;
}
