import { PortalApplication } from '@imx-modules/imx-api-aob';
import { CollectionLoadParameters, IForeignKeyInfo, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { ApiClientService, ClassloggerService } from 'qbm';
import { AobApiService } from '../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class AccountsService {
    private readonly aobClient;
    private readonly logger;
    private readonly apiProvider;
    get display(): string;
    private readonly builder;
    private appUsesAccounts;
    constructor(aobClient: AobApiService, logger: ClassloggerService, apiProvider: ApiClientService);
    updateApplicationUsesAccounts(application: PortalApplication, changeSet: {
        add: TypedEntity[];
        remove: TypedEntity[];
    }): Promise<boolean>;
    getCandidateTables(): ReadonlyArray<IForeignKeyInfo>;
    getSelectedAccountLength(uidApplication: string): Promise<number>;
    getAssigned(application: string, parameters?: CollectionLoadParameters): Promise<TypedEntity[]>;
    getFirstAndCount(uidApplication: string): Promise<{
        first: TypedEntity | undefined;
        count: number;
    }>;
    private accountsWithTableInfo;
    private assign;
    private unassign;
    private searchCandidates;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountsService>;
}
