import { TypedEntity, EntitySchema } from '@imx-modules/imx-qbm-dbts';
export declare class AobAccountContainer extends TypedEntity {
    static GetEntitySchema(): EntitySchema;
}
