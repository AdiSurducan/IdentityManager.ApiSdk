import { ErrorHandler, EventEmitter, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { AbstractControl, UntypedFormGroup } from '@angular/forms';
import { EuiLoadingService } from '@elemental-ui/core';
import { Router } from '@angular/router';
import { PortalEntitlement, PortalEntitlementServiceitem } from '@imx-modules/imx-api-aob';
import { CdrFactoryService, ClassloggerService, ColumnDependentReference } from 'qbm';
import { ServiceItemTagsService } from 'qer';
import { AobPermissionsService } from '../../permissions/aob-permissions.service';
import * as i0 from "@angular/core";
/**
 * A component that provides a form for viewing and editing entitlements/roles.
 */
export declare class EntitlementEditComponent implements OnChanges, OnInit {
    private readonly tagProvider;
    private readonly logger;
    private readonly router;
    private readonly errorHandler;
    private readonly cdrFactoryService;
    private readonly permissions;
    private readonly busyService;
    readonly form: UntypedFormGroup;
    productTagsInitial: string[];
    productTagsSelected: string[];
    loadingTags: boolean;
    cdrList: (ColumnDependentReference | undefined)[];
    cdrListServiceItem: (ColumnDependentReference | undefined)[];
    isEditableEntitlement: boolean;
    entitlement: PortalEntitlement;
    serviceItem: PortalEntitlementServiceitem;
    readonly controlCreated: EventEmitter<AbstractControl<any, any>>;
    readonly saved: EventEmitter<any>;
    constructor(tagProvider: ServiceItemTagsService, logger: ClassloggerService, router: Router, errorHandler: ErrorHandler, cdrFactoryService: CdrFactoryService, permissions: AobPermissionsService, busyService: EuiLoadingService);
    ngOnInit(): Promise<void>;
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    /**
     * Saves all changes of specified  {@link PortalEntitlement|entitlement}.
     * @param entitlement The {@link PortalEntitlement|entitlement} to be saved.
     */
    save(): Promise<void>;
    private initTags;
    private tryCommit;
    private saveTags;
    private getTagsChangeSet;
    editableEntitlement(): Promise<boolean>;
    manageEntitlement(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntitlementEditComponent, "imx-entitlement-edit", never, { "entitlement": { "alias": "entitlement"; "required": false; }; "serviceItem": { "alias": "serviceItem"; "required": false; }; }, { "controlCreated": "controlCreated"; "saved": "saved"; }, never, never, false, never>;
}
