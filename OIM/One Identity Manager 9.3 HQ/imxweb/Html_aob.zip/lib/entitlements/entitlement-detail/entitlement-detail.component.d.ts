import { OnDestroy } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { ConfirmationService, SnackBarService } from 'qbm';
import { EntitlementWrapper } from '../entitlement-wrapper.interface';
import * as i0 from "@angular/core";
export declare class EntitlementDetailComponent implements OnDestroy {
    readonly data: EntitlementWrapper;
    private readonly sidesheetRef;
    private readonly snackbar;
    readonly form: UntypedFormGroup;
    private readonly subscriptions;
    constructor(data: EntitlementWrapper, sidesheetRef: EuiSidesheetRef, snackbar: SnackBarService, confirmation: ConfirmationService);
    ngOnDestroy(): void;
    afterSave(success: boolean): void;
    private entityHasChanges;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementDetailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntitlementDetailComponent, "imx-entitlement-detail", never, {}, {}, never, never, false, never>;
}
