import { EntitlementToAddData } from '@imx-modules/imx-api-aob';
import { TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { EntitlementToAddTyped } from './entitlement-to-add-typed';
import * as i0 from "@angular/core";
export declare class EntitlementToAddDataWrapperService {
    readonly entitySchema: import("@imx-modules/imx-qbm-dbts").EntitySchema;
    private readonly builder;
    buildTypedEntities(data: EntitlementToAddData): TypedEntityCollectionData<EntitlementToAddTyped>;
    private buildEntityData;
    private compareElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementToAddDataWrapperService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EntitlementToAddDataWrapperService>;
}
