import { OnInit } from '@angular/core';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { DisplayColumns, EntitySchema, TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { DataViewSource } from 'qbm';
import { EntitlementToAddTyped } from '../entitlement-to-add-typed';
import * as i0 from "@angular/core";
export declare class MappedEntitlementsPreviewComponent implements OnInit {
    data: {
        withSave: boolean;
        entitlementToAdd: TypedEntityCollectionData<EntitlementToAddTyped>;
    };
    private readonly sidesheetRef;
    dataSource: DataViewSource<EntitlementToAddTyped>;
    readonly DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    alertText: string;
    speedupText: string;
    constructor(data: {
        withSave: boolean;
        entitlementToAdd: TypedEntityCollectionData<EntitlementToAddTyped>;
    }, sidesheetRef: EuiSidesheetRef, dataSource: DataViewSource<EntitlementToAddTyped>);
    apply(map: boolean): void;
    getCount(type: '' | 'add' | 'assigned' | 'conflicted'): number;
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MappedEntitlementsPreviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MappedEntitlementsPreviewComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
