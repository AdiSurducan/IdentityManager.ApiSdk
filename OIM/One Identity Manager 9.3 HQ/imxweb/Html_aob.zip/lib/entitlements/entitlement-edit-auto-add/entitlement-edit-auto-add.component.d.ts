import { OnDestroy } from '@angular/core';
import { EuiLoadingService, EuiSidesheetRef, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PortalApplication } from '@imx-modules/imx-api-aob';
import { SqlWizardExpression } from '@imx-modules/imx-qbm-dbts';
import { ConfirmationService, SnackBarService } from 'qbm';
import { EntitlementEditAutoAddService } from './entitlement-edit-auto-add.service';
import { EntitlementToAddDataWrapperService } from './entitlement-to-add-data-wrapper.service';
import * as i0 from "@angular/core";
export declare class EntitlementEditAutoAddComponent implements OnDestroy {
    data: {
        sqlExpression: SqlWizardExpression;
        application: PortalApplication;
    };
    readonly svc: EntitlementEditAutoAddService;
    private readonly sidesheetRef;
    private readonly entitlementToAddWrapperService;
    private readonly busyService;
    private readonly snackbar;
    private readonly sidesheet;
    private readonly translateService;
    private subscriptions;
    private reload;
    exprHasntChanged: boolean;
    sqlExpression: SqlWizardExpression;
    checkChanges(): void;
    get controlsInvalid(): boolean;
    constructor(data: {
        sqlExpression: SqlWizardExpression;
        application: PortalApplication;
    }, svc: EntitlementEditAutoAddService, sidesheetRef: EuiSidesheetRef, entitlementToAddWrapperService: EntitlementToAddDataWrapperService, busyService: EuiLoadingService, snackbar: SnackBarService, sidesheet: EuiSidesheetService, translateService: TranslateService, confirm: ConfirmationService);
    ngOnDestroy(): void;
    showResults(withSave: boolean): Promise<void>;
    isConditionInvalid(): boolean;
    private hasValuesSet;
    private setExtendedData;
    private showBusyIndicator;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementEditAutoAddComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntitlementEditAutoAddComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
