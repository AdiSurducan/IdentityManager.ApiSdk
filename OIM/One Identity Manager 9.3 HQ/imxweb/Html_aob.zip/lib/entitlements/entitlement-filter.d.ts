import { PortalEntitlement } from '@imx-modules/imx-api-aob';
export declare class EntitlementFilter {
    notPublished(entitlement: PortalEntitlement): boolean;
    willPublish(entitlement: PortalEntitlement): boolean;
    published(entitlement: PortalEntitlement): boolean;
}
