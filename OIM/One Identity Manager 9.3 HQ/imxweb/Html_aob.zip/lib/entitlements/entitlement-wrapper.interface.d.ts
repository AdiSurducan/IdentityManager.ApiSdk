import { PortalEntitlement, PortalEntitlementServiceitem } from '@imx-modules/imx-api-aob';
export interface EntitlementWrapper {
    entitlement?: PortalEntitlement;
    serviceItem?: PortalEntitlementServiceitem;
}
