import { OnInit } from '@angular/core';
import { MatSelectChange } from '@angular/material/select';
import { EuiLoadingService, EuiSidesheetRef, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { DisplayColumns, EntitySchema, IClientProperty, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { ClassloggerService, DataViewSource, MetadataService, SettingsService, StorageService } from 'qbm';
import { AddEntitlementParameter, EntitlementSourceType, EntitlementsType } from '../entitlements.model';
import { EntitlementsService } from '../entitlements.service';
import * as i0 from "@angular/core";
/**
 * A component that represents a sidesheet for adding application entitlements to an {@link PortalApplication}.
 */
export declare class EntitlementsAddComponent implements OnInit {
    readonly sidesheetRef: EuiSidesheetRef;
    private data;
    private logger;
    readonly entitlementsProvider: EntitlementsService;
    private readonly busyService;
    private readonly storageService;
    private readonly metaData;
    private readonly sidesheet;
    private readonly translateService;
    dataSource: DataViewSource;
    readonly settingsService: SettingsService;
    readonly EntitlementsType: typeof EntitlementsType;
    readonly DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    displayedColumns: IClientProperty[];
    selectedSourceType: EntitlementsType;
    isSystemRolesEnabled: boolean;
    entitlementsLabel: string;
    rolesLabel: string;
    selections: TypedEntity[];
    readonly browserCulture: string;
    entitlementSourceTypes: EntitlementSourceType[];
    get showHelperAlert(): boolean;
    constructor(sidesheetRef: EuiSidesheetRef, data: AddEntitlementParameter, logger: ClassloggerService, entitlementsProvider: EntitlementsService, busyService: EuiLoadingService, storageService: StorageService, metaData: MetadataService, sidesheet: EuiSidesheetService, translateService: TranslateService, dataSource: DataViewSource, settingsService: SettingsService);
    ngOnInit(): Promise<void>;
    onHelperDismissed(): void;
    /**
     * Call to toggle the view and show entitlements candidates or roles candidates.
     */
    toggleView(arg: MatSelectChange): Promise<void>;
    onOk(): void;
    onCreateRole(): Promise<void>;
    onAddToRole(): Promise<void>;
    onSelectionChanged(selection: TypedEntity[]): void;
    private useSource;
    private getDisplayedColumnsForEntitlement;
    LdsInfoAlert: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementsAddComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntitlementsAddComponent, "imx-entitlements-add", never, {}, {}, never, never, false, never>;
}
