import { Platform } from '@angular/cdk/platform';
import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PortalApplication, PortalEntitlement } from '@imx-modules/imx-api-aob';
import { DisplayColumns, EntitySchema, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { BusyService, ClassloggerService, DataTileBadge, DataViewSource, MetadataService, SettingsService, SnackBarService, SystemInfoService } from 'qbm';
import { ServiceItemsService } from '../service-items/service-items.service';
import { ShopsService } from '../shops/shops.service';
import { EntitlementEditAutoAddService } from './entitlement-edit-auto-add/entitlement-edit-auto-add.service';
import { EntitlementFilter } from './entitlement-filter';
import { EntitlementsType } from './entitlements.model';
import { EntitlementsService } from './entitlements.service';
import * as i0 from "@angular/core";
/**
 * A component for viewing, editing and acting all {@link PortalEntitlement|entitlements} for a given {@link PortalApplication|application}.
 *
 * @see addEntitlements
 * @see addRoles
 * @see publish
 * @see unpublish
 * @see unassign
 */
export declare class EntitlementsComponent implements OnChanges {
    private readonly logger;
    private matDialog;
    private entitlementsProvider;
    private readonly euiBusyService;
    private readonly dialog;
    private readonly snackbar;
    private readonly shopsProvider;
    private readonly serviceItemsProvider;
    private readonly platform;
    private readonly translateService;
    private readonly sidesheet;
    private readonly settingsService;
    private readonly systemInfo;
    private readonly metadata;
    private readonly autoAddService;
    dataSource: DataViewSource<PortalEntitlement>;
    /** The {@link PortalApplication|application} */
    application: PortalApplication;
    reloadRequested: EventEmitter<void>;
    readonly DisplayColumns: typeof DisplayColumns;
    readonly EntitlementsType: typeof EntitlementsType;
    selections: PortalEntitlement[];
    publishDisabled: boolean;
    unpublishDisabled: boolean;
    unassignedDisabled: boolean;
    isUsedInDialog: boolean;
    entitySchema: EntitySchema;
    readonly filter: EntitlementFilter;
    busyService: BusyService;
    isSystemRoleEnabled: boolean;
    isLoading: boolean;
    hideTable: boolean;
    /**
     * Checks, if there's a dynamic assignment rule attached to this application
     */
    get hasConditionForDynamicAssignment(): boolean;
    /**
     * Defines a set of status information methods, that are used to determine the status of each element in the entitlements table
     */
    readonly status: {
        getBadges: (entitlement: PortalEntitlement) => DataTileBadge[];
        enabled: (_: PortalEntitlement) => boolean;
    };
    private readonly updatedTableNames;
    constructor(logger: ClassloggerService, matDialog: MatDialog, entitlementsProvider: EntitlementsService, euiBusyService: EuiLoadingService, dialog: MatDialog, snackbar: SnackBarService, shopsProvider: ShopsService, serviceItemsProvider: ServiceItemsService, platform: Platform, translateService: TranslateService, sidesheet: EuiSidesheetService, settingsService: SettingsService, systemInfo: SystemInfoService, metadata: MetadataService, autoAddService: EntitlementEditAutoAddService, dataSource: DataViewSource<PortalEntitlement>);
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    /**
     * checks, if an Entitlement can be edited
     * @param aobEntitlement the entitlement to check
     * @returns true, if the entitlements Ident_AOBEntitlement or Description property can be edited
     */
    canEdit(aobEntitlement: PortalEntitlement): boolean;
    openInfo(event: Event): void;
    /**
     * Opens a sidesheet to assign new entitlements to the application
     * Afterwards entitlements are added to the application as single entitlements or wrapped into a system role
     */
    addNewElement(): Promise<void>;
    /**
     * Applys the dynamic assignment rule, that is defined for the application
     */
    applyMappingForDynamicAssignments(): Promise<void>;
    /**
     * Opens a side sheet to create/edit the dynamic assignement rule that belongs to the application
     */
    editConditionForDynamicAssignments(): Promise<void>;
    /**
     * Call to publish the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to publish
     */
    publish(aobEntitlement?: PortalEntitlement): Promise<void>;
    /**
     * Call to unpublish the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to unpublish
     */
    unpublish(aobEntitlement?: PortalEntitlement): Promise<void>;
    /**
     * Call to unassign the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}
     * from the associated {@link PortalApplication|application}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to unassign
     */
    unassign(aobEntitlement?: PortalEntitlement): Promise<void>;
    /**
     * Call to get data from server depending on the {@link CollectionLoadParameters}.
     */
    getData(): Promise<void>;
    /**
     * Opens a side sheet to edit entitlement information
     * @param entitlement the entitlement to edit
     */
    editEntitlement(entitlement: TypedEntity): Promise<void>;
    /**
     * Triggered action from the {@link DataTableComponent} or {@link TilesComponent} after the selection have changed.
     */
    onSelectionChanged(selection: PortalEntitlement[]): void;
    getType(data: PortalEntitlement): string;
    private addDirectEntitlements;
    private buildRoleAndAddItToApplication;
    private clearSelections;
    private updateTableNames;
    private createEntitlementWrapper;
    private showBusyIndicator;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntitlementsComponent, "imx-entitlements", never, { "application": { "alias": "application"; "required": false; }; }, { "reloadRequested": "reloadRequested"; }, never, never, false, never>;
}
