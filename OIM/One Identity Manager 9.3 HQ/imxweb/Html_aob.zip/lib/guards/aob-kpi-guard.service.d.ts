import { OnDestroy } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { AppConfigService, AuthenticationService, RouteGuardService } from 'qbm';
import { AobPermissionsService } from '../permissions/aob-permissions.service';
import * as i0 from "@angular/core";
export declare class AobKpiGuardService implements OnDestroy {
    private readonly aobPermissionService;
    private readonly authentication;
    private readonly appConfig;
    private readonly router;
    private readonly routeGuardService;
    private onSessionResponse;
    constructor(aobPermissionService: AobPermissionsService, authentication: AuthenticationService, appConfig: AppConfigService, router: Router, routeGuardService: RouteGuardService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AobKpiGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AobKpiGuardService>;
}
