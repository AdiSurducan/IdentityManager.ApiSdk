export { AobConfigModule } from './lib/aob-config.module';
export { StartPageComponent } from './lib/start-page/start-page.component';
export { ApplicationsComponent } from './lib/applications/applications.component';
export { ApplicationsModule } from './lib/applications/applications.module';
export { EntitlementsComponent } from './lib/entitlements/entitlements.component';
export { EntitlementsModule } from './lib/entitlements/entitlements.module';
