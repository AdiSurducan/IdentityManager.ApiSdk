import * as i6 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Component, Input, Injectable, Inject, EventEmitter, Output, ViewChild, effect, NgModule } from '@angular/core';
import * as i4 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i3 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i1 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiTheme, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i2 from 'qbm';
import { EntityColumnContainer, BaseCdr, calculateSidesheetWidth, DataViewSource, HELPER_ALERT_KEY_PREFIX, CdrFactoryService, BusyService, YAxisInformation, SeriesInformation, LineChartOptions, XAxisInformation, TranslationEditorComponent, TreeDatabase, DisableControlModule, QbmModule, DataSourceToolbarModule, DataTableModule, LdsReplaceModule, DataViewModule, CdrModule, ClassloggerModule, DataTilesModule, SqlWizardModule, InfoModalDialogModule, SelectedElementsModule, BusyIndicatorModule, DateModule, DataTreeModule, DataTreeWrapperModule, FkAdvancedPickerModule, EntityModule, ImageModule, HelpContextualModule, RouteGuardService, HELP_CONTEXTUAL } from 'qbm';
import * as i1$1 from 'qer';
import { ServiceItemsEditFormComponent, additionalColumnsForServiceItemsKey, UserModule, ServiceItemTagsModule, ObjectHyperviewModule, TilesModule } from 'qer';
import '@imx-modules/imx-api-qer';
import * as i7 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import { Subject, BehaviorSubject } from 'rxjs';
import * as i13$2 from '@imx-modules/imx-api-aob';
import { V2Client, TypedClient, PortalApplicationNew, PortalApplication } from '@imx-modules/imx-api-aob';
import * as i12 from '@angular/forms';
import { UntypedFormControl, UntypedFormGroup, FormGroup, Validators, FormArray, ReactiveFormsModule, FormsModule } from '@angular/forms';
import * as i6$1 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i1$2 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i5 from '@angular/cdk/platform';
import { DisplayColumns, FilterType, CompareOperator, DbObjectKey, TypedEntity, ValType, DisplayPattern, TypedEntityBuilder, isExpressionInvalid } from '@imx-modules/imx-qbm-dbts';
import moment from 'moment-timezone';
import * as i11 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import * as i12$1 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i13 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i14 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i15 from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import * as i11$1 from '@angular/cdk/scrolling';
import { ScrollingModule } from '@angular/cdk/scrolling';
import * as i9 from '@angular/material/list';
import * as i6$2 from '@angular/material/core';
import * as i10 from '@angular/material/select';
import _ from 'lodash';
import * as i6$3 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import * as i12$2 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i13$1 from '@angular/material/menu';
import { MatMenuTrigger, MatMenuModule } from '@angular/material/menu';
import * as i10$1 from '@angular/material/tabs';
import * as i8 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i18 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i6$4 from '@angular/cdk/overlay';
import { OverlayModule } from '@angular/cdk/overlay';
import * as i10$2 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { PortalModule } from '@angular/cdk/portal';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { pie } from 'billboard.js';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function LockInfoAlertComponent_eui_alert_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 1)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 3, "#LDS#You cannot edit all properties, because the service item is assigned to an application and therefore some properties are locked."), " ");
} }
class LockInfoAlertComponent {
    serviceItem;
    isLocked = false;
    ngOnInit() {
        this.isLocked = this.serviceItem?.GetEntity()?.GetColumn('LockInfo')?.GetValue();
    }
    static ɵfac = function LockInfoAlertComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || LockInfoAlertComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LockInfoAlertComponent, selectors: [["imx-lock-info-alert"]], inputs: { serviceItem: "serviceItem" }, decls: 1, vars: 1, consts: [["type", "info", 3, "condensed", "colored", 4, "ngIf"], ["type", "info", 3, "condensed", "colored"]], template: function LockInfoAlertComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, LockInfoAlertComponent_eui_alert_0_Template, 4, 5, "eui-alert", 0);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.isLocked);
        } }, dependencies: [i6.NgIf, i1.EuiAlertComponent, i3.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LockInfoAlertComponent, [{
        type: Component,
        args: [{ selector: 'imx-lock-info-alert', template: "<eui-alert *ngIf=\"isLocked\" type=\"info\" [condensed]=\"true\" [colored]=\"true\">\n  <span>\n    {{\n      '#LDS#You cannot edit all properties, because the service item is assigned to an application and therefore some properties are locked.'\n        | translate\n    }}\n  </span>\n</eui-alert>\n", styles: [":host{display:flex;flex-direction:column}\n"] }]
    }], null, { serviceItem: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(LockInfoAlertComponent, { className: "LockInfoAlertComponent", filePath: "lib\\extensions\\service-items-edit\\lock-info-alert\\lock-info-alert.component.ts", lineNumber: 36 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class LockInfoAlertExtension {
    static id = ServiceItemsEditFormComponent.alertExtId;
    instance = LockInfoAlertComponent;
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isAobApplicationOwner(features) {
    return features.find((item) => item === 'Portal_UI_ApplicationOwner') != null;
}
function isAobApplicationAdmin(features) {
    return features.find((item) => item === 'Portal_UI_ApplicationAdmin') != null;
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobPermissionsService {
    userService;
    constructor(userService) {
        this.userService = userService;
    }
    async isAobApplicationOwner() {
        return isAobApplicationOwner((await this.userService.getFeatures()).Features || []);
    }
    async isAobApplicationAdmin() {
        return isAobApplicationAdmin((await this.userService.getFeatures()).Features || []);
    }
    async isAobApplicationOwnerOrAdmin() {
        const features = (await this.userService.getFeatures()).Features || [];
        return isAobApplicationAdmin(features) || isAobApplicationOwner(features);
    }
    static ɵfac = function AobPermissionsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AobPermissionsService)(i0.ɵɵinject(i1$1.UserModelService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobPermissionsService, factory: AobPermissionsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobPermissionsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1$1.UserModelService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function KpiTileComponent_imx_icon_tile_0_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 3);
    i0.ɵɵlistener("click", function KpiTileComponent_imx_icon_tile_0_ng_template_3_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.goToGlobalKpi()); });
    i0.ɵɵelementStart(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(4, "eui-icon", 4);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵattribute("data-imx-identifier", "kpi-tile-button-view");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#View KPI overview"));
} }
function KpiTileComponent_imx_icon_tile_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "imx-icon-tile", 2);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵtemplate(3, KpiTileComponent_imx_icon_tile_0_ng_template_3_Template, 5, 4, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("caption", i0.ɵɵpipeBind1(1, 3, "#LDS#Heading Application KPI Overview"))("subtitle", i0.ɵɵpipeBind1(2, 5, "#LDS#Get an overview of the KPIs for your applications."))("identifier", "global-kpi");
} }
class KpiTileComponent {
    router;
    aobPermissionService;
    constructor(router, aobPermissionService) {
        this.router = router;
        this.aobPermissionService = aobPermissionService;
    }
    isAobOwner;
    async ngOnInit() {
        this.isAobOwner = await this.aobPermissionService.isAobApplicationAdmin();
    }
    goToGlobalKpi() {
        this.router.navigate(['applications/kpi']);
    }
    static ɵfac = function KpiTileComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || KpiTileComponent)(i0.ɵɵdirectiveInject(i4.Router), i0.ɵɵdirectiveInject(AobPermissionsService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: KpiTileComponent, selectors: [["imx-kpi-tile"]], decls: 1, vars: 1, consts: [["ActionTemplate", ""], ["data-imx-identifier", "kpi-tile", 3, "caption", "subtitle", "identifier", 4, "ngIf"], ["data-imx-identifier", "kpi-tile", 3, "caption", "subtitle", "identifier"], ["mat-button", "", "color", "primary", 1, "imx-button-uppercase", 3, "click"], ["icon", "forward", 1, "imx-margin-left-15"]], template: function KpiTileComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, KpiTileComponent_imx_icon_tile_0_Template, 5, 7, "imx-icon-tile", 1);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.isAobOwner);
        } }, dependencies: [i6.NgIf, i7.MatButton, i1.EuiIconComponent, i1$1.IconTileComponent, i3.TranslatePipe], encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(KpiTileComponent, [{
        type: Component,
        args: [{ selector: 'imx-kpi-tile', template: "<imx-icon-tile\n  data-imx-identifier=\"kpi-tile\"\n  *ngIf=\"isAobOwner\"\n  [caption]=\"'#LDS#Heading Application KPI Overview' | translate\"\n  [subtitle]=\"'#LDS#Get an overview of the KPIs for your applications.' | translate\"\n  [identifier]=\"'global-kpi'\"\n>\n  <ng-template #ActionTemplate>\n    <button mat-button class=\"imx-button-uppercase\" color=\"primary\" [attr.data-imx-identifier]=\"'kpi-tile-button-view'\" (click)=\"goToGlobalKpi()\">\n      <span>{{ '#LDS#View KPI overview' | translate }}</span>\n      <eui-icon class=\"imx-margin-left-15\" icon=\"forward\"></eui-icon>\n    </button>\n  </ng-template>\n</imx-icon-tile>\n" }]
    }], () => [{ type: i4.Router }, { type: AobPermissionsService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(KpiTileComponent, { className: "KpiTileComponent", filePath: "lib\\global-kpi\\kpi-tile\\kpi-tile.component.ts", lineNumber: 35 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobService {
    router;
    extService;
    menuService;
    constructor(router, extService, menuService) {
        this.router = router;
        this.extService = extService;
        this.menuService = menuService;
        this.setupMenu();
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register(additionalColumnsForServiceItemsKey, {
            inputData: {
                columnName: 'UID_AOBApplication',
            },
        });
        this.extService.register('Dashboard-MediumTiles', {
            instance: KpiTileComponent,
        });
        this.extService.register(LockInfoAlertExtension.id, new LockInfoAlertExtension());
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features) => {
            const items = [];
            if (isAobApplicationAdmin(features) || isAobApplicationOwner(features)) {
                items.push({
                    id: 'AOB_Data_Applications',
                    title: '#LDS#Applications',
                    navigationCommands: { commands: ['/applications', { outlets: { primary: ['navigation'], content: ['detail'] } }] },
                    sorting: '40-20',
                });
            }
            if (items.length === 0) {
                return undefined;
            }
            return {
                id: 'ROOT_Data',
                title: '#LDS#Data administration',
                sorting: '40',
                items,
            };
        });
    }
    static ɵfac = function AobService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AobService)(i0.ɵɵinject(i4.Router), i0.ɵɵinject(i2.ExtService), i0.ɵɵinject(i2.MenuService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobService, factory: AobService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i4.Router }, { type: i2.ExtService }, { type: i2.MenuService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing AOB API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function AobApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AobApiService)(i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobApiService, factory: AobApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2.AppConfigService }, { type: i2.ClassloggerService }, { type: i2.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ImageSelectorDialogComponent_mat_card_9_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 14);
    i0.ɵɵlistener("click", function ImageSelectorDialogComponent_mat_card_9_Template_mat_card_click_0_listener() { const name_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.selectIcon(name_r3)); });
    i0.ɵɵelement(1, "eui-icon", 15);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const name_r3 = ctx.$implicit;
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("selected", ctx_r3.iconIsSelected(name_r3));
    i0.ɵɵadvance();
    i0.ɵɵpropertyInterpolate("icon", name_r3);
} }
function ImageSelectorDialogComponent_mat_card_13_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 16);
    i0.ɵɵlistener("click", function ImageSelectorDialogComponent_mat_card_13_Template_mat_card_click_0_listener() { i0.ɵɵrestoreView(_r5); i0.ɵɵnextContext(); const file_r6 = i0.ɵɵreference(20); return i0.ɵɵresetView(file_r6.click()); });
    i0.ɵɵelement(1, "eui-icon", 17);
    i0.ɵɵelementEnd();
} }
function ImageSelectorDialogComponent_mat_card_14_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 18);
    i0.ɵɵlistener("click", function ImageSelectorDialogComponent_mat_card_14_Template_mat_card_click_0_listener() { i0.ɵɵrestoreView(_r7); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.selectImage()); });
    i0.ɵɵelement(1, "img", 19);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("selected", ctx_r3.imageIsSelected);
    i0.ɵɵadvance();
    i0.ɵɵproperty("src", ctx_r3.imageHandler.addBase64Prefix(ctx_r3.imageUrl), i0.ɵɵsanitizeUrl)("alt", i0.ɵɵpipeBind1(2, 4, "#LDS#Selected application icon"));
} }
function ImageSelectorDialogComponent_div_21_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 20);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Please select an image in PNG format."));
} }
/**
 * A dialog to select an icon from a predefined list or upload an own one.
 */
class ImageSelectorDialogComponent {
    dialogRef;
    imageHandler;
    logger;
    fileSelector;
    get imageIsSelected() {
        return this.selectedIconName == null;
    }
    imageUrl;
    fileFormatError = false;
    iconNames = [];
    title;
    selectedIconName;
    icons;
    subscriptions = [];
    constructor(dialogRef, imageHandler, logger, data, fileSelector) {
        this.dialogRef = dialogRef;
        this.imageHandler = imageHandler;
        this.logger = logger;
        this.fileSelector = fileSelector;
        this.subscriptions.push(this.fileSelector.fileFormatError.subscribe(() => (this.fileFormatError = true)), this.fileSelector.fileSelected.subscribe((imageUrl) => this.selectImage(imageUrl)));
        this.title = data.title;
        this.icons = data.icons;
        Object.keys(data.icons).forEach((iconName) => this.iconNames.push(iconName));
        if (data.imageUrl) {
            this.logger.debug(this, 'show and select actual assigned icon');
            this.selectImage(data.imageUrl);
        }
        else {
            this.logger.debug(this, 'initially select the default icon');
            this.selectIcon(data.defaultIcon);
        }
    }
    ngOnDestroy() {
        this.subscriptions.forEach((s) => s.unsubscribe());
    }
    onSave() {
        this.dialogRef.close({ file: this.getIconUrl() });
    }
    iconIsSelected(name) {
        return name === this.selectedIconName;
    }
    selectImage(newImageUrl) {
        if (newImageUrl) {
            this.imageUrl = newImageUrl;
        }
        this.selectedIconName = undefined;
    }
    selectIcon(name) {
        this.selectedIconName = name;
    }
    emitFiles(event) {
        const files = event?.files;
        if (files) {
            this.fileSelector.emitFiles(files, 'image/png');
        }
    }
    resetFileFormatErrorState() {
        this.fileFormatError = false;
    }
    getIconUrl() {
        if (this.selectedIconName) {
            return this.icons[this.selectedIconName];
        }
        return this.imageUrl;
    }
    static ɵfac = function ImageSelectorDialogComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ImageSelectorDialogComponent)(i0.ɵɵdirectiveInject(i1$2.MatDialogRef), i0.ɵɵdirectiveInject(i2.Base64ImageService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(MAT_DIALOG_DATA), i0.ɵɵdirectiveInject(i2.FileSelectorService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ImageSelectorDialogComponent, selectors: [["imx-image-selector-dialog"]], decls: 29, vars: 22, consts: [["file", ""], ["mat-dialog-title", "", 1, "imx-dialog-title"], ["mat-dialog-content", ""], [1, "imx-icon-selector-list"], ["class", "imx-card-select", "data-imx-identifier", "selector-icon-select", 3, "selected", "click", 4, "ngFor", "ngForOf"], ["class", "imx-card-select", "data-imx-identifier", "selector-image-open-upload", 3, "click", 4, "ngIf"], ["class", "imx-card-select", 3, "selected", "click", 4, "ngIf"], [1, "imx-margin-vertical-20"], ["type", "button", "mat-flat-button", "", "color", "warn", "data-imx-identifier", "selector-image-open-upload-button", 3, "click"], ["type", "file", "multiple", "false", "accept", "image/png", 1, "imx-hidden-element", 3, "click", "change"], ["class", "imx-error-message", 4, "ngIf"], ["mat-dialog-actions", ""], ["mat-stroked-button", "", "mat-dialog-close", "", "data-imx-identifier", "selector-dialog-button-cancel"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "selector-dialog-button-save", 3, "click"], ["data-imx-identifier", "selector-icon-select", 1, "imx-card-select", 3, "click"], ["size", "xl", 3, "icon"], ["data-imx-identifier", "selector-image-open-upload", 1, "imx-card-select", 3, "click"], ["size", "xl", "icon", "image"], [1, "imx-card-select", 3, "click"], ["height", "48", "data-imx-identifier", "selector-image-select", 1, "imx-preview-image", 3, "src", "alt"], [1, "imx-error-message"]], template: function ImageSelectorDialogComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div")(1, "h2", 1);
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "div", 2)(5, "span");
            i0.ɵɵtext(6);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(8, "div", 3);
            i0.ɵɵtemplate(9, ImageSelectorDialogComponent_mat_card_9_Template, 2, 3, "mat-card", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "span");
            i0.ɵɵtext(11);
            i0.ɵɵpipe(12, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(13, ImageSelectorDialogComponent_mat_card_13_Template, 2, 0, "mat-card", 5)(14, ImageSelectorDialogComponent_mat_card_14_Template, 3, 6, "mat-card", 6);
            i0.ɵɵelementStart(15, "div", 7)(16, "button", 8);
            i0.ɵɵlistener("click", function ImageSelectorDialogComponent_Template_button_click_16_listener() { i0.ɵɵrestoreView(_r1); const file_r6 = i0.ɵɵreference(20); return i0.ɵɵresetView(file_r6.click()); });
            i0.ɵɵtext(17);
            i0.ɵɵpipe(18, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(19, "input", 9, 0);
            i0.ɵɵlistener("click", function ImageSelectorDialogComponent_Template_input_click_19_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.resetFileFormatErrorState()); })("change", function ImageSelectorDialogComponent_Template_input_change_19_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.emitFiles($event.target)); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(21, ImageSelectorDialogComponent_div_21_Template, 3, 3, "div", 10);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(22, "div", 11)(23, "button", 12);
            i0.ɵɵtext(24);
            i0.ɵɵpipe(25, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(26, "button", 13);
            i0.ɵɵlistener("click", function ImageSelectorDialogComponent_Template_button_click_26_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSave()); });
            i0.ɵɵtext(27);
            i0.ɵɵpipe(28, "translate");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 10, ctx.title));
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(7, 12, "#LDS#Select an Icon"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngForOf", ctx.iconNames);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(12, 14, "#LDS#WC_Or"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !ctx.imageUrl);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.imageUrl);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(18, 16, "#LDS#Select image"), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngIf", ctx.fileFormatError);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(25, 18, "#LDS#Cancel"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(28, 20, "#LDS#Save"), " ");
        } }, dependencies: [i6.NgForOf, i6.NgIf, i1.EuiIconComponent, i7.MatButton, i6$1.MatCard, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogActions, i1$2.MatDialogContent, i3.TranslatePipe], styles: [".mat-mdc-dialog-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center}.mat-mdc-dialog-content[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:20px}.imx-hidden-element[_ngcontent-%COMP%]{display:none}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ImageSelectorDialogComponent, [{
        type: Component,
        args: [{ selector: 'imx-image-selector-dialog', template: "<div>\n  <h2 mat-dialog-title class=\"imx-dialog-title\">{{ title | translate }}</h2>\n  <div mat-dialog-content>\n    <span>{{ '#LDS#Select an Icon' | translate }}</span>\n    <div class=\"imx-icon-selector-list\">\n      <mat-card\n        *ngFor=\"let name of iconNames\"\n        class=\"imx-card-select\"\n        (click)=\"selectIcon(name)\"\n        [class.selected]=\"iconIsSelected(name)\"\n        data-imx-identifier=\"selector-icon-select\"\n      >\n        <eui-icon size=\"xl\" icon=\"{{ name }}\"></eui-icon>\n      </mat-card>\n    </div>\n    <span>{{ '#LDS#WC_Or' | translate }}</span>\n    <mat-card *ngIf=\"!imageUrl\" class=\"imx-card-select\" (click)=\"file.click()\" data-imx-identifier=\"selector-image-open-upload\">\n      <eui-icon size=\"xl\" icon=\"image\"></eui-icon>\n    </mat-card>\n    <mat-card class=\"imx-card-select\" *ngIf=\"imageUrl\" (click)=\"selectImage()\" [class.selected]=\"imageIsSelected\">\n      <img\n        [src]=\"imageHandler.addBase64Prefix(imageUrl)\"\n        height=\"48\"\n        class=\"imx-preview-image\"\n        data-imx-identifier=\"selector-image-select\"\n        [alt]=\"'#LDS#Selected application icon' | translate\"\n      />\n    </mat-card>\n    <div class=\"imx-margin-vertical-20\">\n      <button type=\"button\" mat-flat-button color=\"warn\" data-imx-identifier=\"selector-image-open-upload-button\" (click)=\"file.click()\">\n        {{ '#LDS#Select image' | translate }}\n      </button>\n    </div>\n    <input\n      class=\"imx-hidden-element\"\n      #file\n      type=\"file\"\n      multiple=\"false\"\n      accept=\"image/png\"\n      (click)=\"resetFileFormatErrorState()\"\n      (change)=\"emitFiles($event.target)\"\n    />\n    <div *ngIf=\"fileFormatError\" class=\"imx-error-message\">{{ '#LDS#Please select an image in PNG format.' | translate }}</div>\n  </div>\n  <div mat-dialog-actions>\n    <button mat-stroked-button mat-dialog-close data-imx-identifier=\"selector-dialog-button-cancel\">\n      {{ '#LDS#Cancel' | translate }}\n    </button>\n    <button mat-flat-button color=\"primary\" (click)=\"onSave()\" data-imx-identifier=\"selector-dialog-button-save\">\n      {{ '#LDS#Save' | translate }}\n    </button>\n  </div>\n</div>\n", styles: [".mat-mdc-dialog-content{display:flex;flex-direction:column;align-items:center}.mat-mdc-dialog-content>span{font-size:20px}.imx-hidden-element{display:none}\n"] }]
    }], () => [{ type: i1$2.MatDialogRef }, { type: i2.Base64ImageService }, { type: i2.ClassloggerService }, { type: undefined, decorators: [{
                type: Inject,
                args: [MAT_DIALOG_DATA]
            }] }, { type: i2.FileSelectorService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ImageSelectorDialogComponent, { className: "ImageSelectorDialogComponent", filePath: "lib\\applications\\application-image-select\\image-selector-dialog\\image-selector-dialog.component.ts", lineNumber: 43 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationImageSelectComponent {
    dialog;
    imageProvider;
    control = new UntypedFormControl();
    columnContainer = new EntityColumnContainer();
    column;
    controlCreated = new EventEmitter();
    icons = {
        // eslint-disable-next-line max-len
        application: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAlCAYAAAAA7LqSAAAAAXNSR0IArs4c6QAAAeJJREFUWAntWbFKA0EQde/CYSGk0SqIiEhEVNBW/YLkD4SQIsc1/oCVtZWlJLlK0C/w6ivE1kIiIiJcKgtttNKId74Jd7JcYrMwa052YZm5eTs782Z2mz0xhRGGYSmKohnSizaazeabECIWnU5nD8kfJ0kyVzQSlC9I9DFdCwSOdJNA4HfkcD+ucMC+YO+Nw1IbYXGGI/cFzEMLhkpm1CSfEHje87wVy7L25ZhEEFgV2DrsdRkj3bbtHcLgt5kSHi6BT4WIaB1I4ALJvFBQJHQK8VNd6JfAHgmDDLD2mfR0PLRarSvSXde9gbhO7UOhnQiqV2+327MUPY7jBoScwy6wJcIga1gr39tl3/e3Cet2uxsQW6RnQ8AhyT50yfQI9RGvmo9JRwYE7mBfG4MBSm5hX8WUCxCV8ot1fCOZacQZIUGxgdkQIyRSTPyG5YmcYOEBORVgnCHHWpZnnsgHLtlrBk6yxJX4lPOTz5lsL5xuiExay0xHTEeYKmCOFlNhlbc1HVEuHZOj6QhTYZW3NR1RLh2To+kIU2GVtzUdUS4dk6PpCFNhlbc1HVEuHZPjv+nInzyZMjQloo7Ir+EMMbRsGRORQEsoxiB4+A5KjuM0BoMBPe8vMsZi2xr/WHrlcvn8Gxm0iGtOIek+AAAAAElFTkSuQmCC',
        // eslint-disable-next-line max-len
        box: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAABqklEQVRoQ+1YPUvDQBh+riSiBJRubo7FWXD1B7h3L4gHyWQGF62DH4tDnBo4Ebp39we4Cs7i6OZWFIJiQk4OtFiqJL3cBYnvrXnf573ng9wlDA1ZrCE8QET+mpPkCDliSQGKliVhtWHJEW3pLDU20xEhxApjbCvP83VLwhmBbbVa91LKG8758xfgxJHRaLQwHo9PAOwbmWYf5Lzdbve73e67GjUhEkXRkud5FwC4/T0YmSCSJNkLw/CViBjRszoIOVJdQ7MI5IhZPauj/ezIcDhcTNP0QEq5WX2GfQTG2K3rume9Xu9t6vVrf7TdCc28a9nVzC76r44IIfoAju2Onxv9iHOu7oMzi4jMraWZhloceQSwm6bpXZk9u667AeASwFqZ+s+aWohMHVBFm9P8bKiFyHWWZTtBEDwVkVDPB4PBquM4VwC2y9TX6Yia9QBARazMUpHqlCn8VlOLI3PuSauciNCBqBWc4iaKFkWrOCVaFRQtipZWcIqbKFoUreKUaFX842jFcdxxHOdUSrmspZ3hJsbYS5Zlh77vq0+FmUX/tQwLXhmuMY58ANUk7zNkl1kaAAAAAElFTkSuQmCC',
        // eslint-disable-next-line max-len
        openfolder: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAC80lEQVRoQ+2Zz2sTQRTHv28zadUiklp602tP4lH/AoUePElErYdQs1uSWmi9qNBa6UUKpoptdJtDD9KDVUEPRdSbJ68qiKIX9VoTtBRt2cyTDSQQJbNhmgnTkr0F9v34zHf2fWc3hF1y0S7hQAfENiU7inQUMbQCna1laGG109YpsrCwcEgIcZqZu3QzEtFWEASPs9nsd90cOnE1kJWVla5SqXQTwLhOon9i5hKJxJVkMrnVglxNpaiB5HK5vT09PXMAvKYi1Tf5Gxsb4xMTE79bkKupFKZAngK4J6U0oogQoiylfOd53s8qpSmQplZxmzfNJhKJyer23ckgddtXBfKVmR8BWNvmypkK/9bb2/skUhEiGnRd97mpLlqdt5Ei7wEkPc/72OqCpvI1AnlbLpfPZDKZT2Hh6elpp7+//4CU0jHViG7eeDweuK77KxKEmalQKIwx823dYobj1gFcigTxfX8fgDsALhpuSDs9M+cjQebn5w8KIZaJ6KR2JfOBU5Eg+Xx+IBaLPQRw1Hw/ehWIaCgSpFAoHJdSvgSwX6+M+ShmPhEJsri4eIqZn5lvR7vCuuM40SC+74fH+px2GfOBFatQKtLX1/elWCzOENFV8/3oVWDmF0EQnFeCxGKx8C3P6tEL4IEQIqsEkVKu2T56Qw/p7u6+rAQJxbZ99AKY8jxvRgkSj8cTto/e0ENc111WggghBiwfvQg9ZGRk5FXUwz5o+eiteEg6nX7TEISZzwEYsnn0Aqi9bjQEkVKmHMfJWH7qrXjI6OjoDxVIlogmLT/1VjxkeHh4XbW1rhPRDZtPvVUPSaVSf1Qgd4ko/PJo7am36iGh3zUEAbAK4JreCag9UVUPUYIQ0QdmPtuelvSqVD1EBfIZQBHAMb0SbYmqeYgKpC2dbLNI3Ser2jOytLS0Z3Nz8xYRhd6xE67Vcrl8IZPJlOoUCX/4vn8EwBiAw5aTFInofjqdfk1E/B+I5c0r2+v8q2ubeh1FOooYWoG/nVypz2zv/LMAAAAASUVORK5CYII=',
        // eslint-disable-next-line max-len
        server: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAACM0lEQVRoQ+2ZMWvbUBDH717jOMWQYA8eswfSvdDQD1ACHQJa4sWLJAcSqAvdWkS7FeJCCrakxYuzCDIEQj5AaSB7Ct0zerBJwLSu23elpTG1ooCe7GfLL8+bhd7d/f7/QzpOCIr8UBEO0CBpc1I7kmpHPM97BAB7ALCatkJD9VwCwIFlWRc314et1Ww2l/r9/j4i7qQc4m95RFTPZrMvy+Xy9z//hyC1Wu1hLpf7AADWPIAAgNfr9V5Uq9VvIiA7nPOvYUDG2BoA1GcELg7COd+oVCpn4YIbjcYTxthnDTKeAuKOAIAarTWecNJOJ3JEWjVjBI4GCYJgsdPpbM3By/CG/bJQKBwZhvFj5PE7hjKpOKrm0Og4DisWiyucc5YKme8ogjHG2+32leM4/NasFQTBg263WwWA92mG+K+2V/l8vmYYxi+RESWNbOKPXyI6R8TrMA0RLSPi4xlRioPoWUuuVffYEbnCJo4u7kjiVHIPKg5CROj7/vJgMFiQK+RkomcymZ+maV4jIumhcTKaTjbKyPSrF3STFTdWNL2g0wu6WI2S6CbxF6Iy069e0CXqmNiHxFsrdujp3hhvQccYe0pEzyJqaxHRF5k1I+I6AJTCORDxlHP+6d/1eAs6z/NeA8DbiGAl0zQPZYL4vr9NRK2IHG8sy3oXlfvOBZ0yIK7r7iLiZsTmpG7b9rFMR1zXfR71LZOITmzb/ijkiMxCZcRWc/crQ6lpxdSOTEvpuHmUceQ3am+oQn9k2zIAAAAASUVORK5CYII=',
        // eslint-disable-next-line max-len
        hdd: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAETklEQVRoQ+2ZTWhjVRTH/+e91kZSnSaLSgdk3MksdDcKulDQcasDQ1BnHJAmvYkfwWZRdKD6tDhKF4lUSt5LUgaGGUfCDKPoShwYEcWPhagL6U4XnWAXDWObmkjfO3JLMoSQvps2uamG3uW795x7fvece+659xEGpNGAcOAA5L/myQOP/C89UigUwq7rvgbg4T4DfG+a5gfRaHRNNW9HoeU4zjSAtEqZpv6UECKj0t0pyCyAd1TKNPW/KYSYU+nWBfIVgBsAfvQ8ryKNMAwjCOAYgMcBPKYyrKm/7yBrzJxh5vPxePwmEXE7Y5mZbNs+TEQvEpEM2bACqn8gRHTZdd2ziUTi912sNLLZ7H2maZ5j5ud85PoGYlUqlflUKvX3biAaY9Pp9J3BYHAGgLWDvH4QIjpbrVbTyWSytheIhszCwsJIIBBIMfO5Nnr0ghDRhWq1+moymfyrG4gmmLsDgcCHzHymRZ9WkN8Mw3g2Fov90guIho58Pv+g53kfAzjar6w1FwqF3o5EIm4vQYrFolkul98CIM+tRtPmkZLnec8kEokfegnR0JXNZh8yDOMTABP1b3pAiOgKM0eFELdUIJZlGePj44fkuNXV1VuWZXkqGcdxDhFRgZlPagVh5vfC4fCsKqwKhcKRra2tDBGdkAYx87WhoaHpaDT6hx+MDK+1tbU5InpDKwiAuBDC8TNGptORkZF5AMmWcQu1Wm1Gla4dxxEAbK0gRHR6amrqkh+I9Ibruh8BeKRl3LemaT6v8koulzvFzBf3HWRpaemw67qXmFkWiLcbEd0wTfPU5OTkTb+F6AsIAOX9oJ5GUwBkeDW3mVAolFbtr5b7j56sBSATCoVej0Qi//itqqyhRkdHp5hZVrggoszGxkZOVZMVi8U7yuXy+wC25QBoA/kSwBkhREmVSvfS7ziOPD8uAHhSN8g6M5+Ix+PX92KoSsa27SeI6BqAu3SDSP1OpVKZVoWJyujW/npJL+/nMv02mrbQkhOsAzgphPhit8b6jXcc5ykAV5q8oXWPbNtCRN+4rnt6p1uhZVlDExMTwVKptN5JaZLP5496nne+zZOTVo80YD4lIhGLxf5sXul6iMjU+wqAZXm4maZ5dWVlZbkdVD6fv4eZHWZ+uo3H9IPISdvVUIuLi/cODw9fZuZHWwz7FcBFwzA+a0C11mT7BlKfeFm+e9VqtauyjvI5EJvtlFDy2eg4gPt99k5/PNJsADN/bRhGplqtXh8bG3M3NzfnieilLhOCVhDpAcfzvJ8MwzgC4OX649ttm5n5OyKSj3MPABjvAkYbyM8AXhBCyNDYborN2gXDtqgeEGaeFUK82/qSaNv2cSLq6blSXwE9IDvdR3K53DFm/rzLMGrnPT0gA+MRAIOxR5rODd+s1e0Ob5LXE1o9NLBTVT0FGYxfbwPzM7TTGNjPcR39Q9xPAzud+wCk05Xq17gDj/RrpTud51+Swm1RKPvqDgAAAABJRU5ErkJggg==',
    };
    defaultIcon = this.icons.application;
    constructor(dialog, imageProvider) {
        this.dialog = dialog;
        this.imageProvider = imageProvider;
    }
    ngOnChanges(changes) {
        if (changes.column && this.column) {
            const cdr = new (class {
                column;
                get hint() {
                    return !this.column.GetValue()?.length ? '#LDS#If you do not select an icon, the default icon will be used.' : '';
                }
                constructor(column) {
                    this.column = column;
                }
                isReadOnly = () => !this.column.GetMetadata().CanEdit();
            })(this.column);
            this.columnContainer.init(cdr);
            this.updateControlValue();
        }
    }
    ngAfterViewInit() {
        this.controlCreated.emit(this.control);
    }
    async openEditDialog() {
        const imageSelectorDialogParams = {
            autoFocus: false,
            data: {
                title: '#LDS#Edit Application Icon',
                icons: this.icons,
                imageUrl: this.control.value,
                defaultIcon: 'application',
            },
        };
        const result = await this.dialog.open(ImageSelectorDialogComponent, imageSelectorDialogParams).afterClosed().toPromise();
        if (result) {
            await this.column.PutValue(this.imageProvider.getImageData(result.file));
            this.updateControlValue();
            this.control.markAsDirty();
        }
    }
    updateControlValue() {
        const value = this.column.GetValue();
        this.control.setValue(value?.length ? value : this.defaultIcon, { emitEvent: false });
    }
    static ɵfac = function ApplicationImageSelectComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationImageSelectComponent)(i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(i2.Base64ImageService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationImageSelectComponent, selectors: [["imx-application-image-select"]], inputs: { column: "column" }, outputs: { controlCreated: "controlCreated" }, features: [i0.ɵɵNgOnChangesFeature], decls: 1, vars: 3, consts: [[3, "change", "valueWrapper", "control", "hideRemoveButton"]], template: function ApplicationImageSelectComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "imx-image-select", 0);
            i0.ɵɵlistener("change", function ApplicationImageSelectComponent_Template_imx_image_select_change_0_listener() { return ctx.openEditDialog(); });
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("valueWrapper", ctx.columnContainer)("control", ctx.control)("hideRemoveButton", true);
        } }, dependencies: [i2.ImageSelectComponent] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationImageSelectComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-image-select', template: "<imx-image-select [valueWrapper]=\"columnContainer\" [control]=\"control\" (change)=\"openEditDialog()\" [hideRemoveButton]=\"true\">\n</imx-image-select>\n" }]
    }], () => [{ type: i1$2.MatDialog }, { type: i2.Base64ImageService }], { column: [{
            type: Input
        }], controlCreated: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ApplicationImageSelectComponent, { className: "ApplicationImageSelectComponent", filePath: "lib\\applications\\application-image-select\\application-image-select.component.ts", lineNumber: 40 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ApplicationCreateComponent_imx_cdr_editor_5_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_5_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.form.addControl(ctx_r1.name.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r1.name);
} }
function ApplicationCreateComponent_imx_cdr_editor_6_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_6_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.form.addControl(ctx_r1.description.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r1.description);
} }
function ApplicationCreateComponent_imx_cdr_editor_7_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 9);
    i0.ɵɵlistener("valueChange", function ApplicationCreateComponent_imx_cdr_editor_7_Template_imx_cdr_editor_valueChange_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.updateName($event)); })("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_7_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.form.addControl(ctx_r1.serviceCategory.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r1.serviceCategory);
} }
function ApplicationCreateComponent_imx_cdr_editor_8_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_8_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.form.addControl(ctx_r1.manager.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r1.manager);
} }
function ApplicationCreateComponent_imx_cdr_editor_9_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_9_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.form.addControl(ctx_r1.owner.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r1.owner);
} }
class ApplicationCreateComponent {
    sidesheetRef;
    translateService;
    form = new UntypedFormGroup({});
    name;
    description;
    serviceCategory;
    manager;
    owner;
    imageColumn;
    nameColumn;
    subscriptions = [];
    constructor(data, sidesheetRef, translateService, confirmation) {
        this.sidesheetRef = sidesheetRef;
        this.translateService = translateService;
        this.imageColumn = data.application.JPegPhoto.Column;
        this.nameColumn = data.application.Ident_AOBApplication.Column;
        this.name = new BaseCdr(this.nameColumn);
        this.description = new BaseCdr(data.application.Description.Column);
        this.serviceCategory = new (class {
            property;
            translateService;
            get hint() {
                return this.property.value?.length > 0
                    ? ''
                    : this.translateService.instant('#LDS#If you do not select a service category, a service category with the same name as the application is created and assigned.');
            }
            column;
            constructor(property, translateService) {
                this.property = property;
                this.translateService = translateService;
                this.column = this.property.Column;
            }
            isReadOnly = () => !this.property.GetMetadata().CanEdit();
        })(data.application.UID_AccProductGroup, this.translateService);
        this.manager = new BaseCdr(data.application.UID_PersonHead.Column);
        this.owner = new BaseCdr(data.application.UID_AERoleOwner.Column);
        this.subscriptions.push(sidesheetRef.closeClicked().subscribe(async () => {
            if ((!!data.application.GetEntity().GetDiffData()?.Data?.length || !this.form.pristine) &&
                !(await confirmation.confirmLeaveWithUnsavedChanges())) {
                return;
            }
            sidesheetRef.close(false);
        }));
    }
    ngOnDestroy() {
        this.subscriptions.forEach((s) => s.unsubscribe());
    }
    async updateName(value) {
        const name = this.name.column.GetValue();
        if (name == null || name.length === 0) {
            await this.name.column.PutValue(value?.DisplayValue);
            this.name = new BaseCdr(this.nameColumn);
        }
    }
    async save() {
        this.sidesheetRef.close(true);
    }
    static ɵfac = function ApplicationCreateComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationCreateComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationCreateComponent, selectors: [["imx-application-create"]], decls: 14, vars: 8, consts: [["eui-sidesheet-content", "", 1, "imx-content"], ["translate", ""], ["id", "form", 1, "imx-form", 3, "formGroup"], [1, "imx-select", 3, "controlCreated", "column"], ["class", "imx-select", 3, "cdr", "controlCreated", 4, "ngIf"], ["class", "imx-select", 3, "cdr", "valueChange", "controlCreated", 4, "ngIf"], ["eui-sidesheet-actions", "", 1, "imx-button-bar"], ["data-imx-identifier", "createApp-save", "mat-flat-button", "", "color", "primary", "type", "button", "form", "form", 3, "click", "disabled"], [1, "imx-select", 3, "controlCreated", "cdr"], [1, "imx-select", 3, "valueChange", "controlCreated", "cdr"]], template: function ApplicationCreateComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card", 0)(1, "p", 1);
            i0.ɵɵtext(2, "#LDS#Add an icon, name and description to the application and assign a manager to it.");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "form", 2)(4, "imx-application-image-select", 3);
            i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_Template_imx_application_image_select_controlCreated_4_listener($event) { return ctx.form.addControl(ctx.imageColumn.ColumnName, $event); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, ApplicationCreateComponent_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 4)(6, ApplicationCreateComponent_imx_cdr_editor_6_Template, 1, 1, "imx-cdr-editor", 4)(7, ApplicationCreateComponent_imx_cdr_editor_7_Template, 1, 1, "imx-cdr-editor", 5)(8, ApplicationCreateComponent_imx_cdr_editor_8_Template, 1, 1, "imx-cdr-editor", 4)(9, ApplicationCreateComponent_imx_cdr_editor_9_Template, 1, 1, "imx-cdr-editor", 4);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(10, "div", 6)(11, "button", 7);
            i0.ɵɵlistener("click", function ApplicationCreateComponent_Template_button_click_11_listener() { return ctx.save(); });
            i0.ɵɵelementStart(12, "span", 1);
            i0.ɵɵtext(13, "#LDS#Save");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("formGroup", ctx.form);
            i0.ɵɵadvance();
            i0.ɵɵproperty("column", ctx.imageColumn);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.name);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.description);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.serviceCategory);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.manager);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.owner);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.form.dirty || ctx.form.invalid);
        } }, dependencies: [i6.NgIf, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i7.MatButton, i6$1.MatCard, i12.ɵNgNoValidate, i12.NgControlStatusGroup, i2.CdrEditorComponent, i12.FormGroupDirective, i3.TranslateDirective, ApplicationImageSelectComponent], styles: ["[_nghost-%COMP%]{overflow-y:auto;display:flex;flex-direction:column;height:100%;background-color:#f9fbfc}.imx-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto;margin:30px;overflow-y:auto;max-height:calc(100% - 60px)}.eui-dark-theme   [_nghost-%COMP%]{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationCreateComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-create', template: "<mat-card eui-sidesheet-content class=\"imx-content\">\n  <p translate>#LDS#Add an icon, name and description to the application and assign a manager to it.</p>\n\n  <form class=\"imx-form\" id=\"form\" [formGroup]=\"form\">\n    <imx-application-image-select\n      class=\"imx-select\"\n      [column]=\"imageColumn\"\n      (controlCreated)=\"form.addControl(imageColumn.ColumnName, $event)\"\n    >\n    </imx-application-image-select>\n    <imx-cdr-editor class=\"imx-select\" *ngIf=\"name\" [cdr]=\"name\" (controlCreated)=\"form.addControl(name.column.ColumnName, $event)\">\n    </imx-cdr-editor>\n    <imx-cdr-editor\n      class=\"imx-select\"\n      *ngIf=\"description\"\n      [cdr]=\"description\"\n      (controlCreated)=\"form.addControl(description.column.ColumnName, $event)\"\n    >\n    </imx-cdr-editor>\n    <imx-cdr-editor\n      class=\"imx-select\"\n      *ngIf=\"serviceCategory\"\n      [cdr]=\"serviceCategory\"\n      (valueChange)=\"updateName($event)\"\n      (controlCreated)=\"form.addControl(serviceCategory.column.ColumnName, $event)\"\n    >\n    </imx-cdr-editor>\n    <imx-cdr-editor\n      class=\"imx-select\"\n      *ngIf=\"manager\"\n      [cdr]=\"manager\"\n      (controlCreated)=\"form.addControl(manager.column.ColumnName, $event)\"\n    >\n    </imx-cdr-editor>\n    <imx-cdr-editor class=\"imx-select\" *ngIf=\"owner\" [cdr]=\"owner\" (controlCreated)=\"form.addControl(owner.column.ColumnName, $event)\">\n    </imx-cdr-editor>\n  </form>\n</mat-card>\n\n<div eui-sidesheet-actions class=\"imx-button-bar\">\n  <button\n    data-imx-identifier=\"createApp-save\"\n    mat-flat-button\n    color=\"primary\"\n    type=\"button\"\n    (click)=\"save()\"\n    form=\"form\"\n    [disabled]=\"!form.dirty || form.invalid\"\n  >\n    <span translate>#LDS#Save</span>\n  </button>\n</div>\n", styles: [":host{overflow-y:auto;display:flex;flex-direction:column;height:100%;background-color:#f9fbfc}.imx-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto;margin:30px;overflow-y:auto;max-height:calc(100% - 60px)}.eui-dark-theme :host{background-color:#2f3233}.eui-contrast-theme :host{background-color:#000}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1.EuiSidesheetRef }, { type: i3.TranslateService }, { type: i2.ConfirmationService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ApplicationCreateComponent, { className: "ApplicationCreateComponent", filePath: "lib\\applications\\application-create\\application-create.component.ts", lineNumber: 42 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * This service provides methods for handling with {@link PortalApplication[]|applications}.
 * {@link ApplicationCardComponent|ApplicationCardComponent}.
 */
class ApplicationsService {
    aobClient;
    logger;
    errorHandler;
    apiProvider;
    translateService;
    sidesheet;
    snackbar;
    busyService;
    onApplicationCreated = new Subject();
    onApplicationDeleted = new Subject();
    applicationRefresh = new BehaviorSubject(false);
    badgePublished;
    badgeKpiErrors;
    badgeNew;
    publishedText;
    kpiErrorsText;
    newBadgeText;
    get applicationSchema() {
        return this.aobClient.typedClient.PortalApplication.GetSchema();
    }
    get theme() {
        const bodyClasses = document.body.classList;
        return bodyClasses.contains(EuiTheme.LIGHT)
            ? EuiTheme.LIGHT
            : bodyClasses.contains(EuiTheme.DARK)
                ? EuiTheme.DARK
                : bodyClasses.contains(EuiTheme.CONTRAST)
                    ? EuiTheme.CONTRAST
                    : '';
    }
    constructor(aobClient, logger, errorHandler, apiProvider, translateService, sidesheet, snackbar, busyService) {
        this.aobClient = aobClient;
        this.logger = logger;
        this.errorHandler = errorHandler;
        this.apiProvider = apiProvider;
        this.translateService = translateService;
        this.sidesheet = sidesheet;
        this.snackbar = snackbar;
        this.busyService = busyService;
        this.translateService.get('#LDS#Published').subscribe((trans) => (this.publishedText = trans));
        this.translateService.get('#LDS#KPI issues').subscribe((trans) => (this.kpiErrorsText = trans));
        this.translateService.get('#LDS#New').subscribe((trans) => (this.newBadgeText = trans));
    }
    /**
     * Encapsules the aob/applications GET endpoint and delivers a list of {@link PortalApplication[]|applications}.
     */
    async get(parameters = {}) {
        if (this.aobClient.typedClient == null) {
            return new Promise((resolve) => resolve(undefined));
        }
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalApplication.Get(parameters));
    }
    async reload(uidApplication) {
        return await this.apiProvider.request(async () => (await this.aobClient.typedClient.PortalApplicationInteractive.Get_byid(uidApplication)).Data[0]);
    }
    createNew() {
        return this.aobClient.typedClient.PortalApplicationNew.createEntity();
    }
    async tryCommit(application, reload) {
        try {
            await application.GetEntity().Commit(reload);
            if (application.AuthenticationRoot.value) {
                application.AuthenticationRootHelper.value = application.AuthenticationRoot.value;
            }
            this.logger.debug(this, 'storedapp:', application);
            return true;
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        return false;
    }
    /**
     * Publishs the given {@link PortalApplication[]|applications} by setting IsInactive to false or an ActivationDate to the given date.
     */
    async publish(application, publishData) {
        if (!publishData.publishFuture) {
            await application.IsInActive.Column.PutValue(publishData.publishFuture);
        }
        else {
            await application.ActivationDate.Column.PutValue(publishData.date);
        }
        this.logger.debug(this, 'Commit change: publish application...', application.ActivationDate.value);
        return this.tryCommit(application, true);
    }
    /**
     * Unpublishs the given {@link PortalApplication[]|applications} by setting IsInactive to true and ActivationDate to the default.
     */
    async unpublish(application) {
        await application.IsInActive.Column.PutValue(true);
        await application.ActivationDate.Column.PutValue(null);
        this.logger.debug(this, 'Commit change: unpublish application...');
        return this.tryCommit(application, true);
    }
    /**
     * Shows a badge on the given {@link PortalApplication[]|applications},
     * if the application is published or has kpi issues.
     */
    getApplicationBadges(application) {
        this.updateBadges(this.theme);
        if (application instanceof PortalApplicationNew) {
            this.logger.trace(this, 'Add a new badge to the badgelist.');
            return [this.badgeNew];
        }
        const badges = [];
        if (this.hasKpiIssues(application)) {
            this.logger.trace(this, 'Add a kpi error badge to the badgelist.');
            badges.push(this.badgeKpiErrors);
        }
        if (this.isPublished(application)) {
            this.logger.trace(this, 'Add a published badge to the badgelist.');
            badges.push(this.badgePublished);
        }
        if (this.createdToday(application)) {
            this.logger.trace(this, 'Add a new badge to the badgelist.');
            badges.push(this.badgeNew);
        }
        if (badges.length === 0) {
            this.logger.trace(this, 'Add no badge.');
        }
        return badges;
    }
    async createApplication() {
        const application = this.createNew();
        const result = await this.sidesheet
            .open(ApplicationCreateComponent, {
            title: await this.translateService.get('#LDS#Heading Create Application').toPromise(),
            padding: '0px',
            width: calculateSidesheetWidth(),
            disableClose: true,
            testId: 'create-aob-application',
            data: {
                application,
            },
        })
            .afterClosed()
            .toPromise();
        if (result) {
            if (this.busyService.overlayRefs.length === 0) {
                this.busyService.show();
            }
            try {
                await application.GetEntity().Commit(true);
                this.onApplicationCreated.next(application.UID_AOBApplication.value);
                this.snackbar.open({ key: '#LDS#The application has been successfully created.' });
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                this.busyService.hide();
            }
        }
        else {
            this.snackbar.open({ key: '#LDS#The creation of the application has been canceled.' });
        }
    }
    async deleteApplication(uid) {
        await this.aobClient.client.portal_application_delete(uid);
        this.onApplicationDeleted.next(uid);
    }
    isPublished(application) {
        if (application.IsInActive == null) {
            return false;
        }
        return !application.IsInActive.value;
    }
    hasKpiIssues(application) {
        if (application.HasKpiIssues == null) {
            return false;
        }
        return application.HasKpiIssues.value;
    }
    createdToday(app) {
        return (app != null && app.XDateInserted != null && new Date(app.XDateInserted.value).toLocaleDateString() === new Date().toLocaleDateString());
    }
    /**
     * Updates the badges, that are used on the application tiles, according to the used theme
     *
     * @param theme Currently used EuiTheme
     */
    updateBadges(theme) {
        //ToDo Bug422573 find a better solution for theming
        const published = {};
        published[EuiTheme.LIGHT] = '#0a96d1';
        published[EuiTheme.DARK] = '#016b91';
        published[EuiTheme.CONTRAST] = '#016b91';
        const newb = {};
        newb[EuiTheme.LIGHT] = '#4ba803';
        newb[EuiTheme.DARK] = '#327301';
        newb[EuiTheme.CONTRAST] = '#327301';
        const kpi = {};
        kpi[EuiTheme.LIGHT] = '#e36a00';
        kpi[EuiTheme.DARK] = '#900';
        kpi[EuiTheme.CONTRAST] = '#900';
        this.badgePublished = {
            content: this.publishedText,
            color: published[theme] ?? '#618f3e',
            textColor: '#ffffff',
        };
        this.badgeKpiErrors = {
            content: this.kpiErrorsText,
            color: kpi[theme] ?? '#f4770b',
            textColor: '#ffffff',
        };
        this.badgeNew = {
            content: this.newBadgeText,
            color: newb[theme] ?? '#02556d',
            textColor: theme === EuiTheme.LIGHT ? '#ffffff' : '#000000',
        };
    }
    static ɵfac = function ApplicationsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i0.ErrorHandler), i0.ɵɵinject(i2.ApiClientService), i0.ɵɵinject(i3.TranslateService), i0.ɵɵinject(i1.EuiSidesheetService), i0.ɵɵinject(i2.SnackBarService), i0.ɵɵinject(i1.EuiLoadingService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApplicationsService, factory: ApplicationsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobApiService }, { type: i2.ClassloggerService }, { type: i0.ErrorHandler }, { type: i2.ApiClientService }, { type: i3.TranslateService }, { type: i1.EuiSidesheetService }, { type: i2.SnackBarService }, { type: i1.EuiLoadingService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * The list of all possible actions on the {@link PortalEntitlement|PortalEntitlements} for an {@link PortalApplication|PortalApplication}.
 */
var LifecycleAction;
(function (LifecycleAction) {
    LifecycleAction[LifecycleAction["Publish"] = 0] = "Publish";
    LifecycleAction[LifecycleAction["Unpublish"] = 1] = "Unpublish";
    LifecycleAction[LifecycleAction["Unassign"] = 2] = "Unassign";
})(LifecycleAction || (LifecycleAction = {}));

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function LifecycleActionComponent_th_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.tableDisplay, " ");
} }
function LifecycleActionComponent_td_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 16)(1, "div", 17);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 18);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r2 == null ? null : item_r2.GetEntity().GetDisplay());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r2 == null ? null : item_r2.Description.Column.GetDisplayValue());
} }
function LifecycleActionComponent_th_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.entitySchema.Columns.UID_AERoleOwner.Display);
} }
function LifecycleActionComponent_td_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 19)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r3.UID_AERoleOwner == null ? null : item_r3.UID_AERoleOwner.Column.GetDisplayValue());
} }
function LifecycleActionComponent_span_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 20);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#*If you unassign an application entitlement from this application, it is removed from this application. The application entitlement can still be reassigned as required."));
} }
function LifecycleActionComponent_div_12_mat_card_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card");
    i0.ɵɵelement(1, "eui-icon", 30);
    i0.ɵɵelementStart(2, "mat-card-title", 31);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const shop_r5 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(shop_r5.GetEntity().GetDisplay());
} }
function LifecycleActionComponent_div_12_span_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 32);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, ctx_r0.data.type === "AobEntitlement" ? "#LDS#Application entitlements cannot be published. No shop is assigned to the application. Please assign at least one shop to the application." : "#LDS#No shop is assigned to the application. Without a shop, the assigned application entitlements cannot be requested. Please assign at least one shop to the application."), " ");
} }
function LifecycleActionComponent_div_12_span_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 20);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("*", i0.ɵɵpipeBind1(2, 1, "#LDS#IT Shops are set at the application level."), "");
} }
function LifecycleActionComponent_div_12_span_19_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 20);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, ctx_r0.isApplication() ? "#LDS#The application will be published immediately. The exact time may vary." : "#LDS#The application entitlement will be published immediately. The exact time may vary."), "");
} }
function LifecycleActionComponent_div_12_mat_form_field_20_mat_error_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Please specify a date that lies in the future."), " ");
} }
function LifecycleActionComponent_div_12_mat_form_field_20_mat_error_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Please enter a valid date or select a date from the calendar."), " ");
} }
function LifecycleActionComponent_div_12_mat_form_field_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-form-field");
    i0.ɵɵelement(1, "input", 33);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelement(3, "mat-datepicker-toggle", 34)(4, "mat-datepicker", null, 0);
    i0.ɵɵtemplate(6, LifecycleActionComponent_div_12_mat_form_field_20_mat_error_6_Template, 3, 3, "mat-error", 29)(7, LifecycleActionComponent_div_12_mat_form_field_20_mat_error_7_Template, 3, 3, "mat-error", 29);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const datepicker_r6 = i0.ɵɵreference(5);
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵpropertyInterpolate("placeholder", i0.ɵɵpipeBind1(2, 6, "#LDS#Date"));
    i0.ɵɵproperty("min", ctx_r0.minDate)("matDatepicker", datepicker_r6);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("for", datepicker_r6);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r0.datepickerFormControl.hasError("noFutureDateSelected"));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.datepickerFormControl.hasError("invalidDate"));
} }
function LifecycleActionComponent_div_12_span_21_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 20);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵpipe(3, "ldsReplace");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind3(3, 3, i0.ɵɵpipeBind1(2, 1, ctx_r0.isApplication() ? "#LDS#The application will be published on {0} at {1} (your local time)." : "#LDS#The application entitlement will be published on {0} at {1} (your local time) if the application is published."), ctx_r0.dateString, ctx_r0.timeString));
} }
function LifecycleActionComponent_div_12_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 21)(1, "div", 22)(2, "h5");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(5, LifecycleActionComponent_div_12_mat_card_5_Template, 4, 1, "mat-card", 23)(6, LifecycleActionComponent_div_12_span_6_Template, 3, 3, "span", 24)(7, LifecycleActionComponent_div_12_span_7_Template, 3, 3, "span", 9);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "form", 25);
    i0.ɵɵlistener("ngSubmit", function LifecycleActionComponent_div_12_Template_form_ngSubmit_8_listener() { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.submitData()); });
    i0.ɵɵelementStart(9, "h5");
    i0.ɵɵtext(10);
    i0.ɵɵpipe(11, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "mat-radio-group", 26)(13, "mat-radio-button", 27);
    i0.ɵɵtext(14);
    i0.ɵɵpipe(15, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(16, "mat-radio-button", 28);
    i0.ɵɵtext(17);
    i0.ɵɵpipe(18, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(19, LifecycleActionComponent_div_12_span_19_Template, 3, 3, "span", 9)(20, LifecycleActionComponent_div_12_mat_form_field_20_Template, 8, 8, "mat-form-field", 29)(21, LifecycleActionComponent_div_12_span_21_Template, 4, 7, "span", 9);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 11, "#LDS#Shops") + (ctx_r0.data.type === "AobEntitlement" ? "*" : ""));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r0.data.shops);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.data.shops.length == 0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.data.type === "AobEntitlement");
    i0.ɵɵadvance();
    i0.ɵɵproperty("formGroup", ctx_r0.publishDateForm);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(11, 13, "#LDS#Publication Date"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(15, 15, "#LDS#Now"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(18, 17, "#LDS#Later"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", !ctx_r0.publishFuture);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.publishFuture);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.publishFuture && ctx_r0.datepickerFormControl.value);
} }
function LifecycleActionComponent_button_17_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 35);
    i0.ɵɵlistener("click", function LifecycleActionComponent_button_17_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r7); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.submitData()); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.actionButtonText, " ");
} }
function LifecycleActionComponent_button_18_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 36);
    i0.ɵɵlistener("click", function LifecycleActionComponent_button_18_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r8); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.submitDataIe()); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r0.publishDateForm.invalid || ctx_r0.data.shops.length < 1 && ctx_r0.data.type === "AobEntitlement");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.actionButtonText, " ");
} }
/**
 * A component that represents a dialog for submitting an {@link LifecycleAction|action} on the
 * given {@link PortalApplication|PortalApplication} or {@link PortalEntitlement|PortalEntitlements}.
 *
 */
class LifecycleActionComponent {
    dialogRef;
    data;
    logger;
    ldsReplace;
    translateService;
    metadataProvider;
    aobApiService;
    platform;
    dataSource;
    DisplayColumns = DisplayColumns; // Enables use of this static class in Angular Templates.
    entitySchema;
    /** The caption for the button with the corresponding action for specified {@link LifecycleAction|action} */
    actionButtonText;
    /** The caption for the heading title of this dialog. */
    dialogTitle;
    /** The display value for the specified type. */
    tableDisplay;
    /** the mininum date for the datepicker */
    minDate;
    publishFuture;
    publishDateForm;
    datepickerFormControl;
    browserCulture;
    whenToPublish = 'now';
    get dateString() {
        return this.datepickerFormControl.value.toDate().toLocaleDateString(this.browserCulture);
    }
    get timeString() {
        return this.datepickerFormControl.value.toDate().toLocaleTimeString(this.browserCulture);
    }
    /**
     * @ignore
     * List of subscriptions.
     */
    subscriptions = [];
    /** The list of colums to display in the dialog. */
    displayedColumns;
    constructor(dialogRef, data, logger, ldsReplace, translateService, metadataProvider, aobApiService, platform, dataSource) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.logger = logger;
        this.ldsReplace = ldsReplace;
        this.translateService = translateService;
        this.metadataProvider = metadataProvider;
        this.aobApiService = aobApiService;
        this.platform = platform;
        this.dataSource = dataSource;
        this.browserCulture = this.translateService.currentLang;
        this.initCaptions();
        const curDate = new Date();
        curDate.setHours(24, 0, 0, 0);
        // set date to tomorrow
        this.minDate = moment(curDate);
        this.datepickerFormControl = new UntypedFormControl(this.minDate, this.validateDate(this.minDate, () => this.publishFuture));
        this.publishDateForm = new FormGroup({
            datepickerFormControl: this.datepickerFormControl,
            whenToPublish: new UntypedFormControl('now'),
        });
        this.subscriptions.push(this.publishDateForm.controls.whenToPublish.valueChanges.subscribe((when) => {
            this.whenToPublish = when;
            this.publishFuture = this.whenToPublish === 'future';
        }));
        this.publishFuture = false;
    }
    /**
     * @ignore Used internally.
     */
    async ngOnInit() {
        this.entitySchema = this.isApplication()
            ? this.aobApiService.typedClient.PortalApplication.GetSchema()
            : this.aobApiService.typedClient.PortalEntitlement.GetSchema();
        this.displayedColumns = [this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME], this.entitySchema.Columns.UID_AERoleOwner];
        this.dataSource.init({
            execute: () => Promise.resolve({ Data: this.data.elements, totalCount: this.data.elements.length }),
            schema: this.entitySchema,
            columnsToDisplay: this.displayedColumns,
            localSource: true,
        });
        await this.metadataProvider
            .GetTableMetadata(this.entitySchema.TypeName || '')
            .then((metadata) => (this.tableDisplay = metadata.DisplaySingular || ''));
    }
    /**
     * @ignore Used internally.
     * Unsubscribes all listeners.
     */
    ngOnDestroy() {
        this.subscriptions.forEach((subscription) => subscription.unsubscribe());
    }
    /**
     * Closes the {@link MatDialog|dialog} and returns the publish-data (in the publish-mode) or true (for all modes).
     */
    submitData() {
        this.logger.debug(this, `Close the ${this.data.action} dialog for ${this.data.elements.length} ${this.data.type}(s).`);
        const result = this.data.action === LifecycleAction.Publish
            ? { publishFuture: this.publishFuture, date: this.datepickerFormControl.value.toDate() }
            : true;
        this.dialogRef.close(result);
    }
    submitDataIe() {
        if (!this.platform.TRIDENT) {
            return;
        }
        this.submitData();
    }
    /** Returns true, if the dialog is used for unassigning items. */
    isUnassign() {
        return this.data.action === LifecycleAction.Unassign;
    }
    /** Returns true, if the dialog is used for publishing items. */
    isPublish() {
        return this.data.action === LifecycleAction.Publish;
    }
    /** Returns true, if the dialog is used for unpublishing items. */
    isUnpublish() {
        return this.data.action === LifecycleAction.Unpublish;
    }
    /** Returns true, if the dialog is used for {@link PortalApplication|PortalApplication}. */
    isApplication() {
        return this.data.type === 'AobApplication';
    }
    /** Returns true, if the dialog is used for {@link PortalEntitlement|PortalEntitlements}. */
    isEntitlement() {
        return this.data.type === 'AobEntitlement';
    }
    initCaptions() {
        this.logger.debug(this, `Init captions for the ${this.data.action.toString()}-mode depending on the application count.`);
        const multipleEntitlements = this.data != null && this.data.elements != null && this.data.elements.length > 1;
        let dialogTitle = multipleEntitlements
            ? '#LDS#Heading Unassign {0} Application Entitlements'
            : '#LDS#Heading Unassign Application Entitlement';
        let buttonText = multipleEntitlements ? '#LDS#Unassign' : '#LDS#Unassign';
        if (this.data.type === 'AobApplication') {
            dialogTitle = multipleEntitlements ? '#LDS#Heading Delete {0} Applications' : '#LDS#Heading Delete Application';
            buttonText = multipleEntitlements ? '#LDS#Delete' : '#LDS#Delete';
        }
        if (this.isPublish()) {
            if (this.data.type === 'AobApplication') {
                dialogTitle = multipleEntitlements ? '#LDS#Heading Publish {0} Applications' : '#LDS#Heading Publish Application';
                buttonText = multipleEntitlements ? '#LDS#Publish' : '#LDS#Publish';
            }
            else {
                dialogTitle = multipleEntitlements
                    ? '#LDS#Heading Publish {0} Application Entitlements'
                    : '#LDS#Heading Publish Application Entitlement';
                buttonText = multipleEntitlements ? '#LDS#Publish' : '#LDS#Publish';
            }
        }
        else if (this.isUnpublish()) {
            if (this.data.type === 'AobApplication') {
                dialogTitle = multipleEntitlements ? '#LDS#Heading Unpublish {0} Applications' : '#LDS#Heading Unpublish Application';
                buttonText = multipleEntitlements ? '#LDS#Unpublish' : '#LDS#Unpublish';
            }
            else {
                dialogTitle = multipleEntitlements
                    ? '#LDS#Heading Unpublish {0} Application Entitlements'
                    : '#LDS#Heading Unpublish Application Entitlement';
                buttonText = multipleEntitlements ? '#LDS#Unpublish' : '#LDS#Unpublish';
            }
        }
        this.translateService
            .get(dialogTitle)
            .subscribe((trans) => (this.dialogTitle = this.ldsReplace.transform(trans, this.data.elements.length)));
        this.translateService.get(buttonText).subscribe((trans) => (this.actionButtonText = trans));
    }
    validateDate(minDate, publishFuture) {
        return (control) => {
            if (!publishFuture()) {
                return null;
            }
            if (!control.value || control.value.length > 0) {
                return { invalidDate: true };
            }
            if (control.value < minDate) {
                return { noFutureDateSelected: true };
            }
            else {
                return null;
            }
        };
    }
    static ɵfac = function LifecycleActionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || LifecycleActionComponent)(i0.ɵɵdirectiveInject(i1$2.MatDialogRef), i0.ɵɵdirectiveInject(MAT_DIALOG_DATA), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i2.LdsReplacePipe), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i2.MetadataService), i0.ɵɵdirectiveInject(AobApiService), i0.ɵɵdirectiveInject(i5.Platform), i0.ɵɵdirectiveInject(i2.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LifecycleActionComponent, selectors: [["imx-entitlements-action"]], features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 19, vars: 11, consts: [["datepicker", ""], ["mat-dialog-title", ""], ["mat-dialog-content", "", 1, "imx-dialog-content-flex-column"], ["imxtable", ""], ["mode", "manual", 3, "dataSource"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], ["class", "mat-small", 4, "ngIf"], ["class", "imx-entitlements-publish-settings", 4, "ngIf"], ["mat-dialog-actions", ""], ["mat-stroked-button", "", "mat-dialog-close", ""], ["mat-flat-button", "", "color", "warn", "cdkFocusInitial", "", 3, "click", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "form", "publishDateForm", "cdkFocusInitial", "", 3, "disabled", "click", 4, "ngIf"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], ["imxTitle", ""], ["imxSubtitle", ""], ["mat-cell", "", "role", "gridcell"], [1, "mat-small"], [1, "imx-entitlements-publish-settings"], [1, "imx-entitlements-publish-itshops"], [4, "ngFor", "ngForOf"], ["class", "mat-error", 4, "ngIf"], ["id", "publishDateForm", 1, "imx-entitlements-publish-date", 3, "ngSubmit", "formGroup"], ["aria-label", "Publish date", "formControlName", "whenToPublish"], ["value", "now"], ["value", "future"], [4, "ngIf"], ["mat-card-avatar", "", "size", "16px", "icon", "library"], [1, "imx-card-title-s"], [1, "mat-error"], ["matInput", "", "required", "", "formControlName", "datepickerFormControl", 3, "min", "matDatepicker", "placeholder"], ["matSuffix", "", 3, "for"], ["mat-flat-button", "", "color", "warn", "cdkFocusInitial", "", 3, "click"], ["mat-flat-button", "", "color", "primary", "form", "publishDateForm", "cdkFocusInitial", "", 3, "click", "disabled"]], template: function LifecycleActionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "h2", 1);
            i0.ɵɵtext(1);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(2, "div", 2)(3, "div", 3)(4, "imx-data-view-auto-table", 4);
            i0.ɵɵelementContainerStart(5, 5);
            i0.ɵɵtemplate(6, LifecycleActionComponent_th_6_Template, 2, 1, "th", 6)(7, LifecycleActionComponent_td_7_Template, 5, 2, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(8, 5);
            i0.ɵɵtemplate(9, LifecycleActionComponent_th_9_Template, 2, 1, "th", 6)(10, LifecycleActionComponent_td_10_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(11, LifecycleActionComponent_span_11_Template, 3, 3, "span", 9)(12, LifecycleActionComponent_div_12_Template, 22, 19, "div", 10);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(13, "div", 11)(14, "button", 12);
            i0.ɵɵtext(15);
            i0.ɵɵpipe(16, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(17, LifecycleActionComponent_button_17_Template, 2, 1, "button", 13)(18, LifecycleActionComponent_button_18_Template, 2, 2, "button", 14);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate(ctx.dialogTitle);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.DisplayColumns.DISPLAY_PROPERTYNAME);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_AERoleOwner.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.isEntitlement() && ctx.isUnassign());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isPublish());
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(16, 9, "#LDS#Cancel"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !ctx.isPublish());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isPublish());
        } }, dependencies: [i6.NgForOf, i6.NgIf, i1.EuiIconComponent, i12.ɵNgNoValidate, i12.DefaultValueAccessor, i12.NgControlStatus, i12.NgControlStatusGroup, i12.RequiredValidator, i7.MatButton, i6$1.MatCard, i6$1.MatCardAvatar, i6$1.MatCardTitle, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogActions, i1$2.MatDialogContent, i11.MatDatepicker, i11.MatDatepickerInput, i11.MatDatepickerToggle, i12$1.MatFormField, i12$1.MatError, i12$1.MatSuffix, i13.MatInput, i14.MatRadioGroup, i14.MatRadioButton, i12.FormGroupDirective, i12.FormControlName, i2.DataViewAutoTableComponent, i15.MatHeaderCellDef, i15.MatColumnDef, i15.MatCellDef, i15.MatHeaderCell, i15.MatCell, i2.LdsReplacePipe, i3.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:inherit}imx-data-source-toolbar[_ngcontent-%COMP%]{display:none}.mat-mdc-card-avatar[_ngcontent-%COMP%]{background-color:#aab0b3;color:#fff;padding:5px;height:25px;width:25px;-webkit-user-select:none;user-select:none}.mat-column-__Display[_ngcontent-%COMP%]{max-width:500px}div[imxTitle][_ngcontent-%COMP%]{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}div[imxSubtitle][_ngcontent-%COMP%]{font-size:smaller;opacity:.7;color:#919799}div[imxtable][_ngcontent-%COMP%]{overflow:auto;flex-grow:1;flex-shrink:0}div[imxActionsLabel][_ngcontent-%COMP%]{max-height:50px;margin:30px 0}.imx-entitlements-publish-settings[_ngcontent-%COMP%]{display:flex;margin-top:20px;overflow:auto}.imx-entitlements-publish-itshops[_ngcontent-%COMP%], .imx-entitlements-publish-date[_ngcontent-%COMP%]{display:flex;flex-direction:column;padding-bottom:20px}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%], .imx-entitlements-publish-date[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{margin-bottom:25px}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]{overflow:auto;width:380px;margin-right:20px}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   .mat-mdc-card[_ngcontent-%COMP%]{display:flex;align-items:center;height:50px;width:300px;margin-bottom:15px}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   .mat-mdc-card-title[_ngcontent-%COMP%]{font-size:16px;margin-left:10px;white-space:nowrap}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   .mat-small[_ngcontent-%COMP%]{font-size:10px;color:#919799}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   .mat-mdc-form-field-error[_ngcontent-%COMP%]{font-size:12px;margin-right:15px}.imx-entitlements-publish-date[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:25px;width:400px}.imx-entitlements-publish-date[_ngcontent-%COMP%]   .mat-small[_ngcontent-%COMP%]{display:block;font-size:14px;font-style:italic;color:#444647}.eui-dark-theme   [_nghost-%COMP%]   .mat-mdc-card-avatar[_ngcontent-%COMP%]{background-color:#616566;color:#2f3233}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LifecycleActionComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlements-action', providers: [DataViewSource], template: "<h2 mat-dialog-title>{{ dialogTitle }}</h2>\n<div mat-dialog-content class=\"imx-dialog-content-flex-column\">\n  <div imxtable>\n    <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\">\n      <ng-container [matColumnDef]=\"DisplayColumns.DISPLAY_PROPERTYNAME\">\n        <th mat-header-cell *matHeaderCellDef>\n          {{ tableDisplay }}\n        </th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n          <div imxTitle>{{ item?.GetEntity().GetDisplay() }}</div>\n          <div imxSubtitle>{{ item?.Description.Column.GetDisplayValue() }}</div>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"entitySchema.Columns.UID_AERoleOwner.ColumnName\">\n        <th mat-header-cell *matHeaderCellDef>{{ entitySchema.Columns.UID_AERoleOwner.Display }}</th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <div>{{ item.UID_AERoleOwner?.Column.GetDisplayValue() }}</div>\n        </td>\n      </ng-container>\n    </imx-data-view-auto-table>\n  </div>\n  <span *ngIf=\"isEntitlement() && isUnassign()\" class=\"mat-small\">{{\n    '#LDS#*If you unassign an application entitlement from this application, it is removed from this application. The application entitlement can still be reassigned as required.'\n      | translate\n  }}</span>\n  <div *ngIf=\"isPublish()\" class=\"imx-entitlements-publish-settings\">\n    <div class=\"imx-entitlements-publish-itshops\">\n      <h5>{{ ('#LDS#Shops' | translate) + (data.type === 'AobEntitlement' ? '*' : '') }}</h5>\n      <mat-card *ngFor=\"let shop of data.shops\">\n        <eui-icon mat-card-avatar size=\"16px\" icon=\"library\"></eui-icon>\n        <mat-card-title class=\"imx-card-title-s\">{{ shop.GetEntity().GetDisplay() }}</mat-card-title>\n      </mat-card>\n      <span *ngIf=\"data.shops.length == 0\" class=\"mat-error\">\n        {{\n          (data.type === 'AobEntitlement'\n            ? '#LDS#Application entitlements cannot be published. No shop is assigned to the application. Please assign at least one shop to the application.'\n            : '#LDS#No shop is assigned to the application. Without a shop, the assigned application entitlements cannot be requested. Please assign at least one shop to the application.'\n          ) | translate\n        }}\n      </span>\n      <span *ngIf=\"data.type === 'AobEntitlement'\" class=\"mat-small\"\n        >*{{ '#LDS#IT Shops are set at the application level.' | translate }}</span\n      >\n    </div>\n    <form class=\"imx-entitlements-publish-date\" id=\"publishDateForm\" [formGroup]=\"publishDateForm\" (ngSubmit)=\"submitData()\">\n      <h5>{{ '#LDS#Publication Date' | translate }}</h5>\n      <mat-radio-group aria-label=\"Publish date\" formControlName=\"whenToPublish\">\n        <mat-radio-button value=\"now\">{{ '#LDS#Now' | translate }}</mat-radio-button>\n        <mat-radio-button value=\"future\">{{ '#LDS#Later' | translate }}</mat-radio-button>\n      </mat-radio-group>\n      <span *ngIf=\"!publishFuture\" class=\"mat-small\">\n        {{\n          (isApplication()\n            ? '#LDS#The application will be published immediately. The exact time may vary.'\n            : '#LDS#The application entitlement will be published immediately. The exact time may vary.'\n          ) | translate\n        }}</span\n      >\n      <mat-form-field *ngIf=\"publishFuture\">\n        <input\n          matInput\n          [min]=\"minDate\"\n          [matDatepicker]=\"datepicker\"\n          required\n          placeholder=\"{{ '#LDS#Date' | translate }}\"\n          formControlName=\"datepickerFormControl\"\n        />\n        <mat-datepicker-toggle matSuffix [for]=\"datepicker\"></mat-datepicker-toggle>\n        <mat-datepicker #datepicker></mat-datepicker>\n        <mat-error *ngIf=\"datepickerFormControl.hasError('noFutureDateSelected')\">\n          {{ '#LDS#Please specify a date that lies in the future.' | translate }}\n        </mat-error>\n        <mat-error *ngIf=\"datepickerFormControl.hasError('invalidDate')\">\n          {{ '#LDS#Please enter a valid date or select a date from the calendar.' | translate }}\n        </mat-error>\n      </mat-form-field>\n      <!-- TODO 225775: Add Timepicker -->\n      <span *ngIf=\"publishFuture && this.datepickerFormControl.value\" class=\"mat-small\">{{\n        (isApplication()\n          ? '#LDS#The application will be published on {0} at {1} (your local time).'\n          : '#LDS#The application entitlement will be published on {0} at {1} (your local time) if the application is published.'\n        )\n          | translate\n          | ldsReplace: dateString : timeString\n      }}</span>\n    </form>\n  </div>\n</div>\n<div mat-dialog-actions>\n  <button mat-stroked-button mat-dialog-close>{{ '#LDS#Cancel' | translate }}</button>\n  <button mat-flat-button color=\"warn\" *ngIf=\"!isPublish()\" (click)=\"submitData()\" cdkFocusInitial>\n    {{ actionButtonText }}\n  </button>\n  <button\n    mat-flat-button\n    color=\"primary\"\n    (click)=\"submitDataIe()\"\n    form=\"publishDateForm\"\n    *ngIf=\"isPublish()\"\n    cdkFocusInitial\n    [disabled]=\"publishDateForm.invalid || (data.shops.length < 1 && data.type === 'AobEntitlement')\"\n  >\n    {{ actionButtonText }}\n  </button>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:inherit}imx-data-source-toolbar{display:none}.mat-mdc-card-avatar{background-color:#aab0b3;color:#fff;padding:5px;height:25px;width:25px;-webkit-user-select:none;user-select:none}.mat-column-__Display{max-width:500px}div[imxTitle]{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}div[imxSubtitle]{font-size:smaller;opacity:.7;color:#919799}div[imxtable]{overflow:auto;flex-grow:1;flex-shrink:0}div[imxActionsLabel]{max-height:50px;margin:30px 0}.imx-entitlements-publish-settings{display:flex;margin-top:20px;overflow:auto}.imx-entitlements-publish-itshops,.imx-entitlements-publish-date{display:flex;flex-direction:column;padding-bottom:20px}.imx-entitlements-publish-itshops h5,.imx-entitlements-publish-date h5{margin-bottom:25px}.imx-entitlements-publish-itshops{overflow:auto;width:380px;margin-right:20px}.imx-entitlements-publish-itshops .mat-mdc-card{display:flex;align-items:center;height:50px;width:300px;margin-bottom:15px}.imx-entitlements-publish-itshops .mat-mdc-card-title{font-size:16px;margin-left:10px;white-space:nowrap}.imx-entitlements-publish-itshops .mat-small{font-size:10px;color:#919799}.imx-entitlements-publish-itshops .mat-mdc-form-field-error{font-size:12px;margin-right:15px}.imx-entitlements-publish-date{display:flex;flex-direction:column;gap:25px;width:400px}.imx-entitlements-publish-date .mat-small{display:block;font-size:14px;font-style:italic;color:#444647}.eui-dark-theme :host .mat-mdc-card-avatar{background-color:#616566;color:#2f3233}\n"] }]
    }], () => [{ type: i1$2.MatDialogRef }, { type: undefined, decorators: [{
                type: Inject,
                args: [MAT_DIALOG_DATA]
            }] }, { type: i2.ClassloggerService }, { type: i2.LdsReplacePipe }, { type: i3.TranslateService }, { type: i2.MetadataService }, { type: AobApiService }, { type: i5.Platform }, { type: i2.DataViewSource }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(LifecycleActionComponent, { className: "LifecycleActionComponent", filePath: "lib\\lifecycle-actions\\lifecycle-action.component.ts", lineNumber: 59 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ServiceItemsService {
    aobClient;
    apiProvider;
    constructor(aobClient, apiProvider) {
        this.aobClient = aobClient;
        this.apiProvider = apiProvider;
    }
    async get(entitlement, parameters = {}) {
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementServiceitem.Get({
            ...{ uid_aobentitlement: entitlement.UID_AOBEntitlement.value },
            ...parameters,
        }));
    }
    static ɵfac = function ServiceItemsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ServiceItemsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ApiClientService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ServiceItemsService, factory: ServiceItemsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ServiceItemsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobApiService }, { type: i2.ApiClientService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ShopsService {
    aobClient;
    logger;
    apiProvider;
    get display() {
        return this.aobClient.typedClient.PortalShops.GetSchema().Display || '';
    }
    constructor(aobClient, logger, apiProvider) {
        this.aobClient = aobClient;
        this.logger = logger;
        this.apiProvider = apiProvider;
    }
    async get(parameters = { ParentKey: '' }) {
        this.logger.debug(this, 'get');
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalShops.Get(parameters));
    }
    async getApplicationInShop(application, parameters = {}) {
        this.logger.debug(this, 'getApplicationInShop');
        if (application) {
            return this.apiProvider.request(() => this.aobClient.typedClient.PortalApplicationinshop.Get(application, parameters));
        }
    }
    async getFirstAndCount(uidApplication) {
        const shops = await this.getApplicationInShop(uidApplication, { PageSize: 1 });
        return {
            first: shops?.Data.length === 0 ? undefined : shops?.Data[0],
            count: shops?.totalCount || 0,
        };
    }
    async updateApplicationInShops(application, changeSet) {
        this.logger.debug(this, 'updateApplicationInShops');
        const applicationInShop = await this.getApplicationInShop(application.UID_AOBApplication.value);
        return (!!applicationInShop &&
            (await this.addShops(application, changeSet.add.filter((shop) => !ShopsService.isAssigned(shop, applicationInShop.Data)))) &&
            (await this.removeShops(application, changeSet.remove.filter((shop) => ShopsService.isAssigned(shop, applicationInShop.Data)))));
    }
    async addShops(application, shops) {
        let count = 0;
        await this.apiProvider.request(async () => {
            for (const shop of shops) {
                await this.aobClient.client.portal_applicationinshop_put(application.UID_AOBApplication.value, shop.UID_ITShopOrg.value, []);
                count++;
            }
        });
        return count === shops.length;
    }
    async removeShops(application, shops) {
        let count = 0;
        await this.apiProvider.request(async () => {
            for (const shop of shops) {
                await this.aobClient.client.portal_applicationinshop_delete(application.UID_AOBApplication.value, shop.UID_ITShopOrg.value, '');
                count++;
            }
        });
        return count === shops.length;
    }
    static isAssigned(shop, shopsAssigned) {
        return shopsAssigned && shopsAssigned.find((shopAssigned) => shopAssigned.UID_ITShopOrg.value === shop.UID_ITShopOrg.value) != null;
    }
    static ɵfac = function ShopsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ShopsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ApiClientService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ShopsService, factory: ShopsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ShopsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobApiService }, { type: i2.ClassloggerService }, { type: i2.ApiClientService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
var EntitlementsType;
(function (EntitlementsType) {
    EntitlementsType[EntitlementsType["UnsGroup"] = 0] = "UnsGroup";
    EntitlementsType[EntitlementsType["Eset"] = 1] = "Eset";
    EntitlementsType[EntitlementsType["Qerresource"] = 2] = "Qerresource";
    EntitlementsType[EntitlementsType["Rpsreport"] = 3] = "Rpsreport";
    EntitlementsType[EntitlementsType["Tsbaccountdef"] = 4] = "Tsbaccountdef";
})(EntitlementsType || (EntitlementsType = {}));

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementFilter {
    notPublished(entitlement) {
        return entitlement.IsInActive && entitlement.IsInActive.value && !entitlement.ActivationDate.value;
    }
    willPublish(entitlement) {
        return entitlement.IsInActive && entitlement.IsInActive.value && entitlement.ActivationDate.value != null;
    }
    published(entitlement) {
        return !entitlement.IsInActive.value;
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementsService {
    aobClient;
    apiProvider;
    logger;
    errorHandler;
    filter = new EntitlementFilter();
    badgePublished;
    badgeWillPublish;
    constructor(aobClient, apiProvider, logger, errorHandler, translate) {
        this.aobClient = aobClient;
        this.apiProvider = apiProvider;
        this.logger = logger;
        this.errorHandler = errorHandler;
        translate.get('#LDS#Published').subscribe((value) => (this.badgePublished = {
            content: value,
            color: '#618f3e',
        }));
        translate.get('#LDS#Will be published').subscribe((value) => (this.badgeWillPublish = {
            content: value,
            color: '#f4770b',
        }));
    }
    get entitlementSchema() {
        return this.aobClient.typedClient.PortalEntitlement.GetSchema();
    }
    async get(parameters = {}) {
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlement.Get(parameters));
    }
    async getInteractive(uid) {
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementInteractive.Get_byid(uid));
    }
    async addElementsToRole(entitlementSystemRoleInput) {
        return this.apiProvider.request(() => this.aobClient.client.portal_entitlement_systemrole_post(entitlementSystemRoleInput));
    }
    candidateSchema(type) {
        switch (type) {
            case EntitlementsType.Eset:
                return this.aobClient.typedClient.PortalEntitlementcandidatesEset.GetSchema();
            case EntitlementsType.Qerresource:
                return this.aobClient.typedClient.PortalEntitlementcandidatesQerresource.GetSchema();
            case EntitlementsType.Rpsreport:
                return this.aobClient.typedClient.PortalEntitlementcandidatesRpsreport.GetSchema();
            case EntitlementsType.Tsbaccountdef:
                return this.aobClient.typedClient.PortalEntitlementcandidatesTsbaccountdef.GetSchema();
            case EntitlementsType.UnsGroup:
                return this.aobClient.typedClient.PortalEntitlementcandidatesUnsgroup.GetSchema();
            default:
                throw new Error(`Type ${0} not supported`);
        }
    }
    async getCandidates(type, parameters = {}) {
        switch (type) {
            case EntitlementsType.Eset:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesEset.Get(parameters));
            case EntitlementsType.Qerresource:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesQerresource.Get(parameters));
            case EntitlementsType.Rpsreport:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesRpsreport.Get(parameters));
            case EntitlementsType.Tsbaccountdef:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesTsbaccountdef.Get(parameters));
            case EntitlementsType.UnsGroup:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesUnsgroup.Get(parameters));
            default:
                throw new Error(`Type ${0} not supported`);
        }
    }
    async getDataModel(type) {
        if (type === EntitlementsType.UnsGroup) {
            return this.aobClient.client.portal_entitlementcandidates_UNSGroup_datamodel_get(undefined);
        }
        return undefined;
    }
    async getEntitlementsForApplication(application, collectionLoadParameters = {}) {
        return this.get({
            ...collectionLoadParameters,
            ...{
                filter: [
                    ...(collectionLoadParameters.filter || []),
                    {
                        ColumnName: 'UID_AOBApplication',
                        Type: FilterType.Compare,
                        CompareOp: CompareOperator.Equal,
                        Value1: application.UID_AOBApplication.value,
                    },
                ],
            },
        });
    }
    async reload(entitlement) {
        const collection = await this.getInteractive(entitlement.UID_AOBEntitlement.value);
        return collection && collection.Data && collection.Data.length > 0 ? collection.Data[0] : undefined;
    }
    async assign(application, candidates) {
        let assignCount = 0;
        for (const candidate of candidates) {
            this.logger.debug(this, 'try to assign a new entitlement to application', application.UID_AOBApplication);
            const entitlement = await this.createNew(candidate, application.UID_AOBApplication);
            this.logger.info(this, 'try to assign a new entitlement to application', application.UID_AOBApplication);
            if (await this.tryCommit(entitlement)) {
                this.logger.info(this, 'The entitlement was assigned to application', application.UID_AOBApplication);
                assignCount++;
            }
        }
        return assignCount;
    }
    async unassign(entitlements) {
        return this.apiProvider.request(async () => {
            let result;
            for (const entitlement of entitlements) {
                result = await this.aobClient.client.portal_entitlement_delete(entitlement.UID_AOBEntitlement.value);
            }
            return result;
        });
    }
    async publish(entitlements, publishData) {
        let publishCount = 0;
        for (const entitlement of entitlements) {
            const interactive = (await this.aobClient.typedClient.PortalEntitlementInteractive.Get_byid(entitlement.GetEntity().GetKeys()[0]))
                .Data[0];
            if (!publishData.publishFuture) {
                await interactive.IsInActive.Column.PutValue(publishData.publishFuture);
            }
            else {
                await interactive.ActivationDate.Column.PutValue(publishData.date);
            }
            this.logger.debug(this, 'Commit change: publish entitlement...');
            if (await this.tryCommit(interactive)) {
                publishCount++;
            }
        }
        return publishCount;
    }
    async unpublish(entitlements) {
        let unpublishCount = 0;
        for (const entitlement of entitlements) {
            const interactive = (await this.aobClient.typedClient.PortalEntitlementInteractive.Get_byid(entitlement.GetEntity().GetKeys()[0]))
                .Data[0];
            await interactive.IsInActive.Column.PutValue(true);
            await interactive.ActivationDate.Column.PutValue(null);
            this.logger.debug(this, 'Commit change: unpublish entitlement...');
            if (await this.tryCommit(interactive)) {
                unpublishCount++;
            }
        }
        return unpublishCount;
    }
    async tryCommit(entitlement, reload) {
        try {
            await entitlement.GetEntity().Commit(reload);
            return true;
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        return false;
    }
    getEntitlementBadges(entitlement) {
        if (this.filter.published(entitlement)) {
            return [this.badgePublished];
        }
        if (this.filter.willPublish(entitlement)) {
            return [this.badgeWillPublish];
        }
        return [];
    }
    async getEntitlementsFilterTree(options) {
        return this.aobClient.client.portal_entitlementcandidates_UNSGroup_filtertree_get(options);
    }
    async createNew(element, uidAobApplication) {
        const entitlement = (await this.aobClient.typedClient.PortalEntitlementInteractive.Get()).Data[0];
        (entitlement.ObjectKeyElement.value = element.GetEntity().GetColumn('XObjectKey').GetValue()),
            (entitlement.UID_AOBApplication.value = uidAobApplication.value);
        return entitlement;
    }
    static ɵfac = function EntitlementsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ApiClientService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i0.ErrorHandler), i0.ɵɵinject(i3.TranslateService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EntitlementsService, factory: EntitlementsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobApiService }, { type: i2.ApiClientService }, { type: i2.ClassloggerService }, { type: i0.ErrorHandler }, { type: i3.TranslateService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SystemRoleConfigService {
    aobClient;
    constructor(aobClient) {
        this.aobClient = aobClient;
    }
    get roleSchema() {
        return this.aobClient.typedClient.PortalEntitlementcandidatesEset.GetSchema();
    }
    async getExistingRoles(application, parameters) {
        return this.aobClient.typedClient.PortalEntitlementSystemrole.Get(application, parameters);
    }
    static ɵfac = function SystemRoleConfigService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SystemRoleConfigService)(i0.ɵɵinject(AobApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: SystemRoleConfigService, factory: SystemRoleConfigService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SystemRoleConfigService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobApiService }], null); })();

const _c0$8 = ["viewport"];
function SystemRoleConfigComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-alert", 10);
    i0.ɵɵlistener("dismissed", function SystemRoleConfigComponent_eui_alert_1_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onHelperDismissed()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, ctx_r1.data.createOnly ? ctx_r1.LdsCreate : ctx_r1.LdsAddOrCreate), " ");
} }
function SystemRoleConfigComponent_mat_radio_group_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-radio-group", 11);
    i0.ɵɵtwoWayListener("ngModelChange", function SystemRoleConfigComponent_mat_radio_group_3_Template_mat_radio_group_ngModelChange_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r1.type, $event) || (ctx_r1.type = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("change", function SystemRoleConfigComponent_mat_radio_group_3_Template_mat_radio_group_change_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.typeChanged($event)); });
    i0.ɵɵelementStart(1, "mat-radio-button", 12);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-radio-button", 13);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵtwoWayProperty("ngModel", ctx_r1.type);
    i0.ɵɵadvance();
    i0.ɵɵproperty("value", "new");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 5, "#LDS#Create new system role"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("value", "existing");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 7, "#LDS#Add to existing system role"), " ");
} }
function SystemRoleConfigComponent_form_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "form", 14)(1, "mat-form-field", 15)(2, "mat-label", 16);
    i0.ɵɵtext(3, "#LDS#Name");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(4, "input", 17);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("formGroup", ctx_r1.form);
} }
function SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_mat_list_option_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-list-option", 23)(1, "div", 24)(2, "div", 25);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const candidate_r5 = ctx.$implicit;
    i0.ɵɵproperty("value", candidate_r5);
    i0.ɵɵattribute("data-imx-identifier", "multi-select-formcontrol-list" + candidate_r5.GetEntity().GetKeys()[0]);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(candidate_r5.GetEntity().GetDisplay());
} }
function SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "cdk-virtual-scroll-viewport", 20, 0)(2, "mat-selection-list", 21);
    i0.ɵɵlistener("selectionChange", function SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_Template_mat_selection_list_selectionChange_2_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.updateSelected($event)); });
    i0.ɵɵtemplate(3, SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_mat_list_option_3_Template, 4, 3, "mat-list-option", 22);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("itemSize", 50);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("multiple", false);
    i0.ɵɵadvance();
    i0.ɵɵproperty("cdkVirtualForOf", ctx_r1.candidates);
} }
function SystemRoleConfigComponent_ng_container_5_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 26);
    i0.ɵɵelement(1, "eui-icon", 27);
    i0.ɵɵelementStart(2, "p", 16);
    i0.ɵɵtext(3, "#LDS#There are currently no system roles.");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("icon", "table");
} }
function SystemRoleConfigComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_Template, 4, 3, "cdk-virtual-scroll-viewport", 18)(2, SystemRoleConfigComponent_ng_container_5_div_2_Template, 4, 1, "div", 19);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !!(ctx_r1.candidates == null ? null : ctx_r1.candidates.length));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.candidates == null || ctx_r1.candidates.length === 0);
} }
function SystemRoleConfigComponent_button_7_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 28);
    i0.ɵɵlistener("click", function SystemRoleConfigComponent_button_7_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r6); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.close(true)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r1.form.invalid || !ctx_r1.form.dirty);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Create system role"), " ");
} }
function SystemRoleConfigComponent_button_8_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 29);
    i0.ɵɵlistener("click", function SystemRoleConfigComponent_button_8_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r7); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.close(false)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r1.selectedRole == null);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Add to system role"), " ");
} }
class SystemRoleConfigComponent {
    data;
    sidesheetRef;
    busyService;
    addToExistingProvider;
    settingsService;
    changeDetectorRef;
    form;
    type = 'new';
    selectedRole;
    showHelperAlert = true;
    candidates;
    viewport;
    parameters;
    subscriptions = [];
    constructor(data, sidesheetRef, busyService, addToExistingProvider, settingsService, changeDetectorRef) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.busyService = busyService;
        this.addToExistingProvider = addToExistingProvider;
        this.settingsService = settingsService;
        this.changeDetectorRef = changeDetectorRef;
        this.form = new UntypedFormGroup({ name: new UntypedFormControl(undefined, Validators.required) });
    }
    async ngAfterViewInit() {
        this.parameters = { PageSize: this.settingsService.DefaultPageSize, StartIndex: 0 };
        if (this.viewport) {
            this.subscriptions.push(this.viewport.renderedRangeStream.subscribe(async (range) => {
                if (range.end === this.settingsService.DefaultPageSize + (this.parameters.StartIndex || 0)) {
                    this.parameters.StartIndex = (this.parameters.StartIndex || 0) + this.settingsService.DefaultPageSize;
                    const tmpCandidates = Object.assign([], this.candidates);
                    await this.loadData(this.parameters);
                    this.candidates.unshift(...tmpCandidates);
                    this.changeDetectorRef.detectChanges();
                }
            }));
        }
    }
    ngOnDestroy() {
        this.subscriptions.forEach((s) => s.unsubscribe());
    }
    async typeChanged(evt) {
        if (evt.value === 'existing') {
            if (this.viewport) {
                this.subscriptions.push(this.viewport.renderedRangeStream.subscribe(async (range) => {
                    if (range.end === this.settingsService.DefaultPageSize + (this.parameters.StartIndex || 0)) {
                        this.parameters.StartIndex = (this.parameters.StartIndex || 0) + this.settingsService.DefaultPageSize;
                        const tmpCandidates = Object.assign([], this.candidates);
                        await this.loadData(this.parameters);
                        this.candidates.unshift(...tmpCandidates);
                        this.changeDetectorRef.detectChanges();
                    }
                }));
            }
            this.selectedRole = undefined;
            await this.loadData({ ...this.parameters, ...{ StartIndex: 0 } });
        }
    }
    async updateSelected(selection) {
        this.selectedRole = selection.options[0].value.GetEntity().GetKeys()[0];
    }
    onHelperDismissed() {
        this.showHelperAlert = false;
    }
    close(createNew) {
        if (createNew) {
            this.sidesheetRef.close({ NameNewEset: this.form.get('name')?.value });
        }
        else {
            this.sidesheetRef.close({ UidEset: this.selectedRole });
        }
    }
    async loadData(newState) {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            this.candidates = (await this.addToExistingProvider.getExistingRoles(this.data.uid, newState || {})).Data;
        }
        finally {
            this.busyService.hide();
        }
    }
    LdsAddOrCreate = '#LDS#Here you can merge the application entitlements into a new system role or add the application entitlements to an existing system role. The system role will then be assigned to the application as an application entitlement.';
    LdsCreate = '#LDS#Here you can create an empty system role. The system role will then be assigned to the application as an application entitlement.';
    static ɵfac = function SystemRoleConfigComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SystemRoleConfigComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(SystemRoleConfigService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SystemRoleConfigComponent, selectors: [["ng-component"]], viewQuery: function SystemRoleConfigComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$8, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.viewport = _t.first);
        } }, decls: 9, vars: 6, consts: [["viewport", ""], ["eui-sidesheet-content", "", 1, "imx-sidesheet-content__overflow"], ["type", "info", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [1, "imx-sidesheet-content__flex"], [3, "ngModel", "ngModelChange", "change", 4, "ngIf"], [3, "formGroup", 4, "ngIf"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "system-role-config-create-new-system-role-button", 3, "disabled", "click", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "system-role-config-add-to-existing-system-role-button", 3, "disabled", "click", 4, "ngIf"], ["type", "info", 3, "dismissed", "condensed", "colored", "dismissable"], [3, "ngModelChange", "change", "ngModel"], ["data-imx-identifier", "add-to-role-new", 3, "value"], ["data-imx-identifier", "add-to-role-existing", 3, "value"], [3, "formGroup"], ["appearance", "outline"], ["translate", ""], ["matInput", "", "formControlName", "name", "data-imx-identifier", "system-role-config-new-system-role-input"], ["minBufferPx", "300", "maxBufferPx", "800", "class", "imx-viewport", 3, "itemSize", 4, "ngIf"], ["class", "imx-no-results", 4, "ngIf"], ["minBufferPx", "300", "maxBufferPx", "800", 1, "imx-viewport", 3, "itemSize"], [3, "selectionChange", "multiple"], ["class", "imx-candidate-option", 3, "value", 4, "cdkVirtualFor", "cdkVirtualForOf"], [1, "imx-candidate-option", 3, "value"], [1, "imx-candidate-content"], [1, "imx-candidate-display"], [1, "imx-no-results"], [3, "icon"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "system-role-config-create-new-system-role-button", 3, "click", "disabled"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "system-role-config-add-to-existing-system-role-button", 3, "click", "disabled"]], template: function SystemRoleConfigComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵtemplate(1, SystemRoleConfigComponent_eui_alert_1_Template, 3, 6, "eui-alert", 2);
            i0.ɵɵelementStart(2, "mat-card", 3);
            i0.ɵɵtemplate(3, SystemRoleConfigComponent_mat_radio_group_3_Template, 7, 9, "mat-radio-group", 4)(4, SystemRoleConfigComponent_form_4_Template, 5, 1, "form", 5)(5, SystemRoleConfigComponent_ng_container_5_Template, 3, 2, "ng-container", 6);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(6, "div", 7);
            i0.ɵɵtemplate(7, SystemRoleConfigComponent_button_7_Template, 3, 4, "button", 8)(8, SystemRoleConfigComponent_button_8_Template, 3, 4, "button", 9);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showHelperAlert);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !ctx.data.createOnly);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.type === "new");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.type === "existing");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.type === "new");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.type !== "new");
        } }, dependencies: [i6.NgIf, i1.EuiAlertComponent, i1.EuiIconComponent, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i7.MatButton, i6$1.MatCard, i12$1.MatFormField, i12$1.MatLabel, i13.MatInput, i9.MatSelectionList, i9.MatListOption, i14.MatRadioGroup, i14.MatRadioButton, i11$1.CdkFixedSizeVirtualScroll, i11$1.CdkVirtualForOf, i11$1.CdkVirtualScrollViewport, i12.ɵNgNoValidate, i12.DefaultValueAccessor, i12.NgControlStatus, i12.NgControlStatusGroup, i12.NgModel, i12.FormGroupDirective, i12.FormControlName, i3.TranslateDirective, i3.TranslatePipe], styles: [".imx-viewport[_ngcontent-%COMP%]{height:300px;width:100%;overflow-x:hidden}.mat-mdc-radio-button[_ngcontent-%COMP%]{margin-right:20px}.eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-content-card[_ngcontent-%COMP%]{flex:1 1 auto}.imx-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0}.imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px;color:#919799}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SystemRoleConfigComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content class=\"imx-sidesheet-content__overflow\">\n  <eui-alert *ngIf=\"showHelperAlert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"true\" (dismissed)=\"onHelperDismissed()\">\n    {{ (data.createOnly ? LdsCreate : LdsAddOrCreate) | translate }}\n  </eui-alert>\n  <mat-card class=\"imx-sidesheet-content__flex\">\n    <mat-radio-group [(ngModel)]=\"type\" (change)=\"typeChanged($event)\" *ngIf=\"!data.createOnly\">\n      <mat-radio-button [value]=\"'new'\" data-imx-identifier=\"add-to-role-new\">\n        {{ '#LDS#Create new system role' | translate }}\n      </mat-radio-button>\n      <mat-radio-button [value]=\"'existing'\" data-imx-identifier=\"add-to-role-existing\">\n        {{ '#LDS#Add to existing system role' | translate }}\n      </mat-radio-button>\n    </mat-radio-group>\n    <form [formGroup]=\"form\" *ngIf=\"type === 'new'\">\n      <mat-form-field appearance=\"outline\">\n        <mat-label translate>#LDS#Name</mat-label>\n        <input matInput formControlName=\"name\" data-imx-identifier=\"system-role-config-new-system-role-input\" />\n      </mat-form-field>\n    </form>\n    <ng-container *ngIf=\"type === 'existing'\">\n      <cdk-virtual-scroll-viewport\n        *ngIf=\"!!candidates?.length\"\n        #viewport\n        [itemSize]=\"50\"\n        minBufferPx=\"300\"\n        maxBufferPx=\"800\"\n        class=\"imx-viewport\"\n      >\n        <mat-selection-list [multiple]=\"false\" (selectionChange)=\"updateSelected($event)\">\n          <mat-list-option\n            *cdkVirtualFor=\"let candidate of candidates; index as i\"\n            [value]=\"candidate\"\n            class=\"imx-candidate-option\"\n            [attr.data-imx-identifier]=\"'multi-select-formcontrol-list' + candidate.GetEntity().GetKeys()[0]\"\n          >\n            <div class=\"imx-candidate-content\">\n              <div class=\"imx-candidate-display\">{{ candidate.GetEntity().GetDisplay() }}</div>\n            </div>\n          </mat-list-option>\n        </mat-selection-list>\n      </cdk-virtual-scroll-viewport>\n      <div class=\"imx-no-results\" *ngIf=\"candidates == null || candidates.length === 0\">\n        <eui-icon [icon]=\"'table'\"></eui-icon>\n        <p translate>#LDS#There are currently no system roles.</p>\n      </div>\n    </ng-container>\n  </mat-card>\n</div>\n\n<div eui-sidesheet-actions>\n  <button\n    *ngIf=\"type === 'new'\"\n    mat-flat-button\n    color=\"primary\"\n    [disabled]=\"form.invalid || !form.dirty\"\n    (click)=\"close(true)\"\n    data-imx-identifier=\"system-role-config-create-new-system-role-button\"\n  >\n    {{ '#LDS#Create system role' | translate }}\n  </button>\n  <button\n    [disabled]=\"selectedRole == null\"\n    *ngIf=\"type !== 'new'\"\n    mat-flat-button\n    color=\"primary\"\n    (click)=\"close(false)\"\n    data-imx-identifier=\"system-role-config-add-to-existing-system-role-button\"\n  >\n    {{ '#LDS#Add to system role' | translate }}\n  </button>\n</div>\n", styles: [".imx-viewport{height:300px;width:100%;overflow-x:hidden}.mat-mdc-radio-button{margin-right:20px}.eui-sidesheet-content{display:flex;flex-direction:column;overflow:hidden;height:inherit}.eui-sidesheet-content .imx-content-card{flex:1 1 auto}.imx-no-results{text-align:center;margin:20px 0}.imx-no-results p{margin:0;font-size:18px;color:#919799}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1.EuiSidesheetRef }, { type: i1.EuiLoadingService }, { type: SystemRoleConfigService }, { type: i2.SettingsService }, { type: i0.ChangeDetectorRef }], { viewport: [{
            type: ViewChild,
            args: ['viewport']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SystemRoleConfigComponent, { className: "SystemRoleConfigComponent", filePath: "lib\\entitlements\\entitlement-add\\system-role-config\\system-role-config.component.ts", lineNumber: 44 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EntitlementsAddComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-alert", 19);
    i0.ɵɵlistener("dismissed", function EntitlementsAddComponent_eui_alert_1_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onHelperDismissed()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, ctx_r1.LdsInfoAlert), " ");
} }
function EntitlementsAddComponent_mat_option_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-option", 20);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const entitlementSourceType_r3 = ctx.$implicit;
    i0.ɵɵproperty("value", entitlementSourceType_r3.entitlementsType);
    i0.ɵɵattribute("data-imx-identifier", "imx-entitlments-add-type-select" + entitlementSourceType_r3.entitlementsType);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", entitlementSourceType_r3.display, " ");
} }
function EntitlementsAddComponent_th_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 21);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns == null ? null : ctx_r1.entitySchema.Columns[ctx_r1.DisplayColumns.DISPLAY_PROPERTYNAME] == null ? null : ctx_r1.entitySchema.Columns[ctx_r1.DisplayColumns.DISPLAY_PROPERTYNAME].Display);
} }
function EntitlementsAddComponent_td_15_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const item_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4 == null ? null : item_r4.GetEntity().GetDisplay());
} }
function EntitlementsAddComponent_td_15_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 24);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const item_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4 == null ? null : item_r4.GetEntity().GetDisplay());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4 == null ? null : item_r4.Description == null ? null : item_r4.Description.Column.GetDisplayValue());
} }
function EntitlementsAddComponent_td_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22);
    i0.ɵɵtemplate(1, EntitlementsAddComponent_td_15_ng_container_1_Template, 3, 1, "ng-container", 23)(2, EntitlementsAddComponent_td_15_ng_container_2_Template, 5, 2, "ng-container", 23);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.selectedSourceType !== ctx_r1.EntitlementsType.UnsGroup);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.selectedSourceType === ctx_r1.EntitlementsType.UnsGroup);
} }
function EntitlementsAddComponent_ng_container_16_th_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 21);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns == null ? null : ctx_r1.entitySchema.Columns.CanonicalName == null ? null : ctx_r1.entitySchema.Columns.CanonicalName.Display);
} }
function EntitlementsAddComponent_ng_container_16_td_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 26)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r5.CanonicalName == null ? null : item_r5.CanonicalName.Column.GetDisplayValue());
} }
function EntitlementsAddComponent_ng_container_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0, 10);
    i0.ɵɵtemplate(1, EntitlementsAddComponent_ng_container_16_th_1_Template, 2, 1, "th", 11)(2, EntitlementsAddComponent_ng_container_16_td_2_Template, 3, 1, "td", 25);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("matColumnDef", ctx_r1.entitySchema.Columns.CanonicalName.ColumnName);
} }
function EntitlementsAddComponent_ng_container_17_th_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 21);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns == null ? null : ctx_r1.entitySchema.Columns.UID_UNSRoot == null ? null : ctx_r1.entitySchema.Columns.UID_UNSRoot.Display);
} }
function EntitlementsAddComponent_ng_container_17_td_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 26)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r6.UID_UNSRoot == null ? null : item_r6.UID_UNSRoot.Column.GetDisplayValue());
} }
function EntitlementsAddComponent_ng_container_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0, 10);
    i0.ɵɵtemplate(1, EntitlementsAddComponent_ng_container_17_th_1_Template, 2, 1, "th", 11)(2, EntitlementsAddComponent_ng_container_17_td_2_Template, 3, 1, "td", 25);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("matColumnDef", ctx_r1.entitySchema.Columns.UID_UNSRoot.ColumnName);
} }
function EntitlementsAddComponent_button_22_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 27);
    i0.ɵɵlistener("click", function EntitlementsAddComponent_button_22_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r7); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onCreateRole()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Create empty system role"), " ");
} }
function EntitlementsAddComponent_button_23_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 28);
    i0.ɵɵlistener("click", function EntitlementsAddComponent_button_23_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r8); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onAddToRole()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", !(ctx_r1.selections == null ? null : ctx_r1.selections.length));
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Merge into system role"), " ");
} }
const helperAlertKey = `${HELPER_ALERT_KEY_PREFIX}_addNewEntitlements`;
/**
 * A component that represents a sidesheet for adding application entitlements to an {@link PortalApplication}.
 */
class EntitlementsAddComponent {
    sidesheetRef;
    data;
    logger;
    entitlementsProvider;
    busyService;
    storageService;
    metaData;
    sidesheet;
    translateService;
    dataSource;
    settingsService;
    EntitlementsType = EntitlementsType; // Enables use of this Enum in Angular Templates.
    DisplayColumns = DisplayColumns; // Enables use of this static class in Angular Templates.
    entitySchema;
    displayedColumns = [];
    selectedSourceType = EntitlementsType.UnsGroup;
    isSystemRolesEnabled;
    entitlementsLabel;
    rolesLabel;
    selections;
    browserCulture;
    entitlementSourceTypes = [];
    get showHelperAlert() {
        return !this.storageService.isHelperAlertDismissed(helperAlertKey);
    }
    constructor(sidesheetRef, data, logger, entitlementsProvider, busyService, storageService, metaData, sidesheet, translateService, dataSource, settingsService) {
        this.sidesheetRef = sidesheetRef;
        this.data = data;
        this.logger = logger;
        this.entitlementsProvider = entitlementsProvider;
        this.busyService = busyService;
        this.storageService = storageService;
        this.metaData = metaData;
        this.sidesheet = sidesheet;
        this.translateService = translateService;
        this.dataSource = dataSource;
        this.settingsService = settingsService;
        this.selectedSourceType = data.defaultType;
        this.isSystemRolesEnabled = data.isSystemRolesEnabled;
        this.browserCulture = translateService.currentLang;
    }
    async ngOnInit() {
        await this.metaData.updateNonExisting(['ESet', 'UNSGroup', 'QERResource', 'RPSReport', 'TSBAccountDef']);
        this.entitlementSourceTypes = [
            { entitlementsType: EntitlementsType.UnsGroup, display: this.metaData.tables.UNSGroup?.Display || '' },
            { entitlementsType: EntitlementsType.Qerresource, display: this.metaData.tables.QERResource?.Display || '' },
            { entitlementsType: EntitlementsType.Rpsreport, display: this.metaData.tables.RPSReport?.Display || '' },
            { entitlementsType: EntitlementsType.Tsbaccountdef, display: this.metaData.tables.TSBAccountDef?.Display || '' },
        ];
        if (this.isSystemRolesEnabled) {
            this.entitlementSourceTypes.unshift({ entitlementsType: EntitlementsType.Eset, display: this.metaData.tables.ESet?.Display || '' });
        }
        await this.useSource(this.selectedSourceType);
    }
    onHelperDismissed() {
        this.storageService.storeHelperAlertDismissal(helperAlertKey);
    }
    /**
     * Call to toggle the view and show entitlements candidates or roles candidates.
     */
    async toggleView(arg) {
        this.selectedSourceType = arg.value;
        this.logger.debug(this, `Switching view to ${this.selectedSourceType}.`);
        await this.useSource(this.selectedSourceType);
    }
    onOk() {
        this.logger.debug(this, 'Close the sidesheet for assigning application entitlements');
        this.logger.trace(this, this.selections);
        this.sidesheetRef.close({ selection: this.selections });
    }
    async onCreateRole() {
        const entitlementSystemRoleInput = await this.sidesheet
            .open(SystemRoleConfigComponent, {
            title: await this.translateService.get('#LDS#Heading Create Empty System Role').toPromise(),
            padding: '0px',
            width: calculateSidesheetWidth(800, 0.5),
            testId: 'create-role-sidesheet',
            data: { uid: this.data.uidApplication, createOnly: true },
        })
            .afterClosed()
            .toPromise();
        if (!entitlementSystemRoleInput) {
            this.logger.debug(this, 'role dialog canceled');
            return;
        }
        entitlementSystemRoleInput.UidApplication = this.data.uidApplication;
        entitlementSystemRoleInput.ObjectKeyEntitlements = [];
        this.sidesheetRef.close({ role: entitlementSystemRoleInput });
    }
    async onAddToRole() {
        const entitlementSystemRoleInput = await this.sidesheet
            .open(SystemRoleConfigComponent, {
            title: await this.translateService.get('#LDS#Heading Merge Application Entitlements into System Role').toPromise(),
            padding: '0px',
            width: calculateSidesheetWidth(800, 0.5),
            testId: 'add-to-existing-role-sidesheet',
            data: { uid: this.data.uidApplication, createOnly: false },
        })
            .afterClosed()
            .toPromise();
        if (!entitlementSystemRoleInput) {
            this.logger.debug(this, 'role dialog canceled');
            return;
        }
        const keys = this.selections
            .map((elem) => CdrFactoryService.tryGetColumn(elem.GetEntity(), 'XObjectKey')?.GetValue())
            .filter((elem) => elem != null);
        if (keys.length < this.selections.length) {
            this.logger.error(this, 'Attempt to assign entitlement(s) failed');
        }
        entitlementSystemRoleInput.UidApplication = this.data.uidApplication;
        entitlementSystemRoleInput.ObjectKeyEntitlements = keys;
        this.sidesheetRef.close({ role: entitlementSystemRoleInput });
    }
    onSelectionChanged(selection) {
        this.selections = selection;
    }
    async useSource(type) {
        this.selectedSourceType = type;
        this.entitySchema = this.entitlementsProvider.candidateSchema(type);
        let dataModel = undefined;
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            dataModel = await this.entitlementsProvider.getDataModel(type);
        }
        finally {
            this.busyService.hide();
        }
        this.displayedColumns = this.getDisplayedColumnsForEntitlement(this.entitySchema, type);
        this.dataSource.state.set({ PageSize: this.settingsService?.DefaultPageSize, StartIndex: 0 });
        const dataViewInitParameters = {
            execute: (params) => this.entitlementsProvider.getCandidates(this.selectedSourceType, params),
            schema: this.entitySchema,
            columnsToDisplay: this.displayedColumns,
            dataModel,
            selectionChange: (selection) => this.onSelectionChanged(selection),
            filterTree: this.selectedSourceType === EntitlementsType.UnsGroup
                ? {
                    filterMethode: async (parentkey) => {
                        return this.entitlementsProvider.getEntitlementsFilterTree({
                            parentkey,
                        });
                    },
                    multiSelect: false,
                }
                : undefined,
        };
        await this.dataSource.init(dataViewInitParameters);
    }
    getDisplayedColumnsForEntitlement(entitySchema, type) {
        if (!entitySchema) {
            return [];
        }
        switch (type) {
            case EntitlementsType.UnsGroup:
                return [
                    entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
                    entitySchema.Columns.CanonicalName,
                    entitySchema.Columns.UID_UNSRoot,
                ];
            default:
                return [entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]];
        }
    }
    LdsInfoAlert = '#LDS#Here you can assign application entitlements to the application. Once assigned, you can publish these application entitlements so that they can be requested.';
    static ɵfac = function EntitlementsAddComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementsAddComponent)(i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(EntitlementsService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.StorageService), i0.ɵɵdirectiveInject(i2.MetadataService), i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i2.DataViewSource), i0.ɵɵdirectiveInject(i2.SettingsService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementsAddComponent, selectors: [["imx-entitlements-add"]], features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 27, vars: 20, consts: [["eui-sidesheet-content", ""], ["type", "info", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [1, "imx-sidesheet-content__overflow", "imx-sidesheet-content__flex"], [1, "imx-table-action-row"], ["appearance", "outline", 1, "flex-field"], [1, "imx-info-text-light"], ["data-imx-identifier", "imx-entitlments-add-type-select", 3, "ngModelChange", "selectionChange", "ngModel"], [3, "value", 4, "ngFor", "ngForOf"], [3, "dataSource"], ["mode", "manual", 3, "dataSource", "selectable"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], [3, "matColumnDef", 4, "ngIf"], [1, "imx-table-action-row", "imx-margin-top-16"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-create-role-button", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-add-to-role-button", 3, "disabled", "click", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "imx-entitlements-add-assig-button", 3, "click", "disabled"], ["type", "info", 3, "dismissed", "condensed", "colored", "dismissable"], [3, "value"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], [4, "ngIf"], ["subtitle", ""], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], ["mat-cell", "", "role", "gridcell"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-create-role-button", 3, "click"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-add-to-role-button", 3, "click", "disabled"]], template: function EntitlementsAddComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, EntitlementsAddComponent_eui_alert_1_Template, 3, 6, "eui-alert", 1);
            i0.ɵɵelementStart(2, "mat-card", 2);
            i0.ɵɵelementContainerStart(3);
            i0.ɵɵelementStart(4, "div", 3)(5, "mat-form-field", 4)(6, "mat-label", 5);
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(9, "mat-select", 6);
            i0.ɵɵtwoWayListener("ngModelChange", function EntitlementsAddComponent_Template_mat_select_ngModelChange_9_listener($event) { i0.ɵɵtwoWayBindingSet(ctx.selectedSourceType, $event) || (ctx.selectedSourceType = $event); return $event; });
            i0.ɵɵlistener("selectionChange", function EntitlementsAddComponent_Template_mat_select_selectionChange_9_listener($event) { return ctx.toggleView($event); });
            i0.ɵɵtemplate(10, EntitlementsAddComponent_mat_option_10_Template, 2, 3, "mat-option", 7);
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(11, "imx-data-view-toolbar", 8);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(12, "imx-data-view-auto-table", 9);
            i0.ɵɵelementContainerStart(13, 10);
            i0.ɵɵtemplate(14, EntitlementsAddComponent_th_14_Template, 2, 1, "th", 11)(15, EntitlementsAddComponent_td_15_Template, 3, 2, "td", 12);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(16, EntitlementsAddComponent_ng_container_16_Template, 3, 1, "ng-container", 13)(17, EntitlementsAddComponent_ng_container_17_Template, 3, 1, "ng-container", 13);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(18, "div", 14);
            i0.ɵɵelement(19, "imx-data-view-selection", 8)(20, "imx-data-view-paginator", 8);
            i0.ɵɵelementEnd();
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(21, "div", 15);
            i0.ɵɵtemplate(22, EntitlementsAddComponent_button_22_Template, 3, 3, "button", 16)(23, EntitlementsAddComponent_button_23_Template, 3, 4, "button", 17);
            i0.ɵɵelementStart(24, "button", 18);
            i0.ɵɵlistener("click", function EntitlementsAddComponent_Template_button_click_24_listener() { return ctx.onOk(); });
            i0.ɵɵtext(25);
            i0.ɵɵpipe(26, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showHelperAlert);
            i0.ɵɵadvance(6);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(8, 16, "#LDS#Application entitlement type"));
            i0.ɵɵadvance(2);
            i0.ɵɵtwoWayProperty("ngModel", ctx.selectedSourceType);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.entitlementSourceTypes);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource)("selectable", true);
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.DisplayColumns.DISPLAY_PROPERTYNAME);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.selectedSourceType === ctx.EntitlementsType.UnsGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.selectedSourceType === ctx.EntitlementsType.UnsGroup);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.isSystemRolesEnabled);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isSystemRolesEnabled);
            i0.ɵɵadvance();
            i0.ɵɵproperty("disabled", !(ctx.selections == null ? null : ctx.selections.length));
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(26, 18, "#LDS#Assign"), " ");
        } }, dependencies: [i6.NgForOf, i6.NgIf, i1.EuiAlertComponent, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i6$2.MatOption, i7.MatButton, i6$1.MatCard, i12$1.MatFormField, i12$1.MatLabel, i10.MatSelect, i15.MatHeaderCellDef, i15.MatColumnDef, i15.MatCellDef, i15.MatHeaderCell, i15.MatCell, i12.NgControlStatus, i12.NgModel, i2.DataViewAutoTableComponent, i2.DataViewPaginatorComponent, i2.DataViewToolbarComponent, i2.DataViewSelectionComponent, i3.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}.eui-sidesheet-actions[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{align-self:center}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementsAddComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlements-add', providers: [DataViewSource], template: "<div eui-sidesheet-content>\n  <eui-alert *ngIf=\"showHelperAlert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"true\" (dismissed)=\"onHelperDismissed()\">\n    {{ LdsInfoAlert | translate }}\n  </eui-alert>\n  <mat-card class=\"imx-sidesheet-content__overflow imx-sidesheet-content__flex\">\n    <ng-container>\n      <div class=\"imx-table-action-row\">\n        <mat-form-field appearance=\"outline\" class=\"flex-field\">\n          <mat-label class=\"imx-info-text-light\">{{ '#LDS#Application entitlement type' | translate }}</mat-label>\n          <mat-select\n            [(ngModel)]=\"selectedSourceType\"\n            (selectionChange)=\"toggleView($event)\"\n            data-imx-identifier=\"imx-entitlments-add-type-select\"\n          >\n            <mat-option\n              *ngFor=\"let entitlementSourceType of entitlementSourceTypes\"\n              [value]=\"entitlementSourceType.entitlementsType\"\n              [attr.data-imx-identifier]=\"'imx-entitlments-add-type-select' + entitlementSourceType.entitlementsType\"\n            >\n              {{ entitlementSourceType.display }}\n            </mat-option>\n          </mat-select>\n        </mat-form-field>\n        <imx-data-view-toolbar [dataSource]=\"dataSource\"></imx-data-view-toolbar>\n      </div>\n      <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\" [selectable]=\"true\">\n        <ng-container [matColumnDef]=\"DisplayColumns.DISPLAY_PROPERTYNAME\">\n          <th mat-header-cell *matHeaderCellDef>{{ entitySchema?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]?.Display }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n            <ng-container *ngIf=\"selectedSourceType !== EntitlementsType.UnsGroup\">\n              <div>{{ item?.GetEntity().GetDisplay() }}</div>\n            </ng-container>\n            <ng-container *ngIf=\"selectedSourceType === EntitlementsType.UnsGroup\">\n              <div>{{ item?.GetEntity().GetDisplay() }}</div>\n              <div subtitle>{{ item?.Description?.Column.GetDisplayValue() }}</div>\n            </ng-container>\n          </td>\n        </ng-container>\n        <ng-container\n          [matColumnDef]=\"entitySchema.Columns.CanonicalName.ColumnName\"\n          *ngIf=\"selectedSourceType === EntitlementsType.UnsGroup\"\n        >\n          <th mat-header-cell *matHeaderCellDef>{{ entitySchema?.Columns?.CanonicalName?.Display }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <div>{{ item.CanonicalName?.Column.GetDisplayValue() }}</div>\n          </td>\n        </ng-container>\n        <ng-container [matColumnDef]=\"entitySchema.Columns.UID_UNSRoot.ColumnName\" *ngIf=\"selectedSourceType === EntitlementsType.UnsGroup\">\n          <th mat-header-cell *matHeaderCellDef>{{ entitySchema?.Columns?.UID_UNSRoot?.Display }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <div>{{ item.UID_UNSRoot?.Column.GetDisplayValue() }}</div>\n          </td>\n        </ng-container>\n      </imx-data-view-auto-table>\n      <div class=\"imx-table-action-row imx-margin-top-16\">\n        <imx-data-view-selection [dataSource]=\"dataSource\"></imx-data-view-selection>\n        <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n      </div>\n    </ng-container>\n  </mat-card>\n</div>\n<div eui-sidesheet-actions>\n  <button\n    *ngIf=\"isSystemRolesEnabled\"\n    mat-stroked-button\n    (click)=\"onCreateRole()\"\n    data-imx-identifier=\"imx-entitlements-create-role-button\"\n  >\n    {{ '#LDS#Create empty system role' | translate }}\n  </button>\n  <button\n    *ngIf=\"isSystemRolesEnabled\"\n    mat-stroked-button\n    (click)=\"onAddToRole()\"\n    [disabled]=\"!selections?.length\"\n    data-imx-identifier=\"imx-entitlements-add-to-role-button\"\n  >\n    {{ '#LDS#Merge into system role' | translate }}\n  </button>\n  <button\n    mat-flat-button\n    (click)=\"onOk()\"\n    [disabled]=\"!selections?.length\"\n    color=\"primary\"\n    data-imx-identifier=\"imx-entitlements-add-assig-button\"\n  >\n    {{ '#LDS#Assign' | translate }}\n  </button>\n</div>\n", styles: [".eui-sidesheet-content{display:flex;flex-direction:column}.eui-sidesheet-actions>*{align-self:center}\n"] }]
    }], () => [{ type: i1.EuiSidesheetRef }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i2.ClassloggerService }, { type: EntitlementsService }, { type: i1.EuiLoadingService }, { type: i2.StorageService }, { type: i2.MetadataService }, { type: i1.EuiSidesheetService }, { type: i3.TranslateService }, { type: i2.DataViewSource }, { type: i2.SettingsService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EntitlementsAddComponent, { className: "EntitlementsAddComponent", filePath: "lib\\entitlements\\entitlement-add\\entitlements-add.component.ts", lineNumber: 68 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EntitlementEditComponent_imx_cdr_editor_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function EntitlementEditComponent_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { const cdr_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.form.addControl((cdr_r2 == null ? null : cdr_r2.column == null ? null : cdr_r2.column.ColumnName) || "", $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r2 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r2);
} }
function EntitlementEditComponent_ng_container_4_imx_service_item_tags_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-service-item-tags", 10);
    i0.ɵɵlistener("controlCreated", function EntitlementEditComponent_ng_container_4_imx_service_item_tags_1_Template_imx_service_item_tags_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.form.addControl("tags", $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("selection", ctx_r2.productTagsSelected)("loading", ctx_r2.loadingTags);
} }
function EntitlementEditComponent_ng_container_4_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function EntitlementEditComponent_ng_container_4_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { const cdr_r6 = i0.ɵɵrestoreView(_r5).$implicit; const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.form.addControl((cdr_r6 == null ? null : cdr_r6.column == null ? null : cdr_r6.column.ColumnName) || "", $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r6 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r6);
} }
function EntitlementEditComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, EntitlementEditComponent_ng_container_4_imx_service_item_tags_1_Template, 1, 2, "imx-service-item-tags", 9)(2, EntitlementEditComponent_ng_container_4_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 3);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.productTagsSelected);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.cdrListServiceItem);
} }
function EntitlementEditComponent_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 11);
    i0.ɵɵlistener("click", function EntitlementEditComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r7); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.manageEntitlement()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Manage system role"), " ");
} }
/**
 * A component that provides a form for viewing and editing entitlements/roles.
 */
class EntitlementEditComponent {
    tagProvider;
    logger;
    router;
    errorHandler;
    cdrFactoryService;
    permissions;
    busyService;
    form = new UntypedFormGroup({});
    productTagsInitial = [];
    productTagsSelected;
    loadingTags;
    cdrList = [];
    cdrListServiceItem = [];
    isEditableEntitlement;
    entitlement;
    serviceItem;
    controlCreated = new EventEmitter();
    saved = new EventEmitter();
    constructor(tagProvider, logger, router, errorHandler, cdrFactoryService, permissions, busyService) {
        this.tagProvider = tagProvider;
        this.logger = logger;
        this.router = router;
        this.errorHandler = errorHandler;
        this.cdrFactoryService = cdrFactoryService;
        this.permissions = permissions;
        this.busyService = busyService;
    }
    async ngOnInit() {
        this.controlCreated.emit(this.form);
        const entitlementColumns = ['Ident_AOBEntitlement', 'Description', 'ObjectKeyAdditionalApprover'];
        this.cdrList = this.cdrFactoryService.buildCdrFromColumnList(this.entitlement.GetEntity(), entitlementColumns);
        if (this.serviceItem) {
            const serviceIemColumns = [
                'UID_OrgRuler',
                'UID_PWODecisionMethod',
                'UID_QERTermsOfUse',
                'UID_AccProductParamCategory',
                'UID_AccProductGroup',
                'ProductURL',
                'IsApproveRequiresMfa',
            ];
            this.cdrListServiceItem = this.cdrFactoryService.buildCdrFromColumnList(this.serviceItem.GetEntity(), serviceIemColumns);
        }
        this.isEditableEntitlement = await this.editableEntitlement();
    }
    async ngOnChanges(changes) {
        if (changes.entitlement || changes.serviceItem) {
            if (changes.entitlement && this.entitlement) {
                if (this.entitlement.UID_AccProduct.value !== '') {
                    await this.initTags(this.entitlement);
                }
            }
            this.form.markAsPristine();
        }
    }
    /**
     * Saves all changes of specified  {@link PortalEntitlement|entitlement}.
     * @param entitlement The {@link PortalEntitlement|entitlement} to be saved.
     */
    async save() {
        this.logger.trace(this, 'Save clicked for entitlement', this.entitlement);
        const success = await this.tryCommit([this.entitlement, this.serviceItem]);
        this.saved.emit(success);
    }
    async initTags(entitlement) {
        this.loadingTags = true;
        this.productTagsInitial = (await this.tagProvider.getTags(entitlement.UID_AccProduct.value)).Data.map((elem) => elem.Ident_DialogTag.value);
        this.productTagsSelected = this.productTagsInitial.slice();
        this.loadingTags = false;
    }
    async tryCommit(typedEntities) {
        let success = false;
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            for (const typedEntity of typedEntities) {
                if (typedEntity) {
                    await typedEntity.GetEntity().Commit(true);
                }
            }
            if (this.entitlement.UID_AccProduct.value !== '') {
                await this.saveTags();
                this.productTagsInitial = this.productTagsSelected.slice();
            }
            this.form.markAsPristine();
            success = true;
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        finally {
            this.busyService.hide();
        }
        return success;
    }
    async saveTags() {
        const changeSet = this.getTagsChangeSet();
        return this.tagProvider.updateTags(this.entitlement.UID_AccProduct.value, changeSet.add, changeSet.remove);
    }
    getTagsChangeSet() {
        this.logger.trace(this, 'save tags initial', this.productTagsInitial);
        this.logger.trace(this, 'save tags selected', this.productTagsSelected);
        return {
            add: this.productTagsSelected.filter((elem) => this.productTagsInitial.indexOf(elem) < 0),
            remove: this.productTagsInitial.filter((elem) => this.productTagsSelected.indexOf(elem) < 0),
        };
    }
    async editableEntitlement() {
        return (await this.permissions.isAobApplicationOwnerOrAdmin())
            ? DbObjectKey.FromXml(this.entitlement.ObjectKeyElement.value).TableName == 'ESet'
            : false;
    }
    manageEntitlement() {
        this.saved.emit(false);
        this.router.navigate(['/myresponsibilities/ESet']);
    }
    static ɵfac = function EntitlementEditComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementEditComponent)(i0.ɵɵdirectiveInject(i1$1.ServiceItemTagsService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i4.Router), i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i2.CdrFactoryService), i0.ɵɵdirectiveInject(AobPermissionsService), i0.ɵɵdirectiveInject(i1.EuiLoadingService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementEditComponent, selectors: [["imx-entitlement-edit"]], inputs: { entitlement: "entitlement", serviceItem: "serviceItem" }, outputs: { controlCreated: "controlCreated", saved: "saved" }, features: [i0.ɵɵNgOnChangesFeature], decls: 10, vars: 8, consts: [["eui-sidesheet-content", ""], [1, "imx-card-sidesheet"], ["id", "entitlementForm", 1, "imx-form", 3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "data-imx-identifier", "entitlement-edit-details-button", "type", "button", "color", "primary", 3, "click", 4, "ngIf"], ["mat-flat-button", "", "data-imx-identifier", "entitlement-edit-button-save", "type", "button", "color", "primary", 3, "click", "disabled"], [3, "controlCreated", "cdr"], [3, "selection", "loading", "controlCreated", 4, "ngIf"], [3, "controlCreated", "selection", "loading"], ["mat-flat-button", "", "data-imx-identifier", "entitlement-edit-details-button", "type", "button", "color", "primary", 3, "click"]], template: function EntitlementEditComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card", 1)(2, "form", 2);
            i0.ɵɵtemplate(3, EntitlementEditComponent_imx_cdr_editor_3_Template, 1, 1, "imx-cdr-editor", 3)(4, EntitlementEditComponent_ng_container_4_Template, 3, 2, "ng-container", 4);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(5, "div", 5);
            i0.ɵɵtemplate(6, EntitlementEditComponent_button_6_Template, 3, 3, "button", 6);
            i0.ɵɵelementStart(7, "button", 7);
            i0.ɵɵlistener("click", function EntitlementEditComponent_Template_button_click_7_listener() { return ctx.save(); });
            i0.ɵɵtext(8);
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.form);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.serviceItem);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.isEditableEntitlement);
            i0.ɵɵadvance();
            i0.ɵɵproperty("disabled", !ctx.form.dirty);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 6, "#LDS#Save"), " ");
        } }, dependencies: [i2.CdrEditorComponent, i6.NgForOf, i6.NgIf, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i12.ɵNgNoValidate, i12.NgControlStatusGroup, i7.MatButton, i6$1.MatCard, i12.FormGroupDirective, i1$1.ServiceItemTagsComponent, i3.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:100%}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementEditComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlement-edit', template: "<div eui-sidesheet-content>\n  <mat-card class=\"imx-card-sidesheet\">\n    <form class=\"imx-form\" id=\"entitlementForm\" [formGroup]=\"form\">\n      <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"form.addControl(cdr?.column?.ColumnName || '', $event)\">\n      </imx-cdr-editor>\n      <ng-container *ngIf=\"serviceItem\">\n        <imx-service-item-tags\n          *ngIf=\"productTagsSelected\"\n          [selection]=\"productTagsSelected\"\n          [loading]=\"loadingTags\"\n          (controlCreated)=\"form.addControl('tags', $event)\"\n        >\n        </imx-service-item-tags>\n        <imx-cdr-editor\n          *ngFor=\"let cdr of cdrListServiceItem\"\n          [cdr]=\"cdr\"\n          (controlCreated)=\"form.addControl(cdr?.column?.ColumnName || '', $event)\"\n        >\n        </imx-cdr-editor>\n      </ng-container>\n    </form>\n  </mat-card>\n</div>\n<div eui-sidesheet-actions>\n  <button\n    mat-flat-button\n    data-imx-identifier=\"entitlement-edit-details-button\"\n    *ngIf=\"isEditableEntitlement\"\n    type=\"button\"\n    (click)=\"manageEntitlement()\"\n    color=\"primary\"\n  >\n    {{ '#LDS#Manage system role' | translate }}\n  </button>\n  <button\n    mat-flat-button\n    data-imx-identifier=\"entitlement-edit-button-save\"\n    [disabled]=\"!form.dirty\"\n    type=\"button\"\n    (click)=\"save()\"\n    color=\"primary\"\n  >\n    {{ '#LDS#Save' | translate }}\n  </button>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:100%}\n"] }]
    }], () => [{ type: i1$1.ServiceItemTagsService }, { type: i2.ClassloggerService }, { type: i4.Router }, { type: i0.ErrorHandler }, { type: i2.CdrFactoryService }, { type: AobPermissionsService }, { type: i1.EuiLoadingService }], { entitlement: [{
            type: Input
        }], serviceItem: [{
            type: Input
        }], controlCreated: [{
            type: Output
        }], saved: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EntitlementEditComponent, { className: "EntitlementEditComponent", filePath: "lib\\entitlements\\entitlement-edit\\entitlement-edit.component.ts", lineNumber: 46 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementDetailComponent {
    data;
    sidesheetRef;
    snackbar;
    form = new UntypedFormGroup({});
    subscriptions = [];
    constructor(data, sidesheetRef, snackbar, confirmation) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.snackbar = snackbar;
        this.subscriptions.push(this.sidesheetRef.closeClicked().subscribe(async () => {
            const entitlementHasChanges = this.entityHasChanges(this.data.entitlement);
            const serviceItemHasChanges = this.entityHasChanges(this.data?.serviceItem);
            const hasChanges = entitlementHasChanges || serviceItemHasChanges || !this.form.pristine;
            if (hasChanges && !(await confirmation.confirmLeaveWithUnsavedChanges())) {
                return;
            }
            if (entitlementHasChanges) {
                await this.data.entitlement?.GetEntity().DiscardChanges();
            }
            if (serviceItemHasChanges) {
                await this.data?.serviceItem?.GetEntity().DiscardChanges();
            }
            if (hasChanges) {
                this.snackbar.open({ key: '#LDS#The changes were discarded.' });
            }
            this.sidesheetRef.close(false);
        }));
    }
    ngOnDestroy() {
        this.subscriptions.forEach((s) => s.unsubscribe());
    }
    afterSave(success) {
        if (success) {
            this.snackbar.open({ key: '#LDS#The application entitlement has been successfully saved.' });
        }
        this.sidesheetRef.close(true);
    }
    entityHasChanges(entity) {
        return entity != null && !!entity?.GetEntity().GetDiffData()?.Data?.length;
    }
    static ɵfac = function EntitlementDetailComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementDetailComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementDetailComponent, selectors: [["imx-entitlement-detail"]], decls: 1, vars: 2, consts: [[3, "controlCreated", "saved", "entitlement", "serviceItem"]], template: function EntitlementDetailComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "imx-entitlement-edit", 0);
            i0.ɵɵlistener("controlCreated", function EntitlementDetailComponent_Template_imx_entitlement_edit_controlCreated_0_listener($event) { return ctx.form.addControl("entitlementedit", $event); })("saved", function EntitlementDetailComponent_Template_imx_entitlement_edit_saved_0_listener($event) { return ctx.afterSave($event); });
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("entitlement", ctx.data == null ? null : ctx.data.entitlement)("serviceItem", ctx.data == null ? null : ctx.data.serviceItem);
        } }, dependencies: [EntitlementEditComponent] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementDetailComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlement-detail', template: "<imx-entitlement-edit\n  [entitlement]=\"data?.entitlement\"\n  [serviceItem]=\"data?.serviceItem\"\n  (controlCreated)=\"form.addControl('entitlementedit', $event)\"\n  (saved)=\"afterSave($event)\"\n>\n</imx-entitlement-edit>\n" }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1.EuiSidesheetRef }, { type: i2.SnackBarService }, { type: i2.ConfirmationService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EntitlementDetailComponent, { className: "EntitlementDetailComponent", filePath: "lib\\entitlements\\entitlement-detail\\entitlement-detail.component.ts", lineNumber: 41 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementEditAutoAddService {
    api;
    constructor(api) {
        this.api = api;
    }
    async getFilterProperties(table) {
        return (await this.api.client.portal_application_sqlwizard_tables_columns_get(table)).Properties || [];
    }
    async getCandidates(parentTable, options) {
        return this.api.client.portal_application_sqlwizard_candidates_get(parentTable, options);
    }
    async showEntitlementsToMap(state) {
        return this.api.client.portal_application_interactive_entitlementstoadd_get(state?.EntityId || '', {
            keys: state.Keys,
            state: state.State,
        });
    }
    async mapEntitlementsToApplication(uidApplication) {
        return this.api.client.portal_application_map_post(uidApplication);
    }
    static ɵfac = function EntitlementEditAutoAddService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementEditAutoAddService)(i0.ɵɵinject(AobApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EntitlementEditAutoAddService, factory: EntitlementEditAutoAddService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementEditAutoAddService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: AobApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementToAddTyped extends TypedEntity {
    IsAssignedToMe = this.GetEntityValue('IsAssignedToMe');
    IsAssignedToOther = this.GetEntityValue('IsAssignedToOther');
    DisplayName = this.GetEntityValue('DisplayName');
    CanonicalName = this.GetEntityValue('CanonicalName');
    UID_AOBApplicationConflicted = this.GetEntityValue('UID_AOBApplicationConflicted');
    static GetEntitySchema() {
        const ret = {};
        ret.IsAssignedToMe = {
            Type: ValType.Bool,
            ColumnName: 'IsAssignedToMe',
        };
        ret.IsAssignedToOther = {
            Type: ValType.Bool,
            ColumnName: 'IsAssignedToOther',
        };
        ret.DisplayName = {
            Type: ValType.String,
            ColumnName: 'DisplayName',
        };
        ret.CanonicalName = {
            Type: ValType.String,
            ColumnName: 'CanonicalName',
        };
        ret.UID_AOBApplicationConflicted = {
            Type: ValType.String,
            ColumnName: 'UID_AOBApplicationConflicted',
        };
        return {
            TypeName: 'EntitlementToAddTyped',
            DisplayPattern: new DisplayPattern('%DisplayName%'),
            Columns: ret,
        };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementToAddDataWrapperService {
    entitySchema = EntitlementToAddTyped.GetEntitySchema();
    builder = new TypedEntityBuilder(EntitlementToAddTyped);
    buildTypedEntities(data) {
        const entities = data.Data?.map((element, index) => this.buildEntityData(element, `${index}`));
        return this.builder.buildReadWriteEntities({
            TotalCount: entities?.length || 0,
            Entities: entities?.sort((a, b) => this.compareElement(a, b)),
        }, this.entitySchema);
    }
    buildEntityData(data, key) {
        const ret = {};
        ret.IsAssignedToMe = { Value: data.IsAssignedToMe, IsReadOnly: true };
        ret.IsAssignedToOther = { Value: data.IsAssignedToOther, IsReadOnly: true };
        ret.DisplayName = { Value: data.DisplayName, IsReadOnly: true };
        ret.CanonicalName = { Value: data.CanonicalName, IsReadOnly: true };
        ret.UID_AOBApplicationConflicted = {
            Value: data.UID_AOBApplicationConflicted,
            IsReadOnly: true,
            DisplayValue: data.DisplayApplicationConflicted,
        };
        return { Columns: ret, Keys: [key] };
    }
    compareElement(a, b) {
        const val1 = `${a.Columns?.IsAssignedToMe.Value ? 1 : a.Columns?.IsAssignedToOther.Value ? 0 : 2} ${a.Columns?.DisplayName.Value}`;
        const val2 = `${b.Columns?.IsAssignedToMe.Value ? 1 : b.Columns?.IsAssignedToOther.Value ? 0 : 2} ${b.Columns?.DisplayName.Value}`;
        return val1.localeCompare(val2);
    }
    static ɵfac = function EntitlementToAddDataWrapperService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementToAddDataWrapperService)(); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EntitlementToAddDataWrapperService, factory: EntitlementToAddDataWrapperService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementToAddDataWrapperService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], null, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MappedEntitlementsPreviewComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 12)(1, "div")(2, "span", 13);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(4, "div")(5, "span", 13);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r0.alertText);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r0.speedupText);
} }
function MappedEntitlementsPreviewComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 14)(1, "div")(2, "span", 15);
    i0.ɵɵtext(3, "#LDS#Matching application entitlements");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "span");
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "span", 15);
    i0.ɵɵtext(7, "#LDS#Application entitlements to add");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "span");
    i0.ɵɵtext(9);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(10, "span", 15);
    i0.ɵɵtext(11, "#LDS#Application entitlements already assigned to this application");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "span");
    i0.ɵɵtext(13);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "span", 15);
    i0.ɵɵtext(15, "#LDS#Application entitlements assigned to another application");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(16, "span");
    i0.ɵɵtext(17);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(ctx_r0.getCount(""));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(ctx_r0.getCount("add"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(ctx_r0.getCount("assigned"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(ctx_r0.getCount("conflicted"));
} }
function MappedEntitlementsPreviewComponent_th_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 16);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Application entitlement"));
} }
function MappedEntitlementsPreviewComponent_td_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 17)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 18);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r2.DisplayName.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r2.CanonicalName.Column.GetDisplayValue());
} }
function MappedEntitlementsPreviewComponent_th_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "th", 16);
} }
function MappedEntitlementsPreviewComponent_td_11_eui_badge_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 21);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("color", item_r3.IsAssignedToMe.value ? "green" : "orange");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, item_r3.IsAssignedToMe.value ? "#LDS#Already assigned to this application" : "#LDS#Assigned to other application"), " ");
} }
function MappedEntitlementsPreviewComponent_td_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 19);
    i0.ɵɵtemplate(1, MappedEntitlementsPreviewComponent_td_11_eui_badge_1_Template, 3, 4, "eui-badge", 20);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r3.IsAssignedToMe.value || item_r3.IsAssignedToOther.value);
} }
function MappedEntitlementsPreviewComponent_th_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 16);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Already assigned to following application"));
} }
function MappedEntitlementsPreviewComponent_td_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 19)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4.UID_AOBApplicationConflicted == null ? null : item_r4.UID_AOBApplicationConflicted.Column.GetDisplayValue());
} }
function MappedEntitlementsPreviewComponent_div_15_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 22)(1, "mat-slide-toggle", 23, 0);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "button", 24);
    i0.ɵɵlistener("click", function MappedEntitlementsPreviewComponent_div_15_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r5); const mappedslider_r6 = i0.ɵɵreference(2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.apply(mappedslider_r6.checked)); });
    i0.ɵɵtext(6);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "#LDS#Assign application entitlements after saving"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 4, "#LDS#Save automatic assignment"), " ");
} }
class MappedEntitlementsPreviewComponent {
    data;
    sidesheetRef;
    dataSource;
    DisplayColumns = DisplayColumns;
    entitySchema;
    alertText = '#LDS#Here you can get an overview of application entitlements that will be added to this application by the conditions. Application entitlements that are already assigned to an application will be skipped.';
    speedupText = '#LDS#In addition, you can specify whether the application entitlements should be assigned immediately after the conditions are saved. However, you can also have the application entitlements added later.';
    constructor(data, sidesheetRef, dataSource) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.dataSource = dataSource;
    }
    apply(map) {
        this.sidesheetRef.close({ save: true, map });
    }
    getCount(type) {
        switch (type) {
            case 'conflicted':
                return this.data.entitlementToAdd.Data.filter((elem) => elem.IsAssignedToOther.value).length;
            case 'add':
                return this.data.entitlementToAdd.Data.filter((elem) => !elem.IsAssignedToMe.value && !elem.IsAssignedToOther.value).length;
            case 'assigned':
                return this.data.entitlementToAdd.Data.filter((elem) => elem.IsAssignedToMe.value).length;
        }
        return this.data.entitlementToAdd.totalCount;
    }
    async ngOnInit() {
        this.entitySchema = EntitlementToAddTyped.GetEntitySchema();
        const displayedColumns = [
            this.entitySchema.Columns.DisplayName,
            this.entitySchema.Columns.IsAssignedToMe,
            this.entitySchema.Columns.UID_AOBApplicationConflicted,
        ];
        this.dataSource.init({
            execute: () => Promise.resolve(this.data.entitlementToAdd),
            schema: this.entitySchema,
            columnsToDisplay: displayedColumns,
            localSource: true,
        });
    }
    static ɵfac = function MappedEntitlementsPreviewComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MappedEntitlementsPreviewComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MappedEntitlementsPreviewComponent, selectors: [["ng-component"]], features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 16, vars: 7, consts: [["mappedslider", ""], ["eui-sidesheet-content", ""], ["class", "imx-info-text", "type", "info", 3, "condensed", "colored", "dismissable", 4, "ngIf"], [1, "imx-card-fill"], ["class", "imx-info-grid", 4, "ngIf"], [1, "imx-table-container"], ["mode", "manual", 3, "dataSource"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["type", "info", 1, "imx-info-text", 3, "condensed", "colored", "dismissable"], ["translate", ""], [1, "imx-info-grid"], ["bold", "", "translate", ""], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], ["subtitle", ""], ["mat-cell", "", "role", "gridcell"], [3, "color", 4, "ngIf"], [3, "color"], ["eui-sidesheet-actions", ""], ["checked", "true", "data-imx-identifier", "mapped-entitlements-preview-slider-with-mapping", 1, "justify-start"], ["mat-flat-button", "", "data-imx-identifier", "mapped-entitlements-preview-button-save", "color", "primary", 3, "click"]], template: function MappedEntitlementsPreviewComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵtemplate(1, MappedEntitlementsPreviewComponent_eui_alert_1_Template, 7, 5, "eui-alert", 2);
            i0.ɵɵelementStart(2, "mat-card", 3);
            i0.ɵɵtemplate(3, MappedEntitlementsPreviewComponent_div_3_Template, 18, 4, "div", 4);
            i0.ɵɵelementStart(4, "div", 5)(5, "imx-data-view-auto-table", 6);
            i0.ɵɵelementContainerStart(6, 7);
            i0.ɵɵtemplate(7, MappedEntitlementsPreviewComponent_th_7_Template, 3, 3, "th", 8)(8, MappedEntitlementsPreviewComponent_td_8_Template, 5, 2, "td", 9);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(9, 7);
            i0.ɵɵtemplate(10, MappedEntitlementsPreviewComponent_th_10_Template, 1, 0, "th", 8)(11, MappedEntitlementsPreviewComponent_td_11_Template, 2, 1, "td", 10);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(12, 7);
            i0.ɵɵtemplate(13, MappedEntitlementsPreviewComponent_th_13_Template, 3, 3, "th", 8)(14, MappedEntitlementsPreviewComponent_td_14_Template, 3, 1, "td", 10);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd()()()();
            i0.ɵɵtemplate(15, MappedEntitlementsPreviewComponent_div_15_Template, 8, 6, "div", 11);
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.withSave);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.data.entitlementToAdd.totalCount > 0);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.DisplayName.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.IsAssignedToMe.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_AOBApplicationConflicted.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.data.withSave);
        } }, dependencies: [i6.NgIf, i1.EuiAlertComponent, i1.EuiBadgeComponent, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i7.MatButton, i6$1.MatCard, i6$3.MatSlideToggle, i15.MatHeaderCellDef, i15.MatColumnDef, i15.MatCellDef, i15.MatHeaderCell, i15.MatCell, i3.TranslateDirective, i2.DataViewAutoTableComponent, i3.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit}.imx-info-text[_ngcontent-%COMP%]{margin-bottom:15px}span[bold][_ngcontent-%COMP%]{font-weight:600}.imx-info-grid[_ngcontent-%COMP%]{display:flex;flex-direction:row}.imx-info-grid[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:first-child{display:grid;column-gap:15px;grid-template-columns:auto auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MappedEntitlementsPreviewComponent, [{
        type: Component,
        args: [{ providers: [DataViewSource], template: "<div eui-sidesheet-content>\n  <eui-alert class=\"imx-info-text\" *ngIf=\"data.withSave\" type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"true\">\n    <div>\n      <span translate>{{ alertText }}</span>\n    </div>\n    <div>\n      <span translate>{{ speedupText }}</span>\n    </div>\n  </eui-alert>\n  <mat-card class=\"imx-card-fill\">\n    <div *ngIf=\"data.entitlementToAdd.totalCount > 0\" class=\"imx-info-grid\">\n      <div>\n        <span bold translate>#LDS#Matching application entitlements</span>\n        <span>{{ getCount('') }}</span>\n        <span bold translate>#LDS#Application entitlements to add</span>\n        <span>{{ getCount('add') }}</span>\n        <span bold translate>#LDS#Application entitlements already assigned to this application</span>\n        <span>{{ getCount('assigned') }}</span>\n        <span bold translate>#LDS#Application entitlements assigned to another application</span>\n        <span>{{ getCount('conflicted') }}</span>\n      </div>\n    </div>\n\n    <div class=\"imx-table-container\">\n      <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\">\n        <ng-container [matColumnDef]=\"entitySchema.Columns.DisplayName.ColumnName\">\n          <th mat-header-cell *matHeaderCellDef>{{ '#LDS#Application entitlement' | translate }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n            <div>{{ item.DisplayName.Column.GetDisplayValue() }}</div>\n            <div subtitle>{{ item.CanonicalName.Column.GetDisplayValue() }}</div>\n          </td>\n        </ng-container>\n        <ng-container [matColumnDef]=\"entitySchema.Columns.IsAssignedToMe.ColumnName\">\n          <th mat-header-cell *matHeaderCellDef></th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <eui-badge\n              *ngIf=\"item.IsAssignedToMe.value || item.IsAssignedToOther.value\"\n              [color]=\"item.IsAssignedToMe.value ? 'green' : 'orange'\"\n            >\n              {{\n                (item.IsAssignedToMe.value ? '#LDS#Already assigned to this application' : '#LDS#Assigned to other application') | translate\n              }}\n            </eui-badge>\n          </td>\n        </ng-container>\n        <ng-container [matColumnDef]=\"entitySchema.Columns.UID_AOBApplicationConflicted.ColumnName\">\n          <th mat-header-cell *matHeaderCellDef>{{ '#LDS#Already assigned to following application' | translate }}</th>\n          <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n            <div>{{ item.UID_AOBApplicationConflicted?.Column.GetDisplayValue() }}</div>\n          </td>\n        </ng-container>\n      </imx-data-view-auto-table>\n    </div>\n  </mat-card>\n</div>\n<div eui-sidesheet-actions *ngIf=\"data.withSave\">\n  <mat-slide-toggle\n    class=\"justify-start\"\n    #mappedslider\n    checked=\"true\"\n    data-imx-identifier=\"mapped-entitlements-preview-slider-with-mapping\"\n  >\n    {{ '#LDS#Assign application entitlements after saving' | translate }}\n  </mat-slide-toggle>\n  <button\n    mat-flat-button\n    data-imx-identifier=\"mapped-entitlements-preview-button-save\"\n    color=\"primary\"\n    (click)=\"apply(mappedslider.checked)\"\n  >\n    {{ '#LDS#Save automatic assignment' | translate }}\n  </button>\n</div>\n", styles: [".eui-sidesheet-content{display:flex;flex-direction:column;overflow:hidden;height:inherit}.imx-info-text{margin-bottom:15px}span[bold]{font-weight:600}.imx-info-grid{display:flex;flex-direction:row}.imx-info-grid :first-child{display:grid;column-gap:15px;grid-template-columns:auto auto}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1.EuiSidesheetRef }, { type: i2.DataViewSource }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MappedEntitlementsPreviewComponent, { className: "MappedEntitlementsPreviewComponent", filePath: "lib\\entitlements\\entitlement-edit-auto-add\\mapped-entitlements-preview\\mapped-entitlements-preview.component.ts", lineNumber: 39 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EntitlementEditAutoAddComponent_imx_sqlwizard_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-sqlwizard", 5);
    i0.ɵɵlistener("change", function EntitlementEditAutoAddComponent_imx_sqlwizard_2_Template_imx_sqlwizard_change_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.checkChanges()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("tableName", "UNSGroup")("apiService", ctx_r1.svc)("expression", ctx_r1.sqlExpression == null ? null : ctx_r1.sqlExpression.Expression);
} }
class EntitlementEditAutoAddComponent {
    data;
    svc;
    sidesheetRef;
    entitlementToAddWrapperService;
    busyService;
    snackbar;
    sidesheet;
    translateService;
    subscriptions = [];
    reload = false;
    exprHasntChanged = true;
    sqlExpression;
    checkChanges() {
        this.exprHasntChanged = _.isEqual(this.data.sqlExpression, this.sqlExpression);
    }
    get controlsInvalid() {
        return this.exprHasntChanged || (!this.sqlExpression.IsUnsupported && this.isConditionInvalid());
    }
    constructor(data, svc, sidesheetRef, entitlementToAddWrapperService, busyService, snackbar, sidesheet, translateService, confirm) {
        this.data = data;
        this.svc = svc;
        this.sidesheetRef = sidesheetRef;
        this.entitlementToAddWrapperService = entitlementToAddWrapperService;
        this.busyService = busyService;
        this.snackbar = snackbar;
        this.sidesheet = sidesheet;
        this.translateService = translateService;
        this.subscriptions.push(sidesheetRef.closeClicked().subscribe(async () => {
            if (this.exprHasntChanged || (await confirm.confirmLeaveWithUnsavedChanges()))
                sidesheetRef.close(this.reload);
        }));
        this.sqlExpression = _.cloneDeep(data.sqlExpression);
    }
    ngOnDestroy() {
        this.subscriptions.forEach((elem) => elem.unsubscribe());
    }
    async showResults(withSave) {
        this.showBusyIndicator();
        let elements;
        try {
            await this.setExtendedData(this.sqlExpression.Expression);
            elements = await this.svc.showEntitlementsToMap(this.data.application.InteractiveEntityStateData);
        }
        finally {
            this.busyService.hide();
        }
        if (!elements) {
            return;
        }
        const entitlementToAdd = this.entitlementToAddWrapperService.buildTypedEntities(elements);
        const saveChanges = await this.sidesheet
            .open(MappedEntitlementsPreviewComponent, {
            title: await this.translateService.get('#LDS#Heading View Matching Application Entitlements').toPromise(),
            subTitle: this.data.application.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(1000),
            testId: 'mapped-entitlements-preview-sidesheet',
            data: {
                entitlementToAdd,
                withSave,
            },
        })
            .afterClosed()
            .toPromise();
        this.reload = true;
        if (withSave && saveChanges?.save) {
            this.showBusyIndicator();
            try {
                await this.data.application.GetEntity().Commit(false);
                if (saveChanges.map) {
                    this.svc.mapEntitlementsToApplication(this.data.application.UID_AOBApplication.value);
                }
            }
            finally {
                this.busyService.hide();
            }
            this.sidesheetRef.close(true);
            this.snackbar.open({
                key: saveChanges.map
                    ? '#LDS#The conditions for automatically added application entitlements have been changed. The application entitlements are added now. This may take some time.'
                    : '#LDS#The conditions for automatically added application entitlements have been changed.',
            });
        }
        else {
            // reset the extended data if you do not save the data
            this.showBusyIndicator();
            try {
                await this.setExtendedData(this.data.sqlExpression.Expression);
            }
            finally {
                this.busyService.hide();
            }
        }
    }
    isConditionInvalid() {
        // check if the sqlWizard has a valid expression
        return (this.exprHasntChanged ||
            this.sqlExpression?.Expression?.Expressions?.length === 0 ||
            isExpressionInvalid(this.sqlExpression) ||
            !this.hasValuesSet(this.sqlExpression?.Expression));
    }
    hasValuesSet(sqlExpression, checkCurrent = false) {
        const current = !checkCurrent || sqlExpression?.Value != null;
        if (!!sqlExpression?.Expressions?.length) {
            return current && !!sqlExpression?.Expressions?.every((elem) => this.hasValuesSet(elem, true));
        }
        return current;
    }
    async setExtendedData(sqlExpression) {
        const SqlExpression = { Filters: [] };
        if (sqlExpression) {
            SqlExpression.Filters?.push(sqlExpression);
        }
        return this.data.application.setExtendedData({
            ...this.data.application.extendedData,
            ...{
                SqlExpression,
            },
        });
    }
    showBusyIndicator() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
    }
    static ɵfac = function EntitlementEditAutoAddComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementEditAutoAddComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(EntitlementEditAutoAddService), i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(EntitlementToAddDataWrapperService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementEditAutoAddComponent, selectors: [["ng-component"]], decls: 10, vars: 9, consts: [["eui-sidesheet-content", "", 1, "imx-sidesheet-content__overflow"], [3, "tableName", "apiService", "expression", "change", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "entitlement-edit-auto-add-button-test-condition", 1, "justify-start", 3, "click", "disabled"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "entitlement-edit-auto-add-button-save-condition", 3, "click", "disabled"], [3, "change", "tableName", "apiService", "expression"]], template: function EntitlementEditAutoAddComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card");
            i0.ɵɵtemplate(2, EntitlementEditAutoAddComponent_imx_sqlwizard_2_Template, 1, 3, "imx-sqlwizard", 1);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(3, "div", 2)(4, "button", 3);
            i0.ɵɵlistener("click", function EntitlementEditAutoAddComponent_Template_button_click_4_listener() { return ctx.showResults(false); });
            i0.ɵɵtext(5);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "button", 4);
            i0.ɵɵlistener("click", function EntitlementEditAutoAddComponent_Template_button_click_7_listener() { return ctx.showResults(true); });
            i0.ɵɵtext(8);
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !(ctx.sqlExpression == null ? null : ctx.sqlExpression.IsUnsupported));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.controlsInvalid);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 5, "#LDS#Test automatic assignment"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.controlsInvalid);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 7, "#LDS#Save automatic assignment"), " ");
        } }, dependencies: [i6.NgIf, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i7.MatButton, i6$1.MatCard, i2.SqlWizardComponent, i3.TranslatePipe], encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementEditAutoAddComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content class=\"imx-sidesheet-content__overflow\">\n  <mat-card>\n    <imx-sqlwizard\n      *ngIf=\"!sqlExpression?.IsUnsupported\"\n      [tableName]=\"'UNSGroup'\"\n      (change)=\"checkChanges()\"\n      [apiService]=\"svc\"\n      [expression]=\"sqlExpression?.Expression\"\n    >\n    </imx-sqlwizard>\n  </mat-card>\n</div>\n<div eui-sidesheet-actions>\n  <button\n    [disabled]=\"controlsInvalid\"\n    class=\"justify-start\"\n    mat-stroked-button\n    data-imx-identifier=\"entitlement-edit-auto-add-button-test-condition\"\n    (click)=\"showResults(false)\"\n  >\n    {{ '#LDS#Test automatic assignment' | translate }}\n  </button>\n  <button\n    [disabled]=\"controlsInvalid\"\n    mat-flat-button\n    color=\"primary\"\n    (click)=\"showResults(true)\"\n    data-imx-identifier=\"entitlement-edit-auto-add-button-save-condition\"\n  >\n    {{ '#LDS#Save automatic assignment' | translate }}\n  </button>\n</div>\n" }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: EntitlementEditAutoAddService }, { type: i1.EuiSidesheetRef }, { type: EntitlementToAddDataWrapperService }, { type: i1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i1.EuiSidesheetService }, { type: i3.TranslateService }, { type: i2.ConfirmationService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EntitlementEditAutoAddComponent, { className: "EntitlementEditAutoAddComponent", filePath: "lib\\entitlements\\entitlement-edit-auto-add\\entitlement-edit-auto-add.component.ts", lineNumber: 43 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$7 = a0 => ({ "imx-hidden": a0 });
function EntitlementsComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 14)(1, "button", 15);
    i0.ɵɵlistener("click", function EntitlementsComponent_div_2_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.publish()); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 16);
    i0.ɵɵlistener("click", function EntitlementsComponent_div_2_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.unpublish()); });
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "button", 17)(8, "span");
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(11, "eui-icon", 18);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "mat-menu", 19, 1)(14, "button", 20);
    i0.ɵɵlistener("click", function EntitlementsComponent_div_2_Template_button_click_14_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addNewElement()); });
    i0.ɵɵtext(15);
    i0.ɵɵpipe(16, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(17, "mat-divider");
    i0.ɵɵelementStart(18, "button", 21);
    i0.ɵɵlistener("click", function EntitlementsComponent_div_2_Template_button_click_18_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.editConditionForDynamicAssignments()); });
    i0.ɵɵtext(19);
    i0.ɵɵpipe(20, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(21, "button", 22);
    i0.ɵɵlistener("click", function EntitlementsComponent_div_2_Template_button_click_21_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.applyMappingForDynamicAssignments()); });
    i0.ɵɵtext(22);
    i0.ɵɵpipe(23, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(24, "button", 23);
    i0.ɵɵlistener("click", function EntitlementsComponent_div_2_Template_button_click_24_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.unassign()); });
    i0.ɵɵtext(25);
    i0.ɵɵpipe(26, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const actionsMenu_r3 = i0.ɵɵreference(13);
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", ctx_r1.publishDisabled);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 13, "#LDS#Publish"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r1.unpublishDisabled);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 15, "#LDS#Unpublish"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("matMenuTriggerFor", actionsMenu_r3);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 17, "#LDS#Assign more"));
    i0.ɵɵadvance(6);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(16, 19, "#LDS#Assign manually"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("disabled", !ctx_r1.application.extendedDataRead);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(20, 21, ctx_r1.hasConditionForDynamicAssignment ? "#LDS#Edit automatic assignment" : "#LDS#Assign automatically"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r1.hasConditionForDynamicAssignment);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(23, 23, "#LDS#Check for new automatic assignments"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r1.unassignedDisabled);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(26, 25, "#LDS#Unassign"), " ");
} }
function EntitlementsComponent_th_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 24);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns == null ? null : ctx_r1.entitySchema.Columns.Ident_AOBEntitlement == null ? null : ctx_r1.entitySchema.Columns.Ident_AOBEntitlement.Display);
} }
function EntitlementsComponent_td_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 25)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 26);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4.Ident_AOBEntitlement.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4.Description.Column.GetDisplayValue());
} }
function EntitlementsComponent_th_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 24);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Type"));
} }
function EntitlementsComponent_td_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 27)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r1.getType(item_r5), " ");
} }
function EntitlementsComponent_th_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "th", 24);
} }
function EntitlementsComponent_td_13_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 31)(1, "eui-badge");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 1, "#LDS#Automatic"));
} }
function EntitlementsComponent_td_13_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵelement(1, "imx-info-badge", 32);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵnextContext(2);
    const infoContent_r6 = i0.ɵɵreference(28);
    i0.ɵɵadvance();
    i0.ɵɵproperty("badgeText", i0.ɵɵpipeBind1(2, 3, "#LDS#Wrong service category"))("templateRef", infoContent_r6)("title", i0.ɵɵpipeBind1(3, 5, "#LDS#Heading Wrong Service Category"));
} }
function EntitlementsComponent_td_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 27)(1, "div", 28);
    i0.ɵɵtemplate(2, EntitlementsComponent_td_13_div_2_Template, 4, 3, "div", 29)(3, EntitlementsComponent_td_13_div_3_Template, 4, 7, "div", 30);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r7 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", item_r7.IsDynamic.value);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r7.IsOutlierAssignment.value);
} }
function EntitlementsComponent_th_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 24);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns == null ? null : ctx_r1.entitySchema.Columns.UID_AERoleOwner == null ? null : ctx_r1.entitySchema.Columns.UID_AERoleOwner.Display);
} }
function EntitlementsComponent_td_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 27)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r8 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r8.UID_AERoleOwner.Column.GetDisplayValue());
} }
function EntitlementsComponent_th_18_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 24);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Assigned"));
} }
function EntitlementsComponent_td_19_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 27)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r9 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r9.XDateInserted.Column.GetDisplayValue());
} }
function EntitlementsComponent_th_21_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 24);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Status"));
} }
function EntitlementsComponent_td_22_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Not published"));
} }
function EntitlementsComponent_td_22_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div");
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r10 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Will be published"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(item_r10.ActivationDate.Column.GetDisplayValue());
} }
function EntitlementsComponent_td_22_div_3_div_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 26);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#(not yet requestable)"));
} }
function EntitlementsComponent_td_22_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, EntitlementsComponent_td_22_div_3_div_4_Template, 3, 3, "div", 33);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Published"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.application.IsInActive.value);
} }
function EntitlementsComponent_td_22_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 25);
    i0.ɵɵtemplate(1, EntitlementsComponent_td_22_div_1_Template, 3, 3, "div", 30)(2, EntitlementsComponent_td_22_div_2_Template, 6, 4, "div", 30)(3, EntitlementsComponent_td_22_div_3_Template, 5, 4, "div", 30);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r10 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.filter.notPublished(item_r10));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.filter.willPublish(item_r10));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.filter.published(item_r10));
} }
function EntitlementsComponent_div_26_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 34)(1, "div", 35);
    i0.ɵɵelement(2, "eui-icon", 36);
    i0.ɵɵelementStart(3, "div", 37)(4, "h2");
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "span");
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(10, "div", 38)(11, "button", 39);
    i0.ɵɵlistener("click", function EntitlementsComponent_div_26_Template_button_click_11_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addNewElement()); });
    i0.ɵɵtext(12);
    i0.ɵɵpipe(13, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "button", 40);
    i0.ɵɵlistener("click", function EntitlementsComponent_div_26_Template_button_click_14_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.editConditionForDynamicAssignments()); });
    i0.ɵɵtext(15);
    i0.ɵɵpipe(16, "translate");
    i0.ɵɵelementEnd()()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 5, "#LDS#No application entitlements assigned"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 7, "#LDS#Assign application entitlements to this application."), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 9, "#LDS#Assign application entitlements"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r1.application.extendedDataRead);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(16, 11, "#LDS#Create automatic assignment"), " ");
} }
function EntitlementsComponent_ng_template_27_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "p", 41);
} if (rf & 2) {
    i0.ɵɵproperty("translate", "#LDS#This application entitlement is not assigned to the root service category of this application nor to any of its child service categories.");
} }
/**
 * A component for viewing, editing and acting all {@link PortalEntitlement|entitlements} for a given {@link PortalApplication|application}.
 *
 * @see addEntitlements
 * @see addRoles
 * @see publish
 * @see unpublish
 * @see unassign
 */
class EntitlementsComponent {
    logger;
    matDialog;
    entitlementsProvider;
    euiBusyService;
    dialog;
    snackbar;
    shopsProvider;
    serviceItemsProvider;
    platform;
    translateService;
    sidesheet;
    settingsService;
    systemInfo;
    metadata;
    autoAddService;
    dataSource;
    /** The {@link PortalApplication|application} */
    application;
    reloadRequested = new EventEmitter();
    DisplayColumns = DisplayColumns; // Enables use of this static class in Angular Templates.
    EntitlementsType = EntitlementsType; // Enables use of this static class in Angular Templates.
    selections = [];
    publishDisabled = true;
    unpublishDisabled = true;
    unassignedDisabled = true;
    isUsedInDialog = false;
    entitySchema;
    filter = new EntitlementFilter();
    busyService = new BusyService();
    isSystemRoleEnabled;
    isLoading = false;
    hideTable = false;
    /**
     * Checks, if there's a dynamic assignment rule attached to this application
     */
    get hasConditionForDynamicAssignment() {
        return (!!this.application.extendedDataRead?.SqlExpression?.Expressions?.length &&
            !!this.application.extendedDataRead?.SqlExpression?.Expressions?.[0].Expression?.Expressions?.length);
    }
    /**
     * Defines a set of status information methods, that are used to determine the status of each element in the entitlements table
     */
    status = {
        getBadges: (entitlement) => this.entitlementsProvider.getEntitlementBadges(entitlement),
        enabled: (_) => {
            return true;
        },
    };
    updatedTableNames = [];
    constructor(logger, matDialog, entitlementsProvider, euiBusyService, dialog, snackbar, shopsProvider, serviceItemsProvider, platform, translateService, sidesheet, settingsService, systemInfo, metadata, autoAddService, dataSource) {
        this.logger = logger;
        this.matDialog = matDialog;
        this.entitlementsProvider = entitlementsProvider;
        this.euiBusyService = euiBusyService;
        this.dialog = dialog;
        this.snackbar = snackbar;
        this.shopsProvider = shopsProvider;
        this.serviceItemsProvider = serviceItemsProvider;
        this.platform = platform;
        this.translateService = translateService;
        this.sidesheet = sidesheet;
        this.settingsService = settingsService;
        this.systemInfo = systemInfo;
        this.metadata = metadata;
        this.autoAddService = autoAddService;
        this.dataSource = dataSource;
        this.entitySchema = entitlementsProvider.entitlementSchema;
        this.busyService.busyStateChanged.subscribe((elem) => (this.isLoading = elem));
        effect(() => {
            if (!!this.dataSource.collectionData()) {
                this.updateTableNames(this.dataSource.collectionData().Data);
            }
        });
    }
    async ngOnChanges(changes) {
        if (changes.application?.currentValue?.UID_AOBApplication.value === changes.application?.previousValue?.UID_AOBApplication.value) {
            return;
        }
        const isBusy = this.busyService.beginBusy();
        try {
            this.isSystemRoleEnabled = !!(await this.systemInfo.get()).PreProps?.includes('ESET');
            this.getData();
        }
        finally {
            isBusy.endBusy();
        }
    }
    /**
     * checks, if an Entitlement can be edited
     * @param aobEntitlement the entitlement to check
     * @returns true, if the entitlements Ident_AOBEntitlement or Description property can be edited
     */
    canEdit(aobEntitlement) {
        return (aobEntitlement != null &&
            (aobEntitlement.Ident_AOBEntitlement.GetMetadata().CanEdit() || aobEntitlement.Description.GetMetadata().CanEdit()));
    }
    openInfo(event) {
        event.stopPropagation();
    }
    /**
     * Opens a sidesheet to assign new entitlements to the application
     * Afterwards entitlements are added to the application as single entitlements or wrapped into a system role
     */
    async addNewElement() {
        const candidates = await this.sidesheet
            .open(EntitlementsAddComponent, {
            title: await this.translateService.get('#LDS#Heading Assign Application Entitlements').toPromise(),
            subTitle: this.application.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(),
            testId: 'entitlements-sidesheet',
            data: {
                defaultType: this.isSystemRoleEnabled ? EntitlementsType.Eset : EntitlementsType.UnsGroup,
                isSystemRolesEnabled: this.isSystemRoleEnabled,
                uidApplication: this.application.GetEntity().GetKeys()[0],
            },
        })
            .afterClosed()
            .toPromise();
        if (!candidates) {
            this.logger.debug(this, 'candidate dialog canceled');
            return;
        }
        if (candidates.role) {
            await this.buildRoleAndAddItToApplication(candidates.role);
        }
        else {
            await this.addDirectEntitlements(candidates.selection);
        }
    }
    /**
     * Applys the dynamic assignment rule, that is defined for the application
     */
    async applyMappingForDynamicAssignments() {
        this.showBusyIndicator();
        try {
            this.autoAddService.mapEntitlementsToApplication(this.application.UID_AOBApplication.value);
        }
        finally {
            this.euiBusyService.hide();
        }
        this.snackbar.open({ key: '#LDS#The application entitlements are added now. This may take some time.' });
    }
    /**
     * Opens a side sheet to create/edit the dynamic assignement rule that belongs to the application
     */
    async editConditionForDynamicAssignments() {
        const sidesheetTitle = this.hasConditionForDynamicAssignment
            ? '#LDS#Heading Edit Automatic Assignment'
            : '#LDS#Heading Create Automatic Assignment';
        const reload = await this.sidesheet
            .open(EntitlementEditAutoAddComponent, {
            title: await this.translateService.get(sidesheetTitle).toPromise(),
            subTitle: this.application.GetEntity().GetDisplay(),
            padding: '0px',
            disableClose: true,
            width: calculateSidesheetWidth(),
            testId: 'entitlements-edit-auto-add-sidesheet',
            data: {
                sqlExpression: this.application.extendedDataRead.SqlExpression?.Expressions?.[0],
                application: this.application,
            },
        })
            .afterClosed()
            .toPromise();
        if (!reload) {
            return;
        }
        this.showBusyIndicator();
        try {
            this.reloadRequested.emit();
        }
        finally {
            this.euiBusyService.hide();
        }
    }
    /**
     * Call to publish the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to publish
     */
    async publish(aobEntitlement) {
        const shops = await this.shopsProvider.getApplicationInShop(this.application.UID_AOBApplication.value);
        if (shops == null) {
            this.logger.error(this, 'TypedEntityCollectionData<AobApplicationinshop> is undefined');
            return;
        }
        const selectedEntitlements = aobEntitlement != null ? [aobEntitlement] : this.selections;
        const dialogConfig = {
            data: {
                action: LifecycleAction.Publish,
                elements: selectedEntitlements,
                shops: shops.Data,
                type: 'AobEntitlement',
            },
            height: this.platform.TRIDENT ? '550px' : 'auto',
        };
        const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(async (publishData) => {
            if (publishData) {
                const overlay = this.euiBusyService.show();
                try {
                    this.logger.debug(this, `Publishing entitlement(s)/role(s) ${publishData.date && publishData.publishFuture ? `on ${publishData.date}` : 'now'}`);
                    const publishCount = await this.entitlementsProvider.publish(selectedEntitlements, publishData);
                    this.matDialog.closeAll();
                    if (publishCount > 0) {
                        this.logger.debug(this, 'Deselect published entitlement(s)/role(s)');
                        this.clearSelections();
                        let publishMessage = {
                            key: 'Application entitlements published',
                        };
                        if (publishData.publishFuture && publishData.date) {
                            const browserCulture = this.translateService.currentLang;
                            publishMessage = {
                                key: '#LDS#The application entitlement will be published on {0} at {1} (your local time) if the application is published.',
                                parameters: [publishData.date.toLocaleDateString(browserCulture), publishData.date.toLocaleTimeString(browserCulture)],
                            };
                        }
                        this.snackbar.open(publishMessage, '#LDS#Close');
                        await this.dataSource.updateState();
                    }
                    if (publishCount < selectedEntitlements.length) {
                        this.logger.error(this, 'Attempt to publish entitlement(s)/role(s) failed');
                    }
                }
                finally {
                    this.euiBusyService.hide(overlay);
                }
            }
            else {
                this.logger.debug(this, 'dialog Cancel');
            }
        });
    }
    /**
     * Call to unpublish the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to unpublish
     */
    async unpublish(aobEntitlement) {
        const selectedEntitlements = aobEntitlement != null ? [aobEntitlement] : this.selections;
        const dialogConfig = {
            data: { action: LifecycleAction.Unpublish, elements: selectedEntitlements, type: 'AobEntitlement' },
            width: '800px',
            height: '500px',
        };
        const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(async (result) => {
            if (result) {
                const overlay = this.euiBusyService.show();
                try {
                    this.logger.debug(this, 'Unpublish entitlement(s)/role(s)...');
                    const unpublishCount = await this.entitlementsProvider.unpublish(selectedEntitlements);
                    this.matDialog.closeAll();
                    if (unpublishCount > 0) {
                        this.logger.debug(this, 'Deselect unpublished entitlement(s)/role(s)');
                        this.clearSelections();
                        this.snackbar.open({ key: '#LDS#Application entitlements unpublished' }, '#LDS#Close');
                        await this.dataSource.updateState();
                    }
                    if (unpublishCount < selectedEntitlements.length) {
                        this.logger.error(this, 'Attempt to unpublish entitlement(s)/role(s) failed');
                    }
                }
                finally {
                    this.euiBusyService.hide(overlay);
                }
            }
            else {
                this.logger.debug(this, 'dialog Cancel');
            }
        });
    }
    /**
     * Call to unassign the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}
     * from the associated {@link PortalApplication|application}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to unassign
     */
    async unassign(aobEntitlement) {
        const selectedEntitlements = aobEntitlement != null ? [aobEntitlement] : this.selections;
        const dialogConfig = {
            data: { action: LifecycleAction.Unassign, elements: selectedEntitlements, type: 'AobEntitlement' },
            width: '800px',
            height: '500px',
        };
        const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(async (result) => {
            if (result) {
                this.logger.debug(this, 'Remove entitlement(s) from application');
                if (selectedEntitlements.length > 0) {
                    this.showBusyIndicator();
                    try {
                        const unassignResult = await this.entitlementsProvider.unassign(selectedEntitlements);
                        if (unassignResult) {
                            this.clearSelections();
                            await this.dataSource.updateState();
                            this.snackbar.open({ key: '#LDS#Application entitlements unassigned' }, '#LDS#Close');
                        }
                        else {
                            this.logger.error(this, 'Attempt to unassign entitlement(s)/role(s) failed');
                        }
                    }
                    finally {
                        this.euiBusyService.hide();
                    }
                }
                this.matDialog.closeAll();
            }
            else {
                this.logger.debug(this, 'dialog Cancel');
            }
        });
    }
    /**
     * Call to get data from server depending on the {@link CollectionLoadParameters}.
     */
    async getData() {
        this.hideTable = false;
        this.dataSource.state.set({ PageSize: this.settingsService?.DefaultPageSize, StartIndex: 0 });
        this.dataSource.itemStatus = this.status;
        const columnsToDisplay = [
            this.entitySchema.Columns.Ident_AOBEntitlement,
            {
                ColumnName: 'badges',
                Type: ValType.String,
            },
            {
                ColumnName: 'type',
                Type: ValType.String,
            },
            this.entitySchema.Columns.UID_AERoleOwner,
            {
                ColumnName: 'assigned',
                Type: ValType.Date,
            },
            {
                ColumnName: 'status',
                Type: ValType.String,
            },
        ];
        const dataViewInitParameters = {
            execute: (params) => this.entitlementsProvider.getEntitlementsForApplication(this.application, params),
            schema: this.entitySchema,
            columnsToDisplay,
            highlightEntity: (entitlement) => {
                this.editEntitlement(entitlement);
            },
            selectionChange: (selection) => this.onSelectionChanged(selection),
        };
        await this.dataSource.init(dataViewInitParameters);
        if (this.dataSource.collectionData().Data.length === 0) {
            this.hideTable = true;
        }
    }
    /**
     * Opens a side sheet to edit entitlement information
     * @param entitlement the entitlement to edit
     */
    async editEntitlement(entitlement) {
        const entitlementWrapper = await this.createEntitlementWrapper(entitlement);
        if (entitlementWrapper?.entitlement == null) {
            this.logger.error(this, 'AobEntitlement is undefined');
            return;
        }
        this.sidesheet.open(EntitlementDetailComponent, {
            title: await this.translateService.get('#LDS#Heading Edit Application Entitlement').toPromise(),
            subTitle: entitlementWrapper.entitlement.GetEntity().GetDisplay(),
            padding: '0',
            width: calculateSidesheetWidth(),
            disableClose: true,
            data: entitlementWrapper,
            testId: 'application-entitlement-edit-sidesheet',
        });
    }
    /**
     * Triggered action from the {@link DataTableComponent} or {@link TilesComponent} after the selection have changed.
     */
    onSelectionChanged(selection) {
        this.unassignedDisabled = true;
        this.publishDisabled = true;
        this.unpublishDisabled = true;
        this.selections = selection;
        if (this.selections == null || this.selections.length === 0) {
            return;
        }
        this.unassignedDisabled = this.selections.some((elem) => elem.IsDynamic.value === true);
        let foundPublished = false;
        let foundUnpublished = false;
        let foundWillBePublished = false;
        let foundReadonly = false;
        this.selections.forEach((item) => {
            if (this.filter.notPublished(item)) {
                foundUnpublished = true;
            }
            if (this.filter.willPublish(item)) {
                foundWillBePublished = true;
            }
            if (this.filter.published(item)) {
                foundPublished = true;
            }
            if (!this.canEdit(item)) {
                foundReadonly = true;
            }
        });
        if ((foundUnpublished || foundWillBePublished) && !foundPublished) {
            this.publishDisabled = foundReadonly;
        }
        if ((foundPublished || foundWillBePublished) && !foundUnpublished) {
            this.unpublishDisabled = foundReadonly;
        }
    }
    getType(data) {
        if (data?.ObjectKeyElement?.value == null) {
            return '';
        }
        const tableName = DbObjectKey.FromXml(data.ObjectKeyElement.value)?.TableName;
        return tableName != null && this.metadata.tables[tableName] ? this.metadata.tables[tableName]?.DisplaySingular || '' : '';
    }
    async addDirectEntitlements(candidates) {
        this.showBusyIndicator();
        try {
            const assignedCount = await this.entitlementsProvider.assign(this.application, candidates);
            if (assignedCount > 0) {
                await this.dataSource.updateState();
            }
            if (assignedCount < candidates.length) {
                this.logger.error(this, 'Attempt to assign entitlement(s)/role(s) failed');
            }
        }
        finally {
            this.euiBusyService.hide();
        }
    }
    async buildRoleAndAddItToApplication(entitlementSystemRoleInput) {
        this.showBusyIndicator();
        let success = true;
        try {
            await this.entitlementsProvider.addElementsToRole(entitlementSystemRoleInput);
        }
        catch {
            success = false;
        }
        finally {
            this.euiBusyService.hide();
        }
        if (success) {
            this.snackbar.open({ key: '#LDS#The application entitlements have been successfully merged into the system role and added to application.' }, '#LDS#Close');
            await this.dataSource.updateState();
        }
    }
    clearSelections() {
        this.dataSource.selection.clear();
    }
    async updateTableNames(objs) {
        const newTableNamesForUpdate = objs
            .map((obj) => DbObjectKey.FromXml(obj.ObjectKeyElement.value).TableName)
            .filter((obj) => !this.updatedTableNames.includes(obj));
        if (newTableNamesForUpdate.length === 0) {
            this.logger.debug(this, 'there are no new table names in this data');
            return;
        }
        this.updatedTableNames.push(...newTableNamesForUpdate);
        this.logger.trace(this, 'following items are added to the list of table names', newTableNamesForUpdate);
        return this.metadata.updateNonExisting([...new Set(newTableNamesForUpdate)]);
    }
    async createEntitlementWrapper(entitlement) {
        let entitlementReloaded;
        let serviceItem = undefined;
        this.showBusyIndicator();
        try {
            entitlementReloaded = await this.entitlementsProvider.reload(entitlement);
            if (entitlementReloaded) {
                serviceItem = (await this.serviceItemsProvider.get(entitlement))?.Data?.[0];
            }
        }
        finally {
            this.euiBusyService.hide();
        }
        return {
            entitlement: entitlementReloaded,
            serviceItem,
        };
    }
    showBusyIndicator() {
        if (this.euiBusyService.overlayRefs.length === 0) {
            this.euiBusyService.show();
        }
    }
    static ɵfac = function EntitlementsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementsComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(EntitlementsService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(ShopsService), i0.ɵɵdirectiveInject(ServiceItemsService), i0.ɵɵdirectiveInject(i5.Platform), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i2.SystemInfoService), i0.ɵɵdirectiveInject(i2.MetadataService), i0.ɵɵdirectiveInject(EntitlementEditAutoAddService), i0.ɵɵdirectiveInject(i2.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementsComponent, selectors: [["imx-entitlements"]], inputs: { application: "application" }, outputs: { reloadRequested: "reloadRequested" }, features: [i0.ɵɵProvidersFeature([DataViewSource]), i0.ɵɵNgOnChangesFeature], decls: 29, vars: 18, consts: [["infoContent", ""], ["actionsMenu", "matMenu"], [1, "imx-entitlements-site", 3, "ngClass"], [1, "imx-table-action-row"], ["class", "imx-entitlements-row-actions", 4, "ngIf"], [3, "dataSource", "showSettings", "showSearch"], ["mode", "manual", 3, "dataSource", "selectable"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], [1, "imx-table-action-row", "imx-margin-top-16"], [3, "dataSource"], ["class", "imx-entitlements-site", 4, "ngIf"], [1, "imx-entitlements-row-actions"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "imx-entitlements-publish", 3, "click", "disabled"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-unpublish", 3, "click", "disabled"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-assign-mode-button", 3, "matMenuTriggerFor"], ["icon", "collapsedown"], ["data-imx-identifier", "entitlements-assign-more-actions-menu"], ["mat-menu-item", "", "data-imx-identifier", "imx-entitlements-assign-manually", 3, "click"], ["mat-menu-item", "", "data-imx-identifier", "imx-entitlements-updateCondition", 3, "click", "disabled"], ["mat-menu-item", "", "data-imx-identifier", "imx-entitlements-apply-mapping", 3, "click", "disabled"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-unassign", 3, "click", "disabled"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], ["subtitle", ""], ["mat-cell", "", "role", "gridcell"], [1, "imx-badge-container"], ["color", "primary", 4, "ngIf"], [4, "ngIf"], ["color", "primary"], ["color", "warn", 3, "badgeText", "templateRef", "title"], ["subtitle", "", 4, "ngIf"], [1, "imx-entitlements-site"], [1, "imx-aob-entitlements-empty", "imx-no-results"], ["icon", "key"], [1, "imx-aob-entitlements-empty-description"], [1, "imx-aob-entitlements-empty-actions"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "entitlements-add-unsGroup", 3, "click"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-assign", 3, "click", "disabled"], [3, "translate"]], template: function EntitlementsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 2)(1, "div", 3);
            i0.ɵɵtemplate(2, EntitlementsComponent_div_2_Template, 27, 27, "div", 4);
            i0.ɵɵelement(3, "imx-data-view-toolbar", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "imx-data-view-auto-table", 6);
            i0.ɵɵelementContainerStart(5, 7);
            i0.ɵɵtemplate(6, EntitlementsComponent_th_6_Template, 2, 1, "th", 8)(7, EntitlementsComponent_td_7_Template, 5, 2, "td", 9);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(8, 7);
            i0.ɵɵtemplate(9, EntitlementsComponent_th_9_Template, 3, 3, "th", 8)(10, EntitlementsComponent_td_10_Template, 3, 1, "td", 10);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(11, 7);
            i0.ɵɵtemplate(12, EntitlementsComponent_th_12_Template, 1, 0, "th", 8)(13, EntitlementsComponent_td_13_Template, 4, 2, "td", 10);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(14, 7);
            i0.ɵɵtemplate(15, EntitlementsComponent_th_15_Template, 2, 1, "th", 8)(16, EntitlementsComponent_td_16_Template, 3, 1, "td", 10);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(17, 7);
            i0.ɵɵtemplate(18, EntitlementsComponent_th_18_Template, 3, 3, "th", 8)(19, EntitlementsComponent_td_19_Template, 3, 1, "td", 10);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(20, 7);
            i0.ɵɵtemplate(21, EntitlementsComponent_th_21_Template, 3, 3, "th", 8)(22, EntitlementsComponent_td_22_Template, 4, 3, "td", 9);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(23, "div", 11);
            i0.ɵɵelement(24, "imx-data-view-selection", 12)(25, "imx-data-view-paginator", 12);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(26, EntitlementsComponent_div_26_Template, 17, 13, "div", 13)(27, EntitlementsComponent_ng_template_27_Template, 1, 1, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(16, _c0$7, ctx.hideTable));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !ctx.isLoading);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource)("showSettings", false)("showSearch", false);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource)("selectable", true);
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.Ident_AOBEntitlement.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", "type");
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", "badges");
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_AERoleOwner.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", "assigned");
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", "status");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.hideTable);
        } }, dependencies: [i6.NgClass, i6.NgIf, i1.EuiBadgeComponent, i1.EuiIconComponent, i7.MatButton, i12$2.MatDivider, i13$1.MatMenu, i13$1.MatMenuItem, i13$1.MatMenuTrigger, i15.MatHeaderCellDef, i15.MatColumnDef, i15.MatCellDef, i15.MatHeaderCell, i15.MatCell, i3.TranslateDirective, i2.InfoBadgeComponent, i2.DataViewAutoTableComponent, i2.DataViewPaginatorComponent, i2.DataViewToolbarComponent, i2.DataViewSelectionComponent, i3.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%;flex:1 1 auto}.imx-entitlements-site[_ngcontent-%COMP%]{padding:16px 40px;height:100%;display:flex;flex-direction:column;flex:1 1 auto}.imx-entitlements-site.imx-hidden[_ngcontent-%COMP%]{display:none}.imx-entitlements-site[_ngcontent-%COMP%]   .imx-entitlements-row-actions[_ngcontent-%COMP%]{display:flex;gap:8px}imx-data-source-toolbar-custom[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-right:5px}.imx-aob-entitlements-empty[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;margin-bottom:10px;flex:1 1 auto;justify-content:center}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{font-weight:600}.imx-aob-entitlements-empty[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{margin-top:30px}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   .imx-aob-entitlements-empty-description[_ngcontent-%COMP%]{margin-bottom:10px}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   .imx-aob-entitlements-empty-actions[_ngcontent-%COMP%]{display:flex;flex-direction:column}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   .imx-aob-entitlements-empty-actions[_ngcontent-%COMP%] > .mat-mdc-unelevated-button[_ngcontent-%COMP%]{margin-bottom:15px}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   .imx-aob-entitlements-empty-actions[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:last-child{justify-self:center}.imx-aob-data-container[_ngcontent-%COMP%]{flex-grow:1;align-content:flex-start}div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}.eui-contrast-theme   [_nghost-%COMP%]   .imx-entitlements-site[_ngcontent-%COMP%]{background-color:#000}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementsComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlements', providers: [DataViewSource], template: "<div class=\"imx-entitlements-site\" [ngClass]=\"{ 'imx-hidden': hideTable }\">\n  <div class=\"imx-table-action-row\">\n    <div *ngIf=\"!isLoading\" class=\"imx-entitlements-row-actions\">\n      <button\n        mat-flat-button\n        color=\"primary\"\n        [disabled]=\"publishDisabled\"\n        (click)=\"publish()\"\n        data-imx-identifier=\"imx-entitlements-publish\"\n      >\n        {{ '#LDS#Publish' | translate }}\n      </button>\n      <button mat-stroked-button [disabled]=\"unpublishDisabled\" (click)=\"unpublish()\" data-imx-identifier=\"imx-entitlements-unpublish\">\n        {{ '#LDS#Unpublish' | translate }}\n      </button>\n      <button mat-stroked-button data-imx-identifier=\"imx-entitlements-assign-mode-button\" [matMenuTriggerFor]=\"actionsMenu\">\n        <span>{{ '#LDS#Assign more' | translate }}</span>\n        <eui-icon icon=\"collapsedown\"></eui-icon>\n      </button>\n      <mat-menu data-imx-identifier=\"entitlements-assign-more-actions-menu\" #actionsMenu=\"matMenu\">\n        <button mat-menu-item data-imx-identifier=\"imx-entitlements-assign-manually\" (click)=\"addNewElement()\">\n          {{ '#LDS#Assign manually' | translate }}\n        </button>\n        <mat-divider></mat-divider>\n        <button\n          mat-menu-item\n          data-imx-identifier=\"imx-entitlements-updateCondition\"\n          [disabled]=\"!application.extendedDataRead\"\n          (click)=\"editConditionForDynamicAssignments()\"\n        >\n          {{ (hasConditionForDynamicAssignment ? '#LDS#Edit automatic assignment' : '#LDS#Assign automatically') | translate }}\n        </button>\n        <button\n          mat-menu-item\n          data-imx-identifier=\"imx-entitlements-apply-mapping\"\n          [disabled]=\"!hasConditionForDynamicAssignment\"\n          (click)=\"applyMappingForDynamicAssignments()\"\n        >\n          {{ '#LDS#Check for new automatic assignments' | translate }}\n        </button>\n      </mat-menu>\n      <button mat-stroked-button [disabled]=\"unassignedDisabled\" (click)=\"unassign()\" data-imx-identifier=\"imx-entitlements-unassign\">\n        {{ '#LDS#Unassign' | translate }}\n      </button>\n    </div>\n    <imx-data-view-toolbar [dataSource]=\"dataSource\" [showSettings]=\"false\" [showSearch]=\"false\"></imx-data-view-toolbar>\n  </div>\n  <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\" [selectable]=\"true\">\n    <ng-container [matColumnDef]=\"entitySchema.Columns.Ident_AOBEntitlement.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>{{ entitySchema?.Columns?.Ident_AOBEntitlement?.Display }}</th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n        <div>{{ item.Ident_AOBEntitlement.Column.GetDisplayValue() }}</div>\n        <div subtitle>{{ item.Description.Column.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"'type'\">\n      <th mat-header-cell *matHeaderCellDef>{{ '#LDS#Type' | translate }}</th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <span>\n          {{ getType(item) }}\n        </span>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"'badges'\">\n      <th mat-header-cell *matHeaderCellDef></th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div class=\"imx-badge-container\">\n          <div color=\"primary\" *ngIf=\"item.IsDynamic.value\">\n            <eui-badge>{{ '#LDS#Automatic' | translate }}</eui-badge>\n          </div>\n          <div *ngIf=\"item.IsOutlierAssignment.value\">\n            <imx-info-badge\n              color=\"warn\"\n              [badgeText]=\"'#LDS#Wrong service category' | translate\"\n              [templateRef]=\"infoContent\"\n              [title]=\"'#LDS#Heading Wrong Service Category' | translate\"\n            ></imx-info-badge>\n          </div>\n        </div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.UID_AERoleOwner.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>{{ entitySchema?.Columns?.UID_AERoleOwner?.Display }}</th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.UID_AERoleOwner.Column.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"'assigned'\">\n      <th mat-header-cell *matHeaderCellDef>{{ '#LDS#Assigned' | translate }}</th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.XDateInserted.Column.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"'status'\">\n      <th mat-header-cell *matHeaderCellDef>{{ '#LDS#Status' | translate }}</th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n        <div *ngIf=\"filter.notPublished(item)\">{{ '#LDS#Not published' | translate }}</div>\n        <div *ngIf=\"filter.willPublish(item)\">\n          <div>{{ '#LDS#Will be published' | translate }}</div>\n          <div>{{ item.ActivationDate.Column.GetDisplayValue() }}</div>\n        </div>\n        <div *ngIf=\"filter.published(item)\">\n          <div>{{ '#LDS#Published' | translate }}</div>\n          <div subtitle *ngIf=\"application.IsInActive.value\">{{ '#LDS#(not yet requestable)' | translate }}</div>\n        </div>\n      </td>\n    </ng-container>\n  </imx-data-view-auto-table>\n  <div class=\"imx-table-action-row imx-margin-top-16\">\n    <imx-data-view-selection [dataSource]=\"dataSource\"></imx-data-view-selection>\n    <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n  </div>\n</div>\n<div class=\"imx-entitlements-site\" *ngIf=\"hideTable\">\n  <div class=\"imx-aob-entitlements-empty imx-no-results\">\n    <eui-icon icon=\"key\"></eui-icon>\n    <div class=\"imx-aob-entitlements-empty-description\">\n      <h2>\n        {{ '#LDS#No application entitlements assigned' | translate }}\n      </h2>\n      <span>\n        {{ '#LDS#Assign application entitlements to this application.' | translate }}\n      </span>\n    </div>\n    <div class=\"imx-aob-entitlements-empty-actions\">\n      <button mat-flat-button color=\"primary\" (click)=\"addNewElement()\" data-imx-identifier=\"entitlements-add-unsGroup\">\n        {{ '#LDS#Assign application entitlements' | translate }}\n      </button>\n      <button\n        mat-stroked-button\n        data-imx-identifier=\"imx-entitlements-assign\"\n        [disabled]=\"!application.extendedDataRead\"\n        (click)=\"editConditionForDynamicAssignments()\"\n      >\n        {{ '#LDS#Create automatic assignment' | translate }}\n      </button>\n    </div>\n  </div>\n</div>\n\n<ng-template #infoContent>\n  <p\n    [translate]=\"\n      '#LDS#This application entitlement is not assigned to the root service category of this application nor to any of its child service categories.'\n    \"\n  ></p>\n</ng-template>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;height:100%;flex:1 1 auto}.imx-entitlements-site{padding:16px 40px;height:100%;display:flex;flex-direction:column;flex:1 1 auto}.imx-entitlements-site.imx-hidden{display:none}.imx-entitlements-site .imx-entitlements-row-actions{display:flex;gap:8px}imx-data-source-toolbar-custom button{margin-right:5px}.imx-aob-entitlements-empty{display:flex;flex-direction:column;align-items:center;margin-bottom:10px;flex:1 1 auto;justify-content:center}.imx-aob-entitlements-empty h2{font-weight:600}.imx-aob-entitlements-empty>div{margin-top:30px}.imx-aob-entitlements-empty .imx-aob-entitlements-empty-description{margin-bottom:10px}.imx-aob-entitlements-empty .imx-aob-entitlements-empty-actions{display:flex;flex-direction:column}.imx-aob-entitlements-empty .imx-aob-entitlements-empty-actions>.mat-mdc-unelevated-button{margin-bottom:15px}.imx-aob-entitlements-empty .imx-aob-entitlements-empty-actions>:last-child{justify-self:center}.imx-aob-data-container{flex-grow:1;align-content:flex-start}div[subtitle]{font-size:smaller;color:#919799}.eui-contrast-theme :host .imx-entitlements-site{background-color:#000}\n"] }]
    }], () => [{ type: i2.ClassloggerService }, { type: i1$2.MatDialog }, { type: EntitlementsService }, { type: i1.EuiLoadingService }, { type: i1$2.MatDialog }, { type: i2.SnackBarService }, { type: ShopsService }, { type: ServiceItemsService }, { type: i5.Platform }, { type: i3.TranslateService }, { type: i1.EuiSidesheetService }, { type: i2.SettingsService }, { type: i2.SystemInfoService }, { type: i2.MetadataService }, { type: EntitlementEditAutoAddService }, { type: i2.DataViewSource }], { application: [{
            type: Input
        }], reloadRequested: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EntitlementsComponent, { className: "EntitlementsComponent", filePath: "lib\\entitlements\\entitlements.component.ts", lineNumber: 85 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class KpiOverviewService {
    aobClient;
    apiProvider;
    constructor(aobClient, apiProvider) {
        this.aobClient = aobClient;
        this.apiProvider = apiProvider;
    }
    async get(uidapplication) {
        return this.apiProvider.request(() => this.aobClient.client.portal_application_kpi_get(uidapplication));
    }
    static ɵfac = function KpiOverviewService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || KpiOverviewService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ApiClientService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: KpiOverviewService, factory: KpiOverviewService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(KpiOverviewService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobApiService }, { type: i2.ApiClientService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$6 = ["chartdialog"];
function KpiOverviewComponent_ng_container_0_imx_busy_indicator_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-busy-indicator");
} }
function KpiOverviewComponent_ng_container_0_div_6_h4_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "h4");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Failed"));
} }
function KpiOverviewComponent_ng_container_0_div_6_li_3_button_9_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 14);
    i0.ɵɵlistener("click", function KpiOverviewComponent_ng_container_0_div_6_li_3_button_9_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r1); const chart_r2 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r2.showDetails(chart_r2, true)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Details"), " ");
} }
function KpiOverviewComponent_ng_container_0_div_6_li_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li")(1, "mat-card")(2, "div", 7);
    i0.ɵɵelement(3, "eui-icon", 8);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-card-content", 9)(5, "div", 10);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(7, "div", 11);
    i0.ɵɵelementStart(8, "mat-card-actions", 12);
    i0.ɵɵtemplate(9, KpiOverviewComponent_ng_container_0_div_6_li_3_button_9_Template, 3, 3, "button", 13);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const chart_r2 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(5);
    i0.ɵɵproperty("matTooltip", chart_r2.Display);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(chart_r2.Display);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r2.hasDetails(chart_r2));
} }
function KpiOverviewComponent_ng_container_0_div_6_h4_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "h4");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Passed"));
} }
function KpiOverviewComponent_ng_container_0_div_6_li_6_button_9_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 18);
    i0.ɵɵlistener("click", function KpiOverviewComponent_ng_container_0_div_6_li_6_button_9_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const chart_r5 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r2.showDetails(chart_r5, false)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Details"), " ");
} }
function KpiOverviewComponent_ng_container_0_div_6_li_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li")(1, "mat-card")(2, "div", 15);
    i0.ɵɵelement(3, "eui-icon", 16);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-card-content", 9)(5, "div", 10);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(7, "div", 11);
    i0.ɵɵelementStart(8, "mat-card-actions", 12);
    i0.ɵɵtemplate(9, KpiOverviewComponent_ng_container_0_div_6_li_6_button_9_Template, 3, 3, "button", 17);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const chart_r5 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(5);
    i0.ɵɵproperty("matTooltip", chart_r5.Display);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(chart_r5.Display);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r2.hasDetails(chart_r5));
} }
function KpiOverviewComponent_ng_container_0_div_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, KpiOverviewComponent_ng_container_0_div_6_h4_1_Template, 3, 3, "h4", 4);
    i0.ɵɵelementStart(2, "ul", 5);
    i0.ɵɵtemplate(3, KpiOverviewComponent_ng_container_0_div_6_li_3_Template, 10, 3, "li", 6);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, KpiOverviewComponent_ng_container_0_div_6_h4_4_Template, 3, 3, "h4", 4);
    i0.ɵɵelementStart(5, "ul", 5);
    i0.ɵɵtemplate(6, KpiOverviewComponent_ng_container_0_div_6_li_6_Template, 10, 3, "li", 6);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.chartDataFail.length > 0);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r2.chartDataFail);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.chartDataPass.length > 0);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r2.chartDataPass);
} }
function KpiOverviewComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 3)(2, "h3");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(5, KpiOverviewComponent_ng_container_0_imx_busy_indicator_5_Template, 1, 0, "imx-busy-indicator", 4)(6, KpiOverviewComponent_ng_container_0_div_6_Template, 7, 4, "div", 4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 3, "#LDS#KPIs That Affect This Application"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.isLoading);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r2.isLoading);
} }
function KpiOverviewComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 19)(1, "div", 20);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 21);
    i0.ɵɵelement(5, "eui-icon", 22);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(6, "div", 23)(7, "h2", 24);
    i0.ɵɵtext(8);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(9, "p", 24);
    i0.ɵɵtext(10);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "div", 25);
    i0.ɵɵelement(12, "eui-billboard", 26);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const data_r6 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngClass", data_r6.failed ? "imx-fail imx-title-text" : "imx-pass imx-title-text");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 5, data_r6.failed ? "#LDS#Failed" : "#LDS#Passed"), " ");
    i0.ɵɵadvance(6);
    i0.ɵɵtextInterpolate(data_r6.chart.display);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(data_r6.chart.description);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("options", data_r6.chart.options);
} }
function KpiOverviewComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 27);
    i0.ɵɵelement(1, "eui-icon", 28);
    i0.ɵɵelementStart(2, "h2");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 1, "#LDS#There are no KPIs affecting this application."), " ");
} }
/**
 * A component, that displays key Performance Indicators (KPIs) for an application
 *
 * @example
 * <imx-kpi-overview [application]="application"></imx-kpi-overview>
 */
class KpiOverviewComponent {
    translateService;
    kpiOverviewProvider;
    logger;
    matDialog;
    /**
     * @ignore internally used KPIs, that passes
     */
    chartDataPass;
    /**
     * @ignore internally used KPIs, that failed
     */
    chartDataFail;
    /**
     * @ignore columns for the mat-table that is shown, if a KPI has only one dataPoint
     */
    displayedColumns = ['Date', 'Value', 'Threshold'];
    /**
     * The AobApplication, which KPI data should be displayed
     */
    application;
    /**
     * @ignore the template used for the datail Dialog
     */
    chartDialog;
    errorThreshhold;
    busyService = new BusyService();
    isLoading = false;
    constructor(translateService, kpiOverviewProvider, logger, matDialog) {
        this.translateService = translateService;
        this.kpiOverviewProvider = kpiOverviewProvider;
        this.logger = logger;
        this.matDialog = matDialog;
        translateService.get('#LDS#Error threshold').subscribe((trans) => (this.errorThreshhold = trans));
        this.busyService.busyStateChanged.subscribe((elem) => (this.isLoading = elem));
    }
    /**
     * Displays a busyIndicator and initializes the data, when the OnChanges life cycle hook is called
     */
    async ngOnChanges(changes) {
        if (changes.application?.currentValue?.UID_AOBApplication.value === changes.application?.previousValue?.UID_AOBApplication.value) {
            return;
        }
        const isBusy = this.busyService.beginBusy();
        try {
            const data = await this.kpiOverviewProvider.get(this.application.UID_AOBApplication.value);
            if (data) {
                this.chartDataPass = data.filter((kpi) => !!kpi.Data?.length && (kpi.Data?.[0].Points?.[0].Value || 0) < kpi.ErrorThreshold);
                this.chartDataFail = data.filter((kpi) => !!kpi.Data?.length && (kpi.Data?.[0].Points?.[0].Value || 0) >= kpi.ErrorThreshold);
            }
            else {
                this.logger.error(this, 'ChartDto[] is undefined');
            }
        }
        finally {
            isBusy.endBusy();
        }
    }
    /**
     * @ignore Opens a dialog that shows the details of a KPI
     * @param chart the data of a single chart
     */
    showDetails(chart, isFail) {
        if (!this.hasDetails(chart)) {
            return;
        }
        this.matDialog.open(this.chartDialog, {
            data: { chart: this.getChartData(chart), failed: isFail },
            width: '600px',
            autoFocus: false,
            panelClass: 'kpi-overview-modal',
        });
    }
    /**
     * @ignore determines whether a chart has detailed data
     * @param chart the data of a single chart
     */
    hasDetails(chart) {
        return chart.Data != null && chart.Data.length > 0;
    }
    /**
     * @ignore determines whether an application has chart data or not
     * @returns true, if there are failed or passed KPIs else it returns false
     */
    hasKpis() {
        return (this.chartDataFail != null && this.chartDataFail.length > 0) || (this.chartDataPass != null && this.chartDataPass.length > 0);
    }
    /**
     * @ignore get an unified display for a date string
     * @param date a date string as represented in the chart
     * @returns the local date string for a date represented by an other string
     */
    getDateDisplay(date) {
        return new Date(date).toLocaleString(this.translateService.currentLang);
    }
    /**
     * @ignore determines whether a chart has more then one data point
     * @param chart the data of a single chart
     * @returns true, if the chart has multiple points else it return false
     */
    hasMultipleDataPoints(chart) {
        return this.hasDetails(chart) && (chart.Data?.[0].Points?.length || 0) > 1;
    }
    /**
     * @irgnore Builds an object, that could be passed to the detail dialog
     * @param chart the data of a single chart
     * @returns a dictionary, that can be display on the details dialog
     */
    getChartData(chart) {
        return { display: chart.Display, description: chart.Description, options: this.buildOptions(chart) };
    }
    /**
     * @ignore Build the ChartOptions that can be displayed with billboard.js
     * @param chart the data of a single chart
     * @returns a ChartOptions object, that can be used by billboard.js
     */
    buildOptions(chart) {
        const yAxis = new YAxisInformation(chart.Data?.map((serie) => new SeriesInformation(chart.Display || '', serie.Points?.map((point) => point.Value) || [])) || []);
        const browserCulture = this.translateService.currentLang;
        yAxis.tickConfiguration = { format: (d) => d.toLocaleString(browserCulture), values: this.accumulateTicks(chart) };
        const lineChartOptions = new LineChartOptions(new XAxisInformation('date', chart.Data?.[0].Points?.map((point) => new Date(point.Date)) || [], {
            count: 6,
            format: (d) => d.toLocaleDateString(browserCulture),
        }), yAxis);
        lineChartOptions.useCurvedLines = false;
        lineChartOptions.hideLegend = true;
        lineChartOptions.showPoints = !this.hasMultipleDataPoints(chart);
        lineChartOptions.additionalLines = [
            {
                value: chart.ErrorThreshold,
                text: this.errorThreshhold,
            },
        ];
        lineChartOptions.size = {
            height: 400,
            width: 500,
        };
        this.logger.debug(this, 'Options', lineChartOptions.options);
        return lineChartOptions.options;
    }
    accumulateTicks(chart) {
        let ret = [];
        const max = Math.max.apply(Math, chart.Data?.[0].Points?.map((o) => o.Value));
        const steps = Math.max(1, Math.trunc(max / 10)) + 1;
        ret.push(0);
        if (max <= 0) {
            return ret;
        }
        for (let index = 1; index <= 10; index++) {
            ret.push(index * steps);
        }
        return ret;
    }
    static ɵfac = function KpiOverviewComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || KpiOverviewComponent)(i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(KpiOverviewService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i1$2.MatDialog)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: KpiOverviewComponent, selectors: [["imx-kpi-overview"]], viewQuery: function KpiOverviewComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$6, 7);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.chartDialog = _t.first);
        } }, inputs: { application: "application" }, features: [i0.ɵɵNgOnChangesFeature], decls: 5, vars: 2, consts: [["chartdialog", ""], ["nonExisting", ""], [4, "ngIf", "ngIfElse"], [1, "imx-kpi-site"], [4, "ngIf"], [1, "imx-kpi-list"], [4, "ngFor", "ngForOf"], ["mat-card-avatar", "", 1, "imx-fail"], ["icon", "ignore", "size", "m"], [1, "imx-kpi-content"], [1, "imx-kpi-text", 3, "matTooltip"], [1, "imx-spacer"], [1, "imx-kpi-tile-actions"], ["mat-stroked-button", "", "data-imx-identifier", "KPI_overview_showFailedShowDetails", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "data-imx-identifier", "KPI_overview_showFailedShowDetails", 3, "click"], ["mat-card-avatar", "", 1, "imx-pass"], ["icon", "check", "size", "m"], ["mat-stroked-button", "", "data-imx-identifier", "KPI_overview_showPassedShowDetails", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "data-imx-identifier", "KPI_overview_showPassedShowDetails", 3, "click"], ["mat-dialog-title", "", 1, "imx-dialog-title-closable"], [3, "ngClass"], ["mat-icon-button", "", "data-imx-identifier", "KPI_overview_closeChartDialog", "mat-dialog-close", "", 1, "mat-button", "imx-button-close-dialog"], ["icon", "close", "size", "large"], ["mat-dialog-content", ""], [1, "imx-title-text"], [1, "imx-chart-container-center"], [3, "options"], [1, "imx-no-results"], ["icon", "areachart"]], template: function KpiOverviewComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, KpiOverviewComponent_ng_container_0_Template, 7, 5, "ng-container", 2)(1, KpiOverviewComponent_ng_template_1_Template, 13, 7, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor)(3, KpiOverviewComponent_ng_template_3_Template, 5, 3, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            const nonExisting_r7 = i0.ɵɵreference(4);
            i0.ɵɵproperty("ngIf", ctx.hasKpis() || ctx.isLoading)("ngIfElse", nonExisting_r7);
        } }, dependencies: [i6.NgClass, i6.NgForOf, i6.NgIf, i6$1.MatCard, i6$1.MatCardActions, i6$1.MatCardAvatar, i6$1.MatCardContent, i7.MatButton, i7.MatIconButton, i8.MatTooltip, i1.EuiBillboardComponent, i1.EuiIconComponent, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogContent, i2.BusyIndicatorComponent, i3.TranslatePipe], styles: ["[_nghost-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column}[_nghost-%COMP%]   .mat-mdc-card[_ngcontent-%COMP%] > .mat-mdc-card-actions[_ngcontent-%COMP%]:last-child{margin-bottom:0}.imx-kpi-site[_ngcontent-%COMP%]{padding:16px 40px;height:auto;min-height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}li[_ngcontent-%COMP%]{list-style-type:none;margin:0 10px 10px 0}.mat-mdc-card[_ngcontent-%COMP%]{padding:5px 10px;width:340px;height:68px;display:flex;flex-direction:row}h2[_ngcontent-%COMP%]{font-size:20px;margin-bottom:8px}p[_ngcontent-%COMP%]{font-size:14px;margin-top:0}h3[_ngcontent-%COMP%]{margin-top:20px;font-size:18px;font-weight:400}h4[_ngcontent-%COMP%]{font-size:16px;font-weight:600;margin:30px 0 15px}.imx-kpi-text[_ngcontent-%COMP%]{margin:0;vertical-align:middle;word-break:break-word}.imx-kpi-content[_ngcontent-%COMP%]{flex:1 1 auto;align-self:center;margin-bottom:0;margin-right:5px;font-size:14px}.imx-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.imx-kpi-tile-actions[_ngcontent-%COMP%]{display:flex;align-items:center;margin:0 5px 0 0;padding:0}.imx-pass[_ngcontent-%COMP%], .imx-fail[_ngcontent-%COMP%]{text-transform:uppercase;font-size:24px;line-height:38px;font-weight:900;margin:0 20px 0 0;align-self:center}.imx-kpi-list[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap}.imx-kpi-view[_ngcontent-%COMP%]{padding:20px 0 0 20px}.imx-title-text[_ngcontent-%COMP%]{text-align:center;margin:0 24px 0 60px;flex:1}.imx-no-results[_ngcontent-%COMP%]{display:flex;flex-direction:column;justify-content:center;align-items:center;flex:1 1 auto}.imx-no-results[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{font-weight:600}.eui-light-theme   [_nghost-%COMP%]   li[_ngcontent-%COMP%]   .mat-mdc-card[_ngcontent-%COMP%]{background-color:#fff}.eui-light-theme   [_nghost-%COMP%]   p[_ngcontent-%COMP%]{color:#18191a}.eui-light-theme   [_nghost-%COMP%]   .imx-pass[_ngcontent-%COMP%]{color:#4ba803}.eui-light-theme   [_nghost-%COMP%]   .imx-fail[_ngcontent-%COMP%]{color:#db2534}  .eui-light-theme .kpi-overview-modal .imx-title-text{color:#2f3233}  .eui-light-theme .kpi-overview-modal .imx-pass{color:#4ba803}  .eui-light-theme .kpi-overview-modal .imx-fail{color:#db2534}.eui-dark-theme   [_nghost-%COMP%]   .imx-kpi-list[_ngcontent-%COMP%] > li[_ngcontent-%COMP%] > .mat-mdc-card[_ngcontent-%COMP%]{background-color:#616566}.eui-dark-theme   [_nghost-%COMP%]   .imx-pass[_ngcontent-%COMP%]{color:#99c478}.eui-dark-theme   [_nghost-%COMP%]   .imx-fail[_ngcontent-%COMP%]{color:#f29d99}  .eui-dark-theme .kpi-overview-modal .imx-title-text{color:#f9fbfc}  .eui-dark-theme .kpi-overview-modal .imx-pass{color:#99c478}  .eui-dark-theme .kpi-overview-modal .imx-fail{color:#f29d99}.eui-contrast-theme   [_nghost-%COMP%]   .imx-kpi-list[_ngcontent-%COMP%] > li[_ngcontent-%COMP%] > .mat-mdc-card[_ngcontent-%COMP%]{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .imx-pass[_ngcontent-%COMP%]{color:#cee3bf}.eui-contrast-theme   [_nghost-%COMP%]   .imx-fail[_ngcontent-%COMP%]{color:#f3c8c8}  .eui-contrast-theme .kpi-overview-modal .imx-title-text{color:#dfe4e6}  .eui-contrast-theme .kpi-overview-modal .imx-pass{color:#4ba803}  .eui-contrast-theme .kpi-overview-modal .imx-fail{color:#db2534}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(KpiOverviewComponent, [{
        type: Component,
        args: [{ selector: 'imx-kpi-overview', template: "<ng-container *ngIf=\"hasKpis() || isLoading; else nonExisting\">\n  <div class=\"imx-kpi-site\">\n    <h3>\n      {{ '#LDS#KPIs That Affect This Application' | translate }}\n    </h3>\n    <imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\n    <div *ngIf=\"!isLoading\">\n      <h4 *ngIf=\"chartDataFail.length > 0\">{{ '#LDS#Failed' | translate }}</h4>\n      <ul class=\"imx-kpi-list\">\n        <li *ngFor=\"let chart of chartDataFail\">\n          <mat-card>\n            <div mat-card-avatar class=\"imx-fail\">\n              <eui-icon icon=\"ignore\" size=\"m\"></eui-icon>\n            </div>\n            <mat-card-content class=\"imx-kpi-content\">\n              <div class=\"imx-kpi-text\" [matTooltip]=\"chart.Display\">{{ chart.Display }}</div>\n            </mat-card-content>\n            <div class=\"imx-spacer\"></div>\n            <mat-card-actions class=\"imx-kpi-tile-actions\">\n              <button\n                *ngIf=\"hasDetails(chart)\"\n                mat-stroked-button\n                data-imx-identifier=\"KPI_overview_showFailedShowDetails\"\n                (click)=\"showDetails(chart, true)\"\n              >\n                {{ '#LDS#Details' | translate }}\n              </button>\n            </mat-card-actions>\n          </mat-card>\n        </li>\n      </ul>\n      <h4 *ngIf=\"chartDataPass.length > 0\">{{ '#LDS#Passed' | translate }}</h4>\n      <ul class=\"imx-kpi-list\">\n        <li *ngFor=\"let chart of chartDataPass\">\n          <mat-card>\n            <div mat-card-avatar class=\"imx-pass\">\n              <eui-icon icon=\"check\" size=\"m\"></eui-icon>\n            </div>\n            <mat-card-content class=\"imx-kpi-content\">\n              <div class=\"imx-kpi-text\" [matTooltip]=\"chart.Display\">{{ chart.Display }}</div>\n            </mat-card-content>\n            <div class=\"imx-spacer\"></div>\n            <mat-card-actions class=\"imx-kpi-tile-actions\">\n              <button\n                *ngIf=\"hasDetails(chart)\"\n                mat-stroked-button\n                data-imx-identifier=\"KPI_overview_showPassedShowDetails\"\n                (click)=\"showDetails(chart, false)\"\n              >\n                {{ '#LDS#Details' | translate }}\n              </button>\n            </mat-card-actions>\n          </mat-card>\n        </li>\n      </ul>\n    </div>\n  </div>\n</ng-container>\n\n<!-- Template for a chart dialog -->\n<ng-template #chartdialog let-data>\n  <div mat-dialog-title class=\"imx-dialog-title-closable\">\n    <div [ngClass]=\"data.failed ? 'imx-fail imx-title-text' : 'imx-pass imx-title-text'\">\n      {{ (data.failed ? '#LDS#Failed' : '#LDS#Passed') | translate }}\n    </div>\n    <button mat-icon-button class=\"mat-button imx-button-close-dialog\" data-imx-identifier=\"KPI_overview_closeChartDialog\" mat-dialog-close>\n      <eui-icon icon=\"close\" size=\"large\"></eui-icon>\n    </button>\n  </div>\n  <div mat-dialog-content>\n    <h2 class=\"imx-title-text\">{{ data.chart.display }}</h2>\n    <p class=\"imx-title-text\">{{ data.chart.description }}</p>\n    <div class=\"imx-chart-container-center\">\n      <eui-billboard [options]=\"data.chart.options\"></eui-billboard>\n    </div>\n  </div>\n</ng-template>\n\n<!-- Template for non existing entitlements -->\n<ng-template #nonExisting>\n  <div class=\"imx-no-results\">\n    <eui-icon icon=\"areachart\"></eui-icon>\n    <h2>\n      {{ '#LDS#There are no KPIs affecting this application.' | translate }}\n    </h2>\n  </div>\n</ng-template>\n", styles: [":host{flex:1 1 auto;display:flex;flex-direction:column}:host .mat-mdc-card>.mat-mdc-card-actions:last-child{margin-bottom:0}.imx-kpi-site{padding:16px 40px;height:auto;min-height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}li{list-style-type:none;margin:0 10px 10px 0}.mat-mdc-card{padding:5px 10px;width:340px;height:68px;display:flex;flex-direction:row}h2{font-size:20px;margin-bottom:8px}p{font-size:14px;margin-top:0}h3{margin-top:20px;font-size:18px;font-weight:400}h4{font-size:16px;font-weight:600;margin:30px 0 15px}.imx-kpi-text{margin:0;vertical-align:middle;word-break:break-word}.imx-kpi-content{flex:1 1 auto;align-self:center;margin-bottom:0;margin-right:5px;font-size:14px}.imx-spacer{flex:1 1 auto}.imx-kpi-tile-actions{display:flex;align-items:center;margin:0 5px 0 0;padding:0}.imx-pass,.imx-fail{text-transform:uppercase;font-size:24px;line-height:38px;font-weight:900;margin:0 20px 0 0;align-self:center}.imx-kpi-list{display:flex;flex-wrap:wrap}.imx-kpi-view{padding:20px 0 0 20px}.imx-title-text{text-align:center;margin:0 24px 0 60px;flex:1}.imx-no-results{display:flex;flex-direction:column;justify-content:center;align-items:center;flex:1 1 auto}.imx-no-results h2{font-weight:600}.eui-light-theme :host li .mat-mdc-card{background-color:#fff}.eui-light-theme :host p{color:#18191a}.eui-light-theme :host .imx-pass{color:#4ba803}.eui-light-theme :host .imx-fail{color:#db2534}::ng-deep .eui-light-theme .kpi-overview-modal .imx-title-text{color:#2f3233}::ng-deep .eui-light-theme .kpi-overview-modal .imx-pass{color:#4ba803}::ng-deep .eui-light-theme .kpi-overview-modal .imx-fail{color:#db2534}.eui-dark-theme :host .imx-kpi-list>li>.mat-mdc-card{background-color:#616566}.eui-dark-theme :host .imx-pass{color:#99c478}.eui-dark-theme :host .imx-fail{color:#f29d99}::ng-deep .eui-dark-theme .kpi-overview-modal .imx-title-text{color:#f9fbfc}::ng-deep .eui-dark-theme .kpi-overview-modal .imx-pass{color:#99c478}::ng-deep .eui-dark-theme .kpi-overview-modal .imx-fail{color:#f29d99}.eui-contrast-theme :host .imx-kpi-list>li>.mat-mdc-card{background-color:#2f3233}.eui-contrast-theme :host .imx-pass{color:#cee3bf}.eui-contrast-theme :host .imx-fail{color:#f3c8c8}::ng-deep .eui-contrast-theme .kpi-overview-modal .imx-title-text{color:#dfe4e6}::ng-deep .eui-contrast-theme .kpi-overview-modal .imx-pass{color:#4ba803}::ng-deep .eui-contrast-theme .kpi-overview-modal .imx-fail{color:#db2534}\n"] }]
    }], () => [{ type: i3.TranslateService }, { type: KpiOverviewService }, { type: i2.ClassloggerService }, { type: i1$2.MatDialog }], { application: [{
            type: Input
        }], chartDialog: [{
            type: ViewChild,
            args: ['chartdialog', { static: true }]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(KpiOverviewComponent, { className: "KpiOverviewComponent", filePath: "lib\\kpi\\kpi-overview\\kpi-overview.component.ts", lineNumber: 47 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobAccountContainer extends TypedEntity {
    static GetEntitySchema() {
        const columns = {
            XObjectKey: {
                Type: ValType.String,
                ColumnName: 'XObjectKey',
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        return { Columns: columns };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountsService {
    aobClient;
    logger;
    apiProvider;
    get display() {
        return this.aobClient.typedClient.PortalApplicationusesaccount.GetSchema().Display || '';
    }
    builder = new TypedEntityBuilder(AobAccountContainer);
    appUsesAccounts = {};
    constructor(aobClient, logger, apiProvider) {
        this.aobClient = aobClient;
        this.logger = logger;
        this.apiProvider = apiProvider;
    }
    async updateApplicationUsesAccounts(application, changeSet) {
        const assignResult = await this.assign(application, changeSet.add);
        return assignResult && this.unassign(application, changeSet.remove);
    }
    getCandidateTables() {
        return this.aobClient.typedClient.PortalApplicationusesaccountNew.createEntity().ObjectKeyAccount.GetMetadata().GetFkRelations();
    }
    async getSelectedAccountLength(uidApplication) {
        return ((await this.apiProvider.request(() => this.aobClient.typedClient.PortalApplicationusesaccount.Get(uidApplication, { PageSize: -1 })))
            ?.totalCount || 0);
    }
    async getAssigned(application, parameters = {}) {
        this.appUsesAccounts = {};
        this.logger.debug(this, 'getting assigned accounts...');
        const appUsesAccountCollection = await this.apiProvider.request(() => this.aobClient.typedClient.PortalApplicationusesaccount.Get(application, parameters));
        return this.accountsWithTableInfo(appUsesAccountCollection, parameters);
    }
    async getFirstAndCount(uidApplication) {
        const elements = await this.apiProvider.request(() => this.aobClient.typedClient.PortalApplicationusesaccount.Get(uidApplication, { PageSize: 1 }));
        let accounts = [];
        if (!!elements) {
            accounts = await this.accountsWithTableInfo(elements, { PageSize: 1 });
        }
        return {
            first: accounts.length === 0 ? undefined : accounts[0],
            count: elements?.totalCount || 0,
        };
    }
    async accountsWithTableInfo(appUsesAccountCollection, parameters) {
        const accountsAssigned = [];
        const tables = this.getCandidateTables();
        if (!!appUsesAccountCollection && appUsesAccountCollection.Data && tables) {
            for (const appUsesAccount of appUsesAccountCollection.Data) {
                const tableName = DbObjectKey.FromXml(appUsesAccount.ObjectKeyAccount.value).TableName;
                const table = tables.find((fkr) => fkr.TableName === tableName);
                if (table) {
                    const accountCollection = await table.Get({
                        ...parameters,
                        ...{
                            filter: [
                                {
                                    ColumnName: table.ColumnName,
                                    Type: FilterType.Compare,
                                    CompareOp: CompareOperator.Like,
                                    Value1: `%${appUsesAccount.ObjectKeyAccount.value}%`,
                                },
                            ],
                            search: undefined,
                        },
                    });
                    if (!!accountCollection?.Entities?.length) {
                        const entity = this.builder.buildReadWriteEntity({
                            entitySchema: AobAccountContainer.GetEntitySchema(),
                            entityData: accountCollection.Entities?.[0],
                        });
                        this.appUsesAccounts[entity.GetEntity().GetKeys().join()] = appUsesAccount;
                        accountsAssigned.push(entity);
                    }
                }
            }
        }
        return accountsAssigned;
    }
    async assign(application, accounts) {
        let count = 0;
        await this.apiProvider.request(async () => {
            for (const account of accounts) {
                this.logger.debug(this, 'assigning account to application...');
                const assignedAccount = this.aobClient.typedClient.PortalApplicationusesaccountNew.createEntity();
                assignedAccount.UID_AOBApplication.value = application.UID_AOBApplication.value;
                assignedAccount.ObjectKeyAccount.value = account.GetEntity().GetColumn('XObjectKey').GetValue();
                await assignedAccount.GetEntity().Commit();
                count++;
            }
        });
        return count === accounts.length;
    }
    async unassign(application, accounts) {
        let count = 0;
        await this.apiProvider.request(async () => {
            for (const account of accounts) {
                this.logger.debug(this, 'unassigning account from application...');
                await this.aobClient.client.portal_applicationusesaccount_delete(application.UID_AOBApplication.value, this.appUsesAccounts[account.GetEntity().GetKeys().join()].UID_AOBAppUsesAccount.value);
                count++;
            }
        });
        return count === accounts.length;
    }
    async searchCandidates(table, keyword, parameters = {}) {
        this.logger.debug(this, 'searching accounts...');
        return table.Get({
            ...parameters,
            ...{
                filter: [
                    {
                        ColumnName: table.ColumnName,
                        Type: FilterType.Compare,
                        CompareOp: CompareOperator.Like,
                        Value1: `%${keyword}%`,
                    },
                ],
                search: undefined,
            },
        });
    }
    static ɵfac = function AccountsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AccountsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ApiClientService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AccountsService, factory: AccountsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobApiService }, { type: i2.ClassloggerService }, { type: i2.ApiClientService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SelectionContainer {
    getKey;
    selected = [];
    assigned = [];
    constructor(getKey) {
        this.getKey = getKey;
    }
    init(assigned) {
        this.assigned = assigned;
        this.selected = assigned.slice();
    }
    getChangeSet() {
        return {
            add: this.selected.filter((item) => this.assigned.find((itemAssigned) => this.equals(item, itemAssigned)) == null),
            remove: this.selected == null || this.selected.length === 0
                ? this.assigned
                : this.assigned.filter((itemAssigned) => this.selected.find((item) => this.equals(item, itemAssigned)) == null),
        };
    }
    equals(item1, item2) {
        return this.getKey(item1) === this.getKey(item2);
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function AuthenticationRootComponent_imx_entity_column_editor_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-entity-column-editor", 3);
    i0.ɵɵlistener("controlCreated", function AuthenticationRootComponent_imx_entity_column_editor_0_Template_imx_entity_column_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.form.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("column", ctx_r1.application.IsAuthenticationIntegrated.Column);
} }
function AuthenticationRootComponent_mat_error_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵpipe(3, "ldsReplace");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind2(3, 3, i0.ɵɵpipeBind1(2, 1, "#LDS#Please specify a value for {0}."), ctx_r1.application.AuthenticationRoot.GetMetadata().GetDisplay()), "\n");
} }
function AuthenticationRootComponent_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 4);
    i0.ɵɵlistener("controlCreated", function AuthenticationRootComponent_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.form.addControl("authenticationRoot", $event)); })("valueChange", function AuthenticationRootComponent_imx_cdr_editor_2_Template_imx_cdr_editor_valueChange_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.form.updateValueAndValidity()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r1.authenticationRootWrapper);
} }
class AuthenticationRootComponent {
    form = new UntypedFormGroup({}, (__) => {
        if (this.application == null) {
            return null;
        }
        const isAuthenticationIntegrated = this.application.IsAuthenticationIntegrated.value;
        const authenticationRootValue = this.application.AuthenticationRootHelper.value;
        return !authenticationRootValue?.length && isAuthenticationIntegrated ? { relationInvalid: true } : null;
    });
    authenticationRootWrapper;
    application;
    controlCreated = new EventEmitter();
    async ngOnInit() {
        const authenticationRootHelper = this.application.AuthenticationRootHelper;
        if (!authenticationRootHelper.value?.length) {
            await authenticationRootHelper.Column.PutValueStruct({
                DataValue: this.application.AuthenticationRoot.value,
                DisplayValue: this.application.AuthenticationRoot.Column.GetDisplayValue(),
            });
        }
        this.authenticationRootWrapper = new BaseCdr(authenticationRootHelper.Column);
        this.controlCreated.emit(this.form);
    }
    static ɵfac = function AuthenticationRootComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AuthenticationRootComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AuthenticationRootComponent, selectors: [["imx-authentication-root"]], inputs: { application: "application" }, outputs: { controlCreated: "controlCreated" }, decls: 3, vars: 3, consts: [[3, "column", "controlCreated", 4, "ngIf"], [4, "ngIf"], [3, "cdr", "controlCreated", "valueChange", 4, "ngIf"], [3, "controlCreated", "column"], [3, "controlCreated", "valueChange", "cdr"]], template: function AuthenticationRootComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, AuthenticationRootComponent_imx_entity_column_editor_0_Template, 1, 1, "imx-entity-column-editor", 0)(1, AuthenticationRootComponent_mat_error_1_Template, 4, 6, "mat-error", 1)(2, AuthenticationRootComponent_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 2);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.application);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.form == null ? null : ctx.form.errors == null ? null : ctx.form.errors.relationInvalid);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.authenticationRootWrapper);
        } }, dependencies: [i6.NgIf, i12$1.MatError, i2.CdrEditorComponent, i2.EntityColumnEditorComponent, i2.LdsReplacePipe, i3.TranslatePipe] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AuthenticationRootComponent, [{
        type: Component,
        args: [{ selector: 'imx-authentication-root', template: "<imx-entity-column-editor\n  *ngIf=\"application\"\n  [column]=\"application.IsAuthenticationIntegrated.Column\"\n  (controlCreated)=\"form.addControl($event.name, $event.control)\"\n>\n</imx-entity-column-editor>\n<mat-error *ngIf=\"form?.errors?.relationInvalid\">\n  {{ '#LDS#Please specify a value for {0}.' | translate | ldsReplace: application.AuthenticationRoot.GetMetadata().GetDisplay() }}\n</mat-error>\n<imx-cdr-editor\n  *ngIf=\"authenticationRootWrapper\"\n  [cdr]=\"authenticationRootWrapper\"\n  (controlCreated)=\"form.addControl('authenticationRoot', $event)\"\n  (valueChange)=\"form.updateValueAndValidity()\"\n>\n</imx-cdr-editor>\n" }]
    }], null, { application: [{
            type: Input
        }], controlCreated: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AuthenticationRootComponent, { className: "AuthenticationRootComponent", filePath: "lib\\applications\\edit-application\\authentication-root\\authentication-root.component.ts", lineNumber: 38 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EditApplicationComponent_div_3_imx_typed_entity_select_8_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-typed-entity-select", 12);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_imx_typed_entity_select_8_Template_imx_typed_entity_select_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.applicationForm.addControl("shops", $event)); })("selectionChanged", function EditApplicationComponent_div_3_imx_typed_entity_select_8_Template_imx_typed_entity_select_selectionChanged_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.shopSelectionChanged($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("data", ctx_r1.shopsData);
} }
function EditApplicationComponent_div_3_imx_typed_entity_select_9_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-typed-entity-select", 12);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_imx_typed_entity_select_9_Template_imx_typed_entity_select_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.applicationForm.addControl("accounts", $event)); })("selectionChanged", function EditApplicationComponent_div_3_imx_typed_entity_select_9_Template_imx_typed_entity_select_selectionChanged_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.accountSelectionChanged($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("data", ctx_r1.accountsData);
} }
function EditApplicationComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div")(1, "imx-application-image-select", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_application_image_select_controlCreated_1_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.applicationForm.addControl(ctx_r1.application.JPegPhoto.Column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_2_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_3_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "imx-entity-column-editor", 9);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_4_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_5_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_6_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_7_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(8, EditApplicationComponent_div_3_imx_typed_entity_select_8_Template, 1, 1, "imx-typed-entity-select", 10)(9, EditApplicationComponent_div_3_imx_typed_entity_select_9_Template, 1, 1, "imx-typed-entity-select", 10);
    i0.ɵɵelementStart(10, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_10_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_11_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "imx-authentication-root", 11);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_authentication_root_controlCreated_12_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.applicationForm.addControl("authRoot", $event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_13_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_14_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(15, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_15_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(16, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_16_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(17, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_17_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(18, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_18_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(19, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_19_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(20, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_20_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addAndValidate($event)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.JPegPhoto == null ? null : ctx_r1.application.JPegPhoto.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.Ident_AOBApplication == null ? null : ctx_r1.application.Ident_AOBApplication.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.Description == null ? null : ctx_r1.application.Description.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.UID_AccProductGroup == null ? null : ctx_r1.application.UID_AccProductGroup.Column)("readonly", true);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.UID_PersonHead == null ? null : ctx_r1.application.UID_PersonHead.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.UID_AERoleOwner == null ? null : ctx_r1.application.UID_AERoleOwner.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.UID_AERoleApprover == null ? null : ctx_r1.application.UID_AERoleApprover.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.shopsData);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.accountsData);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.ApplicationEnvironment == null ? null : ctx_r1.application.ApplicationEnvironment.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.ApplicationWebURL == null ? null : ctx_r1.application.ApplicationWebURL.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("application", ctx_r1.application);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.IsFederationEnabled == null ? null : ctx_r1.application.IsFederationEnabled.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.IsMultiFactorEnabled == null ? null : ctx_r1.application.IsMultiFactorEnabled.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.IsSSOEnabled == null ? null : ctx_r1.application.IsSSOEnabled.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.SSORedirectionUrl == null ? null : ctx_r1.application.SSORedirectionUrl.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.PurchasedLicenses == null ? null : ctx_r1.application.PurchasedLicenses.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.RiskIndex == null ? null : ctx_r1.application.RiskIndex.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.UID_FunctionalArea == null ? null : ctx_r1.application.UID_FunctionalArea.Column);
    i0.ɵɵadvance();
    i0.ɵɵproperty("column", ctx_r1.application == null ? null : ctx_r1.application.NextRunDate == null ? null : ctx_r1.application.NextRunDate.Column);
} }
class EditApplicationComponent {
    logger;
    shopsProvider;
    snackbar;
    busyService;
    accountsProvider;
    errorHandler;
    sidesheetRef;
    confirmation;
    translate;
    ldsReplace;
    application;
    dialog;
    applicationForm = new UntypedFormGroup({});
    shopsData;
    accountsData;
    close = new EventEmitter();
    shopsSelection = new SelectionContainer((item) => item.UID_ITShopOrg.value);
    accountsSelection = new SelectionContainer((item) => item.GetEntity().GetKeys().join());
    constructor(logger, shopsProvider, snackbar, busyService, accountsProvider, errorHandler, sidesheetRef, confirmation, translate, ldsReplace, application, dialog) {
        this.logger = logger;
        this.shopsProvider = shopsProvider;
        this.snackbar = snackbar;
        this.busyService = busyService;
        this.accountsProvider = accountsProvider;
        this.errorHandler = errorHandler;
        this.sidesheetRef = sidesheetRef;
        this.confirmation = confirmation;
        this.translate = translate;
        this.ldsReplace = ldsReplace;
        this.application = application;
        this.dialog = dialog;
        this.sidesheetRef.closeClicked().subscribe(async () => {
            if (!this.hasUnsavedChanges()) {
                await this.cancelProcess();
                return;
            }
            if (await this.confirmation.confirmLeaveWithUnsavedChanges()) {
                await this.cancelProcess();
            }
        });
        this.accountsData = this.getAccountsData();
        this.shopsData = this.getShopsData();
    }
    shopSelectionChanged(selection) {
        this.shopsSelection.selected = selection;
    }
    accountSelectionChanged(selection) {
        this.accountsSelection.selected = selection;
    }
    canSubmit() {
        return this.hasUnsavedChanges() && !this.applicationForm.invalid;
    }
    hasUnsavedChanges() {
        return this.application != null && this.applicationForm.dirty;
    }
    async submitData() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            await this.saveShops();
            await this.saveAccounts();
            this.logger.debug(this, 'submitData - commit application changes...');
            await this.application.GetEntity().Commit(true);
            this.applicationForm.markAsPristine();
            this.close.emit(this.application?.UID_AOBApplication?.value);
            this.snackbar.open({ key: '#LDS#The application has been successfully saved.' }, '#LDS#Close', { duration: 3000 });
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        finally {
            this.busyService.hide();
            this.sidesheetRef.close();
        }
    }
    async cancelProcess() {
        if (this.hasUnsavedChanges()) {
            this.applicationForm.markAsPristine();
            this.snackbar.open({ key: '#LDS#The changes were discarded.' }, '#LDS#Close', { duration: 3000 });
        }
        this.close.emit(this.application?.UID_AOBApplication?.value);
        this.sidesheetRef.close();
    }
    editTranslation() {
        const dialogConfig = {
            data: this.application,
            width: '600px',
        };
        this.dialog.open(TranslationEditorComponent, dialogConfig);
    }
    addAndValidate(event) {
        this.applicationForm.addControl(event.name, event.control);
        event.control.updateValueAndValidity();
    }
    getShopsData() {
        return {
            title: '#LDS#Heading Edit IT Shop Structures',
            valueWrapper: {
                display: this.shopsProvider.display,
                name: 'shops',
                canEdit: true,
            },
            getInitialDisplay: async () => {
                const info = await this.shopsProvider.getFirstAndCount(this.application.UID_AOBApplication.value);
                if (info.first) {
                    return this.buildInitalValue(info.first, info.count);
                }
                return '';
            },
            getSelected: async () => {
                this.shopsSelection.init((await this.shopsProvider.getApplicationInShop(this.application.UID_AOBApplication.value, { PageSize: 100000 }))?.Data || []);
                return this.shopsSelection.selected;
            },
            getTyped: (parameters) => this.shopsProvider.get(parameters),
        };
    }
    async saveShops() {
        if (this.shopsData) {
            this.logger.debug(this, 'submitData - update shops...');
            const result = await this.shopsProvider.updateApplicationInShops(this.application, this.shopsSelection.getChangeSet());
            if (!result) {
                this.logger.error(this, 'Attempt to update the shops failed');
            }
        }
    }
    getAccountsData() {
        return {
            title: '#LDS#Heading Edit User Accounts',
            valueWrapper: {
                display: this.accountsProvider.display,
                name: 'accounts',
                canEdit: true,
            },
            getInitialDisplay: async () => {
                const info = await this.accountsProvider.getFirstAndCount(this.application.UID_AOBApplication.value);
                if (info.first) {
                    return this.buildInitalValue(info.first, info.count);
                }
                return '';
            },
            getSelected: async () => {
                this.accountsSelection.init(await this.accountsProvider.getAssigned(this.application.UID_AOBApplication.value, { PageSize: 100000 }));
                return this.accountsSelection.selected;
            },
            dynamicFkRelation: {
                tables: this.accountsProvider.getCandidateTables(),
                getSelectedTableName: (selected) => {
                    if (selected?.length > 0) {
                        return DbObjectKey.FromXml(selected[0].GetEntity().GetColumn('XObjectKey').GetValue()).TableName;
                    }
                    return '';
                },
            },
        };
    }
    async saveAccounts() {
        if (this.accountsData) {
            this.logger.debug(this, 'submitData - update accounts...');
            const result = await this.accountsProvider.updateApplicationUsesAccounts(this.application, this.accountsSelection.getChangeSet());
            if (!result) {
                this.logger.error(this, 'Attempt to update the accounts failed');
            }
        }
    }
    async buildInitalValue(entity, count) {
        return count < 1
            ? ''
            : count === 1
                ? entity.GetEntity().GetDisplay()
                : this.ldsReplace.transform(await this.translate.get('#LDS#{0} items selected').toPromise(), count);
    }
    static ɵfac = function EditApplicationComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EditApplicationComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(ShopsService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i2.LdsReplacePipe), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1$2.MatDialog)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditApplicationComponent, selectors: [["imx-edit-application"]], outputs: { close: "close" }, decls: 14, vars: 12, consts: [["eui-sidesheet-content", ""], [1, "imx-card-sidesheet"], [3, "formGroup"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["data-imx-identifier", "editApp-translate", "mat-stroked-button", "", "type", "button", 1, "justify-start", 3, "click"], ["data-imx-identifier", "editApp-cancel", "mat-stroked-button", "", "type", "button", 3, "click"], ["data-imx-identifier", "editApp-save", "mat-flat-button", "", "type", "button", "color", "primary", 3, "click", "disabled"], [3, "controlCreated", "column"], [3, "controlCreated", "column", "readonly"], [3, "data", "controlCreated", "selectionChanged", 4, "ngIf"], [3, "controlCreated", "application"], [3, "controlCreated", "selectionChanged", "data"]], template: function EditApplicationComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card", 1)(2, "form", 2);
            i0.ɵɵtemplate(3, EditApplicationComponent_div_3_Template, 21, 21, "div", 3);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(4, "div", 4)(5, "button", 5);
            i0.ɵɵlistener("click", function EditApplicationComponent_Template_button_click_5_listener() { return ctx.editTranslation(); });
            i0.ɵɵtext(6);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(8, "button", 6);
            i0.ɵɵlistener("click", function EditApplicationComponent_Template_button_click_8_listener() { return ctx.cancelProcess(); });
            i0.ɵɵtext(9);
            i0.ɵɵpipe(10, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(11, "button", 7);
            i0.ɵɵlistener("click", function EditApplicationComponent_Template_button_click_11_listener() { return ctx.submitData(); });
            i0.ɵɵtext(12);
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.applicationForm);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.application);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 6, "#LDS#Edit translations"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(10, 8, "#LDS#Cancel"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.canSubmit());
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 10, "#LDS#Save"), " ");
        } }, dependencies: [i6.NgIf, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i7.MatButton, i6$1.MatCard, i12.ɵNgNoValidate, i12.NgControlStatusGroup, i12.FormGroupDirective, i2.TypedEntitySelectComponent, i2.EntityColumnEditorComponent, ApplicationImageSelectComponent, AuthenticationRootComponent, i3.TranslatePipe], encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditApplicationComponent, [{
        type: Component,
        args: [{ selector: 'imx-edit-application', template: "<div eui-sidesheet-content>\n  <mat-card class=\"imx-card-sidesheet\">\n    <form [formGroup]=\"applicationForm\">\n      <div *ngIf=\"application\">\n        <imx-application-image-select\n          [column]=\"application?.JPegPhoto?.Column\"\n          (controlCreated)=\"applicationForm.addControl(application.JPegPhoto.Column.ColumnName, $event)\"\n        >\n        </imx-application-image-select>\n        <imx-entity-column-editor [column]=\"application?.Ident_AOBApplication?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.Description?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor\n          [column]=\"application?.UID_AccProductGroup?.Column\"\n          [readonly]=\"true\"\n          (controlCreated)=\"addAndValidate($event)\"\n        >\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.UID_PersonHead?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.UID_AERoleOwner?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.UID_AERoleApprover?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-typed-entity-select\n          *ngIf=\"shopsData\"\n          [data]=\"shopsData\"\n          (controlCreated)=\"applicationForm.addControl('shops', $event)\"\n          (selectionChanged)=\"shopSelectionChanged($event)\"\n        >\n        </imx-typed-entity-select>\n        <imx-typed-entity-select\n          *ngIf=\"accountsData\"\n          [data]=\"accountsData\"\n          (controlCreated)=\"applicationForm.addControl('accounts', $event)\"\n          (selectionChanged)=\"accountSelectionChanged($event)\"\n        >\n        </imx-typed-entity-select>\n        <imx-entity-column-editor [column]=\"application?.ApplicationEnvironment?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.ApplicationWebURL?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-authentication-root [application]=\"application\" (controlCreated)=\"applicationForm.addControl('authRoot', $event)\">\n        </imx-authentication-root>\n        <imx-entity-column-editor [column]=\"application?.IsFederationEnabled?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.IsMultiFactorEnabled?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.IsSSOEnabled?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.SSORedirectionUrl?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.PurchasedLicenses?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.RiskIndex?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.UID_FunctionalArea?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n        <imx-entity-column-editor [column]=\"application?.NextRunDate?.Column\" (controlCreated)=\"addAndValidate($event)\">\n        </imx-entity-column-editor>\n      </div>\n    </form>\n  </mat-card>\n</div>\n\n<div eui-sidesheet-actions>\n  <button data-imx-identifier=\"editApp-translate\" mat-stroked-button type=\"button\" class=\"justify-start\" (click)=\"editTranslation()\">\n    {{ '#LDS#Edit translations' | translate }}\n  </button>\n  <button data-imx-identifier=\"editApp-cancel\" mat-stroked-button type=\"button\" (click)=\"cancelProcess()\">\n    {{ '#LDS#Cancel' | translate }}\n  </button>\n  <button data-imx-identifier=\"editApp-save\" mat-flat-button type=\"button\" (click)=\"submitData()\" [disabled]=\"!canSubmit()\" color=\"primary\">\n    {{ '#LDS#Save' | translate }}\n  </button>\n</div>\n" }]
    }], () => [{ type: i2.ClassloggerService }, { type: ShopsService }, { type: i2.SnackBarService }, { type: i1.EuiLoadingService }, { type: AccountsService }, { type: i0.ErrorHandler }, { type: i1.EuiSidesheetRef }, { type: i2.ConfirmationService }, { type: i3.TranslateService }, { type: i2.LdsReplacePipe }, { type: i13$2.PortalApplication, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1$2.MatDialog }], { close: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EditApplicationComponent, { className: "EditApplicationComponent", filePath: "lib\\applications\\edit-application\\edit-application.component.ts", lineNumber: 52 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ServiceCategoryService {
    apiClient;
    constructor(apiClient) {
        this.apiClient = apiClient;
    }
    get serviceCategorySchema() {
        return this.apiClient.typedClient.PortalServicecategories.GetSchema();
    }
    async get(parameters = {}) {
        return this.apiClient.typedClient.PortalServicecategories.Get(parameters);
    }
    createChild() {
        const entity = this.apiClient.typedClient.PortalServicecategories.createEntity();
        return entity.GetEntity();
    }
    async delete(uid) {
        return this.apiClient.client.portal_servicecategories_delete(uid);
    }
    static ɵfac = function ServiceCategoryService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ServiceCategoryService)(i0.ɵɵinject(i1$1.QerApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ServiceCategoryService, factory: ServiceCategoryService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ServiceCategoryService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1$1.QerApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EditServiceCategoryInformationComponent_imx_cdr_editor_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 6);
    i0.ɵɵlistener("controlCreated", function EditServiceCategoryInformationComponent_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.formGroup.controls.cdrArray.push($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r3);
    i0.ɵɵattribute("data-imx-identifier", "edit-service-category-information-" + (cdr_r3 == null ? null : cdr_r3.column == null ? null : cdr_r3.column.ColumnName));
} }
class EditServiceCategoryInformationComponent {
    categoryProvider;
    confirm;
    ref;
    cdrFactoryService;
    data;
    cdrList;
    formGroup;
    get formArray() {
        return this.formGroup.controls.cdrArray;
    }
    constructor(categoryProvider, confirm, ref, cdrFactoryService, data) {
        this.categoryProvider = categoryProvider;
        this.confirm = confirm;
        this.ref = ref;
        this.cdrFactoryService = cdrFactoryService;
        this.data = data;
        this.formGroup = new FormGroup({
            cdrArray: new FormArray([]),
        });
        this.ref.closeClicked().subscribe(async () => {
            if (!this.formGroup.dirty || (await this.confirm.confirmLeaveWithUnsavedChanges())) {
                this.ref.close(false);
            }
        });
    }
    async ngOnInit() {
        const schema = this.categoryProvider.serviceCategorySchema;
        const columnNames = [
            schema.Columns.Ident_AccProductGroup,
            schema.Columns.Description,
            schema.Columns.UID_OrgRuler,
            schema.Columns.UID_PWODecisionMethod,
            schema.Columns.UID_OrgAttestator,
            schema.Columns.JPegPhoto,
        ].map((elem) => elem.ColumnName || '');
        this.cdrList = this.cdrFactoryService.buildCdrFromColumnList(this.data.serviceCategory, columnNames);
        if (!this.data.isNew && schema.Columns.UID_AccProductGroupParent.ColumnName) {
            this.cdrList.push(new BaseCdr(this.data.serviceCategory.GetColumn(schema.Columns.UID_AccProductGroupParent.ColumnName)));
        }
    }
    save() {
        this.ref.close(true);
    }
    static ɵfac = function EditServiceCategoryInformationComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EditServiceCategoryInformationComponent)(i0.ɵɵdirectiveInject(ServiceCategoryService), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.CdrFactoryService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditServiceCategoryInformationComponent, selectors: [["imx-edit-service-category-information"]], decls: 8, vars: 3, consts: [["eui-sidesheet-content", ""], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "data-imx-identifier", "edit-service-category-information-button-save", "color", "primary", 3, "click", "disabled"], ["translate", ""], [3, "controlCreated", "cdr"]], template: function EditServiceCategoryInformationComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "form", 1);
            i0.ɵɵtemplate(3, EditServiceCategoryInformationComponent_imx_cdr_editor_3_Template, 1, 2, "imx-cdr-editor", 2);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(4, "div", 3)(5, "button", 4);
            i0.ɵɵlistener("click", function EditServiceCategoryInformationComponent_Template_button_click_5_listener() { return ctx.save(); });
            i0.ɵɵelementStart(6, "span", 5);
            i0.ɵɵtext(7, "#LDS#Save");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.formGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.formGroup.dirty || ctx.formGroup.invalid);
        } }, dependencies: [i6.NgForOf, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i7.MatButton, i6$1.MatCard, i12.ɵNgNoValidate, i12.NgControlStatusGroup, i2.CdrEditorComponent, i12.FormGroupDirective, i3.TranslateDirective] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditServiceCategoryInformationComponent, [{
        type: Component,
        args: [{ selector: 'imx-edit-service-category-information', template: "<div eui-sidesheet-content>\n  <mat-card>\n    <form [formGroup]=\"formGroup\">\n      <imx-cdr-editor\n        *ngFor=\"let cdr of cdrList\"\n        [cdr]=\"cdr\"\n        [attr.data-imx-identifier]=\"'edit-service-category-information-' + cdr?.column?.ColumnName\"\n        (controlCreated)=\"formGroup.controls.cdrArray.push($event)\"\n      >\n      </imx-cdr-editor>\n    </form>\n  </mat-card>\n</div>\n<div eui-sidesheet-actions>\n  <button\n    [disabled]=\"!formGroup.dirty || formGroup.invalid\"\n    mat-flat-button\n    data-imx-identifier=\"edit-service-category-information-button-save\"\n    color=\"primary\"\n    (click)=\"save()\"\n  >\n    <span translate>#LDS#Save</span>\n  </button>\n</div>\n" }]
    }], () => [{ type: ServiceCategoryService }, { type: i2.ConfirmationService }, { type: i1.EuiSidesheetRef }, { type: i2.CdrFactoryService }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EditServiceCategoryInformationComponent, { className: "EditServiceCategoryInformationComponent", filePath: "lib\\applications\\edit-application\\service-category\\edit-service-category-information\\edit-service-category-information.component.ts", lineNumber: 42 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/** Provider of servicecategory-data for the imx-data-tree */
class ServiceCategoryTreeDatabase extends TreeDatabase {
    loadingServiceElemental;
    settings;
    serviceCategoriesProvider;
    uidRootElement;
    constructor(loadingServiceElemental, settings, serviceCategoriesProvider, uidRootElement) {
        super();
        this.loadingServiceElemental = loadingServiceElemental;
        this.settings = settings;
        this.serviceCategoriesProvider = serviceCategoriesProvider;
        this.uidRootElement = uidRootElement;
        this.identifierColumnName = 'FullPath';
        this.canSearch = true;
    }
    async getData(showLoading, parameters = { ParentKey: '' }) {
        if (parameters.ParentKey != '') {
            return this.loadData(showLoading, parameters);
        }
        return this.loadRoot(showLoading);
    }
    async loadRoot(showLoading) {
        let entities;
        if (showLoading && this.loadingServiceElemental.overlayRefs.length === 0) {
            this.loadingServiceElemental.show();
        }
        try {
            const opts = {
                PageSize: 1,
                StartIndex: 0,
                filter: [
                    {
                        ColumnName: 'UID_AccProductGroup',
                        Value1: this.uidRootElement,
                    },
                ],
            };
            const serviceCategories = await this.serviceCategoriesProvider.get(opts);
            entities = {
                entities: serviceCategories?.Data?.map((element) => element.GetEntity()),
                canLoadMore: false,
                totalCount: serviceCategories.totalCount,
            };
        }
        finally {
            if (showLoading) {
                this.loadingServiceElemental.hide();
            }
        }
        return entities;
    }
    async loadData(showLoading, parameters) {
        let entities;
        let overlayRef;
        if (showLoading && this.loadingServiceElemental.overlayRefs.length === 0) {
            this.loadingServiceElemental.show();
        }
        try {
            const opts = {
                PageSize: this.settings.DefaultPageSize,
                StartIndex: 0,
                ...parameters,
            };
            const serviceCategories = await this.serviceCategoriesProvider.get(opts);
            entities = {
                entities: serviceCategories?.Data?.map((element) => element.GetEntity()),
                canLoadMore: opts.StartIndex + opts.PageSize < serviceCategories.totalCount,
                totalCount: serviceCategories.totalCount,
            };
        }
        finally {
            if (showLoading) {
                this.loadingServiceElemental.hide();
            }
        }
        return entities;
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$5 = ["dataTreeWrapper"];
function ServiceCategoryComponent_ng_template_4_button_1_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 7);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵlistener("click", function ServiceCategoryComponent_ng_template_4_button_1_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r3); const entity_r4 = i0.ɵɵnextContext().$implicit; const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.onDelete($event, entity_r4)); });
    i0.ɵɵelement(3, "eui-icon", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_6_0;
    const entity_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 3, "#LDS#Delete service category"));
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(2, 5, "#LDS#Delete service category"))("data-imx-identifier", "service-category-delete-" + ((tmp_6_0 = entity_r4.GetKeys()) == null ? null : tmp_6_0.join(",")));
} }
function ServiceCategoryComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, ServiceCategoryComponent_ng_template_4_button_1_Template, 4, 7, "button", 4);
    i0.ɵɵelementStart(2, "button", 5);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵlistener("click", function ServiceCategoryComponent_ng_template_4_Template_button_click_2_listener($event) { const entity_r4 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.addChildCategory($event, entity_r4)); });
    i0.ɵɵelement(5, "eui-icon", 6);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    let tmp_6_0;
    const entity_r4 = ctx.$implicit;
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r4.isDeletable(entity_r4));
    i0.ɵɵadvance();
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(3, 4, "#LDS#Add child service category"));
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(4, 6, "#LDS#Add child service category"))("data-imx-identifier", "service-category-add-child-for-" + ((tmp_6_0 = entity_r4.GetKeys()) == null ? null : tmp_6_0.join(",")));
} }
class ServiceCategoryComponent {
    categoryService;
    settingsService;
    busyService;
    snackbar;
    sidesheet;
    translate;
    confirm;
    application;
    treeDatabase;
    dataTreeWrapper;
    constructor(categoryService, settingsService, busyService, snackbar, sidesheet, translate, confirm, application) {
        this.categoryService = categoryService;
        this.settingsService = settingsService;
        this.busyService = busyService;
        this.snackbar = snackbar;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.confirm = confirm;
        this.application = application;
        this.initializeTree();
    }
    async onServiceCategorySelected(entity) {
        const oldParent = entity.GetColumn('UID_AccProductGroupParent').GetValue();
        const result = await this.editServiceCategory(entity, 'edit');
        if (result) {
            const overlay = this.busyService.show();
            try {
                await entity.Commit(true);
            }
            catch (exception) {
                await entity.DiscardChanges();
                throw exception;
            }
            finally {
                this.busyService.hide(overlay);
            }
            this.treeDatabase.updateNodeItem(entity);
            if (oldParent !== entity.GetColumn('UID_AccProductGroupParent').GetValue()) {
                this.tryToMoveElement(entity, entity.GetColumn('UID_AccProductGroupParent').GetValue());
                this.snackbar.open({
                    key: '#LDS#The parent of the service category "{0}" has been successfully changed.',
                    parameters: [entity.GetDisplay()],
                });
            }
        }
        else {
            await entity.DiscardChanges();
        }
    }
    async onDelete(evt, entity) {
        evt.stopPropagation();
        if (!(await this.confirm.confirmDelete('#LDS#Heading Delete Service Category', '#LDS#Are you sure you want to delete the service category?'))) {
            return;
        }
        const overlay = this.busyService.show();
        try {
            await this.categoryService.delete(entity.GetKeys()[0]);
        }
        finally {
            this.busyService.hide(overlay);
        }
        this.dataTreeWrapper.deleteNode(entity, false);
        this.snackbar.open({ key: '#LDS#The service category "{0}" has been successfully deleted.', parameters: [entity.GetDisplay()] });
    }
    async addChildCategory(evt, entity) {
        evt.stopPropagation();
        const newEntity = this.categoryService.createChild();
        newEntity.GetColumn('UID_AccProductGroupParent').PutValueStruct({ DataValue: entity.GetKeys()[0], DisplayValue: entity.GetDisplay() });
        const result = await this.editServiceCategory(newEntity, 'create');
        if (result) {
            const overlay = this.busyService.show();
            try {
                await newEntity.Commit(true);
            }
            finally {
                this.busyService.hide(overlay);
            }
            this.snackbar.open({ key: '#LDS#The service category "{0}" has been successfully created.', parameters: [newEntity.GetDisplay()] });
            this.add(entity, newEntity);
        }
        else {
            await entity.DiscardChanges();
        }
    }
    isDeletable(entity) {
        return TreeDatabase.getId(entity) !== this.application.UID_AccProductGroup.value && !this.dataTreeWrapper?.hasChildren(entity);
    }
    tryToMoveElement(entity, newParentId) {
        this.dataTreeWrapper.deleteNode(entity, true);
        const realParent = this.dataTreeWrapper.getEntityById(newParentId);
        if (realParent) {
            this.addToParent(realParent, entity);
        }
    }
    add(entity, newEntity) {
        const parentId = newEntity.GetColumn('UID_AccProductGroupParent').GetValue();
        if (parentId === entity.GetKeys()[0]) {
            // the new category was added as a child
            this.addToParent(entity, newEntity);
        }
        else {
            // the user updated  UID_AccProductGroupParent before saving, try to add a node to the real parent (onöy possible, if the new parent is rendered)
            const realParent = this.dataTreeWrapper.getEntityById(parentId);
            if (realParent) {
                this.addToParent(realParent, newEntity);
            }
        }
    }
    addToParent(entity, newEntity) {
        if (this.dataTreeWrapper.isExpanded(entity)) {
            this.dataTreeWrapper.add(newEntity, TreeDatabase.getId(entity));
        }
        else {
            this.dataTreeWrapper.updateNode(entity, { expandable: true });
            this.dataTreeWrapper.expandNode(entity);
        }
    }
    initializeTree() {
        this.treeDatabase = new ServiceCategoryTreeDatabase(this.busyService, this.settingsService, this.categoryService, this.application.UID_AccProductGroup.value);
        this.treeDatabase.initialized.subscribe(async () => {
            this.dataTreeWrapper.treeRendered.subscribe(() => {
                this.dataTreeWrapper.expandNode(this.treeDatabase.topLevelEntities[0]);
                this.treeDatabase.initialized.unsubscribe(); // can be unsubscribed again, because it only needed for initial loading
            });
        });
    }
    async editServiceCategory(serviceCategory, mode) {
        return await this.sidesheet
            .open(EditServiceCategoryInformationComponent, {
            title: await this.translate.instant(mode === 'edit' ? '#LDS#Heading Edit Service Category' : '#LDS#Heading Create Service Category'),
            subTitle: mode === 'edit' ? serviceCategory.GetDisplay() : '',
            padding: '0px',
            width: calculateSidesheetWidth(1000),
            disableClose: true,
            testId: mode === 'edit' ? 'edit-service-category' : 'create-service-category',
            data: { serviceCategory, isNew: mode === 'create' },
        })
            .afterClosed()
            .toPromise();
    }
    static ɵfac = function ServiceCategoryComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ServiceCategoryComponent)(i0.ɵɵdirectiveInject(ServiceCategoryService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ServiceCategoryComponent, selectors: [["imx-service-category"]], viewQuery: function ServiceCategoryComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$5, 7);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataTreeWrapper = _t.first);
        } }, decls: 5, vars: 2, consts: [["dataTreeWrapper", ""], ["eui-sidesheet-content", ""], [1, "imx-card-fill"], ["data-imx-identifier", "service-category-data-tree-categorytree", 3, "nodeSelected", "database", "withSelectedNodeHighlight"], ["mat-icon-button", "", "color", "warn", 3, "matTooltip", "click", 4, "ngIf"], ["mat-icon-button", "", "color", "primary", 3, "click", "matTooltip"], ["icon", "add"], ["mat-icon-button", "", "color", "warn", 3, "click", "matTooltip"], ["icon", "delete"]], template: function ServiceCategoryComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 1)(1, "mat-card", 2)(2, "imx-data-tree-wrapper", 3, 0);
            i0.ɵɵlistener("nodeSelected", function ServiceCategoryComponent_Template_imx_data_tree_wrapper_nodeSelected_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onServiceCategorySelected($event)); });
            i0.ɵɵtemplate(4, ServiceCategoryComponent_ng_template_4_Template, 6, 8, "ng-template");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("database", ctx.treeDatabase)("withSelectedNodeHighlight", false);
        } }, dependencies: [i6.NgIf, i1.EuiIconComponent, i1.EuiSidesheetContentDirective, i7.MatIconButton, i6$1.MatCard, i8.MatTooltip, i2.DataTreeWrapperComponent, i3.TranslatePipe], encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ServiceCategoryComponent, [{
        type: Component,
        args: [{ selector: 'imx-service-category', template: "<div eui-sidesheet-content>\n  <mat-card class=\"imx-card-fill\">\n    <imx-data-tree-wrapper\n      #dataTreeWrapper\n      [database]=\"treeDatabase\"\n      [withSelectedNodeHighlight]=\"false\"\n      (nodeSelected)=\"onServiceCategorySelected($event)\"\n      data-imx-identifier=\"service-category-data-tree-categorytree\"\n    >\n      <ng-template let-entity>\n        <div>\n          <button\n            *ngIf=\"isDeletable(entity)\"\n            [attr.aria-label]=\"'#LDS#Delete service category' | translate\"\n            [attr.data-imx-identifier]=\"'service-category-delete-' + entity.GetKeys()?.join(',')\"\n            [matTooltip]=\"'#LDS#Delete service category' | translate\"\n            mat-icon-button\n            color=\"warn\"\n            (click)=\"onDelete($event, entity)\"\n          >\n            <eui-icon icon=\"delete\"></eui-icon>\n          </button>\n          <button\n            [attr.aria-label]=\"'#LDS#Add child service category' | translate\"\n            [attr.data-imx-identifier]=\"'service-category-add-child-for-' + entity.GetKeys()?.join(',')\"\n            [matTooltip]=\"'#LDS#Add child service category' | translate\"\n            mat-icon-button\n            color=\"primary\"\n            (click)=\"addChildCategory($event, entity)\"\n          >\n            <eui-icon icon=\"add\"></eui-icon>\n          </button>\n        </div>\n      </ng-template>\n    </imx-data-tree-wrapper>\n  </mat-card>\n</div>\n" }]
    }], () => [{ type: ServiceCategoryService }, { type: i2.SettingsService }, { type: i1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i1.EuiSidesheetService }, { type: i3.TranslateService }, { type: i2.ConfirmationService }, { type: i13$2.PortalApplication, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }], { dataTreeWrapper: [{
            type: ViewChild,
            args: ['dataTreeWrapper', { static: true }]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ServiceCategoryComponent, { className: "ServiceCategoryComponent", filePath: "lib\\applications\\edit-application\\service-category\\service-category.component.ts", lineNumber: 49 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$4 = ["*"];
function ApplicationPropertyComponent_eui_icon_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 3);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("icon", ctx_r0.icon);
} }
class ApplicationPropertyComponent {
    display;
    icon;
    static ɵfac = function ApplicationPropertyComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationPropertyComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationPropertyComponent, selectors: [["imx-application-property"]], inputs: { display: "display", icon: "icon" }, ngContentSelectors: _c0$4, decls: 5, vars: 2, consts: [["class", "imx-icon-circle", 3, "icon", 4, "ngIf"], [1, "imx-application-property"], [1, "imx-application-property-display"], [1, "imx-icon-circle", 3, "icon"]], template: function ApplicationPropertyComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵtemplate(0, ApplicationPropertyComponent_eui_icon_0_Template, 1, 1, "eui-icon", 0);
            i0.ɵɵelementStart(1, "div", 1);
            i0.ɵɵprojection(2);
            i0.ɵɵelementStart(3, "span", 2);
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.icon);
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(ctx.display);
        } }, dependencies: [i6.NgIf, i1.EuiIconComponent], styles: ["[_nghost-%COMP%]{display:flex;align-items:center;justify-items:center;min-height:40px}.imx-application-property[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-application-property[_ngcontent-%COMP%]   .imx-application-property-display[_ngcontent-%COMP%]{font-size:12px;color:#aab0b3;font-weight:600;overflow:hidden;text-overflow:ellipsis}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationPropertyComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-property', template: "<eui-icon *ngIf=\"icon\" class=\"imx-icon-circle\" [icon]=\"icon\"></eui-icon>\n<div class=\"imx-application-property\">\n  <ng-content></ng-content>\n  <span class=\"imx-application-property-display\">{{ display }}</span>\n</div>\n", styles: [":host{display:flex;align-items:center;justify-items:center;min-height:40px}.imx-application-property{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-application-property .imx-application-property-display{font-size:12px;color:#aab0b3;font-weight:600;overflow:hidden;text-overflow:ellipsis}\n"] }]
    }], null, { display: [{
            type: Input
        }], icon: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ApplicationPropertyComponent, { className: "ApplicationPropertyComponent", filePath: "lib\\application-property\\application-property.component.ts", lineNumber: 34 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ColumnInfoComponent {
    property;
    icon;
    placeholder;
    static ɵfac = function ColumnInfoComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ColumnInfoComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ColumnInfoComponent, selectors: [["imx-column-info"]], inputs: { property: "property", icon: "icon", placeholder: "placeholder" }, decls: 5, vars: 5, consts: [[3, "display", "icon"], [1, "imx-user-properties"]], template: function ColumnInfoComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "imx-application-property", 0)(1, "div", 1)(2, "span");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            let tmp_0_0;
            i0.ɵɵproperty("display", ctx.property == null ? null : ctx.property.Column == null ? null : (tmp_0_0 = ctx.property.Column.GetMetadata()) == null ? null : tmp_0_0.GetDisplay())("icon", ctx.icon);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate((ctx.property == null ? null : ctx.property.Column == null ? null : ctx.property.Column.GetDisplayValue()) || "-" + (ctx.placeholder || i0.ɵɵpipeBind1(4, 3, "#LDS#Not set")) + "-");
        } }, dependencies: [ApplicationPropertyComponent, i3.TranslatePipe], styles: [".imx-user-properties[_ngcontent-%COMP%]{overflow:hidden;text-overflow:ellipsis}.imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-weight:600;color:#616566}.eui-dark-theme   [_nghost-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#fff}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ColumnInfoComponent, [{
        type: Component,
        args: [{ selector: 'imx-column-info', template: "<imx-application-property [display]=\"property?.Column?.GetMetadata()?.GetDisplay()\" [icon]=\"icon\">\n  <div class=\"imx-user-properties\">\n    <span>{{ property?.Column?.GetDisplayValue() || '-' + (placeholder || ('#LDS#Not set' | translate)) + '-' }}</span>\n  </div>\n</imx-application-property>\n", styles: [".imx-user-properties{overflow:hidden;text-overflow:ellipsis}.imx-user-properties>span{font-weight:600;color:#616566}.eui-dark-theme :host .imx-user-properties>span{color:#dfe4e6}.eui-contrast-theme :host .imx-user-properties>span{color:#fff}\n"] }]
    }], null, { property: [{
            type: Input
        }], icon: [{
            type: Input
        }], placeholder: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ColumnInfoComponent, { className: "ColumnInfoComponent", filePath: "lib\\column-info\\column-info.component.ts", lineNumber: 36 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$3 = ["multiValueControl"];
const _c1$3 = a0 => ({ hidden: a0 });
function ApplicationDetailsComponent_imx_busy_indicator_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-busy-indicator");
} }
function ApplicationDetailsComponent_span_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate("-" + i0.ɵɵpipeBind1(2, 1, "#LDS#None assigned") + "-");
} }
function ApplicationDetailsComponent_span_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.assignedShops[0].GetEntity().GetDisplay());
} }
function ApplicationDetailsComponent_button_16_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 27);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_button_16_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.showMore(ctx_r0.assignedShops, ctx_r0.shopsDisplay, "library")); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵpipe(3, "ldsReplace");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind2(3, 3, i0.ɵɵpipeBind1(2, 1, "#LDS#and {0} more..."), ctx_r0.assignedShops.length - 1), " ");
} }
function ApplicationDetailsComponent_span_24_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 28);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Not published"));
} }
function ApplicationDetailsComponent_span_25_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 29);
    i0.ɵɵelement(1, "eui-icon", 30);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Will be published"), " ");
} }
function ApplicationDetailsComponent_span_26_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 31)(1, "mat-icon", 32);
    i0.ɵɵtext(2, "check_circle");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 1, "#LDS#Published"), " ");
} }
function ApplicationDetailsComponent_div_27_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 33)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "shortDate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 1, (ctx_r0.application == null ? null : ctx_r0.application.ActivationDate == null ? null : ctx_r0.application.ActivationDate.value == null ? null : ctx_r0.application.ActivationDate.value.toString()) || ""));
} }
function ApplicationDetailsComponent_span_89_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate("-" + i0.ɵɵpipeBind1(2, 1, "#LDS#None selected") + "-");
} }
function ApplicationDetailsComponent_span_90_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_2_0;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.accountsInformation.first == null ? null : (tmp_2_0 = ctx_r0.accountsInformation.first.GetEntity()) == null ? null : tmp_2_0.GetDisplay());
} }
function ApplicationDetailsComponent_button_91_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 34);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_button_91_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.showMoreAccounts()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵpipe(3, "ldsReplace");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind2(3, 3, i0.ɵɵpipeBind1(2, 1, "#LDS#and {0} more..."), ctx_r0.accountsInformation.count - 1), " ");
} }
function ApplicationDetailsComponent_mat_card_103_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 35)(1, "button", 36)(2, "eui-icon", 37);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_eui_icon_click_2_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.menuClicked($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "mat-menu", null, 1)(7, "button", 38);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_7_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.publishApplication($event)); });
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(10, "button", 39);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_10_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.unpublishApplication($event)); });
    i0.ɵɵtext(11);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "button", 40);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_13_listener() { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.editServiceCategories()); });
    i0.ɵɵtext(14);
    i0.ɵɵpipe(15, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(16, "button", 41);
    i0.ɵɵpipe(17, "translate");
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_16_listener() { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.deleteApplication()); });
    i0.ɵɵelement(18, "eui-icon", 42);
    i0.ɵɵtext(19);
    i0.ɵɵpipe(20, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(21, "button", 43);
    i0.ɵɵpipe(22, "translate");
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_21_listener() { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.editApplication()); });
    i0.ɵɵelement(23, "eui-icon", 44);
    i0.ɵɵtext(24);
    i0.ɵɵpipe(25, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const menu_r5 = i0.ɵɵreference(6);
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("matMenuTriggerFor", menu_r5);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 12, "#LDS#Actions"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵproperty("disabled", !ctx_r0.isPublishable);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 14, "#LDS#Publish"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r0.isUnpublishable);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(12, 16, "#LDS#Unpublish"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(15, 18, "#LDS#Manage service categories"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r0.canBeDeleted);
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(17, 20, "#LDS#Delete application"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(20, 22, "#LDS#Delete"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(22, 24, "#LDS#Edit Application"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(25, 26, "#LDS#Edit"), " ");
} }
function ApplicationDetailsComponent_ng_template_104_li_4_eui_icon_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 51);
} if (rf & 2) {
    const data_r6 = i0.ɵɵnextContext(2).$implicit;
    i0.ɵɵproperty("icon", data_r6.icon);
} }
function ApplicationDetailsComponent_ng_template_104_li_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 48)(1, "mat-card");
    i0.ɵɵtemplate(2, ApplicationDetailsComponent_ng_template_104_li_4_eui_icon_2_Template, 1, 1, "eui-icon", 49);
    i0.ɵɵelementStart(3, "mat-card-title", 50);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const content_r7 = ctx.$implicit;
    const data_r6 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵattribute("data-imx-identifier", "imx-application-details-" + data_r6.caption + "-" + content_r7);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", data_r6.icon);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(content_r7);
} }
function ApplicationDetailsComponent_ng_template_104_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 45);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "mat-dialog-content")(3, "ul");
    i0.ɵɵtemplate(4, ApplicationDetailsComponent_ng_template_104_li_4_Template, 5, 3, "li", 46);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(5, "mat-dialog-actions")(6, "button", 47);
    i0.ɵɵtext(7);
    i0.ɵɵpipe(8, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const data_r6 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(data_r6.caption);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngForOf", data_r6.parts);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 3, "#LDS#Close"), " ");
} }
class ApplicationDetailsComponent {
    entitlementsProvider;
    shopsProvider;
    euiBusyService;
    logger;
    accountsProvider;
    dialog;
    applicationprovider;
    snackbar;
    platform;
    aobApiService;
    translateService;
    confirmation;
    sidesheetService;
    permissions;
    /**
     * The {@link PortalApplication | AobApplication}
     */
    application;
    chartDialog;
    menuTrigger;
    hasAssignedEntitlements;
    hasPublishedEntitlements = false;
    canBeDeleted = false;
    hasOwner;
    accountsInformation;
    assignedShops = [];
    shopsDisplay;
    accountsDisplay;
    busyService = new BusyService();
    isLoading;
    constructor(entitlementsProvider, shopsProvider, euiBusyService, logger, accountsProvider, dialog, applicationprovider, snackbar, platform, aobApiService, translateService, confirmation, sidesheetService, permissions) {
        this.entitlementsProvider = entitlementsProvider;
        this.shopsProvider = shopsProvider;
        this.euiBusyService = euiBusyService;
        this.logger = logger;
        this.accountsProvider = accountsProvider;
        this.dialog = dialog;
        this.applicationprovider = applicationprovider;
        this.snackbar = snackbar;
        this.platform = platform;
        this.aobApiService = aobApiService;
        this.translateService = translateService;
        this.confirmation = confirmation;
        this.sidesheetService = sidesheetService;
        this.permissions = permissions;
        this.shopsDisplay = this.aobApiService.typedClient.PortalShops.GetSchema().Display || '';
        this.accountsDisplay = this.aobApiService.typedClient.PortalApplicationusesaccount.GetSchema().Display || '';
        this.busyService.busyStateChanged.subscribe((elem) => (this.isLoading = elem));
    }
    ngOnInit() {
        this.accountsInformation = {
            count: 0,
            first: undefined,
            uidApplication: this.application?.UID_AOBApplication.value || '',
        };
    }
    async ngOnChanges() {
        return this.reloadData();
    }
    /**
     * Deletes the displayed application, after confirming the process by the user
     */
    async deleteApplication() {
        if (await this.confirmation.confirm({
            Title: '#LDS#Heading Delete Application',
            Message: '#LDS#Are you sure you want to delete the application?',
        })) {
            if (this.euiBusyService.overlayRefs.length === 0) {
                this.euiBusyService.show();
            }
            try {
                if (!!this.application) {
                    await this.applicationprovider.deleteApplication(this.application.UID_AOBApplication.value);
                }
            }
            finally {
                this.euiBusyService.hide();
            }
        }
    }
    /**
     * Edits the information of the associated application
     */
    async editApplication() {
        await this.sidesheetService
            .open(EditApplicationComponent, {
            title: await this.translateService.get('#LDS#Heading Edit Application').toPromise(),
            subTitle: this.application?.GetEntity().GetDisplay(),
            width: calculateSidesheetWidth(800),
            padding: '0',
            data: this.application,
            testId: 'edit-application',
            disableClose: true,
        })
            .afterClosed()
            .toPromise();
        this.applicationprovider.applicationRefresh.next(true);
        if (this.application) {
            this.application = await this.applicationprovider.reload(this.application?.UID_AOBApplication.value);
        }
        this.reloadData();
    }
    /**
     * Opens a dialog for publishing the application
     * @ignore @param _ unused mouse event
     */
    async publishApplication(_) {
        if (await this.updateShops()) {
            const dialogConfig = {
                data: {
                    action: LifecycleAction.Publish,
                    elements: [this.application],
                    shops: this.assignedShops,
                    type: 'AobApplication',
                },
                height: this.platform.TRIDENT ? '550px' : 'auto',
            };
            const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
            dialogRef.afterClosed().subscribe(async (publishData) => {
                if (publishData) {
                    this.logger.debug(this, `Publishing application) ${publishData.date && publishData.publishFuture ? `on ${publishData.date}` : 'now'}`);
                    if (!!this.application && (await this.applicationprovider.publish(this.application, publishData))) {
                        let publishMessage = {
                            key: '#LDS#The application was successfully published. It takes a moment for the changes to take effect.',
                        };
                        if (publishData.publishFuture && publishData.date) {
                            const browserCulture = this.translateService.currentLang;
                            publishMessage = {
                                key: '#LDS#The application will be published on {0} at {1} (your local time).',
                                parameters: [publishData.date.toLocaleDateString(browserCulture), publishData.date.toLocaleTimeString(browserCulture)],
                            };
                        }
                        this.snackbar.open(publishMessage, '#LDS#Close');
                    }
                    else {
                        this.logger.error(this, 'Attempt to publish the application failed');
                    }
                }
                else {
                    this.logger.debug(this, 'dialog Cancel');
                }
            });
        }
    }
    /**
     * Opens a dialog for unpublishing the application
     * @ignore @param _ unused mouse event
     */
    unpublishApplication(_) {
        const dialogConfig = {
            data: { action: LifecycleAction.Unpublish, elements: [this.application], type: 'AobApplication' },
            width: '800px',
            height: '500px',
        };
        const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(async (result) => {
            if (result) {
                this.logger.debug(this, 'Unpublish application...');
                if (this.application && (await this.applicationprovider.unpublish(this.application))) {
                    this.snackbar.open({ key: '#LDS#The application was successfully unpublished. It takes a moment for the changes to take effect.' }, '#LDS#Close');
                }
                else {
                    this.logger.error(this, 'Attempt to unpublish the  application failed');
                }
            }
            else {
                this.logger.debug(this, 'dialog Cancel');
            }
        });
    }
    /**
     * Checks if the specified  {@link PortalApplication|application} can be publish.
     */
    get isPublishable() {
        return this.application != null && this.application?.ActivationDate.GetMetadata().CanEdit() && !this.published();
    }
    /**
     * Checks if the specified  {@link PortalApplication|application} can be unnpublish.
     */
    get isUnpublishable() {
        return this.application != null && this.application?.IsInActive.GetMetadata().CanEdit() && !this.notPublished();
    }
    // TODO 222863: Use the same filter as for entitlements:
    notPublished() {
        return !!this.application?.IsInActive && !!this.application?.IsInActive.value && !this.application?.ActivationDate.value;
    }
    willPublish() {
        return !!this.application?.IsInActive && !!this.application?.IsInActive.value && this.application?.ActivationDate.value != null;
    }
    published() {
        return !this.application?.IsInActive.value;
    }
    /**
     * Opens/Closes the menu programmatically and stopps propagation of the event.
     * Otherwise the tile would be selected/deselcted as a sideeffect.
     * @ignore Used internally in components template.
     */
    menuClicked(event) {
        this.menuTrigger.toggleMenu();
        event.stopImmediatePropagation();
    }
    /**
     *
     * @param elements Opens a dialog, that shows additional elements (because in the beginning there are only 3 elements displayed)
     * @param title A title for the dialog
     * @param iconText name of a cadence icon, that should be used
     */
    showMore(elements, title, iconText) {
        const content = { parts: elements.map((part) => part.GetEntity().GetDisplay()), caption: title, icon: iconText };
        this.dialog.open(this.chartDialog, { data: content, width: '600px' });
    }
    /**
     * Shows a dialog, that displays additionals accounts (because in the beginning there are only 3 elements displayed)
     */
    async showMoreAccounts() {
        if (this.euiBusyService.overlayRefs.length === 0) {
            this.euiBusyService.show();
        }
        try {
            if (!!this.application) {
                const elements = await this.accountsProvider.getAssigned(this.application.UID_AOBApplication.value, {
                    PageSize: this.accountsInformation.count,
                });
                this.showMore(elements, this.accountsDisplay);
            }
        }
        finally {
            this.euiBusyService.hide();
        }
    }
    async editServiceCategories() {
        await this.sidesheetService
            .open(ServiceCategoryComponent, {
            title: await this.translateService.get('#LDS#Heading Manage Service Categories').toPromise(),
            subTitle: this.application?.GetEntity().GetDisplay(),
            width: calculateSidesheetWidth(),
            padding: '0',
            data: this.application,
            testId: 'edit-application-servicecategory',
        })
            .afterClosed()
            .toPromise();
    }
    async reloadData() {
        const isBusy = this.busyService.beginBusy();
        try {
            if (this.application?.AuthenticationRoot.value) {
                this.application.AuthenticationRootHelper.value = this.application?.AuthenticationRoot.value;
            }
            this.hasOwner = this.application?.UID_PersonHead.value != null && this.application?.UID_PersonHead.value !== '';
            await this.updateShops();
            const accountInfo = !!this.application
                ? await this.accountsProvider.getFirstAndCount(this.application.UID_AOBApplication.value)
                : { count: 0, first: undefined };
            this.accountsInformation = {
                ...this.accountsInformation,
                ...{ count: accountInfo.count, first: accountInfo.first },
                ...{ count: accountInfo.count, first: accountInfo.first },
            };
            const applicationEntitlements = !!this.application
                ? await this.entitlementsProvider.getEntitlementsForApplication(this.application)
                : undefined;
            if (!!applicationEntitlements) {
                const entitlementFilter = new EntitlementFilter();
                this.hasPublishedEntitlements = applicationEntitlements.Data.filter(entitlementFilter.published).length > 0;
                this.hasAssignedEntitlements = applicationEntitlements.Data.length > 0;
                const publishedAndWillBePublished = applicationEntitlements.Data.filter((elem) => entitlementFilter.published(elem) || entitlementFilter.willPublish(elem));
                this.canBeDeleted = (await this.permissions.isAobApplicationAdmin()) && publishedAndWillBePublished.length === 0;
            }
            else {
                this.logger.error(this, 'TypedEntityCollectionData<PortalEntitlement> is undefined');
            }
        }
        finally {
            isBusy.endBusy();
        }
    }
    async updateShops() {
        const appInShop = !!this.application
            ? await this.shopsProvider.getApplicationInShop(this.application.UID_AOBApplication.value)
            : undefined;
        if (!!appInShop) {
            this.assignedShops = appInShop.Data;
            return true;
        }
        this.logger.error(this, 'TypedEntityCollectionData<AobApplicationinshop> is undefined');
        this.assignedShops = [];
        return false;
    }
    static ɵfac = function ApplicationDetailsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationDetailsComponent)(i0.ɵɵdirectiveInject(EntitlementsService), i0.ɵɵdirectiveInject(ShopsService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i5.Platform), i0.ɵɵdirectiveInject(AobApiService), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(AobPermissionsService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationDetailsComponent, selectors: [["imx-application-details"]], viewQuery: function ApplicationDetailsComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$3, 7);
            i0.ɵɵviewQuery(MatMenuTrigger, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.chartDialog = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.menuTrigger = _t.first);
        } }, inputs: { application: "application" }, features: [i0.ɵɵNgOnChangesFeature], decls: 106, vars: 86, consts: [["multiValueControl", ""], ["menu", "matMenu"], [1, "imx-application-details-content"], [4, "ngIf"], [1, "imx-application-details-grid", 3, "ngClass"], [1, "imx-application-properties", "mat-elevation-z0"], [3, "inset"], ["icon", "serviceaccount", 3, "placeholder", "property"], ["icon", "user", 3, "property"], ["icon", "library", 3, "display"], [1, "imx-application-property-multi"], ["mat-button", "", "color", "primary", "data-imx-identifier", "imx-application-details-button-show-more-shops", 3, "click", 4, "ngIf"], [1, "imx-application-state", "mat-elevation-z0"], [1, "imx-application-publish", "mat-elevation-z0"], ["class", "imx-application-unpublished-state", 4, "ngIf"], ["class", "imx-application-willbepublished-state", 4, "ngIf"], ["class", "imx-application-published-state", 4, "ngIf"], ["class", "imx-application-publish-date", 4, "ngIf"], [1, "imx-application-progress", "mat-elevation-z0"], [1, "imx-application-progress-step"], [1, "imx-margin-right-5", "imx-icon-size-16", "imx-icon-new", 3, "ngClass"], [1, "cdk-visually-hidden"], [1, "imx-application-additionalDetails", "mat-elevation-z0"], [3, "property"], [3, "display"], ["mat-button", "", "color", "primary", "data-imx-identifier", "imx-application-details-button-load-more-accounts", 3, "click", 4, "ngIf"], ["class", "imx-padding-15 imx-button-bar imx-button-icon-14 mat-elevation-z0", 4, "ngIf"], ["mat-button", "", "color", "primary", "data-imx-identifier", "imx-application-details-button-show-more-shops", 3, "click"], [1, "imx-application-unpublished-state"], [1, "imx-application-willbepublished-state"], ["icon", "restore", "size", "14px"], [1, "imx-application-published-state"], [1, "imx-icon-size-14", "imx-icon-new"], [1, "imx-application-publish-date"], ["mat-button", "", "color", "primary", "data-imx-identifier", "imx-application-details-button-load-more-accounts", 3, "click"], [1, "imx-padding-15", "imx-button-bar", "imx-button-icon-14", "mat-elevation-z0"], ["mat-stroked-button", "", "data-imx-identifier", "imx-application-details-button-menu", 1, "justify-start", 3, "matMenuTriggerFor"], ["icon", "ellipsisvertical", 3, "click"], ["mat-menu-item", "", "data-imx-identifier", "imx-application-details-button-publish-application", 3, "click", "disabled"], ["mat-menu-item", "", "data-imx-identifier", "imx-application-details-button-unpublish-application", 3, "click", "disabled"], ["data-imx-identifier", "imx-application-details-edit-servicecategories", "mat-menu-item", "", 3, "click"], ["mat-stroked-button", "", "color", "warn", "data-imx-identifier", "imx-application-details-button-delete-application", 3, "click", "disabled"], ["icon", "delete"], ["color", "primary", "mat-flat-button", "", "data-imx-identifier", "imx-application-details-button-edit-application", 3, "click"], ["icon", "edit"], ["mat-dialog-title", ""], ["class", "imx-multivalue-item", 4, "ngFor", "ngForOf"], ["data-imx-identifier", "imx-application-details-button-close-list", "mat-flat-button", "", "color", "primary", "mat-dialog-close", ""], [1, "imx-multivalue-item"], ["mat-card-avatar", "", "size", "16px", 3, "icon", 4, "ngIf"], [1, "imx-card-title"], ["mat-card-avatar", "", "size", "16px", 3, "icon"]], template: function ApplicationDetailsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 2);
            i0.ɵɵtemplate(1, ApplicationDetailsComponent_imx_busy_indicator_1_Template, 1, 0, "imx-busy-indicator", 3);
            i0.ɵɵelementStart(2, "div", 4)(3, "mat-card", 5)(4, "mat-card-title");
            i0.ɵɵtext(5);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(7, "mat-divider", 6);
            i0.ɵɵelementStart(8, "mat-card-content");
            i0.ɵɵelement(9, "imx-column-info", 7);
            i0.ɵɵpipe(10, "translate");
            i0.ɵɵelement(11, "imx-column-info", 8);
            i0.ɵɵelementStart(12, "imx-application-property", 9)(13, "div", 10);
            i0.ɵɵtemplate(14, ApplicationDetailsComponent_span_14_Template, 3, 3, "span", 3)(15, ApplicationDetailsComponent_span_15_Template, 2, 1, "span", 3)(16, ApplicationDetailsComponent_button_16_Template, 4, 6, "button", 11);
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(17, "mat-card", 12)(18, "mat-card", 13)(19, "mat-card-title");
            i0.ɵɵtext(20);
            i0.ɵɵpipe(21, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(22, "mat-divider", 6);
            i0.ɵɵelementStart(23, "mat-card-content");
            i0.ɵɵtemplate(24, ApplicationDetailsComponent_span_24_Template, 3, 3, "span", 14)(25, ApplicationDetailsComponent_span_25_Template, 4, 3, "span", 15)(26, ApplicationDetailsComponent_span_26_Template, 5, 3, "span", 16)(27, ApplicationDetailsComponent_div_27_Template, 4, 3, "div", 17);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(28, "mat-card", 18)(29, "mat-card-title");
            i0.ɵɵtext(30);
            i0.ɵɵpipe(31, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(32, "mat-divider", 6);
            i0.ɵɵelementStart(33, "mat-card-content")(34, "div", 19)(35, "mat-icon", 20);
            i0.ɵɵtext(36, " check_circle ");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(37, "span", 21);
            i0.ɵɵtext(38);
            i0.ɵɵpipe(39, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(40, "span");
            i0.ɵɵtext(41);
            i0.ɵɵpipe(42, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(43, "div", 19)(44, "mat-icon", 20);
            i0.ɵɵtext(45, " check_circle ");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(46, "span", 21);
            i0.ɵɵtext(47);
            i0.ɵɵpipe(48, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(49, "span");
            i0.ɵɵtext(50);
            i0.ɵɵpipe(51, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(52, "div", 19)(53, "mat-icon", 20);
            i0.ɵɵtext(54, " check_circle ");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(55, "span", 21);
            i0.ɵɵtext(56);
            i0.ɵɵpipe(57, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(58, "span");
            i0.ɵɵtext(59);
            i0.ɵɵpipe(60, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(61, "div", 19)(62, "mat-icon", 20);
            i0.ɵɵtext(63, " check_circle ");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(64, "span", 21);
            i0.ɵɵtext(65);
            i0.ɵɵpipe(66, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(67, "span");
            i0.ɵɵtext(68);
            i0.ɵɵpipe(69, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(70, "div", 19)(71, "mat-icon", 20);
            i0.ɵɵtext(72, " check_circle ");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(73, "span", 21);
            i0.ɵɵtext(74);
            i0.ɵɵpipe(75, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(76, "span");
            i0.ɵɵtext(77);
            i0.ɵɵpipe(78, "translate");
            i0.ɵɵelementEnd()()()()();
            i0.ɵɵelementStart(79, "mat-card", 22)(80, "mat-card-title");
            i0.ɵɵtext(81);
            i0.ɵɵpipe(82, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(83, "mat-divider", 6);
            i0.ɵɵelementStart(84, "mat-card-content");
            i0.ɵɵelement(85, "imx-column-info", 23)(86, "imx-column-info", 23);
            i0.ɵɵelementStart(87, "imx-application-property", 24)(88, "div", 10);
            i0.ɵɵtemplate(89, ApplicationDetailsComponent_span_89_Template, 3, 3, "span", 3)(90, ApplicationDetailsComponent_span_90_Template, 2, 1, "span", 3)(91, ApplicationDetailsComponent_button_91_Template, 4, 6, "button", 25);
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(92, "imx-column-info", 23)(93, "imx-column-info", 23)(94, "imx-column-info", 23)(95, "imx-column-info", 23)(96, "imx-column-info", 23)(97, "imx-column-info", 23)(98, "imx-column-info", 23)(99, "imx-column-info", 23)(100, "imx-column-info", 23)(101, "imx-column-info", 23)(102, "imx-column-info", 23);
            i0.ɵɵelementEnd()()()();
            i0.ɵɵtemplate(103, ApplicationDetailsComponent_mat_card_103_Template, 26, 28, "mat-card", 26)(104, ApplicationDetailsComponent_ng_template_104_Template, 9, 5, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isLoading);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(84, _c1$3, ctx.isLoading));
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 54, "#LDS#General"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("inset", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("placeholder", i0.ɵɵpipeBind1(10, 56, "#LDS#Is being computed"))("property", ctx.application == null ? null : ctx.application.UID_AccProductGroup);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.UID_AERoleOwner);
            i0.ɵɵadvance();
            i0.ɵɵproperty("display", ctx.shopsDisplay);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !ctx.assignedShops.length);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.assignedShops.length);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.assignedShops.length > 1);
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(21, 58, "#LDS#Publication status"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("inset", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.notPublished());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.willPublish());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.published());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.willPublish());
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(31, 60, "#LDS#Progress"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("inset", true);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngClass", ctx.application ? "imx-icon-visible" : "imx-icon-hidden");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(39, 62, ctx.application ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(42, 64, "#LDS#Application created"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngClass", ctx.hasOwner ? "imx-icon-visible" : "imx-icon-hidden");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(48, 66, ctx.hasOwner ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(51, 68, "#LDS#Manager assigned"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngClass", !!(ctx.assignedShops == null ? null : ctx.assignedShops.length) ? "imx-icon-visible" : "imx-icon-hidden");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(57, 70, !!(ctx.assignedShops == null ? null : ctx.assignedShops.length) ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(60, 72, "#LDS#Shop assigned"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngClass", ctx.hasAssignedEntitlements ? "imx-icon-visible" : "imx-icon-hidden");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(66, 74, ctx.hasAssignedEntitlements ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(69, 76, "#LDS#Application entitlements assigned"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngClass", ctx.hasPublishedEntitlements ? "imx-icon-visible" : "imx-icon-hidden");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(75, 78, ctx.hasPublishedEntitlements ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(78, 80, "#LDS#Application entitlements published"));
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(82, 82, "#LDS#Additional details"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("inset", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.UID_PersonHead);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.UID_AERoleApprover);
            i0.ɵɵadvance();
            i0.ɵɵproperty("display", ctx.accountsDisplay);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.accountsInformation.count === 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.accountsInformation.count > 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.accountsInformation.count > 1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.ApplicationEnvironment);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.ApplicationWebURL);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.AuthenticationRoot);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.IsAuthenticationIntegrated);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.IsFederationEnabled);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.IsMultiFactorEnabled);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.IsSSOEnabled);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.SSORedirectionUrl);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.PurchasedLicenses);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.RiskIndex);
            i0.ɵɵadvance();
            i0.ɵɵproperty("property", ctx.application == null ? null : ctx.application.UID_FunctionalArea);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.application && !ctx.isLoading);
        } }, dependencies: [i6.NgClass, i6.NgForOf, i6.NgIf, ApplicationPropertyComponent, ColumnInfoComponent, i1.EuiIconComponent, i7.MatButton, i6$1.MatCard, i6$1.MatCardAvatar, i6$1.MatCardContent, i6$1.MatCardTitle, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogActions, i1$2.MatDialogContent, i12$2.MatDivider, i18.MatIcon, i13$1.MatMenu, i13$1.MatMenuItem, i13$1.MatMenuTrigger, i2.BusyIndicatorComponent, i2.LdsReplacePipe, i2.ShortDatePipe, i3.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto;min-height:100%}[_nghost-%COMP%]   .imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid.hidden[_ngcontent-%COMP%]{display:none}.imx-application-details-content[_ngcontent-%COMP%]{display:flex;flex-direction:row;flex:1 1 auto;overflow:hidden}.imx-application-details-content[_ngcontent-%COMP%]   imx-busy-indicator[_ngcontent-%COMP%]{flex:0 0 0}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%]{display:flex;flex-direction:row;overflow:auto;max-height:800px;max-width:1500px;flex-wrap:wrap;padding:16px 24px}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%] > .mat-mdc-card[_ngcontent-%COMP%]{background-color:transparent}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%]   .mat-mdc-card-title[_ngcontent-%COMP%]{font-size:18px;line-height:36px}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%]   .mat-divider-horizontal[_ngcontent-%COMP%]{width:50px;margin-bottom:12px}.imx-application-properties[_ngcontent-%COMP%]{flex:0 0 33%;min-width:200px;box-shadow:none}.imx-application-properties[_ngcontent-%COMP%]   .mat-mdc-card-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;margin-bottom:-15px}.imx-application-properties[_ngcontent-%COMP%]   .mat-mdc-card-content[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{margin-bottom:15px}.imx-application-property-multi[_ngcontent-%COMP%]{display:flex;flex-direction:column}.imx-application-property-multi[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-weight:600;overflow:hidden;text-overflow:ellipsis}.imx-application-property-multi[_ngcontent-%COMP%] > .mat-mdc-button[_ngcontent-%COMP%]{line-height:1.3rem;align-self:flex-start}li[_ngcontent-%COMP%]{list-style-type:none;margin:10px}li[_ngcontent-%COMP%]   .mat-mdc-card[_ngcontent-%COMP%]{display:flex;flex-direction:row}li[_ngcontent-%COMP%]   .mat-mdc-card[_ngcontent-%COMP%] > .imx-card-title[_ngcontent-%COMP%]{font-size:16px;flex:1;margin-left:10px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.imx-application-state[_ngcontent-%COMP%]{display:flex;flex-direction:row;flex-wrap:wrap;flex:0 0 64%;align-content:flex-start;box-shadow:none;padding:0}.imx-application-state[_ngcontent-%COMP%] > .mat-mdc-card[_ngcontent-%COMP%]{background-color:transparent}.imx-application-publish[_ngcontent-%COMP%]{flex:0 0 51%;min-width:220px;box-shadow:none;padding-left:5px;padding-right:0}.imx-application-publish[_ngcontent-%COMP%]   .mat-mdc-card-content[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center}.imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center;font-weight:600;font-size:12px}.imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]{margin-right:6px}.imx-application-publish[_ngcontent-%COMP%]   .imx-application-publish-date[_ngcontent-%COMP%]{margin-left:10px;font-size:14px}.imx-application-progress[_ngcontent-%COMP%]{flex:0 0 48%;box-shadow:none;padding-left:0;padding-right:0}.imx-application-progress[_ngcontent-%COMP%]   .mat-mdc-card-title[_ngcontent-%COMP%]{line-height:45px}.imx-application-progress[_ngcontent-%COMP%]   .imx-application-progress-step[_ngcontent-%COMP%]{margin-bottom:8px}.imx-application-progress[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:14px}.imx-application-progress[_ngcontent-%COMP%]   .mat-mdc-card-content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center}.imx-application-additionalDetails[_ngcontent-%COMP%]{flex:0 0 100%;box-shadow:none;overflow:hidden}.imx-application-additionalDetails[_ngcontent-%COMP%]   .mat-mdc-card-title[_ngcontent-%COMP%]{line-height:45px}.imx-application-additionalDetails[_ngcontent-%COMP%]   .mat-mdc-card-content[_ngcontent-%COMP%]{display:flex;flex-direction:row;flex-wrap:wrap}.imx-application-additionalDetails[_ngcontent-%COMP%]   .mat-mdc-card-content[_ngcontent-%COMP%]   imx-column-info[_ngcontent-%COMP%], .imx-application-additionalDetails[_ngcontent-%COMP%]   .mat-mdc-card-content[_ngcontent-%COMP%]   imx-application-property[_ngcontent-%COMP%]{flex:0 0 33%;min-width:200px;padding-right:21px}.imx-multivalue-item[_ngcontent-%COMP%]{margin:10px 0}[_nghost-%COMP%]   .imx-application-property-multi[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#616566}[_nghost-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%], [_nghost-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]{color:#e36a00}[_nghost-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]{color:#4ba803}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-property-multi[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%], .eui-dark-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]{color:#edbe8e}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]{color:#99c478}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-property-multi[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#18191a}.eui-contrast-theme   [_nghost-%COMP%]   .mat-mdc-card[_ngcontent-%COMP%]{border-color:#18191a}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%], .eui-contrast-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]{color:#f7e4d0}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]{color:#cee3bf}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationDetailsComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-details', template: "<div class=\"imx-application-details-content\">\n  <imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\n  <div class=\"imx-application-details-grid\" [ngClass]=\"{ hidden: isLoading }\">\n    <mat-card class=\"imx-application-properties mat-elevation-z0\">\n      <mat-card-title>\n        {{ '#LDS#General' | translate }}\n      </mat-card-title>\n      <mat-divider [inset]=\"true\"></mat-divider>\n      <mat-card-content>\n        <imx-column-info\n          [placeholder]=\"'#LDS#Is being computed' | translate\"\n          [property]=\"application?.UID_AccProductGroup\"\n          icon=\"serviceaccount\"\n        ></imx-column-info>\n        <imx-column-info [property]=\"application?.UID_AERoleOwner\" icon=\"user\"></imx-column-info>\n        <imx-application-property [display]=\"shopsDisplay\" icon=\"library\">\n          <div class=\"imx-application-property-multi\">\n            <span *ngIf=\"!assignedShops.length\">{{ '-' + ('#LDS#None assigned' | translate) + '-' }}</span>\n            <span *ngIf=\"assignedShops.length\">{{ assignedShops[0].GetEntity().GetDisplay() }}</span>\n            <button\n              mat-button\n              color=\"primary\"\n              (click)=\"showMore(assignedShops, shopsDisplay, 'library')\"\n              data-imx-identifier=\"imx-application-details-button-show-more-shops\"\n              *ngIf=\"assignedShops.length > 1\"\n            >\n              {{ '#LDS#and {0} more...' | translate | ldsReplace: assignedShops.length - 1 }}\n            </button>\n          </div>\n        </imx-application-property>\n      </mat-card-content>\n    </mat-card>\n    <mat-card class=\"imx-application-state mat-elevation-z0\">\n      <mat-card class=\"imx-application-publish mat-elevation-z0\">\n        <mat-card-title>\n          {{ '#LDS#Publication status' | translate }}\n        </mat-card-title>\n        <mat-divider [inset]=\"true\"></mat-divider>\n        <mat-card-content>\n          <span *ngIf=\"notPublished()\" class=\"imx-application-unpublished-state\">{{ '#LDS#Not published' | translate }}</span>\n          <span *ngIf=\"willPublish()\" class=\"imx-application-willbepublished-state\">\n            <eui-icon icon=\"restore\" size=\"14px\"></eui-icon>\n            {{ '#LDS#Will be published' | translate }}\n          </span>\n          <span *ngIf=\"published()\" class=\"imx-application-published-state\">\n            <mat-icon class=\"imx-icon-size-14 imx-icon-new\">check_circle</mat-icon>\n            {{ '#LDS#Published' | translate }}\n          </span>\n          <div *ngIf=\"willPublish()\" class=\"imx-application-publish-date\">\n            <span>{{ application?.ActivationDate?.value?.toString() || '' | shortDate }}</span>\n          </div>\n        </mat-card-content>\n      </mat-card>\n      <mat-card class=\"imx-application-progress mat-elevation-z0\">\n        <mat-card-title>\n          {{ '#LDS#Progress' | translate }}\n        </mat-card-title>\n        <mat-divider [inset]=\"true\"></mat-divider>\n        <mat-card-content>\n          <div class=\"imx-application-progress-step\">\n            <mat-icon\n              class=\"imx-margin-right-5 imx-icon-size-16 imx-icon-new\"\n              [ngClass]=\"application ? 'imx-icon-visible' : 'imx-icon-hidden'\"\n            >\n              check_circle\n            </mat-icon>\n            <span class=\"cdk-visually-hidden\">\n              {{ (application ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}\n            </span>\n            <span>{{ '#LDS#Application created' | translate }}</span>\n          </div>\n          <div class=\"imx-application-progress-step\">\n            <mat-icon\n              class=\"imx-margin-right-5 imx-icon-size-16 imx-icon-new\"\n              [ngClass]=\"hasOwner ? 'imx-icon-visible' : 'imx-icon-hidden'\"\n            >\n              check_circle\n            </mat-icon>\n            <span class=\"cdk-visually-hidden\">\n              {{ (hasOwner ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}\n            </span>\n            <span>{{ '#LDS#Manager assigned' | translate }}</span>\n          </div>\n          <div class=\"imx-application-progress-step\">\n            <mat-icon\n              class=\"imx-margin-right-5 imx-icon-size-16 imx-icon-new\"\n              [ngClass]=\"!!assignedShops?.length ? 'imx-icon-visible' : 'imx-icon-hidden'\"\n            >\n              check_circle\n            </mat-icon>\n            <span class=\"cdk-visually-hidden\">\n              {{ (!!assignedShops?.length ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}\n            </span>\n            <span>{{ '#LDS#Shop assigned' | translate }}</span>\n          </div>\n          <div class=\"imx-application-progress-step\">\n            <mat-icon\n              class=\"imx-margin-right-5 imx-icon-size-16 imx-icon-new\"\n              [ngClass]=\"hasAssignedEntitlements ? 'imx-icon-visible' : 'imx-icon-hidden'\"\n            >\n              check_circle\n            </mat-icon>\n            <span class=\"cdk-visually-hidden\">\n              {{ (hasAssignedEntitlements ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}\n            </span>\n            <span>{{ '#LDS#Application entitlements assigned' | translate }}</span>\n          </div>\n          <div class=\"imx-application-progress-step\">\n            <mat-icon\n              class=\"imx-margin-right-5 imx-icon-size-16 imx-icon-new\"\n              [ngClass]=\"hasPublishedEntitlements ? 'imx-icon-visible' : 'imx-icon-hidden'\"\n            >\n              check_circle\n            </mat-icon>\n            <span class=\"cdk-visually-hidden\">\n              {{ (hasPublishedEntitlements ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}\n            </span>\n            <span>{{ '#LDS#Application entitlements published' | translate }}</span>\n          </div>\n        </mat-card-content>\n      </mat-card>\n    </mat-card>\n    <mat-card class=\"imx-application-additionalDetails mat-elevation-z0\">\n      <mat-card-title>\n        {{ '#LDS#Additional details' | translate }}\n      </mat-card-title>\n      <mat-divider [inset]=\"true\"></mat-divider>\n      <mat-card-content>\n        <imx-column-info [property]=\"application?.UID_PersonHead\"></imx-column-info>\n        <imx-column-info [property]=\"application?.UID_AERoleApprover\"></imx-column-info>\n        <imx-application-property [display]=\"accountsDisplay\">\n          <div class=\"imx-application-property-multi\">\n            <span *ngIf=\"accountsInformation.count === 0\">{{ '-' + ('#LDS#None selected' | translate) + '-' }}</span>\n            <span *ngIf=\"accountsInformation.count > 0\">{{ accountsInformation.first?.GetEntity()?.GetDisplay() }}</span>\n            <button\n              mat-button\n              color=\"primary\"\n              (click)=\"showMoreAccounts()\"\n              *ngIf=\"accountsInformation.count > 1\"\n              data-imx-identifier=\"imx-application-details-button-load-more-accounts\"\n            >\n              {{ '#LDS#and {0} more...' | translate | ldsReplace: accountsInformation.count - 1 }}\n            </button>\n          </div>\n        </imx-application-property>\n        <imx-column-info [property]=\"application?.ApplicationEnvironment\"></imx-column-info>\n        <imx-column-info [property]=\"application?.ApplicationWebURL\"></imx-column-info>\n        <imx-column-info [property]=\"application?.AuthenticationRoot\"></imx-column-info>\n        <imx-column-info [property]=\"application?.IsAuthenticationIntegrated\"></imx-column-info>\n        <imx-column-info [property]=\"application?.IsFederationEnabled\"></imx-column-info>\n        <imx-column-info [property]=\"application?.IsMultiFactorEnabled\"></imx-column-info>\n        <imx-column-info [property]=\"application?.IsSSOEnabled\"></imx-column-info>\n        <imx-column-info [property]=\"application?.SSORedirectionUrl\"></imx-column-info>\n        <imx-column-info [property]=\"application?.PurchasedLicenses\"></imx-column-info>\n        <imx-column-info [property]=\"application?.RiskIndex\"></imx-column-info>\n        <imx-column-info [property]=\"application?.UID_FunctionalArea\"></imx-column-info>\n      </mat-card-content>\n    </mat-card>\n  </div>\n</div>\n<mat-card class=\"imx-padding-15 imx-button-bar imx-button-icon-14 mat-elevation-z0\" *ngIf=\"application && !isLoading\">\n  <button class=\"justify-start\" mat-stroked-button data-imx-identifier=\"imx-application-details-button-menu\" [matMenuTriggerFor]=\"menu\">\n    <eui-icon icon=\"ellipsisvertical\" (click)=\"menuClicked($event)\"></eui-icon>\n    {{ '#LDS#Actions' | translate }}\n  </button>\n  <mat-menu #menu=\"matMenu\">\n    <button\n      mat-menu-item\n      (click)=\"publishApplication($event)\"\n      data-imx-identifier=\"imx-application-details-button-publish-application\"\n      [disabled]=\"!isPublishable\"\n    >\n      {{ '#LDS#Publish' | translate }}\n    </button>\n    <button\n      mat-menu-item\n      (click)=\"unpublishApplication($event)\"\n      data-imx-identifier=\"imx-application-details-button-unpublish-application\"\n      [disabled]=\"!isUnpublishable\"\n    >\n      {{ '#LDS#Unpublish' | translate }}\n    </button>\n    <button data-imx-identifier=\"imx-application-details-edit-servicecategories\" mat-menu-item (click)=\"editServiceCategories()\">\n      {{ '#LDS#Manage service categories' | translate }}\n    </button>\n  </mat-menu>\n  <button\n    mat-stroked-button\n    color=\"warn\"\n    data-imx-identifier=\"imx-application-details-button-delete-application\"\n    [disabled]=\"!canBeDeleted\"\n    [attr.aria-label]=\"'#LDS#Delete application' | translate\"\n    (click)=\"deleteApplication()\"\n  >\n    <eui-icon icon=\"delete\"></eui-icon>\n    {{ '#LDS#Delete' | translate }}\n  </button>\n  <button\n    color=\"primary\"\n    mat-flat-button\n    data-imx-identifier=\"imx-application-details-button-edit-application\"\n    [attr.aria-label]=\"'#LDS#Edit Application' | translate\"\n    (click)=\"editApplication()\"\n  >\n    <eui-icon icon=\"edit\"></eui-icon>\n    {{ '#LDS#Edit' | translate }}\n  </button>\n</mat-card>\n\n<ng-template #multiValueControl let-data>\n  <div mat-dialog-title>{{ data.caption }}</div>\n  <mat-dialog-content>\n    <ul>\n      <li\n        *ngFor=\"let content of data.parts\"\n        class=\"imx-multivalue-item\"\n        [attr.data-imx-identifier]=\"'imx-application-details-' + data.caption + '-' + content\"\n      >\n        <mat-card>\n          <eui-icon *ngIf=\"data.icon\" mat-card-avatar size=\"16px\" [icon]=\"data.icon\"></eui-icon>\n          <mat-card-title class=\"imx-card-title\">{{ content }}</mat-card-title>\n        </mat-card>\n      </li>\n    </ul>\n  </mat-dialog-content>\n  <mat-dialog-actions>\n    <button data-imx-identifier=\"imx-application-details-button-close-list\" mat-flat-button color=\"primary\" mat-dialog-close>\n      {{ '#LDS#Close' | translate }}\n    </button>\n  </mat-dialog-actions>\n</ng-template>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto;min-height:100%}:host .imx-application-details-content .imx-application-details-grid.hidden{display:none}.imx-application-details-content{display:flex;flex-direction:row;flex:1 1 auto;overflow:hidden}.imx-application-details-content imx-busy-indicator{flex:0 0 0}.imx-application-details-content .imx-application-details-grid{display:flex;flex-direction:row;overflow:auto;max-height:800px;max-width:1500px;flex-wrap:wrap;padding:16px 24px}.imx-application-details-content .imx-application-details-grid>.mat-mdc-card{background-color:transparent}.imx-application-details-content .imx-application-details-grid .mat-mdc-card-title{font-size:18px;line-height:36px}.imx-application-details-content .imx-application-details-grid .mat-divider-horizontal{width:50px;margin-bottom:12px}.imx-application-properties{flex:0 0 33%;min-width:200px;box-shadow:none}.imx-application-properties .mat-mdc-card-content{display:flex;flex-direction:column;margin-bottom:-15px}.imx-application-properties .mat-mdc-card-content>*{margin-bottom:15px}.imx-application-property-multi{display:flex;flex-direction:column}.imx-application-property-multi>span{font-weight:600;overflow:hidden;text-overflow:ellipsis}.imx-application-property-multi>.mat-mdc-button{line-height:1.3rem;align-self:flex-start}li{list-style-type:none;margin:10px}li .mat-mdc-card{display:flex;flex-direction:row}li .mat-mdc-card>.imx-card-title{font-size:16px;flex:1;margin-left:10px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.imx-application-state{display:flex;flex-direction:row;flex-wrap:wrap;flex:0 0 64%;align-content:flex-start;box-shadow:none;padding:0}.imx-application-state>.mat-mdc-card{background-color:transparent}.imx-application-publish{flex:0 0 51%;min-width:220px;box-shadow:none;padding-left:5px;padding-right:0}.imx-application-publish .mat-mdc-card-content{display:flex;flex-direction:row;align-items:center}.imx-application-publish .imx-application-unpublished-state,.imx-application-publish .imx-application-willbepublished-state,.imx-application-publish .imx-application-published-state{display:flex;flex-direction:row;align-items:center;font-weight:600;font-size:12px}.imx-application-publish .imx-application-unpublished-state .eui-icon,.imx-application-publish .imx-application-unpublished-state .mat-icon,.imx-application-publish .imx-application-willbepublished-state .eui-icon,.imx-application-publish .imx-application-willbepublished-state .mat-icon,.imx-application-publish .imx-application-published-state .eui-icon,.imx-application-publish .imx-application-published-state .mat-icon{margin-right:6px}.imx-application-publish .imx-application-publish-date{margin-left:10px;font-size:14px}.imx-application-progress{flex:0 0 48%;box-shadow:none;padding-left:0;padding-right:0}.imx-application-progress .mat-mdc-card-title{line-height:45px}.imx-application-progress .imx-application-progress-step{margin-bottom:8px}.imx-application-progress span{font-size:14px}.imx-application-progress .mat-mdc-card-content>div{display:flex;flex-direction:row;align-items:center}.imx-application-additionalDetails{flex:0 0 100%;box-shadow:none;overflow:hidden}.imx-application-additionalDetails .mat-mdc-card-title{line-height:45px}.imx-application-additionalDetails .mat-mdc-card-content{display:flex;flex-direction:row;flex-wrap:wrap}.imx-application-additionalDetails .mat-mdc-card-content imx-column-info,.imx-application-additionalDetails .mat-mdc-card-content imx-application-property{flex:0 0 33%;min-width:200px;padding-right:21px}.imx-multivalue-item{margin:10px 0}:host .imx-application-property-multi>span{color:#616566}:host .imx-application-unpublished-state,:host .imx-application-willbepublished-state{color:#e36a00}:host .imx-application-published-state{color:#4ba803}.eui-dark-theme :host .imx-application-property-multi>span{color:#dfe4e6}.eui-dark-theme :host .imx-application-publish .imx-application-unpublished-state,.eui-dark-theme :host .imx-application-publish .imx-application-willbepublished-state{color:#edbe8e}.eui-dark-theme :host .imx-application-publish .imx-application-published-state{color:#99c478}.eui-contrast-theme :host .imx-application-property-multi>span{color:#fff}.eui-contrast-theme :host .imx-application-content{background-color:#18191a}.eui-contrast-theme :host .mat-mdc-card{border-color:#18191a}.eui-contrast-theme :host .imx-application-publish .imx-application-unpublished-state,.eui-contrast-theme :host .imx-application-publish .imx-application-willbepublished-state{color:#f7e4d0}.eui-contrast-theme :host .imx-application-publish .imx-application-published-state{color:#cee3bf}\n"] }]
    }], () => [{ type: EntitlementsService }, { type: ShopsService }, { type: i1.EuiLoadingService }, { type: i2.ClassloggerService }, { type: AccountsService }, { type: i1$2.MatDialog }, { type: ApplicationsService }, { type: i2.SnackBarService }, { type: i5.Platform }, { type: AobApiService }, { type: i3.TranslateService }, { type: i2.ConfirmationService }, { type: i1.EuiSidesheetService }, { type: AobPermissionsService }], { application: [{
            type: Input
        }], chartDialog: [{
            type: ViewChild,
            args: ['multiValueControl', { static: true }]
        }], menuTrigger: [{
            type: ViewChild,
            args: [MatMenuTrigger]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ApplicationDetailsComponent, { className: "ApplicationDetailsComponent", filePath: "lib\\applications\\application-details\\application-details.component.ts", lineNumber: 55 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class IdentityService {
    api;
    constructor(api) {
        this.api = api;
    }
    async get(applicationId, params) {
        return await this.api.typedClient.PortalApplicationIdentities.Get(applicationId, params);
    }
    getSchema() {
        return this.api.typedClient.PortalApplicationIdentities.GetSchema();
    }
    async getByIdentity(applicationId, identityId, params) {
        return await this.api.typedClient.PortalApplicationIdentitiesbyidentity.Getbyidentity(applicationId, identityId, params);
    }
    getByIdentitySchema() {
        return this.api.typedClient.PortalApplicationIdentitiesbyidentity.GetSchema();
    }
    static ɵfac = function IdentityService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || IdentityService)(i0.ɵɵinject(AobApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: IdentityService, factory: IdentityService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function IdentityDetailComponent_th_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 6);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME] == null ? null : ctx_r0.entitySchema.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME].Display, " ");
} }
function IdentityDetailComponent_td_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 7)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r2.GetEntity().GetDisplay());
} }
function IdentityDetailComponent_th_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 6);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.entitySchema.Columns.OrderState.Display);
} }
function IdentityDetailComponent_td_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 7)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r3.OrderState == null ? null : item_r3.OrderState.Column.GetDisplayValue());
} }
function IdentityDetailComponent_th_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 6);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.entitySchema.Columns.ValidUntil.Display);
} }
function IdentityDetailComponent_td_10_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9)(1, "eui-badge");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "shortDate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = i0.ɵɵnextContext().$implicit;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.translateProvider.GetColumnDisplay("ValidUntil", ctx_r0.entitySchema) + ": " + i0.ɵɵpipeBind1(3, 1, item_r4.ValidUntil.value), " ");
} }
function IdentityDetailComponent_td_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 7);
    i0.ɵɵtemplate(1, IdentityDetailComponent_td_10_div_1_Template, 4, 3, "div", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r4.ValidUntil.value);
} }
class IdentityDetailComponent {
    data;
    identityService;
    translateProvider;
    dataSource;
    dstSettings;
    navigationState;
    DisplayColumns = DisplayColumns;
    entitySchema;
    displayedColumns;
    constructor(data, identityService, translateProvider, dataSource) {
        this.data = data;
        this.identityService = identityService;
        this.translateProvider = translateProvider;
        this.dataSource = dataSource;
        this.entitySchema = this.identityService.getByIdentitySchema();
        this.displayedColumns = [
            this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchema.Columns['OrderState'],
            this.entitySchema.Columns['ValidUntil'],
        ];
    }
    async ngOnInit() {
        this.dataSource.init({
            execute: (params) => this.identityService.getByIdentity(this.data.application.GetEntity().GetKeys()[0], this.data.selectedItem?.GetEntity().GetKeys()[0] || '', params),
            schema: this.entitySchema,
            columnsToDisplay: this.displayedColumns,
        });
    }
    static ɵfac = function IdentityDetailComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || IdentityDetailComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(IdentityService), i0.ɵɵdirectiveInject(i2.ImxTranslationProviderService), i0.ɵɵdirectiveInject(i2.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IdentityDetailComponent, selectors: [["imx-identity-detail"]], features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 12, vars: 7, consts: [[3, "dataSource", "showSettings"], ["mode", "manual", 3, "dataSource"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], [3, "dataSource"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell"], ["class", "imx-badge-container", 4, "ngIf"], [1, "imx-badge-container"]], template: function IdentityDetailComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelement(0, "imx-data-view-toolbar", 0);
            i0.ɵɵelementStart(1, "imx-data-view-auto-table", 1);
            i0.ɵɵelementContainerStart(2, 2);
            i0.ɵɵtemplate(3, IdentityDetailComponent_th_3_Template, 2, 1, "th", 3)(4, IdentityDetailComponent_td_4_Template, 3, 1, "td", 4);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(5, 2);
            i0.ɵɵtemplate(6, IdentityDetailComponent_th_6_Template, 2, 1, "th", 3)(7, IdentityDetailComponent_td_7_Template, 3, 1, "td", 4);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(8, 2);
            i0.ɵɵtemplate(9, IdentityDetailComponent_th_9_Template, 2, 1, "th", 3)(10, IdentityDetailComponent_td_10_Template, 2, 1, "td", 4);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd();
            i0.ɵɵelement(11, "imx-data-view-paginator", 5);
        } if (rf & 2) {
            i0.ɵɵproperty("dataSource", ctx.dataSource)("showSettings", false);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.DisplayColumns.DISPLAY_PROPERTYNAME);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.OrderState.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.ValidUntil.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
        } }, dependencies: [i6.NgIf, i1.EuiBadgeComponent, i15.MatHeaderCellDef, i15.MatColumnDef, i15.MatCellDef, i15.MatHeaderCell, i15.MatCell, i2.DataViewAutoTableComponent, i2.DataViewPaginatorComponent, i2.DataViewToolbarComponent, i2.ShortDatePipe], styles: [".imx-badge-container[_ngcontent-%COMP%]{min-width:105px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityDetailComponent, [{
        type: Component,
        args: [{ selector: 'imx-identity-detail', providers: [DataViewSource], template: "<imx-data-view-toolbar [dataSource]=\"dataSource\" [showSettings]=\"false\"></imx-data-view-toolbar>\n<imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\">\n  <ng-container [matColumnDef]=\"DisplayColumns.DISPLAY_PROPERTYNAME\">\n    <th mat-header-cell *matHeaderCellDef>\n      {{ entitySchema?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]?.Display }}\n    </th>\n    <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n      <span>{{ item.GetEntity().GetDisplay() }}</span>\n    </td>\n  </ng-container>\n  <ng-container [matColumnDef]=\"entitySchema.Columns.OrderState.ColumnName\">\n    <th mat-header-cell *matHeaderCellDef>{{ entitySchema.Columns.OrderState.Display }}</th>\n    <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n      <div>{{ item.OrderState?.Column.GetDisplayValue() }}</div>\n    </td>\n  </ng-container>\n  <ng-container [matColumnDef]=\"entitySchema.Columns.ValidUntil.ColumnName\">\n    <th mat-header-cell *matHeaderCellDef>{{ entitySchema.Columns.ValidUntil.Display }}</th>\n    <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n      <div *ngIf=\"item.ValidUntil.value\" class=\"imx-badge-container\">\n        <eui-badge>\n          {{ translateProvider.GetColumnDisplay('ValidUntil', entitySchema) + ': ' + (item.ValidUntil.value | shortDate) }}\n        </eui-badge>\n      </div>\n    </td>\n  </ng-container>\n</imx-data-view-auto-table>\n<imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n", styles: [".imx-badge-container{min-width:105px}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: IdentityService }, { type: i2.ImxTranslationProviderService }, { type: i2.DataViewSource }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(IdentityDetailComponent, { className: "IdentityDetailComponent", filePath: "lib\\applications\\identities\\identity-detail\\identity-detail.component.ts", lineNumber: 47 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$2 = ["dataTable"];
const _c1$2 = () => ["search", "selectedViewGroup"];
const _c2 = a0 => ({ name: "view", description: a0 });
const _c3 = a0 => [a0];
function IdentitiesComponent_imx_data_table_3_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-data-table", 7, 1);
    i0.ɵɵlistener("highlightedEntityChanged", function IdentitiesComponent_imx_data_table_3_Template_imx_data_table_highlightedEntityChanged_0_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onHighlightedEntityChanged($event)); });
    i0.ɵɵelement(2, "imx-data-table-column", 8)(3, "imx-data-table-column", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    const dst_r4 = i0.ɵɵreference(2);
    i0.ɵɵproperty("dst", dst_r4)("detailViewVisible", false);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("entityColumn", ctx_r2.entitySchema == null ? null : ctx_r2.entitySchema.Columns == null ? null : ctx_r2.entitySchema.Columns[ctx_r2.DisplayColumns.DISPLAY_PROPERTYNAME]);
    i0.ɵɵadvance();
    i0.ɵɵproperty("entityColumn", ctx_r2.entitySchema == null ? null : ctx_r2.entitySchema.Columns == null ? null : ctx_r2.entitySchema.Columns["DefaultEmailAddress"]);
} }
function IdentitiesComponent_imx_data_tiles_4_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-data-tiles", 10);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵlistener("badgeClicked", function IdentitiesComponent_imx_data_tiles_4_Template_imx_data_tiles_badgeClicked_0_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onOpenDetails($event == null ? null : $event.entity)); })("actionSelected", function IdentitiesComponent_imx_data_tiles_4_Template_imx_data_tiles_actionSelected_0_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onSelectedTileChanged($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    const dst_r4 = i0.ɵɵreference(2);
    i0.ɵɵproperty("dst", dst_r4)("selectable", false)("actions", i0.ɵɵpureFunction1(10, _c3, i0.ɵɵpureFunction1(8, _c2, i0.ɵɵpipeBind1(1, 6, "#LDS#Details"))))("useActionMenu", false)("titleObject", ctx_r2.entitySchema == null ? null : ctx_r2.entitySchema.Columns == null ? null : ctx_r2.entitySchema.Columns[ctx_r2.DisplayColumns.DISPLAY_PROPERTYNAME])("subtitleObject", ctx_r2.entitySchema == null ? null : ctx_r2.entitySchema.Columns == null ? null : ctx_r2.entitySchema.Columns["DefaultEmailAddress"]);
} }
class IdentitiesComponent {
    identityService;
    sidesheetService;
    translateService;
    /**
     * The {@link PortalApplication | application} associated with the idenitities
     */
    application;
    dataTable;
    dstSettings;
    navigationState;
    selectedView = 'cardlist';
    DisplayColumns = DisplayColumns;
    entitySchema;
    displayedColumns;
    busyService = new BusyService();
    constructor(identityService, sidesheetService, translateService) {
        this.identityService = identityService;
        this.sidesheetService = sidesheetService;
        this.translateService = translateService;
        this.entitySchema = this.identityService.getSchema();
        this.initNavigationState();
        this.displayedColumns = [
            this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchema.Columns['DefaultEmailAddress'],
        ];
    }
    async ngOnChanges(changes) {
        if (changes.application?.currentValue?.UID_AOBApplication.value === changes.application?.previousValue?.UID_AOBApplication.value) {
            return;
        }
        const isBusy = this.busyService.beginBusy();
        try {
            this.initNavigationState();
            await this.setDst();
        }
        finally {
            isBusy.endBusy();
        }
    }
    async onNavigationStateChanged(navigationState) {
        this.navigationState = navigationState;
        await this.setDst();
    }
    onViewSelectionChanged(selectedView) {
        this.selectedView = selectedView;
    }
    /**
     * Method that is triggered by the (search) output of the data table
     * Reinits the data source
     * @param keywords the search value
     */
    async onSearch(keywords) {
        this.navigationState.StartIndex = 0;
        this.navigationState.search = keywords;
        await this.setDst();
    }
    /**
     * Method that is triggered by the (highlightedEntityChanged) output of the data table
     * opens the details
     * @param selectedItem the TypedEntity that is selected
     */
    async onHighlightedEntityChanged(selectedItem) {
        await this.onOpenDetails(selectedItem);
    }
    /**
     * Method that is triggered by the (actionSelected) output of the data tile component
     * opens the details
     * @param selectedItem the TypedEntity that is selected
     */
    async onSelectedTileChanged(selectedItem) {
        await this.onOpenDetails(selectedItem.typedEntity);
    }
    /**
     * Opens a side sheet that displays identity details
     * @param item the identity, that details should be opened
     */
    async onOpenDetails(item) {
        const data = {
            application: this.application,
            selectedItem: item,
        };
        this.sidesheetService.open(IdentityDetailComponent, {
            title: await this.translateService.get('#LDS#Heading View Application Entitlements').toPromise(),
            subTitle: data.selectedItem?.GetEntity().GetDisplay(),
            width: calculateSidesheetWidth(1100, 0.7),
            testId: 'identity-view-application-entitlements',
            data: data,
        });
    }
    /**
     * Loads the data for the table
     * @returns an {@link ExtendedTypedEntityCollection | extended typed entity collection} of {@link PortalApplicationIdentities | application identities}
     */
    async getData() {
        const isBusy = this.busyService.beginBusy();
        try {
            return await this.identityService.get(this.application.GetEntity().GetKeys()[0], this.navigationState);
        }
        finally {
            isBusy.endBusy();
        }
    }
    async setDst() {
        this.dstSettings = {
            dataSource: await this.getData(),
            entitySchema: this.entitySchema,
            navigationState: this.navigationState,
            displayedColumns: this.displayedColumns,
        };
    }
    initNavigationState() {
        this.navigationState = {
            PageSize: 25,
            StartIndex: 0,
            search: '',
        };
    }
    static ɵfac = function IdentitiesComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || IdentitiesComponent)(i0.ɵɵdirectiveInject(IdentityService), i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3.TranslateService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IdentitiesComponent, selectors: [["imx-aob-identities"]], viewQuery: function IdentitiesComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$2, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataTable = _t.first);
        } }, inputs: { application: "application" }, features: [i0.ɵɵNgOnChangesFeature], decls: 6, vars: 8, consts: [["dst", ""], ["dataTable", ""], [1, "imx-identities-content"], ["data-imx-identifier", "identity-dst", 3, "search", "viewSelectionChanged", "navigationStateChanged", "options", "settings", "busyService", "initalView"], ["data-imx-identifier", "identity-data-table", "mode", "manual", 3, "dst", "detailViewVisible", "highlightedEntityChanged", 4, "ngIf"], ["data-imx-identifier", "identity-tiles", "height", "150px", "icon", "user", 3, "dst", "selectable", "actions", "useActionMenu", "titleObject", "subtitleObject", "badgeClicked", "actionSelected", 4, "ngIf"], ["data-imx-identifier", "identity-paginator", 3, "dst"], ["data-imx-identifier", "identity-data-table", "mode", "manual", 3, "highlightedEntityChanged", "dst", "detailViewVisible"], ["data-imx-identifier", "identity-column-default-display", "data-imx-identifier", "identity-data-default", 3, "entityColumn"], ["data-imx-identifier", "identity-column-default-email", "data-imx-identifier", "identity-data-email", 3, "entityColumn"], ["data-imx-identifier", "identity-tiles", "height", "150px", "icon", "user", 3, "badgeClicked", "actionSelected", "dst", "selectable", "actions", "useActionMenu", "titleObject", "subtitleObject"]], template: function IdentitiesComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 2)(1, "imx-data-source-toolbar", 3, 0);
            i0.ɵɵlistener("search", function IdentitiesComponent_Template_imx_data_source_toolbar_search_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSearch($event)); })("viewSelectionChanged", function IdentitiesComponent_Template_imx_data_source_toolbar_viewSelectionChanged_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onViewSelectionChanged($event)); })("navigationStateChanged", function IdentitiesComponent_Template_imx_data_source_toolbar_navigationStateChanged_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onNavigationStateChanged($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(3, IdentitiesComponent_imx_data_table_3_Template, 4, 4, "imx-data-table", 4)(4, IdentitiesComponent_imx_data_tiles_4_Template, 2, 12, "imx-data-tiles", 5);
            i0.ɵɵelement(5, "imx-data-source-paginator", 6);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            const dst_r4 = i0.ɵɵreference(2);
            i0.ɵɵadvance();
            i0.ɵɵproperty("options", i0.ɵɵpureFunction0(7, _c1$2))("settings", ctx.dstSettings)("busyService", ctx.busyService)("initalView", ctx.selectedView);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.selectedView === "table");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.selectedView === "cardlist");
            i0.ɵɵadvance();
            i0.ɵɵproperty("dst", dst_r4);
        } }, dependencies: [i6.NgIf, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTilesComponent, i3.TranslatePipe], styles: ["[_nghost-%COMP%]{padding:30px;display:flex;flex-direction:column;height:100%;overflow:hidden;flex:1 1 auto}[_nghost-%COMP%]   .imx-identities-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentitiesComponent, [{
        type: Component,
        args: [{ selector: 'imx-aob-identities', template: "<div class=\"imx-identities-content\">\n  <imx-data-source-toolbar\n    #dst\n    data-imx-identifier=\"identity-dst\"\n    [options]=\"['search', 'selectedViewGroup']\"\n    [settings]=\"dstSettings\"\n    [busyService]=\"busyService\"\n    [initalView]=\"selectedView\"\n    (search)=\"onSearch($event)\"\n    (viewSelectionChanged)=\"onViewSelectionChanged($event)\"\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\"\n  >\n  </imx-data-source-toolbar>\n  <imx-data-table\n    *ngIf=\"selectedView === 'table'\"\n    data-imx-identifier=\"identity-data-table\"\n    [dst]=\"dst\"\n    [detailViewVisible]=\"false\"\n    mode=\"manual\"\n    (highlightedEntityChanged)=\"onHighlightedEntityChanged($event)\"\n    #dataTable\n  >\n    <imx-data-table-column\n      data-imx-identifier=\"identity-column-default-display\"\n      [entityColumn]=\"entitySchema?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]\"\n      data-imx-identifier=\"identity-data-default\"\n    ></imx-data-table-column>\n    <imx-data-table-column\n      data-imx-identifier=\"identity-column-default-email\"\n      [entityColumn]=\"entitySchema?.Columns?.['DefaultEmailAddress']\"\n      data-imx-identifier=\"identity-data-email\"\n    ></imx-data-table-column>\n  </imx-data-table>\n  <imx-data-tiles\n    *ngIf=\"selectedView === 'cardlist'\"\n    data-imx-identifier=\"identity-tiles\"\n    [dst]=\"dst\"\n    height=\"150px\"\n    icon=\"user\"\n    [selectable]=\"false\"\n    (badgeClicked)=\"onOpenDetails($event?.entity)\"\n    [actions]=\"[{ name: 'view', description: '#LDS#Details' | translate }]\"\n    [useActionMenu]=\"false\"\n    (actionSelected)=\"onSelectedTileChanged($event)\"\n    [titleObject]=\"entitySchema?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]\"\n    [subtitleObject]=\"entitySchema?.Columns?.['DefaultEmailAddress']\"\n  ></imx-data-tiles>\n  <imx-data-source-paginator [dst]=\"dst\" data-imx-identifier=\"identity-paginator\"></imx-data-source-paginator>\n</div>\n", styles: [":host{padding:30px;display:flex;flex-direction:column;height:100%;overflow:hidden;flex:1 1 auto}:host .imx-identities-content{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}\n"] }]
    }], () => [{ type: IdentityService }, { type: i1.EuiSidesheetService }, { type: i3.TranslateService }], { application: [{
            type: Input
        }], dataTable: [{
            type: ViewChild,
            args: ['dataTable']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(IdentitiesComponent, { className: "IdentitiesComponent", filePath: "lib\\applications\\identities\\identities.component.ts", lineNumber: 49 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ApplicationDetailComponent_div_0_img_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 19);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("src", ctx_r1.getImageUrl(ctx_r1.application), i0.ɵɵsanitizeUrl);
} }
function ApplicationDetailComponent_div_0_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 20);
} }
function ApplicationDetailComponent_div_0_imx_info_button_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-info-button", 21);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵnextContext(2);
    const dialogContent_r3 = i0.ɵɵreference(2);
    i0.ɵɵproperty("title", i0.ɵɵpipeBind1(1, 2, "#LDS#Heading Identities With Access"))("templateRef", dialogContent_r3);
} }
function ApplicationDetailComponent_div_0_ng_template_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-application-details", 22);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("application", ctx_r1.application);
} }
function ApplicationDetailComponent_div_0_ng_template_18_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-object-hyperview", 23);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("objectType", ctx_r1.hyperviewTableName)("objectUid", ctx_r1.application.UID_AOBApplication.value);
} }
function ApplicationDetailComponent_div_0_ng_template_21_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-kpi-overview", 22);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("application", ctx_r1.application);
} }
function ApplicationDetailComponent_div_0_ng_template_24_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-aob-identities", 22);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("application", ctx_r1.application);
} }
function ApplicationDetailComponent_div_0_ng_template_27_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-entitlements", 24);
    i0.ɵɵlistener("reloadRequested", function ApplicationDetailComponent_div_0_ng_template_27_Template_imx_entitlements_reloadRequested_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.reloadApplication()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("application", ctx_r1.application);
} }
function ApplicationDetailComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 5)(1, "div", 6)(2, "div", 7);
    i0.ɵɵtemplate(3, ApplicationDetailComponent_div_0_img_3_Template, 1, 1, "img", 8)(4, ApplicationDetailComponent_div_0_ng_template_4_Template, 1, 0, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelementStart(6, "div", 9)(7, "h3");
    i0.ɵɵtext(8);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(9, ApplicationDetailComponent_div_0_imx_info_button_9_Template, 2, 4, "imx-info-button", 10);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(10, "div", 11);
    i0.ɵɵtext(11);
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(12, "mat-tab-group", 12);
    i0.ɵɵlistener("selectedTabChange", function ApplicationDetailComponent_div_0_Template_mat_tab_group_selectedTabChange_12_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onSelectedTabChanged($event)); });
    i0.ɵɵelementStart(13, "mat-tab", 13);
    i0.ɵɵpipe(14, "translate");
    i0.ɵɵtemplate(15, ApplicationDetailComponent_div_0_ng_template_15_Template, 1, 1, "ng-template", 14);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(16, "mat-tab", 15);
    i0.ɵɵpipe(17, "translate");
    i0.ɵɵtemplate(18, ApplicationDetailComponent_div_0_ng_template_18_Template, 1, 2, "ng-template", 14);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(19, "mat-tab", 16);
    i0.ɵɵpipe(20, "translate");
    i0.ɵɵtemplate(21, ApplicationDetailComponent_div_0_ng_template_21_Template, 1, 1, "ng-template", 14);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(22, "mat-tab", 17);
    i0.ɵɵpipe(23, "translate");
    i0.ɵɵtemplate(24, ApplicationDetailComponent_div_0_ng_template_24_Template, 1, 1, "ng-template", 14);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(25, "mat-tab", 18);
    i0.ɵɵpipe(26, "translate");
    i0.ɵɵtemplate(27, ApplicationDetailComponent_div_0_ng_template_27_Template, 1, 1, "ng-template", 14);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const noImage_r5 = i0.ɵɵreference(5);
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r1.application.JPegPhoto == null ? null : ctx_r1.application.JPegPhoto.value == null ? null : ctx_r1.application.JPegPhoto.value.length)("ngIfElse", noImage_r5);
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(ctx_r1.application.GetEntity().GetDisplay());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.selectedTabIndex === 3);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r1.application.Description.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(14, 10, "#LDS#Details"));
    i0.ɵɵadvance(3);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(17, 12, "#LDS#Info"));
    i0.ɵɵadvance(3);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(20, 14, "#LDS#KPI"));
    i0.ɵɵadvance(3);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(23, 16, "#LDS#Heading Identities With Access"));
    i0.ɵɵadvance(3);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(26, 18, "#LDS#Heading Application Entitlements"));
} }
function ApplicationDetailComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, ctx_r1.ldsIdentitiesWithAccessInfoText), " ");
} }
function ApplicationDetailComponent_ng_template_3_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "span", 28);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "span", 29);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#No Application Selected"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Select an application to view its details."));
} }
function ApplicationDetailComponent_ng_template_3_ng_template_3_button_3_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 31);
    i0.ɵɵlistener("click", function ApplicationDetailComponent_ng_template_3_ng_template_3_button_3_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r6); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.createApplication()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Create new application"), " ");
} }
function ApplicationDetailComponent_ng_template_3_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 28);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, ApplicationDetailComponent_ng_template_3_ng_template_3_button_3_Template, 3, 3, "button", 30);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, ctx_r1.keywords ? "#LDS#No application found" : "#LDS#No applications available"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.isAdmin && !ctx_r1.isLoading);
} }
function ApplicationDetailComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 25);
    i0.ɵɵelement(1, "eui-icon", 26);
    i0.ɵɵtemplate(2, ApplicationDetailComponent_ng_template_3_ng_container_2_Template, 7, 6, "ng-container", 27)(3, ApplicationDetailComponent_ng_template_3_ng_template_3_Template, 4, 4, "ng-template", null, 3, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const noApps_r7 = i0.ɵɵreference(4);
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.totalCount)("ngIfElse", noApps_r7);
} }
class ApplicationDetailComponent {
    base64ImageService;
    logger;
    applicationsProvider;
    userService;
    route;
    aobPermissionsService;
    application;
    loadingSubject;
    totalCount;
    keywords;
    isAdmin;
    selectedTabIndex = 0;
    showHelper = true;
    isLoading = false;
    hyperviewTableName = 'AOBApplication';
    ldsIdentitiesWithAccessInfoText = '#LDS#Here you can get an overview of identities that have access to at least one application entitlement of this application. Additionally, you can view which application entitlements the respective identities have access to.';
    subscription;
    constructor(base64ImageService, logger, applicationsProvider, userService, route, aobPermissionsService) {
        this.base64ImageService = base64ImageService;
        this.logger = logger;
        this.applicationsProvider = applicationsProvider;
        this.userService = userService;
        this.route = route;
        this.aobPermissionsService = aobPermissionsService;
        this.route.queryParams.subscribe(async (params) => {
            if (Object.keys(params).length === 0)
                this.application = undefined;
        });
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    async ngOnInit() {
        this.subscription = this.loadingSubject.subscribe((elem) => (this.isLoading = elem));
        this.isAdmin = await this.aobPermissionsService.isAobApplicationAdmin();
    }
    getImageUrl(app) {
        return this.base64ImageService.getImageUrl(app.JPegPhoto);
    }
    async onSelectedTabChanged(event) {
        await this.reloadApplication();
        this.selectedTabIndex = event.index;
        this.logger.debug(this, 'tab selected', event.tab.textLabel);
    }
    async reloadApplication() {
        this.application = await this.applicationsProvider.reload(this.application?.UID_AOBApplication.value || '');
    }
    createApplication() {
        this.applicationsProvider.createApplication();
    }
    onHelperDismissed() {
        this.showHelper = false;
    }
    static ɵfac = function ApplicationDetailComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationDetailComponent)(i0.ɵɵdirectiveInject(i2.Base64ImageService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(i1$1.UserModelService), i0.ɵɵdirectiveInject(i4.ActivatedRoute), i0.ɵɵdirectiveInject(AobPermissionsService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationDetailComponent, selectors: [["ng-component"]], inputs: { application: "application", loadingSubject: "loadingSubject" }, decls: 5, vars: 2, consts: [["dialogContent", ""], ["noneSelected", ""], ["noImage", ""], ["noApps", ""], ["class", "imx-application-content", 4, "ngIf", "ngIfElse"], [1, "imx-application-content"], [1, "imx-application-details"], [1, "imx-application-details-header"], ["class", "imx-application-details-image", "alt", "", 3, "src", 4, "ngIf", "ngIfElse"], [1, "imx-application-details-title"], [3, "title", "templateRef", 4, "ngIf"], [1, "imx-application-details-subtitle"], ["mat-stretch-tabs", "false", 1, "imx-aob", 3, "selectedTabChange"], ["data-imx-identifier", "app-details", 3, "label"], ["matTabContent", ""], ["data-imx-identifier", "app-info", 3, "label"], ["data-imx-identifier", "app-kpi", 3, "label"], ["data-imx-identifier", "app-identities", 3, "label"], ["data-imx-identifier", "app-entitlements", 3, "label"], ["alt", "", 1, "imx-application-details-image", 3, "src"], ["icon", "application", "size", "42px"], [3, "title", "templateRef"], [3, "application"], [3, "objectType", "objectUid"], [3, "reloadRequested", "application"], [1, "imx-application-content", "imx-application-content-no-app", "imx-no-results"], ["icon", "application"], [4, "ngIf", "ngIfElse"], [1, "imx-application-content-no-app-text"], [1, "imx-application-content-no-app-description"], ["mat-flat-button", "", "color", "primary", "class", "imx-application-content-create-app", "data-imx-identifier", "button-create-app", 3, "click", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "button-create-app", 1, "imx-application-content-create-app", 3, "click"]], template: function ApplicationDetailComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, ApplicationDetailComponent_div_0_Template, 28, 20, "div", 4)(1, ApplicationDetailComponent_ng_template_1_Template, 3, 3, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor)(3, ApplicationDetailComponent_ng_template_3_Template, 5, 2, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            const noneSelected_r8 = i0.ɵɵreference(4);
            i0.ɵɵproperty("ngIf", ctx.application)("ngIfElse", noneSelected_r8);
        } }, dependencies: [i6.NgIf, EntitlementsComponent, i1.EuiIconComponent, i7.MatButton, i10$1.MatTabContent, i10$1.MatTab, i10$1.MatTabGroup, KpiOverviewComponent, i2.InfoButtonComponent, i1$1.ObjectHyperviewComponent, ApplicationDetailsComponent, IdentitiesComponent, i3.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-application-details[_ngcontent-%COMP%]{display:flex;overflow-x:hidden}.imx-application-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;height:calc(100vh - 180px);overflow:hidden}.imx-application-content-no-app[_ngcontent-%COMP%]{display:flex;flex-direction:column;justify-content:center;align-items:center}.imx-application-content-no-app-description[_ngcontent-%COMP%]{font-size:18px}.imx-application-content-create-app[_ngcontent-%COMP%]{margin-top:15px}.imx-application-content-no-app-text[_ngcontent-%COMP%]{font-size:24px;font-weight:600}.imx-application-info-row[_ngcontent-%COMP%]{display:flex;align-items:center}.imx-application-details-header[_ngcontent-%COMP%]{display:grid;grid-template-columns:60px 1fr;grid-template-rows:2fr 1fr;grid-row-gap:5px;align-items:center;padding:30px 40px 35px;flex-grow:1}.imx-application-details-image[_ngcontent-%COMP%]{width:42px;height:42px}.imx-application-details-title[_ngcontent-%COMP%]{grid-column-start:2;grid-column-end:3;grid-row-start:1;grid-row-end:1;font-weight:400;font-size:24px;min-height:40px;margin:0 15px 0 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;flex-direction:row;align-items:center}.imx-application-details-subtitle[_ngcontent-%COMP%]{grid-column-start:2;grid-column-end:3;grid-row-start:2;grid-row-end:2;font-size:14px;margin:0 15px 0 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.imx-info[_ngcontent-%COMP%]{align-self:center;max-width:500px;margin-right:50px}imx-application-hyperview[_ngcontent-%COMP%]{overflow:auto;flex-grow:1;padding:1em}[_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#fff}[_nghost-%COMP%]   .imx-application-details-subtitle[_ngcontent-%COMP%]{color:#444647}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#444647}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-content-no-app[_ngcontent-%COMP%]   .imx-application-content-no-app-text[_ngcontent-%COMP%], .eui-dark-theme   [_nghost-%COMP%]   .imx-application-content-no-app[_ngcontent-%COMP%]   .imx-application-content-no-app-description[_ngcontent-%COMP%]{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-details-subtitle[_ngcontent-%COMP%]{color:#797e80}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-details-subtitle[_ngcontent-%COMP%]{color:#797e80}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationDetailComponent, [{
        type: Component,
        args: [{ template: "<div class=\"imx-application-content\" *ngIf=\"application; else noneSelected\">\n  <div class=\"imx-application-details\">\n    <div class=\"imx-application-details-header\">\n      <img\n        *ngIf=\"application.JPegPhoto?.value?.length; else noImage\"\n        [src]=\"getImageUrl(application)\"\n        class=\"imx-application-details-image\"\n        alt=\"\"\n      />\n      <ng-template #noImage>\n        <eui-icon icon=\"application\" size=\"42px\"></eui-icon>\n      </ng-template>\n      <div class=\"imx-application-details-title\">\n        <h3>{{ application.GetEntity().GetDisplay() }}</h3>\n        <imx-info-button\n          *ngIf=\"selectedTabIndex === 3\"\n          [title]=\"'#LDS#Heading Identities With Access' | translate\"\n          [templateRef]=\"dialogContent\"\n        ></imx-info-button>\n      </div>\n      <div class=\"imx-application-details-subtitle\">{{ application.Description.Column.GetDisplayValue() }}</div>\n    </div>\n  </div>\n  <mat-tab-group mat-stretch-tabs=\"false\" class=\"imx-aob\" (selectedTabChange)=\"onSelectedTabChanged($event)\">\n    <mat-tab label=\"{{ '#LDS#Details' | translate }}\" data-imx-identifier=\"app-details\">\n      <ng-template matTabContent>\n        <imx-application-details [application]=\"application\"></imx-application-details>\n      </ng-template>\n    </mat-tab>\n    <mat-tab label=\"{{ '#LDS#Info' | translate }}\" data-imx-identifier=\"app-info\">\n      <ng-template matTabContent>\n        <imx-object-hyperview [objectType]=\"hyperviewTableName\" [objectUid]=\"application.UID_AOBApplication.value\"> </imx-object-hyperview>\n      </ng-template>\n    </mat-tab>\n    <mat-tab label=\"{{ '#LDS#KPI' | translate }}\" data-imx-identifier=\"app-kpi\">\n      <ng-template matTabContent>\n        <imx-kpi-overview [application]=\"application\"></imx-kpi-overview>\n      </ng-template>\n    </mat-tab>\n    <mat-tab label=\"{{ '#LDS#Heading Identities With Access' | translate }}\" data-imx-identifier=\"app-identities\">\n      <ng-template matTabContent>\n        <imx-aob-identities [application]=\"application\"></imx-aob-identities>\n      </ng-template>\n    </mat-tab>\n    <mat-tab label=\"{{ '#LDS#Heading Application Entitlements' | translate }}\" data-imx-identifier=\"app-entitlements\">\n      <ng-template matTabContent>\n        <imx-entitlements [application]=\"application\" (reloadRequested)=\"reloadApplication()\"></imx-entitlements>\n      </ng-template>\n    </mat-tab>\n  </mat-tab-group>\n</div>\n\n<ng-template #dialogContent>\n  <p>\n    {{ ldsIdentitiesWithAccessInfoText | translate }}\n  </p>\n</ng-template>\n\n<ng-template #noneSelected>\n  <div class=\"imx-application-content imx-application-content-no-app imx-no-results\">\n    <eui-icon icon=\"application\"></eui-icon>\n    <ng-container *ngIf=\"totalCount; else noApps\">\n      <span class=\"imx-application-content-no-app-text\">{{ '#LDS#No Application Selected' | translate }}</span>\n      <span class=\"imx-application-content-no-app-description\">{{ '#LDS#Select an application to view its details.' | translate }}</span>\n    </ng-container>\n    <ng-template #noApps>\n      <span class=\"imx-application-content-no-app-text\">\n        {{ (keywords ? '#LDS#No application found' : '#LDS#No applications available') | translate }}\n      </span>\n      <button\n        *ngIf=\"isAdmin && !isLoading\"\n        mat-flat-button\n        color=\"primary\"\n        (click)=\"createApplication()\"\n        class=\"imx-application-content-create-app\"\n        data-imx-identifier=\"button-create-app\"\n      >\n        {{ '#LDS#Create new application' | translate }}\n      </button>\n    </ng-template>\n  </div>\n</ng-template>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-application-details{display:flex;overflow-x:hidden}.imx-application-content{display:flex;flex-direction:column;flex:1 1 auto;height:calc(100vh - 180px);overflow:hidden}.imx-application-content-no-app{display:flex;flex-direction:column;justify-content:center;align-items:center}.imx-application-content-no-app-description{font-size:18px}.imx-application-content-create-app{margin-top:15px}.imx-application-content-no-app-text{font-size:24px;font-weight:600}.imx-application-info-row{display:flex;align-items:center}.imx-application-details-header{display:grid;grid-template-columns:60px 1fr;grid-template-rows:2fr 1fr;grid-row-gap:5px;align-items:center;padding:30px 40px 35px;flex-grow:1}.imx-application-details-image{width:42px;height:42px}.imx-application-details-title{grid-column-start:2;grid-column-end:3;grid-row-start:1;grid-row-end:1;font-weight:400;font-size:24px;min-height:40px;margin:0 15px 0 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;flex-direction:row;align-items:center}.imx-application-details-subtitle{grid-column-start:2;grid-column-end:3;grid-row-start:2;grid-row-end:2;font-size:14px;margin:0 15px 0 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.imx-info{align-self:center;max-width:500px;margin-right:50px}imx-application-hyperview{overflow:auto;flex-grow:1;padding:1em}:host .imx-application-content{background-color:#fff}:host .imx-application-details-subtitle{color:#444647}.eui-dark-theme :host .imx-application-content{background-color:#444647}.eui-dark-theme :host .imx-application-content-no-app .imx-application-content-no-app-text,.eui-dark-theme :host .imx-application-content-no-app .imx-application-content-no-app-description{color:#c4cacc}.eui-dark-theme :host .imx-application-details-subtitle{color:#797e80}.eui-contrast-theme :host .imx-application-content{background-color:#000}.eui-contrast-theme :host .imx-application-details-subtitle{color:#797e80}\n"] }]
    }], () => [{ type: i2.Base64ImageService }, { type: i2.ClassloggerService }, { type: ApplicationsService }, { type: i1$1.UserModelService }, { type: i4.ActivatedRoute }, { type: AobPermissionsService }], { application: [{
            type: Input
        }], loadingSubject: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ApplicationDetailComponent, { className: "ApplicationDetailComponent", filePath: "lib\\applications\\application-detail.component.ts", lineNumber: 44 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$1 = ["tiles"];
const _c1$1 = () => ["search"];
function ApplicationNavigationComponent_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 9);
    i0.ɵɵlistener("click", function ApplicationNavigationComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onCreateNew()); });
    i0.ɵɵelement(1, "eui-icon", 10);
    i0.ɵɵelementEnd();
} }
/**
 * This component shows a  list of {@link PortalApplication[]|applications} each in an
 * {@link ApplicationCardComponent|ApplicationCardComponent}.
 */
class ApplicationNavigationComponent {
    logger;
    appService;
    settingsService;
    userService;
    route;
    applicationsProvider;
    aobPermissionsService;
    overlay;
    dstSettings;
    entitySchema = PortalApplication.GetEntitySchema();
    selectable = true;
    multiselect = false;
    hideCustomToolbar = true;
    filterKpiChecked = false;
    isAdmin = false;
    selectedEntity;
    loadingSubject;
    busyService = new BusyService();
    /**
     * An event, that is triggert, if the dataSource is changed
     */
    dataSourceChanged = new EventEmitter();
    /**
     * An event that is emitted, if the user selects a data tile from the list
     */
    applicationSelected = new EventEmitter();
    /**
     * a status that defines, how badges are calculated
     */
    status = {
        getBadges: (application) => this.appService.getApplicationBadges(application),
        enabled: (item) => true,
    };
    navigationState;
    tiles;
    constructor(logger, appService, settingsService, userService, route, applicationsProvider, aobPermissionsService, overlay) {
        this.logger = logger;
        this.appService = appService;
        this.settingsService = settingsService;
        this.userService = userService;
        this.route = route;
        this.applicationsProvider = applicationsProvider;
        this.aobPermissionsService = aobPermissionsService;
        this.overlay = overlay;
    }
    async ngOnInit() {
        this.isAdmin = await this.aobPermissionsService.isAobApplicationAdmin();
        this.applicationsProvider.applicationRefresh.subscribe((res) => {
            if (res) {
                return this.getData();
            }
        });
        return this.getData({ PageSize: this.settingsService.DefaultPageSize, StartIndex: 0 });
    }
    /**
     * Emits the applicationSelected event, if the selected tile changes
     * @param selection the {@link PortalApplication | application} that is selected
     */
    async onSelectionChanged(selection) {
        const app = selection[0];
        if (app) {
            this.applicationSelected.emit(app.GetEntity().GetColumn('UID_AOBApplication').GetValue());
        }
    }
    /**
     * Emits the applicationSelected event, if the selected tile changes
     * @param selection the {@link PortalApplication | application} that is selected
     */
    onTileSelected(isSelected) {
        if (!isSelected)
            this.applicationSelected.emit();
    }
    /**
     * Loads the {@link PortalApplication | applications} for the application view
     * @param newState the load parameter for the api call
     * @param keywords possible search parameter
     */
    async getData(newState, keywords) {
        if (newState) {
            this.navigationState = newState;
        }
        const isBusy = this.busyService.beginBusy();
        this.loadingSubject?.next(true);
        try {
            const dataSource = await this.appService.get(this.navigationState);
            if (dataSource) {
                this.dstSettings = {
                    dataSource,
                    entitySchema: this.entitySchema,
                    navigationState: this.navigationState,
                };
            }
            else {
                this.dstSettings = undefined;
                this.logger.error(this, 'TypedEntityCollectionData<PortalApplication> is undefined');
            }
            this.dataSourceChanged.emit({ keywords, dataSource });
            this.route.queryParams.subscribe(async (params) => {
                const selectedEntity = dataSource?.Data.find((x) => x.UID_AOBApplication.value == params.id);
                if (params.id && selectedEntity) {
                    this.selectedEntity = selectedEntity;
                }
            });
        }
        finally {
            isBusy.endBusy();
            this.loadingSubject?.next(false);
        }
    }
    clearSelection() {
        this.tiles?.clearSelection();
    }
    onCreateNew() {
        this.clearSelection();
        this.appService.createApplication();
    }
    async onSearch(keywords) {
        this.logger.debug(this, `Searching for: ${keywords}`);
        this.navigationState.StartIndex = 0;
        if (keywords == null || keywords.length === 0) {
            this.navigationState.search = '';
        }
        else {
            this.navigationState.search = keywords;
        }
        return this.getData(undefined, keywords);
    }
    async filterApplicationsWithKpiIssues() {
        this.navigationState.filterkpi = this.filterKpiChecked;
        this.navigationState.StartIndex = 0;
        await this.getData();
    }
    static ɵfac = function ApplicationNavigationComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationNavigationComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i1$1.UserModelService), i0.ɵɵdirectiveInject(i4.ActivatedRoute), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(AobPermissionsService), i0.ɵɵdirectiveInject(i6$4.Overlay)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationNavigationComponent, selectors: [["imx-application-navigation"]], viewQuery: function ApplicationNavigationComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$1, 7);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.tiles = _t.first);
        } }, outputs: { dataSourceChanged: "dataSourceChanged", applicationSelected: "applicationSelected" }, decls: 15, vars: 24, consts: [["dst", ""], ["tiles", ""], [1, "imx-main-container"], [1, "imx-title-area"], ["mat-icon-button", "", "class", "mat-elevation-z4 imx-icon-button", "data-imx-identifier", "navigation-button-create-app", 3, "click", 4, "ngIf"], [3, "change", "ngModelChange", "ngModel", "disabled"], [3, "navigationStateChanged", "search", "settings", "options", "hideCustomToolbar", "itemStatus", "busyService", "alwaysVisible"], ["fallbackIcon", "application", 1, "imx-application-list", 3, "selectionChanged", "selected", "dst", "selectable", "multiSelect", "image", "titleObject", "subtitleObject", "selectedEntity"], [1, "mat-elevation-z2", "imx-margin-top-10", 3, "dst"], ["mat-icon-button", "", "data-imx-identifier", "navigation-button-create-app", 1, "mat-elevation-z4", "imx-icon-button", 3, "click"], ["icon", "add", "size", "20px"]], template: function ApplicationNavigationComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 2)(1, "div", 3)(2, "h2");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(5, "imx-help-contextual");
            i0.ɵɵtemplate(6, ApplicationNavigationComponent_button_6_Template, 2, 0, "button", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-checkbox", 5);
            i0.ɵɵlistener("change", function ApplicationNavigationComponent_Template_mat_checkbox_change_7_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.filterApplicationsWithKpiIssues()); });
            i0.ɵɵtwoWayListener("ngModelChange", function ApplicationNavigationComponent_Template_mat_checkbox_ngModelChange_7_listener($event) { i0.ɵɵrestoreView(_r1); i0.ɵɵtwoWayBindingSet(ctx.filterKpiChecked, $event) || (ctx.filterKpiChecked = $event); return i0.ɵɵresetView($event); });
            i0.ɵɵtext(8);
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "imx-data-source-toolbar", 6, 0);
            i0.ɵɵlistener("navigationStateChanged", function ApplicationNavigationComponent_Template_imx_data_source_toolbar_navigationStateChanged_10_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.getData($event)); })("search", function ApplicationNavigationComponent_Template_imx_data_source_toolbar_search_10_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSearch($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(12, "imx-data-tiles", 7, 1);
            i0.ɵɵlistener("selectionChanged", function ApplicationNavigationComponent_Template_imx_data_tiles_selectionChanged_12_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSelectionChanged($event)); })("selected", function ApplicationNavigationComponent_Template_imx_data_tiles_selected_12_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onTileSelected($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelement(14, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            const dst_r4 = i0.ɵɵreference(11);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 19, "#LDS#Applications"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.isAdmin);
            i0.ɵɵadvance();
            i0.ɵɵtwoWayProperty("ngModel", ctx.filterKpiChecked);
            i0.ɵɵproperty("disabled", !(ctx.dstSettings == null ? null : ctx.dstSettings.dataSource == null ? null : ctx.dstSettings.dataSource.totalCount));
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 21, "#LDS#Only show applications with KPI issues"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(23, _c1$1))("hideCustomToolbar", ctx.hideCustomToolbar)("itemStatus", ctx.status)("busyService", ctx.busyService)("alwaysVisible", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", dst_r4)("selectable", ctx.selectable)("multiSelect", false)("image", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns["JPegPhoto"])("titleObject", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns["Ident_AOBApplication"])("subtitleObject", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns["Description"])("selectedEntity", ctx.selectedEntity);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", dst_r4);
        } }, dependencies: [i6.NgIf, i1.EuiIconComponent, i7.MatIconButton, i10$2.MatCheckbox, i12.NgControlStatus, i12.NgModel, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTilesComponent, i2.HelpContextualComponent, i3.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:inherit;max-width:400px}[_nghost-%COMP%]   h2[_ngcontent-%COMP%]{font-weight:600}[_nghost-%COMP%]   .mat-mdc-checkbox[_ngcontent-%COMP%]{margin-top:10px;font-size:12px}[_nghost-%COMP%]   imx-data-tiles[_ngcontent-%COMP%]{flex-grow:1}[_nghost-%COMP%]   .imx-main-container[_ngcontent-%COMP%]{display:flex;height:inherit;flex-direction:column;overflow:hidden;flex:1 1 auto}[_nghost-%COMP%]   .imx-overlay[_ngcontent-%COMP%]{background-color:#f9fbfc;opacity:.5;width:100%;height:100%}[_nghost-%COMP%]   .imx-title-area[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center}[_nghost-%COMP%]   .imx-icon-button[_ngcontent-%COMP%]{background-color:#fff;margin-left:15px}[_nghost-%COMP%]   .imx-application-list[_ngcontent-%COMP%]{padding-right:20px;padding-top:20px;overflow-y:auto;display:flex;flex-direction:column}[_nghost-%COMP%]   .imx-application-list[_ngcontent-%COMP%]     .imx-data-container{overflow-y:initial}[_nghost-%COMP%]     .badgeContainer{width:355px}[_nghost-%COMP%]     imx-data-tile>.cardContainer>.imx-selected-icon-container{margin-left:0}[_nghost-%COMP%]     .mat-mdc-card.imx-data-tile-container{padding:35px 50px 0 25px}[_nghost-%COMP%]     .mat-mdc-card.imx-data-tile-container .imx-data-tile-subtitle.mat-body-2{align-self:baseline;top:10px;white-space:normal;overflow:hidden;text-overflow:inherit;position:relative;height:2.4em;line-height:18px}[_nghost-%COMP%]     .mat-mdc-card.imx-data-tile-container .imx-data-tile-subtitle.mat-body-2:after{content:\"\";text-align:right;position:absolute;bottom:0;right:0;width:30px;height:1.2em;background:linear-gradient(to right,#fff0,#fff 60%)}@supports (-webkit-line-clamp: 3){[_nghost-%COMP%]     .mat-mdc-card.imx-data-tile-container .imx-data-tile-subtitle.mat-body-2{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;height:auto;top:0}[_nghost-%COMP%]     .mat-mdc-card.imx-data-tile-container .imx-data-tile-subtitle.mat-body-2:after{display:none}}.eui-dark-theme   [_nghost-%COMP%]   .imx-overlay[_ngcontent-%COMP%]{background-color:#18191a}.eui-dark-theme   [_nghost-%COMP%]   .imx-icon-button[_ngcontent-%COMP%]{background-color:#444647}.eui-dark-theme   [_nghost-%COMP%]     .imx-selected-icon-container{background-color:#99c478}.eui-contrast-theme   [_nghost-%COMP%]   .imx-overlay[_ngcontent-%COMP%]{background-color:#18191a}.eui-contrast-theme   [_nghost-%COMP%]   .imx-icon-button[_ngcontent-%COMP%]{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]     .imx-selected-icon-container{background-color:#99c478}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationNavigationComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-navigation', template: "<div class=\"imx-main-container\">\n  <div class=\"imx-title-area\">\n    <h2>{{ '#LDS#Applications' | translate }}</h2>\n    <imx-help-contextual></imx-help-contextual>\n    <button\n      *ngIf=\"isAdmin\"\n      mat-icon-button\n      (click)=\"onCreateNew()\"\n      class=\"mat-elevation-z4 imx-icon-button\"\n      data-imx-identifier=\"navigation-button-create-app\"\n    >\n      <eui-icon icon=\"add\" size=\"20px\"></eui-icon>\n    </button>\n  </div>\n  <mat-checkbox\n    (change)=\"filterApplicationsWithKpiIssues()\"\n    [(ngModel)]=\"filterKpiChecked\"\n    [disabled]=\"!dstSettings?.dataSource?.totalCount\"\n  >\n    {{ '#LDS#Only show applications with KPI issues' | translate }}\n  </mat-checkbox>\n  <imx-data-source-toolbar\n    #dst\n    [settings]=\"dstSettings\"\n    (navigationStateChanged)=\"getData($event)\"\n    [options]=\"['search']\"\n    [hideCustomToolbar]=\"hideCustomToolbar\"\n    [itemStatus]=\"status\"\n    [busyService]=\"busyService\"\n    (search)=\"onSearch($event)\"\n    [alwaysVisible]=\"true\"\n  >\n  </imx-data-source-toolbar>\n\n  <imx-data-tiles\n    #tiles\n    class=\"imx-application-list\"\n    [dst]=\"dst\"\n    [selectable]=\"selectable\"\n    [multiSelect]=\"false\"\n    [image]=\"entitySchema?.Columns?.['JPegPhoto']\"\n    fallbackIcon=\"application\"\n    [titleObject]=\"entitySchema?.Columns?.['Ident_AOBApplication']\"\n    [subtitleObject]=\"entitySchema?.Columns?.['Description']\"\n    (selectionChanged)=\"onSelectionChanged($event)\"\n    [selectedEntity]=\"selectedEntity\"\n    (selected)=\"onTileSelected($event)\"\n  >\n  </imx-data-tiles>\n\n  <imx-data-source-paginator class=\"mat-elevation-z2 imx-margin-top-10\" [dst]=\"dst\"></imx-data-source-paginator>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:inherit;max-width:400px}:host h2{font-weight:600}:host .mat-mdc-checkbox{margin-top:10px;font-size:12px}:host imx-data-tiles{flex-grow:1}:host .imx-main-container{display:flex;height:inherit;flex-direction:column;overflow:hidden;flex:1 1 auto}:host .imx-overlay{background-color:#f9fbfc;opacity:.5;width:100%;height:100%}:host .imx-title-area{display:flex;flex-direction:row;align-items:center}:host .imx-icon-button{background-color:#fff;margin-left:15px}:host .imx-application-list{padding-right:20px;padding-top:20px;overflow-y:auto;display:flex;flex-direction:column}:host .imx-application-list ::ng-deep .imx-data-container{overflow-y:initial}:host ::ng-deep .badgeContainer{width:355px}:host ::ng-deep imx-data-tile>.cardContainer>.imx-selected-icon-container{margin-left:0}:host ::ng-deep .mat-mdc-card.imx-data-tile-container{padding:35px 50px 0 25px}:host ::ng-deep .mat-mdc-card.imx-data-tile-container .imx-data-tile-subtitle.mat-body-2{align-self:baseline;top:10px;white-space:normal;overflow:hidden;text-overflow:inherit;position:relative;height:2.4em;line-height:18px}:host ::ng-deep .mat-mdc-card.imx-data-tile-container .imx-data-tile-subtitle.mat-body-2:after{content:\"\";text-align:right;position:absolute;bottom:0;right:0;width:30px;height:1.2em;background:linear-gradient(to right,#fff0,#fff 60%)}@supports (-webkit-line-clamp: 3){:host ::ng-deep .mat-mdc-card.imx-data-tile-container .imx-data-tile-subtitle.mat-body-2{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;height:auto;top:0}:host ::ng-deep .mat-mdc-card.imx-data-tile-container .imx-data-tile-subtitle.mat-body-2:after{display:none}}.eui-dark-theme :host .imx-overlay{background-color:#18191a}.eui-dark-theme :host .imx-icon-button{background-color:#444647}.eui-dark-theme :host ::ng-deep .imx-selected-icon-container{background-color:#99c478}.eui-contrast-theme :host .imx-overlay{background-color:#18191a}.eui-contrast-theme :host .imx-icon-button{background-color:#2f3233}.eui-contrast-theme :host ::ng-deep .imx-selected-icon-container{background-color:#99c478}\n"] }]
    }], () => [{ type: i2.ClassloggerService }, { type: ApplicationsService }, { type: i2.SettingsService }, { type: i1$1.UserModelService }, { type: i4.ActivatedRoute }, { type: ApplicationsService }, { type: AobPermissionsService }, { type: i6$4.Overlay }], { dataSourceChanged: [{
            type: Output
        }], applicationSelected: [{
            type: Output
        }], tiles: [{
            type: ViewChild,
            args: ['tiles', { static: true }]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ApplicationNavigationComponent, { className: "ApplicationNavigationComponent", filePath: "lib\\applications\\application-navigation\\application-navigation.component.ts", lineNumber: 56 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationsComponent {
    logger;
    applicationsProvider;
    busyService;
    router;
    route;
    snackbar;
    selectedApplication;
    dataSource;
    applicationNavigation;
    applicationContent;
    subscriptions = [];
    loadingSubject = new Subject();
    constructor(logger, applicationsProvider, busyService, router, route, snackbar) {
        this.logger = logger;
        this.applicationsProvider = applicationsProvider;
        this.busyService = busyService;
        this.router = router;
        this.route = route;
        this.snackbar = snackbar;
        this.subscriptions.push(this.applicationsProvider.onApplicationCreated.subscribe(async (uidApplication) => {
            this.selectedApplication = await this.applicationsProvider.reload(uidApplication);
            if (this.selectedApplication == null) {
                return;
            }
            if (this.dataSource?.Data) {
                this.dataSource.Data.shift();
                this.dataSource.Data.unshift(this.selectedApplication);
            }
            this.applicationContent.application = this.selectedApplication;
            return this.redirectToAppDetails(this.selectedApplication.UID_AOBApplication.value);
        }));
        this.subscriptions.push(this.applicationsProvider.onApplicationDeleted.subscribe(async (uidApplication) => {
            const index = this.dataSource.Data.findIndex((elem) => elem.UID_AOBApplication.value === uidApplication);
            if (index < 0) {
                return this.redirectToAppDetails('');
            }
            const removed = this.dataSource.Data.splice(index, 1);
            this.applicationContent.application = undefined;
            this.snackbar.open({
                key: '#LDS#The application "{0}" has been successfully deleted.',
                parameters: [removed[0].GetEntity().GetDisplay()],
            });
            return this.redirectToAppDetails('');
        }));
    }
    ngOnInit() {
        this.route.queryParams.subscribe(async (params) => {
            this.logger.trace(this, 'Routing parameters', params);
            this.selectedApplication = undefined;
            if (params?.id == null) {
                return;
            }
            if (params.id) {
                this.selectedApplication = await this.applicationsProvider.reload(params.id);
            }
            if (this.selectedApplication) {
                this.applicationContent.application = this.selectedApplication;
            }
            if (!this.selectedApplication) {
                this.applicationNavigation.clearSelection();
            }
            if (this.selectedApplication && this.isEditRoute(this.route)) {
                await this.redirectToAppDetails(this.selectedApplication.UID_AOBApplication.value);
            }
        });
    }
    ngOnDestroy() {
        this.subscriptions.forEach((subscription) => subscription.unsubscribe());
    }
    onActivateNavigationOutlet(componentRef) {
        this.logger.trace(this, 'Initializing Application Navigation View', componentRef);
        this.applicationNavigation = componentRef;
        this.applicationNavigation.loadingSubject = this.loadingSubject;
        this.subscriptions.push(this.applicationNavigation.applicationSelected.subscribe((uidApplication) => this.redirectToAppDetails(uidApplication)));
        this.subscriptions.push(this.applicationNavigation.dataSourceChanged.subscribe((changeSet) => {
            this.dataSource = changeSet?.dataSource;
            this.applicationContent.totalCount = this.dataSource?.totalCount ?? 0;
            this.applicationContent.keywords = changeSet?.keywords;
        }));
    }
    async onActivateContentOutlet(applicationContent) {
        this.applicationContent = applicationContent;
        this.applicationContent.loadingSubject = this.loadingSubject;
        this.logger.trace(this, 'Initializing Application Content View', this.applicationContent);
        if (this.selectedApplication == null) {
            return;
        }
        // reload app:
        this.selectedApplication = await this.applicationsProvider.reload(this.selectedApplication.UID_AOBApplication.value);
        if (applicationContent instanceof ApplicationDetailComponent) {
            this.applicationContent.application = this.selectedApplication;
        }
    }
    isEditRoute(route) {
        return (route.children &&
            route.children.length > 1 &&
            route.children[1].routeConfig?.outlet?.toLowerCase() === 'content' &&
            route.children[1].routeConfig?.path?.toLowerCase() === 'edit');
    }
    async redirectToAppDetails(uidApplication) {
        this.logger.trace(this, 'Redirecting to details view.');
        return this.router.navigate(['applications', { outlets: { content: ['detail'] } }], uidApplication ? { queryParams: { id: uidApplication } } : undefined);
    }
    static ɵfac = function ApplicationsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationsComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i4.Router), i0.ɵɵdirectiveInject(i4.ActivatedRoute), i0.ɵɵdirectiveInject(i2.SnackBarService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationsComponent, selectors: [["imx-applications"]], decls: 4, vars: 0, consts: [[1, "imx-application-navigation"], [3, "activate"], [1, "imx-application-content", "mat-elevation-z1"], ["name", "content", 3, "activate"]], template: function ApplicationsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "router-outlet", 1);
            i0.ɵɵlistener("activate", function ApplicationsComponent_Template_router_outlet_activate_1_listener($event) { return ctx.onActivateNavigationOutlet($event); });
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(2, "div", 2)(3, "router-outlet", 3);
            i0.ɵɵlistener("activate", function ApplicationsComponent_Template_router_outlet_activate_3_listener($event) { return ctx.onActivateContentOutlet($event); });
            i0.ɵɵelementEnd()();
        } }, dependencies: [i4.RouterOutlet], styles: ["[_nghost-%COMP%]{display:flex;margin:0;flex:1 1 auto;height:calc(100% - 120px)}.imx-application-navigation[_ngcontent-%COMP%]{display:flex;margin-right:30px}.imx-application-content[_ngcontent-%COMP%]{flex:1 1 auto;background-color:#fff;overflow:hidden}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#18191a}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationsComponent, [{
        type: Component,
        args: [{ selector: 'imx-applications', template: "<div class=\"imx-application-navigation\">\n  <router-outlet (activate)=\"onActivateNavigationOutlet($event)\"></router-outlet>\n</div>\n<div class=\"imx-application-content mat-elevation-z1\">\n  <router-outlet name=\"content\" (activate)=\"onActivateContentOutlet($event)\"></router-outlet>\n</div>\n", styles: [":host{display:flex;margin:0;flex:1 1 auto;height:calc(100% - 120px)}.imx-application-navigation{display:flex;margin-right:30px}.imx-application-content{flex:1 1 auto;background-color:#fff;overflow:hidden}.eui-dark-theme :host .imx-application-content{background-color:#2f3233}.eui-contrast-theme :host .imx-application-content{background-color:#18191a}\n"] }]
    }], () => [{ type: i2.ClassloggerService }, { type: ApplicationsService }, { type: i1.EuiLoadingService }, { type: i4.Router }, { type: i4.ActivatedRoute }, { type: i2.SnackBarService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ApplicationsComponent, { className: "ApplicationsComponent", filePath: "lib\\applications\\applications.component.ts", lineNumber: 46 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationPropertyModule {
    static ɵfac = function ApplicationPropertyModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationPropertyModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ApplicationPropertyModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, EuiCoreModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationPropertyModule, [{
        type: NgModule,
        args: [{
                declarations: [ApplicationPropertyComponent],
                exports: [ApplicationPropertyComponent],
                imports: [CommonModule, EuiCoreModule],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ApplicationPropertyModule, { declarations: [ApplicationPropertyComponent], imports: [CommonModule, EuiCoreModule], exports: [ApplicationPropertyComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ColumnInfoModule {
    static ɵfac = function ColumnInfoModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ColumnInfoModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ColumnInfoModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [ApplicationPropertyModule,
            CommonModule,
            DisableControlModule,
            EuiCoreModule,
            QbmModule,
            TranslateModule,
            ReactiveFormsModule,
            MatButtonModule,
            MatFormFieldModule,
            MatInputModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ColumnInfoModule, [{
        type: NgModule,
        args: [{
                declarations: [ColumnInfoComponent],
                imports: [
                    ApplicationPropertyModule,
                    CommonModule,
                    DisableControlModule,
                    EuiCoreModule,
                    QbmModule,
                    TranslateModule,
                    ReactiveFormsModule,
                    MatButtonModule,
                    MatFormFieldModule,
                    MatInputModule,
                ],
                exports: [ColumnInfoComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ColumnInfoModule, { declarations: [ColumnInfoComponent], imports: [ApplicationPropertyModule,
        CommonModule,
        DisableControlModule,
        EuiCoreModule,
        QbmModule,
        TranslateModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule], exports: [ColumnInfoComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class LifecycleActionsModule {
    static ɵfac = function LifecycleActionsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || LifecycleActionsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: LifecycleActionsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            EuiCoreModule,
            FormsModule,
            LdsReplaceModule,
            MatButtonModule,
            MatCardModule,
            MatDialogModule,
            MatDatepickerModule,
            MatFormFieldModule,
            MatInputModule,
            MatRadioModule,
            ReactiveFormsModule,
            QbmModule,
            TranslateModule,
            DataViewModule,
            MatTableModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LifecycleActionsModule, [{
        type: NgModule,
        args: [{
                declarations: [LifecycleActionComponent],
                imports: [
                    CommonModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    EuiCoreModule,
                    FormsModule,
                    LdsReplaceModule,
                    MatButtonModule,
                    MatCardModule,
                    MatDialogModule,
                    MatDatepickerModule,
                    MatFormFieldModule,
                    MatInputModule,
                    MatRadioModule,
                    ReactiveFormsModule,
                    QbmModule,
                    TranslateModule,
                    DataViewModule,
                    MatTableModule,
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(LifecycleActionsModule, { declarations: [LifecycleActionComponent], imports: [CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        FormsModule,
        LdsReplaceModule,
        MatButtonModule,
        MatCardModule,
        MatDialogModule,
        MatDatepickerModule,
        MatFormFieldModule,
        MatInputModule,
        MatRadioModule,
        ReactiveFormsModule,
        QbmModule,
        TranslateModule,
        DataViewModule,
        MatTableModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function UserComponent_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.primaryValue);
} }
class UserComponent {
    translateService;
    logger;
    uid;
    role;
    noUserText;
    size = 'default';
    imageUrl;
    primaryValue;
    secondaryValue;
    hasUser;
    constructor(translateService, logger) {
        this.translateService = translateService;
        this.logger = logger;
    }
    ngOnChanges() {
        if (!this.noUserText || this.noUserText.length < 1) {
            this.logger.debug(this, 'Show default noUserText because no other was specified.');
            this.noUserText = '#LDS#(not assigned)';
        }
        if (!this.hasValidUser()) {
            this.logger.debug(this, 'Show noUserText because of an empty value.');
            this.translateService.get(this.noUserText).subscribe((trans) => (this.secondaryValue = trans));
            this.primaryValue = '';
        }
        else {
            this.primaryValue = this.uid.Column.GetDisplayValue();
            this.secondaryValue = this.role;
        }
    }
    hasValidUser() {
        this.hasUser = this.uid != null && this.uid.value != null && this.uid.value.length > 0;
        return this.hasUser;
    }
    static ɵfac = function UserComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || UserComponent)(i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i2.ClassloggerService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: UserComponent, selectors: [["imx-user"]], inputs: { uid: "uid", role: "role", noUserText: "noUserText", size: "size" }, features: [i0.ɵɵNgOnChangesFeature], decls: 7, vars: 7, consts: [[1, "imx-user-icon"], [1, "imx-user-properties"], [4, "ngIf"]], template: function UserComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div")(1, "mat-icon", 0);
            i0.ɵɵtext(2, "person");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "div", 1);
            i0.ɵɵtemplate(4, UserComponent_span_4_Template, 2, 1, "span", 2);
            i0.ɵɵelementStart(5, "span");
            i0.ɵɵtext(6);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵclassMapInterpolate1("imx-user ", ctx.size, "");
            i0.ɵɵclassProp("noUser", !ctx.hasUser);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngIf", ctx.hasUser);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.secondaryValue);
        } }, dependencies: [i6.NgIf, i18.MatIcon], styles: [".imx-user[_ngcontent-%COMP%]{display:flex;align-items:center;justify-items:center;margin:5px;min-height:40px}.imx-user-icon[_ngcontent-%COMP%]{color:#fff;background-color:#c4cacc;border-radius:50%;text-align:center;vertical-align:middle;line-height:30px;width:30px;height:30px;margin-right:5px;flex-shrink:0}.imx-user-properties[_ngcontent-%COMP%]{margin-left:5px;display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-weight:600;font-size:12px;overflow:hidden;text-overflow:ellipsis}.imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:last-child{font-size:10px;color:#aab0b3}.imx-user.large[_ngcontent-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{font-size:30px;height:30px;width:30px}.imx-user.large[_ngcontent-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:16px}.imx-user.large[_ngcontent-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:last-child{font-size:12px}.imx-user.noUser[_ngcontent-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{color:#e36a00;background-color:#f7e4d0}.imx-user.noUser[_ngcontent-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:12px}.imx-user.large.noUser[_ngcontent-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:14px}.eui-dark-theme   [_nghost-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{color:#2f3233;background-color:#616566}.eui-dark-theme   [_nghost-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:last-child{color:#616566}.eui-contrast-theme   [_nghost-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{color:#000;background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:last-child{color:#2f3233}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UserComponent, [{
        type: Component,
        args: [{ selector: 'imx-user', template: "<div class=\"imx-user {{ size }}\" [class.noUser]=\"!hasUser\">\n  <mat-icon class=\"imx-user-icon\">person</mat-icon>\n  <div class=\"imx-user-properties\">\n    <span *ngIf=\"hasUser\">{{ primaryValue }}</span>\n    <span>{{ secondaryValue }}</span>\n  </div>\n</div>\n", styles: [".imx-user{display:flex;align-items:center;justify-items:center;margin:5px;min-height:40px}.imx-user-icon{color:#fff;background-color:#c4cacc;border-radius:50%;text-align:center;vertical-align:middle;line-height:30px;width:30px;height:30px;margin-right:5px;flex-shrink:0}.imx-user-properties{margin-left:5px;display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-user-properties>span{font-weight:600;font-size:12px;overflow:hidden;text-overflow:ellipsis}.imx-user-properties>span:last-child{font-size:10px;color:#aab0b3}.imx-user.large .imx-user-icon{font-size:30px;height:30px;width:30px}.imx-user.large .imx-user-properties>span{font-size:16px}.imx-user.large .imx-user-properties>span:last-child{font-size:12px}.imx-user.noUser .imx-user-icon{color:#e36a00;background-color:#f7e4d0}.imx-user.noUser .imx-user-properties>span{font-size:12px}.imx-user.large.noUser .imx-user-properties>span{font-size:14px}.eui-dark-theme :host .imx-user-icon{color:#2f3233;background-color:#616566}.eui-dark-theme :host .imx-user-properties>span:last-child{color:#616566}.eui-contrast-theme :host .imx-user-icon{color:#000;background-color:#2f3233}.eui-contrast-theme :host .imx-user-properties>span:last-child{color:#2f3233}\n"] }]
    }], () => [{ type: i3.TranslateService }, { type: i2.ClassloggerService }], { uid: [{
            type: Input
        }], role: [{
            type: Input
        }], noUserText: [{
            type: Input
        }], size: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(UserComponent, { className: "UserComponent", filePath: "lib\\user\\user.component.ts", lineNumber: 39 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobUserModule {
    static ɵfac = function AobUserModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AobUserModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: AobUserModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, MatIconModule, UserModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobUserModule, [{
        type: NgModule,
        args: [{
                declarations: [UserComponent],
                imports: [CommonModule, MatIconModule, UserModule],
                exports: [UserComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(AobUserModule, { declarations: [UserComponent], imports: [CommonModule, MatIconModule, UserModule], exports: [UserComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementEditModule {
    static ɵfac = function EntitlementEditModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementEditModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: EntitlementEditModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CdrModule,
            CommonModule,
            EuiCoreModule,
            FormsModule,
            MatButtonModule,
            MatCardModule,
            MatCheckboxModule,
            MatFormFieldModule,
            MatInputModule,
            ReactiveFormsModule,
            ServiceItemTagsModule,
            TranslateModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementEditModule, [{
        type: NgModule,
        args: [{
                declarations: [EntitlementEditComponent],
                exports: [EntitlementEditComponent],
                imports: [
                    CdrModule,
                    CommonModule,
                    EuiCoreModule,
                    FormsModule,
                    MatButtonModule,
                    MatCardModule,
                    MatCheckboxModule,
                    MatFormFieldModule,
                    MatInputModule,
                    ReactiveFormsModule,
                    ServiceItemTagsModule,
                    TranslateModule,
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(EntitlementEditModule, { declarations: [EntitlementEditComponent], imports: [CdrModule,
        CommonModule,
        EuiCoreModule,
        FormsModule,
        MatButtonModule,
        MatCardModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatInputModule,
        ReactiveFormsModule,
        ServiceItemTagsModule,
        TranslateModule], exports: [EntitlementEditComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementsModule {
    static ɵfac = function EntitlementsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EntitlementsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: EntitlementsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [EntitlementsService], imports: [ClassloggerModule,
            CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            DataTilesModule,
            DisableControlModule,
            EuiCoreModule,
            EuiMaterialModule,
            EntitlementEditModule,
            FormsModule,
            LdsReplaceModule,
            MatBadgeModule,
            MatButtonToggleModule,
            MatCardModule,
            MatCheckboxModule,
            MatIconModule,
            MatRadioModule,
            MatTableModule,
            MatTooltipModule,
            MatButtonModule,
            MatDividerModule,
            MatFormFieldModule,
            MatSlideToggleModule,
            MatInputModule,
            MatMenuModule,
            QbmModule,
            ReactiveFormsModule,
            TranslateModule,
            AobUserModule,
            LifecycleActionsModule,
            CdrModule,
            ScrollingModule,
            SqlWizardModule,
            InfoModalDialogModule,
            SelectedElementsModule,
            DataViewModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementsModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    EntitlementsAddComponent,
                    EntitlementsComponent,
                    EntitlementDetailComponent,
                    SystemRoleConfigComponent,
                    EntitlementEditAutoAddComponent,
                    MappedEntitlementsPreviewComponent,
                ],
                imports: [
                    ClassloggerModule,
                    CommonModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    DataTilesModule,
                    DisableControlModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    EntitlementEditModule,
                    FormsModule,
                    LdsReplaceModule,
                    MatBadgeModule,
                    MatButtonToggleModule,
                    MatCardModule,
                    MatCheckboxModule,
                    MatIconModule,
                    MatRadioModule,
                    MatTableModule,
                    MatTooltipModule,
                    MatButtonModule,
                    MatDividerModule,
                    MatFormFieldModule,
                    MatSlideToggleModule,
                    MatInputModule,
                    MatMenuModule,
                    QbmModule,
                    ReactiveFormsModule,
                    TranslateModule,
                    AobUserModule,
                    LifecycleActionsModule,
                    CdrModule,
                    ScrollingModule,
                    SqlWizardModule,
                    InfoModalDialogModule,
                    SelectedElementsModule,
                    DataViewModule,
                ],
                providers: [EntitlementsService],
                exports: [EntitlementsComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(EntitlementsModule, { declarations: [EntitlementsAddComponent,
        EntitlementsComponent,
        EntitlementDetailComponent,
        SystemRoleConfigComponent,
        EntitlementEditAutoAddComponent,
        MappedEntitlementsPreviewComponent], imports: [ClassloggerModule,
        CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        DataTilesModule,
        DisableControlModule,
        EuiCoreModule,
        EuiMaterialModule,
        EntitlementEditModule,
        FormsModule,
        LdsReplaceModule,
        MatBadgeModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatIconModule,
        MatRadioModule,
        MatTableModule,
        MatTooltipModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatSlideToggleModule,
        MatInputModule,
        MatMenuModule,
        QbmModule,
        ReactiveFormsModule,
        TranslateModule,
        AobUserModule,
        LifecycleActionsModule,
        CdrModule,
        ScrollingModule,
        SqlWizardModule,
        InfoModalDialogModule,
        SelectedElementsModule,
        DataViewModule], exports: [EntitlementsComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class KpiModule {
    static ɵfac = function KpiModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || KpiModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: KpiModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [KpiOverviewService], imports: [CommonModule,
            TranslateModule,
            MatCardModule,
            MatButtonModule,
            MatTooltipModule,
            EuiCoreModule,
            EuiMaterialModule,
            ClassloggerModule,
            BusyIndicatorModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(KpiModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule,
                    TranslateModule,
                    MatCardModule,
                    MatButtonModule,
                    MatTooltipModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    ClassloggerModule,
                    BusyIndicatorModule,
                ],
                declarations: [KpiOverviewComponent],
                providers: [KpiOverviewService],
                exports: [KpiOverviewComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(KpiModule, { declarations: [KpiOverviewComponent], imports: [CommonModule,
        TranslateModule,
        MatCardModule,
        MatButtonModule,
        MatTooltipModule,
        EuiCoreModule,
        EuiMaterialModule,
        ClassloggerModule,
        BusyIndicatorModule], exports: [KpiOverviewComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationsModule {
    static ɵfac = function ApplicationsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApplicationsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ApplicationsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [ApplicationsService], imports: [CommonModule,
            ApplicationPropertyModule,
            ClassloggerModule,
            ColumnInfoModule,
            EntitlementsModule,
            EuiCoreModule,
            EuiMaterialModule,
            FormsModule,
            KpiModule,
            LdsReplaceModule,
            MatAutocompleteModule,
            MatBadgeModule,
            MatButtonModule,
            MatCardModule,
            MatDividerModule,
            MatIconModule,
            MatInputModule,
            MatDialogModule,
            MatTooltipModule,
            QbmModule,
            DateModule,
            ReactiveFormsModule,
            TranslateModule,
            AobUserModule,
            DataSourceToolbarModule,
            DataTableModule,
            DataTilesModule,
            DataTreeModule,
            DataTreeWrapperModule,
            RouterModule,
            OverlayModule,
            PortalModule,
            FkAdvancedPickerModule,
            EntityModule,
            ImageModule,
            CdrModule,
            InfoModalDialogModule,
            HelpContextualModule,
            BusyIndicatorModule,
            ObjectHyperviewModule,
            DataViewModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationsModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    ApplicationsComponent,
                    ApplicationDetailComponent,
                    ApplicationDetailsComponent,
                    ApplicationNavigationComponent,
                    EditApplicationComponent,
                    ApplicationCreateComponent,
                    ApplicationImageSelectComponent,
                    ImageSelectorDialogComponent,
                    AuthenticationRootComponent,
                    IdentitiesComponent,
                    IdentityDetailComponent,
                    ServiceCategoryComponent,
                    EditServiceCategoryInformationComponent,
                ],
                imports: [
                    CommonModule,
                    ApplicationPropertyModule,
                    ClassloggerModule,
                    ColumnInfoModule,
                    EntitlementsModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    FormsModule,
                    KpiModule,
                    LdsReplaceModule,
                    MatAutocompleteModule,
                    MatBadgeModule,
                    MatButtonModule,
                    MatCardModule,
                    MatDividerModule,
                    MatIconModule,
                    MatInputModule,
                    MatDialogModule,
                    MatTooltipModule,
                    QbmModule,
                    DateModule,
                    ReactiveFormsModule,
                    TranslateModule,
                    AobUserModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    DataTilesModule,
                    DataTreeModule,
                    DataTreeWrapperModule,
                    RouterModule,
                    OverlayModule,
                    PortalModule,
                    FkAdvancedPickerModule,
                    EntityModule,
                    ImageModule,
                    CdrModule,
                    InfoModalDialogModule,
                    HelpContextualModule,
                    BusyIndicatorModule,
                    ObjectHyperviewModule,
                    DataViewModule,
                ],
                providers: [ApplicationsService],
                exports: [ApplicationsComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ApplicationsModule, { declarations: [ApplicationsComponent,
        ApplicationDetailComponent,
        ApplicationDetailsComponent,
        ApplicationNavigationComponent,
        EditApplicationComponent,
        ApplicationCreateComponent,
        ApplicationImageSelectComponent,
        ImageSelectorDialogComponent,
        AuthenticationRootComponent,
        IdentitiesComponent,
        IdentityDetailComponent,
        ServiceCategoryComponent,
        EditServiceCategoryInformationComponent], imports: [CommonModule,
        ApplicationPropertyModule,
        ClassloggerModule,
        ColumnInfoModule,
        EntitlementsModule,
        EuiCoreModule,
        EuiMaterialModule,
        FormsModule,
        KpiModule,
        LdsReplaceModule,
        MatAutocompleteModule,
        MatBadgeModule,
        MatButtonModule,
        MatCardModule,
        MatDividerModule,
        MatIconModule,
        MatInputModule,
        MatDialogModule,
        MatTooltipModule,
        QbmModule,
        DateModule,
        ReactiveFormsModule,
        TranslateModule,
        AobUserModule,
        DataSourceToolbarModule,
        DataTableModule,
        DataTilesModule,
        DataTreeModule,
        DataTreeWrapperModule,
        RouterModule,
        OverlayModule,
        PortalModule,
        FkAdvancedPickerModule,
        EntityModule,
        ImageModule,
        CdrModule,
        InfoModalDialogModule,
        HelpContextualModule,
        BusyIndicatorModule,
        ObjectHyperviewModule,
        DataViewModule], exports: [ApplicationsComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * A service that provides endpoints for KPI features
 */
class GlobalKpiService {
    aobClient;
    apiProvider;
    constructor(aobClient, apiProvider) {
        this.aobClient = aobClient;
        this.apiProvider = apiProvider;
    }
    /**
     * Encapsules the aob/kpi GET endpoint
     */
    async get() {
        return this.apiProvider.request(() => this.aobClient.client.portal_kpi_get());
    }
    static ɵfac = function GlobalKpiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GlobalKpiService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ApiClientService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: GlobalKpiService, factory: GlobalKpiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GlobalKpiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobApiService }, { type: i2.ApiClientService }], null); })();

const _c0 = ["chartdialog"];
const _c1 = () => ({ minimumFractionDigits: 0, maximumFractionDigits: 3 });
function GlobalKpiComponent_ng_container_8_li_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li")(1, "span", 6);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "span", 7);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "button", 8);
    i0.ɵɵlistener("click", function GlobalKpiComponent_ng_container_8_li_2_Template_button_click_5_listener() { const kpi_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.showDetails(kpi_r2)); });
    i0.ɵɵtext(6);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const kpi_r2 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(!kpi_r2.calculated ? "-" : !kpi_r2.currentDataValue ? "" : kpi_r2.currentDataValue.toLocaleString(ctx_r2.browserCulture, i0.ɵɵpureFunction0(6, _c1)));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(kpi_r2.chartData.Display);
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", !ctx_r2.isCalculated(kpi_r2.chartData));
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 4, "#LDS#View"), " ");
} }
function GlobalKpiComponent_ng_container_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "ul", 4);
    i0.ɵɵtemplate(2, GlobalKpiComponent_ng_container_8_li_2_Template, 8, 7, "li", 5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r2.kpiData);
} }
function GlobalKpiComponent_ng_template_9_div_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 17);
    i0.ɵɵelement(1, "eui-billboard", 18);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("options", data_r4.pieChart);
} }
function GlobalKpiComponent_ng_template_9_h2_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "h2");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#History"));
} }
function GlobalKpiComponent_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9)(1, "div", 10);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "button", 11);
    i0.ɵɵelement(4, "eui-icon", 12);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(5, "div", 13)(6, "p", 14);
    i0.ɵɵtext(7);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(8, GlobalKpiComponent_ng_template_9_div_8_Template, 2, 1, "div", 15)(9, GlobalKpiComponent_ng_template_9_h2_9_Template, 3, 3, "h2", 16);
    i0.ɵɵelementStart(10, "div", 17);
    i0.ɵɵelement(11, "eui-billboard", 18);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const data_r4 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(data_r4.chartData.Display);
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(data_r4.chartData.Description);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", data_r4.pieChart != null);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", data_r4.chartOptions != null);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("options", data_r4.chartDetails);
} }
function GlobalKpiComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 19)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 1, "#LDS#No global KPIs defined"));
} }
/**
 * Builds a component, that displays global KPI data (key performance indicators)
 * Every KPI is displayed with its display value
 * Every KPI card has a "Details" Button, to show a detailed chart
 */
class GlobalKpiComponent {
    logger;
    kpiProvider;
    matDialog;
    busyService;
    translateService;
    kpiData = [];
    browserCulture;
    /**
     * @ignore Only used with template
     */
    chartDialog;
    noDataLoaded;
    business;
    central;
    others;
    colors = ['#B4E6F4', '#82D5ED', '#50C4E6', '#2BB7E0', '#05AADB', '#04A3D7', '#0499D2', '#0390CD', '#017FC4'];
    constructor(logger, kpiProvider, matDialog, busyService, translateService) {
        this.logger = logger;
        this.kpiProvider = kpiProvider;
        this.matDialog = matDialog;
        this.busyService = busyService;
        this.translateService = translateService;
        this.browserCulture = this.translateService.currentLang;
        translateService.get('#LDS#No data available').subscribe((trans) => (this.noDataLoaded = trans));
        translateService.get('#LDS#Used in business roles').subscribe((trans) => (this.business = trans));
        translateService.get('#LDS#Using central directory').subscribe((trans) => (this.central = trans));
        translateService.get('#LDS#Other').subscribe((trans) => (this.others = trans));
    }
    /**
     * Loads the chartDto objects and inits the component
     */
    async ngOnInit() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            this.kpiData = (await this.kpiProvider.get())?.map((elem, i) => this.buildKpiData(i, elem)) || [];
        }
        finally {
            this.busyService.hide();
        }
    }
    /**
     * @ignore opens a dialog that shows the details of a KPI
     * @param chart the data of a single chart
     */
    showDetails(kpi) {
        if (kpi.chartData.Data?.length === 0) {
            return;
        }
        kpi.chartDetails = this.buildLineOptions(kpi.chartData, kpi.pieChart != null, kpi.names);
        this.matDialog.open(this.chartDialog, { data: kpi, minWidth: 600, autoFocus: false });
    }
    /**
     * @ignore determines whether a chart has detailed data
     * @param chart the data of a single chart
     * @returns true, if the KPI has DataPoits also false
     */
    isCalculated(chart) {
        return chart.Data != null && chart.Data.length > 0 && chart.Data[0].Points != null;
    }
    /**
     * @ignore determines whether an application has chart data or not
     * @returns true, if there are any KPIs else false
     */
    hasKpis() {
        return this.kpiData != null && this.kpiData.length > 0 && this.kpiData.some((elem) => elem != null);
    }
    buildKpiData(chartIndex, chart) {
        const calc = this.isCalculated(chart);
        if (!calc) {
            return { index: chartIndex, chartData: chart, calculated: false, names: [] };
        }
        let currentData;
        let pieOptions;
        let captions = [];
        switch (chartIndex) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 7:
            case 8:
                currentData = chart.Data?.[0].Points?.[0].Value;
                captions = chart.Data?.map((ch) => ch.Name || '') || [];
                break;
            case 4:
                pieOptions = this.buildSingleValueChart(chart, this.central);
                captions = [this.central];
                break;
            case 6:
                pieOptions = this.buildSingleValueChart(chart, this.business);
                captions = [this.central];
                break;
            case 5:
                pieOptions = this.buildPieChart(chart);
                captions = chart.Data?.map((ch) => ch.Name || '') || [];
                break;
        }
        return { index: chartIndex, chartData: chart, calculated: calc, names: captions, currentDataValue: currentData, pieChart: pieOptions };
    }
    buildSingleValueChart(chart, name) {
        if (!this.isCalculated(chart)) {
            this.logger.debug(this, 'The chart is not calculated yet, therefore no chart is build');
            return undefined;
        }
        return {
            size: { width: 271, height: 271 },
            data: {
                columns: [
                    ['data1', chart.Data?.[0].Points?.[0].Value || 0],
                    ['data2', 100 - (chart.Data?.[0].Points?.[0].Value || 0)],
                ],
                names: { data1: name, data2: this.others },
                colors: { data1: this.colors[0], data2: '#CCC' },
                type: pie(),
                empty: {
                    label: {
                        text: this.noDataLoaded,
                    },
                },
            },
            pie: {
                padAngle: 0.01,
                label: {
                    format: (d) => `${d.toLocaleString(this.browserCulture, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%`,
                    threshold: 0.06,
                },
            },
        };
    }
    buildPieChart(chart) {
        if (!this.isCalculated(chart)) {
            this.logger.debug(this, 'The chart is not calculated yet, therefore no chart is build');
            return undefined;
        }
        return {
            size: { width: 271, height: 271 },
            data: {
                columns: chart?.Data?.map((ch, index) => ['data' + index, ch?.Points?.[0].Value || 0]),
                names: this.toObject(chart?.Data?.map((ch, index) => ({ key: 'data' + index, value: ch.Name || '' })) || []),
                colors: this.toObject(chart?.Data?.map((ch, index) => ({ key: 'data' + index, value: this.colors[index] })) || []),
                type: pie(),
                empty: {
                    label: {
                        text: this.noDataLoaded,
                    },
                },
            },
            pie: {
                padAngle: 0.01,
                label: {
                    format: (d) => `${d.toLocaleString(this.browserCulture, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%`,
                    threshold: 0.06,
                },
            },
        };
    }
    /**
     * @ignore converts an array of string arrays to an object ( first strign is the property name
     * second string the value)
     * @param array an array of string arrays
     *
     */
    toObject(array) {
        const ret = {};
        for (const elem of array) {
            ret[elem.key] = elem.value;
        }
        return ret;
    }
    /**
     * @ignore determines whether a chart has more then one data point
     * @param chart the data of a single chart
     * @returns true, if the chart has multiple points else it return false
     */
    hasMultipleDataPoints(chart) {
        return this.isCalculated(chart) && (chart?.Data?.[0]?.Points?.length || 0) > 1;
    }
    /**
     * @ignore Build the ChartOptions that can be displayed with billboard.js
     * @param chart the data of a single chart
     * @returns a ChartOptions object, that can be used by billboard.js
     */
    buildLineOptions(chart, isPercentage, names) {
        const yAxis = new YAxisInformation(chart.Data?.map((serie, id) => new SeriesInformation(names[id], serie.Points?.map((point) => point.Value) || [], this.colors[id])) || []);
        yAxis.tickConfiguration = {
            format: (d) => (isPercentage ? `${d.toLocaleString(this.browserCulture)}%` : `${d.toLocaleString(this.browserCulture)}`),
            values: this.accumulateTicks(chart),
        };
        const lineChartOptions = new LineChartOptions(new XAxisInformation('date', chart.Data?.[0]?.Points?.map((point) => new Date(point.Date)) || [], {
            count: 6,
            format: (d) => d.toLocaleDateString(this.browserCulture),
        }), yAxis);
        lineChartOptions.useCurvedLines = false;
        lineChartOptions.hideLegend = chart.Data?.length === 1;
        lineChartOptions.showPoints = !this.hasMultipleDataPoints(chart);
        lineChartOptions.size = { width: 500, height: 325 };
        return lineChartOptions.options;
    }
    accumulateTicks(chart) {
        const ret = [];
        const max = Math.max.apply(Math, chart.Data?.map((o) => this.getMax(o.Points || [])));
        const steps = Math.max(1, Math.trunc(max / 10)) + 1;
        ret.push(0);
        if (max <= 0) {
            return ret;
        }
        for (let index = 1; index <= 10; index++) {
            ret.push(index * steps);
        }
        return ret;
    }
    getMax(points) {
        return Math.max.apply(Math, points.map((o) => o.Value));
    }
    static ɵfac = function GlobalKpiComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GlobalKpiComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(GlobalKpiService), i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i3.TranslateService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GlobalKpiComponent, selectors: [["imx-global-kpi"]], viewQuery: function GlobalKpiComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0, 7);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.chartDialog = _t.first);
        } }, decls: 13, vars: 8, consts: [["chartdialog", ""], ["nonExisting", ""], [1, "mat-headline-5"], [4, "ngIf", "ngIfElse"], [1, "imx-kpi-list"], [4, "ngFor", "ngForOf"], [1, "imx-kpi-number"], [1, "imx-kpi-display"], ["color", "primary", "mat-button", "", "data-imx-identifier", "global_KPI_showShowDetails", 3, "click", "disabled"], ["mat-dialog-title", "", 1, "imx-card-title-l"], [1, "imx-title-text"], ["mat-icon-button", "", "color", "basic", "data-imx-identifier", "global_KPI_closeChartDialog", "mat-dialog-close", "", 1, "imx-button-close-dialog"], ["icon", "close", "size", "large"], ["mat-dialog-content", ""], [1, "imx-subtitle-text"], ["class", "imx-chart-container-center", 4, "ngIf"], [4, "ngIf"], [1, "imx-chart-container-center"], [3, "options"], [1, "imx-aob-kpi-empty"]], template: function GlobalKpiComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "h2", 2);
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card")(4, "mat-card-subtitle");
            i0.ɵɵtext(5);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-card-content");
            i0.ɵɵtemplate(8, GlobalKpiComponent_ng_container_8_Template, 3, 1, "ng-container", 3);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(9, GlobalKpiComponent_ng_template_9_Template, 12, 5, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor)(11, GlobalKpiComponent_ng_template_11_Template, 4, 3, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            const nonExisting_r5 = i0.ɵɵreference(12);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, "#LDS#Global KPIs"), "\n");
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 6, "#LDS#These KPIs give you an overview of your applications, their contents and states."));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.hasKpis())("ngIfElse", nonExisting_r5);
        } }, dependencies: [i6.NgForOf, i6.NgIf, i6$1.MatCard, i6$1.MatCardContent, i6$1.MatCardSubtitle, i7.MatButton, i7.MatIconButton, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogContent, i1.EuiBillboardComponent, i1.EuiIconComponent, i3.TranslatePipe], styles: ["li[_ngcontent-%COMP%]{list-style-type:none;margin:0 15px 0 32px;display:table-row;align-items:center}li[_ngcontent-%COMP%] > .imx-kpi-display[_ngcontent-%COMP%]{display:table-cell;width:100%}li[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:nth-child(3n){display:table-cell}li[_ngcontent-%COMP%] > .imx-kpi-number[_ngcontent-%COMP%]{display:table-cell;color:#919799;text-align:right;font-size:16px;font-weight:600;padding:0 16px 0 0}.mat-mdc-card[_ngcontent-%COMP%]{display:flex;flex-direction:column}.mat-mdc-card-content[_ngcontent-%COMP%]{padding:0 10px 0 35px;overflow:auto}.mat-mdc-card-content[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:last-child{margin-bottom:10px}.mat-mdc-card-title[_ngcontent-%COMP%]{padding:20px 33px 0;font-weight:600;margin-bottom:0}.mat-mdc-card-subtitle[_ngcontent-%COMP%]{font-size:16px;font-weight:400;padding:5px 33px 20px;margin-bottom:0;flex-grow:1}p[_ngcontent-%COMP%]{font-size:14px;color:#919799;margin-top:0}h2[_ngcontent-%COMP%]{font-size:16px;font-weight:600;margin:30px 0 15px;text-align:center}.imx-kpi-list[_ngcontent-%COMP%]{overflow:auto;margin-bottom:5px;display:table}.mat-mdc-dialog-title[_ngcontent-%COMP%]{margin:0}.mat-mdc-dialog-content[_ngcontent-%COMP%]{max-height:100%}.imx-title-text[_ngcontent-%COMP%]{text-align:center;margin:0 0 0 45px;flex:1}.imx-subtitle-text[_ngcontent-%COMP%]{text-align:center;margin:0}.imx-aob-kpi-empty[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;margin-bottom:10px;margin-top:10px}.imx-aob-kpi-empty[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{margin-left:24px}  .bb-chart-arc text{fill:#2f3233}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GlobalKpiComponent, [{
        type: Component,
        args: [{ selector: 'imx-global-kpi', template: "<h2 class=\"mat-headline-5\">\n  {{ '#LDS#Global KPIs' | translate }}\n</h2>\n<mat-card>\n  <mat-card-subtitle>{{\n    '#LDS#These KPIs give you an overview of your applications, their contents and states.' | translate\n  }}</mat-card-subtitle>\n  <mat-card-content>\n    <ng-container *ngIf=\"hasKpis(); else nonExisting\">\n      <ul class=\"imx-kpi-list\">\n        <li *ngFor=\"let kpi of kpiData\">\n          <span class=\"imx-kpi-number\">{{\n            !kpi.calculated\n              ? '-'\n              : !kpi.currentDataValue\n                ? ''\n                : kpi.currentDataValue.toLocaleString(this.browserCulture, { minimumFractionDigits: 0, maximumFractionDigits: 3 })\n          }}</span>\n          <span class=\"imx-kpi-display\">{{ kpi.chartData.Display }}</span>\n          <button\n            [disabled]=\"!isCalculated(kpi.chartData)\"\n            color=\"primary\"\n            mat-button\n            data-imx-identifier=\"global_KPI_showShowDetails\"\n            (click)=\"showDetails(kpi)\"\n          >\n            {{ '#LDS#View' | translate }}\n          </button>\n        </li>\n      </ul>\n    </ng-container>\n  </mat-card-content>\n</mat-card>\n\n<ng-template #chartdialog let-data>\n  <div mat-dialog-title class=\"imx-card-title-l\">\n    <div class=\"imx-title-text\">{{ data.chartData.Display }}</div>\n    <button\n      mat-icon-button\n      color=\"basic\"\n      data-imx-identifier=\"global_KPI_closeChartDialog\"\n      class=\"imx-button-close-dialog\"\n      mat-dialog-close\n    >\n      <eui-icon icon=\"close\" size=\"large\"></eui-icon>\n    </button>\n  </div>\n  <div mat-dialog-content>\n    <p class=\"imx-subtitle-text\">{{ data.chartData.Description }}</p>\n    <div class=\"imx-chart-container-center\" *ngIf=\"data.pieChart != null\">\n      <eui-billboard [options]=\"data.pieChart\"></eui-billboard>\n    </div>\n    <h2 *ngIf=\"data.chartOptions != null\">{{ '#LDS#History' | translate }}</h2>\n    <div class=\"imx-chart-container-center\">\n      <eui-billboard [options]=\"data.chartDetails\"></eui-billboard>\n    </div>\n  </div>\n</ng-template>\n\n<!-- Template for non existing entitlements -->\n<ng-template #nonExisting>\n  <div class=\"imx-aob-kpi-empty\">\n    <span>{{ '#LDS#No global KPIs defined' | translate }}</span>\n  </div>\n</ng-template>\n", styles: ["li{list-style-type:none;margin:0 15px 0 32px;display:table-row;align-items:center}li>.imx-kpi-display{display:table-cell;width:100%}li :nth-child(3n){display:table-cell}li>.imx-kpi-number{display:table-cell;color:#919799;text-align:right;font-size:16px;font-weight:600;padding:0 16px 0 0}.mat-mdc-card{display:flex;flex-direction:column}.mat-mdc-card-content{padding:0 10px 0 35px;overflow:auto}.mat-mdc-card-content>:last-child{margin-bottom:10px}.mat-mdc-card-title{padding:20px 33px 0;font-weight:600;margin-bottom:0}.mat-mdc-card-subtitle{font-size:16px;font-weight:400;padding:5px 33px 20px;margin-bottom:0;flex-grow:1}p{font-size:14px;color:#919799;margin-top:0}h2{font-size:16px;font-weight:600;margin:30px 0 15px;text-align:center}.imx-kpi-list{overflow:auto;margin-bottom:5px;display:table}.mat-mdc-dialog-title{margin:0}.mat-mdc-dialog-content{max-height:100%}.imx-title-text{text-align:center;margin:0 0 0 45px;flex:1}.imx-subtitle-text{text-align:center;margin:0}.imx-aob-kpi-empty{display:flex;flex-direction:column;align-items:center;margin-bottom:10px;margin-top:10px}.imx-aob-kpi-empty span{margin-left:24px}::ng-deep .bb-chart-arc text{fill:#2f3233}\n"] }]
    }], () => [{ type: i2.ClassloggerService }, { type: GlobalKpiService }, { type: i1$2.MatDialog }, { type: i1.EuiLoadingService }, { type: i3.TranslateService }], { chartDialog: [{
            type: ViewChild,
            args: ['chartdialog', { static: true }]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GlobalKpiComponent, { className: "GlobalKpiComponent", filePath: "lib\\global-kpi\\global-kpi.component.ts", lineNumber: 49 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobApplicationsGuardService {
    aobPermissionService;
    authentication;
    appConfig;
    router;
    routeGuardService;
    onSessionResponse;
    constructor(aobPermissionService, authentication, appConfig, router, routeGuardService) {
        this.aobPermissionService = aobPermissionService;
        this.authentication = authentication;
        this.appConfig = appConfig;
        this.router = router;
        this.routeGuardService = routeGuardService;
    }
    async canActivate(route, state) {
        if (await this.routeGuardService.canActivate(route, state)) {
            const isApplicationOwner = await this.aobPermissionService.isAobApplicationOwner();
            const isApplicationAdmin = await this.aobPermissionService.isAobApplicationAdmin();
            if (!isApplicationOwner && !isApplicationAdmin) {
                this.router.navigate([this.appConfig.Config.routeConfig?.start], { queryParams: {} });
            }
            return isApplicationOwner || isApplicationAdmin;
        }
        this.router.navigate([this.appConfig.Config.routeConfig?.login]);
        return false;
    }
    ngOnDestroy() {
        if (this.onSessionResponse) {
            this.onSessionResponse.unsubscribe();
        }
    }
    static ɵfac = function AobApplicationsGuardService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AobApplicationsGuardService)(i0.ɵɵinject(AobPermissionsService), i0.ɵɵinject(i2.AuthenticationService), i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i4.Router), i0.ɵɵinject(i2.RouteGuardService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobApplicationsGuardService, factory: AobApplicationsGuardService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobApplicationsGuardService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobPermissionsService }, { type: i2.AuthenticationService }, { type: i2.AppConfigService }, { type: i4.Router }, { type: i2.RouteGuardService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobKpiGuardService {
    aobPermissionService;
    authentication;
    appConfig;
    router;
    routeGuardService;
    onSessionResponse;
    constructor(aobPermissionService, authentication, appConfig, router, routeGuardService) {
        this.aobPermissionService = aobPermissionService;
        this.authentication = authentication;
        this.appConfig = appConfig;
        this.router = router;
        this.routeGuardService = routeGuardService;
    }
    async canActivate(route, state) {
        if (await this.routeGuardService.canActivate(route, state)) {
            const isApplicationAdmin = await this.aobPermissionService.isAobApplicationAdmin();
            if (!isApplicationAdmin) {
                this.router.navigate([this.appConfig.Config.routeConfig?.start], { queryParams: {} });
            }
            return isApplicationAdmin;
        }
        this.router.navigate([this.appConfig.Config.routeConfig?.login]);
        return false;
    }
    ngOnDestroy() {
        if (this.onSessionResponse) {
            this.onSessionResponse.unsubscribe();
        }
    }
    static ɵfac = function AobKpiGuardService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AobKpiGuardService)(i0.ɵɵinject(AobPermissionsService), i0.ɵɵinject(i2.AuthenticationService), i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i4.Router), i0.ɵɵinject(i2.RouteGuardService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobKpiGuardService, factory: AobKpiGuardService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobKpiGuardService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: AobPermissionsService }, { type: i2.AuthenticationService }, { type: i2.AppConfigService }, { type: i4.Router }, { type: i2.RouteGuardService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class StartPageComponent {
    static ɵfac = function StartPageComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StartPageComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: StartPageComponent, selectors: [["imx-start"]], decls: 0, vars: 0, template: function StartPageComponent_Template(rf, ctx) { }, encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StartPageComponent, [{
        type: Component,
        args: [{ selector: 'imx-start', template: "<!-- not used anymore -->\n " }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(StartPageComponent, { className: "StartPageComponent", filePath: "lib\\start-page\\start-page.component.ts", lineNumber: 33 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GlobalKpiModule {
    static ɵfac = function GlobalKpiModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GlobalKpiModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: GlobalKpiModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [GlobalKpiService], imports: [CommonModule, MatCardModule, MatButtonModule, MatDialogModule, EuiCoreModule, TranslateModule, TilesModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GlobalKpiModule, [{
        type: NgModule,
        args: [{
                declarations: [GlobalKpiComponent, KpiTileComponent],
                imports: [CommonModule, MatCardModule, MatButtonModule, MatDialogModule, EuiCoreModule, TranslateModule, TilesModule],
                providers: [GlobalKpiService],
                exports: [GlobalKpiComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(GlobalKpiModule, { declarations: [GlobalKpiComponent, KpiTileComponent], imports: [CommonModule, MatCardModule, MatButtonModule, MatDialogModule, EuiCoreModule, TranslateModule, TilesModule], exports: [GlobalKpiComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class StartPageModule {
    static ɵfac = function StartPageModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StartPageModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: StartPageModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            LdsReplaceModule,
            MatButtonModule,
            MatCardModule,
            MatIconModule,
            TranslateModule,
            ClassloggerModule,
            AobUserModule,
            QbmModule,
            RouterModule,
            GlobalKpiModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StartPageModule, [{
        type: NgModule,
        args: [{
                declarations: [StartPageComponent],
                imports: [
                    CommonModule,
                    LdsReplaceModule,
                    MatButtonModule,
                    MatCardModule,
                    MatIconModule,
                    TranslateModule,
                    ClassloggerModule,
                    AobUserModule,
                    QbmModule,
                    RouterModule,
                    GlobalKpiModule,
                ],
                exports: [StartPageComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(StartPageModule, { declarations: [StartPageComponent], imports: [CommonModule,
        LdsReplaceModule,
        MatButtonModule,
        MatCardModule,
        MatIconModule,
        TranslateModule,
        ClassloggerModule,
        AobUserModule,
        QbmModule,
        RouterModule,
        GlobalKpiModule], exports: [StartPageComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'applications/kpi',
        component: GlobalKpiComponent,
        canActivate: [AobKpiGuardService],
        resolve: [RouteGuardService],
    },
    {
        path: 'applications',
        component: ApplicationsComponent,
        canActivate: [AobApplicationsGuardService],
        resolve: [RouteGuardService],
        children: [
            {
                path: 'navigation',
                component: ApplicationNavigationComponent,
                canActivate: [RouteGuardService],
                resolve: [RouteGuardService],
                data: {
                    contextId: HELP_CONTEXTUAL.Applications,
                },
            },
            {
                path: 'detail',
                component: ApplicationDetailComponent,
                outlet: 'content',
                canActivate: [RouteGuardService],
                resolve: [RouteGuardService],
            },
            { path: ':create:id', redirectTo: 'applications', pathMatch: 'full' },
        ],
    },
];
class AobConfigModule {
    initializer;
    logger;
    constructor(initializer, logger) {
        this.initializer = initializer;
        this.logger = logger;
        this.logger.info(this, '🔥 AOB loaded');
        this.initializer.onInit(routes);
        this.logger.info(this, '▶️ AOB initialized');
    }
    static ɵfac = function AobConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AobConfigModule)(i0.ɵɵinject(AobService), i0.ɵɵinject(i2.ClassloggerService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: AobConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [ApplicationsModule,
            CommonModule,
            EntitlementsModule,
            EuiCoreModule,
            EuiMaterialModule,
            StartPageModule,
            TilesModule,
            TranslateModule,
            RouterModule.forChild(routes)] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobConfigModule, [{
        type: NgModule,
        args: [{
                imports: [
                    ApplicationsModule,
                    CommonModule,
                    EntitlementsModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    StartPageModule,
                    TilesModule,
                    TranslateModule,
                    RouterModule.forChild(routes),
                ],
                declarations: [LockInfoAlertComponent],
            }]
    }], () => [{ type: AobService }, { type: i2.ClassloggerService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(AobConfigModule, { declarations: [LockInfoAlertComponent], imports: [ApplicationsModule,
        CommonModule,
        EntitlementsModule,
        EuiCoreModule,
        EuiMaterialModule,
        StartPageModule,
        TilesModule,
        TranslateModule, i4.RouterModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Hier kommen die zu exportierenden Komponenten hin
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AobConfigModule, ApplicationsComponent, ApplicationsModule, EntitlementsComponent, EntitlementsModule, StartPageComponent };
//# sourceMappingURL=aob.mjs.map
