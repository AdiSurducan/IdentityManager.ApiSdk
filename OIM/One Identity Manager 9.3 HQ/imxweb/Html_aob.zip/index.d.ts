/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="aob" />
export * from './public-api';
