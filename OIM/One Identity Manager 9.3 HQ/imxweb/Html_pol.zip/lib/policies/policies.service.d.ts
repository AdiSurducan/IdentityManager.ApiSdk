import { PolicyConfig, PortalPolicies, PortalPoliciesMitigatingcontrols } from '@imx-modules/imx-api-pol';
import { CollectionLoadParameters, DataModel, EntitySchema, ExtendedTypedEntityCollection } from '@imx-modules/imx-qbm-dbts';
import { AppConfigService } from 'qbm';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class PoliciesService {
    private apiservice;
    private appConfig;
    constructor(apiservice: ApiService, appConfig: AppConfigService);
    get policySchema(): EntitySchema;
    featureConfig(): Promise<PolicyConfig>;
    getPolicies(parameter?: CollectionLoadParameters, signal?: AbortSignal): Promise<ExtendedTypedEntityCollection<PortalPolicies, unknown>>;
    getDataModel(): Promise<DataModel>;
    policyReport(uidpolicy: string): string;
    /**
     * Calls the api for the mitigating controls associated with a policy
     * @param uid policy uid
     * @returns a promise of the array of mitigating controls
     */
    getMitigatingControls(uid: string): Promise<ExtendedTypedEntityCollection<PortalPoliciesMitigatingcontrols, unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PoliciesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PoliciesService>;
}
