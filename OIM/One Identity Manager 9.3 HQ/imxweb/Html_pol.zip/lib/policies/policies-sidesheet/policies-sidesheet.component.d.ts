import { OnDestroy } from '@angular/core';
import { EuiDownloadOptions, EuiSidesheetRef } from '@elemental-ui/core';
import { Subscription } from 'rxjs';
import { PortalPolicies } from '@imx-modules/imx-api-pol';
import { ColumnDependentReference, ElementalUiConfigService } from 'qbm';
import { PoliciesService } from '../policies.service';
import * as i0 from "@angular/core";
export declare class PoliciesSidesheetComponent implements OnDestroy {
    data: {
        selectedPolicy: PortalPolicies;
        hasRiskIndex: boolean;
        isMControlPerViolation: boolean;
    };
    sidesheetRef: EuiSidesheetRef;
    private readonly policiesProvider;
    reportDownload: EuiDownloadOptions;
    cdrList: ColumnDependentReference[];
    uidNonCompliance: string;
    uidCompliance: string;
    subscriptions$: Subscription[];
    constructor(data: {
        selectedPolicy: PortalPolicies;
        hasRiskIndex: boolean;
        isMControlPerViolation: boolean;
    }, sidesheetRef: EuiSidesheetRef, policiesProvider: PoliciesService, elementalUiConfigService: ElementalUiConfigService);
    get objectType(): string;
    get objectUid(): string;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PoliciesSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PoliciesSidesheetComponent, "imx-policies-sidesheet", never, {}, {}, never, never, false, never>;
}
