import * as i0 from "@angular/core";
import * as i1 from "./policies.component";
import * as i2 from "./policies-sidesheet/policies-sidesheet.component";
import * as i3 from "./mitigating-controls-policy/mitigating-controls-policy.component";
import * as i4 from "@angular/common";
import * as i5 from "@elemental-ui/core";
import * as i6 from "@ngx-translate/core";
import * as i7 from "qbm";
import * as i8 from "@angular/material/button";
import * as i9 from "@angular/material/card";
import * as i10 from "@angular/material/tabs";
import * as i11 from "qer";
import * as i12 from "../policy-violations/policy-violations.module";
import * as i13 from "@angular/material/table";
export declare class PoliciesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PoliciesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PoliciesModule, [typeof i1.PoliciesComponent, typeof i2.PoliciesSidesheetComponent, typeof i3.MitigatingControlsPolicyComponent], [typeof i4.CommonModule, typeof i5.EuiCoreModule, typeof i6.TranslateModule, typeof i7.CdrModule, typeof i7.DataTableModule, typeof i7.DataSourceToolbarModule, typeof i8.MatButtonModule, typeof i9.MatCardModule, typeof i10.MatTabsModule, typeof i11.StatisticsModule, typeof i11.ObjectHyperviewModule, typeof i7.HelpContextualModule, typeof i12.PolicyViolationsModule, typeof i7.DataViewModule, typeof i13.MatTableModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PoliciesModule>;
}
