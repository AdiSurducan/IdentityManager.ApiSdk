import { ObjectInfo, PortalPoliciesViolationslist } from '@imx-modules/imx-api-pol';
import { ColumnDependentReference } from 'qbm';
export declare class PolicyViolation extends PortalPoliciesViolationslist {
    private readonly baseObject;
    properties: ColumnDependentReference[];
    /**
     * The color and the caption depending on the value of the state of a {@link PortalPoliciesViolationslist}.
     */
    get stateBadge(): {
        color: 'blue' | 'orange' | 'green';
        caption: string;
    };
    readonly data: ObjectInfo[];
    private stateBadgeColor;
    private stateCaption;
    constructor(baseObject: PortalPoliciesViolationslist, extendedData: ObjectInfo[]);
    get key(): string;
    private initPropertyInfo;
    private initStateBadge;
}
