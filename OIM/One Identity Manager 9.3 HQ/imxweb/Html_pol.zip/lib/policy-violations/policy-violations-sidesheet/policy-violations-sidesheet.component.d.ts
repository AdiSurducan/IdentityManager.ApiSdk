import { OnDestroy } from '@angular/core';
import { EuiLoadingService, EuiSidesheetRef } from '@elemental-ui/core';
import { ObjectInfo } from '@imx-modules/imx-api-pol';
import { ColumnDependentReference } from 'qbm';
import { Subscription } from 'rxjs';
import { PolicyViolation } from '../policy-violation';
import { PolicyViolationsService } from '../policy-violations.service';
import * as i0 from "@angular/core";
export declare class PolicyViolationsSidesheetComponent implements OnDestroy {
    data: {
        policyViolation: PolicyViolation;
        isMControlPerViolation: boolean;
        isReadOnly: boolean;
    };
    private readonly policyViolationService;
    readonly sideSheetRef: EuiSidesheetRef;
    private readonly euiLoadingService;
    cdrList: ColumnDependentReference[];
    selectedHyperviewType: string;
    selectedHyperviewUID: string;
    selectedOption: ObjectInfo;
    result: boolean;
    closeSubscription: Subscription;
    get isPending(): boolean;
    get objectType(): string;
    get objectUid(): string;
    constructor(data: {
        policyViolation: PolicyViolation;
        isMControlPerViolation: boolean;
        isReadOnly: boolean;
    }, policyViolationService: PolicyViolationsService, sideSheetRef: EuiSidesheetRef, euiLoadingService: EuiLoadingService);
    ngOnDestroy(): void;
    /**
     * Opens the Approve-Sidesheet for the current selected rule violations.
     */
    approve(): Promise<void>;
    /**
     * Opens the Deny-Sidesheet for the current selected rule violations.
     */
    deny(): Promise<void>;
    get relatedOptions(): ObjectInfo[];
    setHyperviewObject(selectedRelatedObject: ObjectInfo): void;
    onHyperviewOptionSelected(): void;
    private reloadData;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyViolationsSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PolicyViolationsSidesheetComponent, "imx-policy-violations-sidesheet", never, {}, {}, never, never, false, never>;
}
