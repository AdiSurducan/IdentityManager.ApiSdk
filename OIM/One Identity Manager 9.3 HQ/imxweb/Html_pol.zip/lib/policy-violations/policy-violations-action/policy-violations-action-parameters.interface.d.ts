import { BaseCdr } from 'qbm';
/**
 * Defines the {@link BaseCdr} for an action that can be performed on a policy violation
 */
export interface PolicyViolationsActionParameters {
    /**
     * A free text field for a reason
     */
    reason: BaseCdr;
    /**
     * A FK-Editor for standard justifications
     */
    justification?: BaseCdr;
}
