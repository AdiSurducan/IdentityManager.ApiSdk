import { OnInit } from '@angular/core';
import { AbstractControl, UntypedFormGroup } from '@angular/forms';
import { PolicyViolation } from '../../policy-violation';
import { PolicyViolationsAction } from '../policy-violations-action.interface';
import * as i0 from "@angular/core";
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a single policy violation.
 * There is an alternative component for the case of a decision for multiple policy violations as
 *  well: {@link PolicyViolationActionMultiActionComponent}.
 */
export declare class PolicyViolationsActionSingleActionComponent implements OnInit {
    /**
     * @ignore since this is only an internal component.
     *
     * Data coming from the service about the policy violation.
     */
    data: PolicyViolationsAction;
    /**
     * @ignore since this is only an internal component.
     *
     * The form group to which the necessary form fields will be added.
     */
    formGroup: UntypedFormGroup;
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * The single policy violation taken from {@link data}
     */
    policyViolation: PolicyViolation;
    /**
     * @ignore since this is only an internal component
     *
     * Sets up the {@link columns} to be displayed/edited during OnInit lifecycle hook.
     */
    ngOnInit(): void;
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * Handles the event emitted when a cdr editor created a new form control.
     *
     * @param name The name of the form control
     * @param control The form control
     */
    onFormControlCreated(name: string, control: AbstractControl): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyViolationsActionSingleActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PolicyViolationsActionSingleActionComponent, "imx-policy-violations-action-single-action", never, { "data": { "alias": "data"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; }, {}, never, never, false, never>;
}
