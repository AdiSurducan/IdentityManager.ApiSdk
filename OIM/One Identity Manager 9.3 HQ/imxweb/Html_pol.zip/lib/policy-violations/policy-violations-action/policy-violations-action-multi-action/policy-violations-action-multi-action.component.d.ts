import { UntypedFormGroup } from '@angular/forms';
import { PolicyViolationsAction } from '../policy-violations-action.interface';
import * as i0 from "@angular/core";
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a multiple policy violations.
 * There is an alternative component for the case of a decision for a single policy violation as well
 * {@link  PolicyViolationsActionSingleActionComponent}
 */
export declare class PolicyViolationsActionMultiActionComponent {
    /**
     * @ignore since this is only an internal component.
     *
     * Data coming from the service about the policy violations.
     */
    data: PolicyViolationsAction;
    /**
     * @ignore since this is only an internal component.
     *
     * The form group to which the necessary form fields will be added.
     */
    formGroup: UntypedFormGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyViolationsActionMultiActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PolicyViolationsActionMultiActionComponent, "imx-policy-violations-action-multi-action", never, { "data": { "alias": "data"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; }, {}, never, never, false, never>;
}
