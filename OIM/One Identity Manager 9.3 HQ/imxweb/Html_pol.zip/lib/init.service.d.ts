import { Route, Router } from '@angular/router';
import { NotificationRegistryService } from 'qer';
import { ExtService, MenuService } from 'qbm';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly extService;
    private readonly menuService;
    private readonly notificationService;
    private readonly router;
    constructor(extService: ExtService, menuService: MenuService, notificationService: NotificationRegistryService, router: Router);
    onInit(routes: Route[]): void;
    private addRoutes;
    private setupMenu;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
