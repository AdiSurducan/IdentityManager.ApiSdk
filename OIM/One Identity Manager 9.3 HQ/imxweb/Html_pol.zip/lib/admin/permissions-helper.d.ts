export declare function isQERPolicyAdmin(features: string[] | undefined): boolean;
export declare function isQERPolicyOwner(features: string[] | undefined): boolean;
