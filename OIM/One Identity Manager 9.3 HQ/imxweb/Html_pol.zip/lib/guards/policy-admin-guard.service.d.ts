import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { AppConfigService, RouteGuardService } from 'qbm';
import { PermissionsService } from '../admin/permissions.service';
import * as i0 from "@angular/core";
export declare class PolicyAdminGuardService {
    private readonly permissionService;
    private readonly appConfig;
    private readonly router;
    private readonly routeGuardService;
    constructor(permissionService: PermissionsService, appConfig: AppConfigService, router: Router, routeGuardService: RouteGuardService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyAdminGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PolicyAdminGuardService>;
}
