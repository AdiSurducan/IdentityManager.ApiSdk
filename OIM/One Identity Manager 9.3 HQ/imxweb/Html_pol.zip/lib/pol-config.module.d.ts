import { ClassloggerService } from 'qbm';
import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "./dashboard-plugin/dashboard-plugin.component";
import * as i2 from "@angular/common";
import * as i3 from "qer";
import * as i4 from "@angular/router";
import * as i5 from "@angular/material/icon";
import * as i6 from "@angular/material/list";
import * as i7 from "@ngx-translate/core";
import * as i8 from "@elemental-ui/core";
import * as i9 from "./policies/policies.module";
import * as i10 from "./policy-violations/policy-violations.module";
export declare class PolConfigModule {
    private readonly initializer;
    private readonly logger;
    constructor(initializer: InitService, logger: ClassloggerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<PolConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PolConfigModule, [typeof i1.DashboardPluginComponent], [typeof i2.CommonModule, typeof i3.TilesModule, typeof i4.RouterModule, typeof i5.MatIconModule, typeof i6.MatListModule, typeof i7.TranslateModule, typeof i8.EuiCoreModule, typeof i9.PoliciesModule, typeof i10.PolicyViolationsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PolConfigModule>;
}
