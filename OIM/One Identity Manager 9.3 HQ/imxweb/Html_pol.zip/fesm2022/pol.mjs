import * as i9 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Component, Injectable, Input, Inject, NgModule } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import * as i2$1 from '@angular/material/list';
import { MatListModule } from '@angular/material/list';
import * as i3 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i4 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i2$2 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i3$1 from 'qbm';
import { BaseReadonlyCdr, BaseCdr, calculateSidesheetWidth, BusyService, DataViewSource, BulkPropertyEditorModule, CdrModule, DataTableModule, DataSourceToolbarModule, SelectedElementsModule, HelpContextualModule, DataViewModule, RouteGuardService, HELP_CONTEXTUAL } from 'qbm';
import * as i2 from 'qer';
import { JustificationType, JustificationModule, StatisticsModule, ObjectHyperviewModule, TilesModule } from 'qer';
import { MethodDefinition, ValType, DbObjectKey, DisplayColumns } from '@imx-modules/imx-qbm-dbts';
import { V2Client, TypedClient, PortalPoliciesViolationslist, V2ApiClientMethodFactory, PortalPoliciesViolations } from '@imx-modules/imx-api-pol';
import * as i5 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i1 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i8$1 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import { Subject, first } from 'rxjs';
import * as i4$1 from '@angular/forms';
import { UntypedFormGroup, FormControl, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import * as i3$2 from '@angular/material/core';
import * as i6 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i7 from '@angular/material/select';
import * as i8 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i9$1 from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function DashboardPluginComponent_imx_badge_tile_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-badge-tile", 1);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵlistener("actionClick", function DashboardPluginComponent_imx_badge_tile_0_Template_imx_badge_tile_actionClick_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.router.navigate(["compliance", "policyviolations", "approve"])); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("caption", i0.ɵɵpipeBind1(1, 3, "#LDS#Heading Pending Policy Violations"))("value", ctx_r1.pendingItems.OpenQERPolicyHasObject.toString())("identifier", "pol-rule-violation-approvals");
} }
class DashboardPluginComponent {
    router;
    dashboardService;
    userModelSvc;
    pendingItems;
    constructor(router, dashboardService, userModelSvc) {
        this.router = router;
        this.dashboardService = dashboardService;
        this.userModelSvc = userModelSvc;
    }
    hasPendingItems() {
        return !!this.pendingItems?.OpenQERPolicyHasObject && this.pendingItems.OpenQERPolicyHasObject > 0;
    }
    async ngOnInit() {
        const busy = this.dashboardService.beginBusy();
        try {
            this.pendingItems = await this.userModelSvc.getPendingItems();
        }
        finally {
            busy.endBusy();
        }
    }
    static ɵfac = function DashboardPluginComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DashboardPluginComponent)(i0.ɵɵdirectiveInject(i3.Router), i0.ɵɵdirectiveInject(i2.DashboardService), i0.ɵɵdirectiveInject(i2.UserModelService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DashboardPluginComponent, selectors: [["ng-component"]], decls: 1, vars: 1, consts: [["data-imx-identifier", "pol-dashboard--plugin-badge-tile-violations-approvals", 3, "caption", "value", "identifier", "actionClick", 4, "ngIf"], ["data-imx-identifier", "pol-dashboard--plugin-badge-tile-violations-approvals", 3, "actionClick", "caption", "value", "identifier"]], template: function DashboardPluginComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, DashboardPluginComponent_imx_badge_tile_0_Template, 2, 5, "imx-badge-tile", 0);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.hasPendingItems());
        } }, dependencies: [i9.NgIf, i2.BadgeTileComponent, i4.TranslatePipe], encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DashboardPluginComponent, [{
        type: Component,
        args: [{ template: "<!-- todo: add dashboard tiles -->\n<imx-badge-tile\n  data-imx-identifier=\"pol-dashboard--plugin-badge-tile-violations-approvals\"\n  [caption]=\"'#LDS#Heading Pending Policy Violations' | translate\"\n  *ngIf=\"hasPendingItems()\"\n  [value]=\"pendingItems.OpenQERPolicyHasObject!.toString()\"\n  [identifier]=\"'pol-rule-violation-approvals'\"\n  (actionClick)=\"router.navigate(['compliance', 'policyviolations', 'approve'])\"\n>\n</imx-badge-tile>\n" }]
    }], () => [{ type: i3.Router }, { type: i2.DashboardService }, { type: i2.UserModelService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DashboardPluginComponent, { className: "DashboardPluginComponent", filePath: "lib\\dashboard-plugin\\dashboard-plugin.component.ts", lineNumber: 35 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isQERPolicyAdmin(features) {
    return features?.find((item) => item === 'Portal_UI_QERPolicyAdmin') != null;
}
function isQERPolicyOwner(features) {
    return features?.find((item) => item === 'Portal_UI_QERPolicyOwner') != null;
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PermissionsService {
    userService;
    constructor(userService) {
        this.userService = userService;
    }
    async isQERPolicyAdmin() {
        return isQERPolicyAdmin((await this.userService.getFeatures()).Features);
    }
    async isQERPolicyOwner() {
        return isQERPolicyOwner((await this.userService.getFeatures()).Features);
    }
    static ɵfac = function PermissionsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PermissionsService)(i0.ɵɵinject(i2.UserModelService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PermissionsService, factory: PermissionsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PermissionsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2.UserModelService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PolicyAdminGuardService {
    permissionService;
    appConfig;
    router;
    routeGuardService;
    constructor(permissionService, appConfig, router, routeGuardService) {
        this.permissionService = permissionService;
        this.appConfig = appConfig;
        this.router = router;
        this.routeGuardService = routeGuardService;
    }
    async canActivate(route, state) {
        if (await this.routeGuardService.canActivate(route, state)) {
            const isPolicyAdmin = await this.permissionService.isQERPolicyAdmin();
            if (!isPolicyAdmin) {
                this.router.navigate([this.appConfig.Config.routeConfig?.start]);
            }
            return isPolicyAdmin;
        }
        this.router.navigate([this.appConfig.Config.routeConfig?.login]);
        return false;
    }
    static ɵfac = function PolicyAdminGuardService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolicyAdminGuardService)(i0.ɵɵinject(PermissionsService), i0.ɵɵinject(i3$1.AppConfigService), i0.ɵɵinject(i3.Router), i0.ɵɵinject(i3$1.RouteGuardService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PolicyAdminGuardService, factory: PolicyAdminGuardService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyAdminGuardService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: PermissionsService }, { type: i3$1.AppConfigService }, { type: i3.Router }, { type: i3$1.RouteGuardService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PolicyAdminOrOwnerGuardService {
    permissionService;
    appConfig;
    router;
    routeGuardService;
    constructor(permissionService, appConfig, router, routeGuardService) {
        this.permissionService = permissionService;
        this.appConfig = appConfig;
        this.router = router;
        this.routeGuardService = routeGuardService;
    }
    async canActivate(route, state) {
        if (await this.routeGuardService.canActivate(route, state)) {
            const hasFeature = (await this.permissionService.isQERPolicyAdmin()) || (await this.permissionService.isQERPolicyOwner());
            if (!hasFeature) {
                this.router.navigate([this.appConfig.Config.routeConfig?.start]);
            }
            return hasFeature;
        }
        this.router.navigate([this.appConfig.Config.routeConfig?.login]);
        return false;
    }
    static ɵfac = function PolicyAdminOrOwnerGuardService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolicyAdminOrOwnerGuardService)(i0.ɵɵinject(PermissionsService), i0.ɵɵinject(i3$1.AppConfigService), i0.ɵɵinject(i3.Router), i0.ɵɵinject(i3$1.RouteGuardService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PolicyAdminOrOwnerGuardService, factory: PolicyAdminOrOwnerGuardService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyAdminOrOwnerGuardService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: PermissionsService }, { type: i3$1.AppConfigService }, { type: i3.Router }, { type: i3$1.RouteGuardService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    extService;
    menuService;
    notificationService;
    router;
    constructor(extService, menuService, notificationService, router) {
        this.extService = extService;
        this.menuService = menuService;
        this.notificationService = notificationService;
        this.router = router;
        this.setupMenu();
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register('Dashboard-SmallTiles', { instance: DashboardPluginComponent });
        // Register handler for policy notifications
        this.notificationService.registerRedirectNotificationHandler({
            id: 'OpenQERPolicyHasObject',
            message: '#LDS#There are new policy violations for which you can grant or deny exceptions.',
            route: 'compliance/policyviolations/approve',
        });
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features) => {
            if (!preProps.includes('QERPOLICY'))
                return undefined;
            const ispolicyadmin = isQERPolicyAdmin(features);
            const ispolicyowner = isQERPolicyOwner(features);
            if (!ispolicyadmin && !ispolicyowner)
                return undefined;
            const items = [];
            if (ispolicyadmin || ispolicyowner) {
                items.push({
                    id: 'POL_Policies',
                    route: 'compliance/policies',
                    title: '#LDS#Menu Entry Company policies',
                    sorting: '20-10',
                });
            }
            if (ispolicyadmin) {
                items.push({
                    id: 'POL_policy-violations',
                    route: 'compliance/policyviolations',
                    title: '#LDS#Menu Entry Policy violations',
                    sorting: '20-10',
                });
            }
            const menu = {
                id: 'ROOT_Compliance',
                title: '#LDS#Compliance',
                sorting: '25',
                items: items,
            };
            return menu;
        });
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i3$1.ExtService), i0.ɵɵinject(i3$1.MenuService), i0.ɵɵinject(i2.NotificationRegistryService), i0.ɵɵinject(i3.Router)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i3$1.ExtService }, { type: i3$1.MenuService }, { type: i2.NotificationRegistryService }, { type: i3.Router }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing POL API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function ApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApiService)(i0.ɵɵinject(i3$1.AppConfigService), i0.ɵɵinject(i3$1.ClassloggerService), i0.ɵɵinject(i3$1.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApiService, factory: ApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i3$1.AppConfigService }, { type: i3$1.ClassloggerService }, { type: i3$1.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PoliciesService {
    apiservice;
    appConfig;
    constructor(apiservice, appConfig) {
        this.apiservice = apiservice;
        this.appConfig = appConfig;
    }
    get policySchema() {
        return this.apiservice.typedClient.PortalPolicies.GetSchema();
    }
    async featureConfig() {
        return this.apiservice.client.portal_policy_config_get();
    }
    async getPolicies(parameter, signal) {
        return this.apiservice.typedClient.PortalPolicies.Get(parameter, { signal });
    }
    async getDataModel() {
        return this.apiservice.client.portal_policies_datamodel_get();
    }
    policyReport(uidpolicy) {
        const path = `policies/${uidpolicy}/report`;
        return `${this.appConfig.BaseUrl}/portal/${path}`;
    }
    /**
     * Calls the api for the mitigating controls associated with a policy
     * @param uid policy uid
     * @returns a promise of the array of mitigating controls
     */
    async getMitigatingControls(uid) {
        return this.apiservice.typedClient.PortalPoliciesMitigatingcontrols.Get(uid);
    }
    static ɵfac = function PoliciesService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PoliciesService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i3$1.AppConfigService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PoliciesService, factory: PoliciesService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PoliciesService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }, { type: i3$1.AppConfigService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PolicyViolation extends PortalPoliciesViolationslist {
    baseObject;
    properties;
    /**
     * The color and the caption depending on the value of the state of a {@link PortalPoliciesViolationslist}.
     */
    get stateBadge() {
        return {
            color: this.stateBadgeColor,
            caption: this.stateCaption,
        };
    }
    data;
    stateBadgeColor;
    stateCaption;
    constructor(baseObject, extendedData) {
        super(baseObject.GetEntity());
        this.baseObject = baseObject;
        this.initPropertyInfo();
        this.initStateBadge();
        this.data = extendedData || [];
    }
    get key() {
        return this.baseObject.GetEntity().GetKeys()[0];
    }
    initPropertyInfo() {
        const props = [this.UID_QERPolicy, this.Description, this.ObjectKey];
        if (this.State.value.toLowerCase() !== 'pending') {
            props.push(...[this.UID_PersonDecisionMade, this.UID_QERJustification, this.DecisionReason, this.DecisionDate]);
        }
        this.properties = props
            .filter((property) => property.value != null && property.value !== '')
            .map((property) => new BaseReadonlyCdr(property.Column));
    }
    async initStateBadge() {
        switch (this.State.value) {
            case 'approved':
                this.stateBadgeColor = 'green';
                this.stateCaption = '#LDS#Exception granted';
                break;
            case 'denied':
                this.stateBadgeColor = 'orange';
                this.stateCaption = '#LDS#Exception denied';
                break;
            default:
                this.stateBadgeColor = 'blue';
                this.stateCaption = '#LDS#Approval decision pending';
        }
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function PolicyViolationsActionMultiActionComponent_mat_list_item_16_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 6);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const policyViolationApproval_r1 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, policyViolationApproval_r1.stateBadge.caption), " ");
} }
function PolicyViolationsActionMultiActionComponent_mat_list_item_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-list-item")(1, "div", 4);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, PolicyViolationsActionMultiActionComponent_mat_list_item_16_div_3_Template, 3, 3, "div", 5);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_2_0;
    const policyViolationApproval_r1 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", policyViolationApproval_r1 == null ? null : (tmp_2_0 = policyViolationApproval_r1.GetEntity()) == null ? null : tmp_2_0.GetDisplay(), " ");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", policyViolationApproval_r1 == null ? null : policyViolationApproval_r1.stateBadge == null ? null : policyViolationApproval_r1.stateBadge.caption);
} }
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a multiple policy violations.
 * There is an alternative component for the case of a decision for a single policy violation as well
 * {@link  PolicyViolationsActionSingleActionComponent}
 */
class PolicyViolationsActionMultiActionComponent {
    /**
     * @ignore since this is only an internal component.
     *
     * Data coming from the service about the policy violations.
     */
    data;
    /**
     * @ignore since this is only an internal component.
     *
     * The form group to which the necessary form fields will be added.
     */
    formGroup;
    static ɵfac = function PolicyViolationsActionMultiActionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolicyViolationsActionMultiActionComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsActionMultiActionComponent, selectors: [["imx-policy-violations-action-multi-action"]], inputs: { data: "data", formGroup: "formGroup" }, decls: 17, vars: 12, consts: [["data-imx-identifier", "policy-violation-property-reason", 3, "controlCreated", "reasonStandard", "reasonFreetext"], [1, "imx-selection-card"], [1, "imx-list-multi-action"], [4, "ngFor", "ngForOf"], [1, "mat-mdc-line"], ["class", "mat-mdc-line imx-list-item-subtitle imx-margin-bottom-5", 4, "ngIf"], [1, "mat-mdc-line", "imx-list-item-subtitle", "imx-margin-bottom-5"]], template: function PolicyViolationsActionMultiActionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-card-subtitle");
            i0.ɵɵtext(5);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-card-content")(8, "div")(9, "imx-decision-reason", 0);
            i0.ɵɵlistener("controlCreated", function PolicyViolationsActionMultiActionComponent_Template_imx_decision_reason_controlCreated_9_listener($event) { return ctx.formGroup.addControl("reason", $event); });
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(10, "mat-card", 1)(11, "mat-card-title");
            i0.ɵɵtext(12);
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(14, "mat-card-content")(15, "mat-list", 2);
            i0.ɵɵtemplate(16, PolicyViolationsActionMultiActionComponent_mat_list_item_16_Template, 4, 2, "mat-list-item", 3);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 6, "#LDS#Heading General Settings"));
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(6, 8, "#LDS#Here you can make settings that are applied to each selected policy violation."), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("reasonStandard", ctx.data.actionParameters.justification)("reasonFreetext", ctx.data.actionParameters.reason);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(13, 10, "#LDS#Heading Selected Policy Violations"));
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngForOf", ctx.data == null ? null : ctx.data.policyViolations);
        } }, dependencies: [i1.MatCard, i1.MatCardContent, i1.MatCardSubtitle, i1.MatCardTitle, i2$1.MatList, i2$1.MatListItem, i9.NgForOf, i9.NgIf, i2.DecisionReasonComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden}mat-card[_ngcontent-%COMP%]{margin-bottom:20px}mat-card-content[_ngcontent-%COMP%]{overflow:auto}.imx-selection-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}imx-bulk-editor[_ngcontent-%COMP%]{margin-top:20px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsActionMultiActionComponent, [{
        type: Component,
        args: [{ selector: 'imx-policy-violations-action-multi-action', template: "<mat-card>\n  <mat-card-title>{{ '#LDS#Heading General Settings' | translate }}</mat-card-title>\n  <mat-card-subtitle\n    >{{ '#LDS#Here you can make settings that are applied to each selected policy violation.' | translate }}\n  </mat-card-subtitle>\n  <mat-card-content>\n    <div>\n      <imx-decision-reason\n        [reasonStandard]=\"data.actionParameters.justification\"\n        [reasonFreetext]=\"data.actionParameters.reason\"\n        (controlCreated)=\"formGroup.addControl('reason', $event)\"\n        data-imx-identifier=\"policy-violation-property-reason\"\n      >\n      </imx-decision-reason>\n    </div>\n  </mat-card-content>\n</mat-card>\n\n<mat-card class=\"imx-selection-card\">\n  <mat-card-title>{{ '#LDS#Heading Selected Policy Violations' | translate }}</mat-card-title>\n  <mat-card-content>\n    <mat-list class=\"imx-list-multi-action\">\n      <mat-list-item *ngFor=\"let policyViolationApproval of data?.policyViolations\">\n        <div class=\"mat-mdc-line\">\n          {{ policyViolationApproval?.GetEntity()?.GetDisplay() }}\n        </div>\n        <div *ngIf=\"policyViolationApproval?.stateBadge?.caption\" class=\"mat-mdc-line imx-list-item-subtitle imx-margin-bottom-5\">\n          {{ policyViolationApproval.stateBadge.caption | translate }}\n        </div>\n      </mat-list-item>\n    </mat-list>\n  </mat-card-content>\n</mat-card>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden}mat-card{margin-bottom:20px}mat-card-content{overflow:auto}.imx-selection-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}imx-bulk-editor{margin-top:20px}\n"] }]
    }], null, { data: [{
            type: Input
        }], formGroup: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PolicyViolationsActionMultiActionComponent, { className: "PolicyViolationsActionMultiActionComponent", filePath: "lib\\policy-violations\\policy-violations-action\\policy-violations-action-multi-action\\policy-violations-action-multi-action.component.ts", lineNumber: 44 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a single policy violation.
 * There is an alternative component for the case of a decision for multiple policy violations as
 *  well: {@link PolicyViolationActionMultiActionComponent}.
 */
class PolicyViolationsActionSingleActionComponent {
    /**
     * @ignore since this is only an internal component.
     *
     * Data coming from the service about the policy violation.
     */
    data;
    /**
     * @ignore since this is only an internal component.
     *
     * The form group to which the necessary form fields will be added.
     */
    formGroup;
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * The single policy violation taken from {@link data}
     */
    policyViolation;
    /**
     * @ignore since this is only an internal component
     *
     * Sets up the {@link columns} to be displayed/edited during OnInit lifecycle hook.
     */
    ngOnInit() {
        this.policyViolation = this.data.policyViolations[0];
    }
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * Handles the event emitted when a cdr editor created a new form control.
     *
     * @param name The name of the form control
     * @param control The form control
     */
    onFormControlCreated(name, control) {
        // use setTimeout to make addControl asynchronous in order to avoid "NG0100: Expression has changed after it was checked"
        setTimeout(() => this.formGroup.addControl(name, control));
    }
    static ɵfac = function PolicyViolationsActionSingleActionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolicyViolationsActionSingleActionComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsActionSingleActionComponent, selectors: [["imx-policy-violations-action-single-action"]], inputs: { data: "data", formGroup: "formGroup" }, decls: 7, vars: 4, consts: [[1, "imx-card-title-s"], ["data-imx-identifier", "policy-violation-property-reason", 3, "controlCreated", "reasonStandard", "reasonFreetext"]], template: function PolicyViolationsActionSingleActionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title", 0);
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card-subtitle");
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-card-content")(6, "imx-decision-reason", 1);
            i0.ɵɵlistener("controlCreated", function PolicyViolationsActionSingleActionComponent_Template_imx_decision_reason_controlCreated_6_listener($event) { return ctx.formGroup.addControl("reason", $event); });
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            let tmp_0_0;
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate((tmp_0_0 = ctx.policyViolation.GetEntity()) == null ? null : tmp_0_0.GetDisplay());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.policyViolation.State.Column.GetDisplayValue());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("reasonStandard", ctx.data.actionParameters.justification)("reasonFreetext", ctx.data.actionParameters.reason);
        } }, dependencies: [i1.MatCard, i1.MatCardContent, i1.MatCardSubtitle, i1.MatCardTitle, i2.DecisionReasonComponent], styles: ["mat-card-content[_ngcontent-%COMP%]{overflow:hidden}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsActionSingleActionComponent, [{
        type: Component,
        args: [{ selector: 'imx-policy-violations-action-single-action', template: "<mat-card>\n  <mat-card-title class=\"imx-card-title-s\">{{ policyViolation.GetEntity()?.GetDisplay() }}</mat-card-title>\n  <mat-card-subtitle>{{ policyViolation.State.Column.GetDisplayValue() }}</mat-card-subtitle>\n  <mat-card-content>\n    <imx-decision-reason\n      [reasonStandard]=\"data.actionParameters.justification\"\n      [reasonFreetext]=\"data.actionParameters.reason\"\n      (controlCreated)=\"formGroup.addControl('reason', $event)\"\n      data-imx-identifier=\"policy-violation-property-reason\"\n    >\n    </imx-decision-reason>\n  </mat-card-content>\n</mat-card>\n", styles: ["mat-card-content{overflow:hidden}\n"] }]
    }], null, { data: [{
            type: Input
        }], formGroup: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PolicyViolationsActionSingleActionComponent, { className: "PolicyViolationsActionSingleActionComponent", filePath: "lib\\policy-violations\\policy-violations-action\\policy-violations-action-single-action\\policy-violations-action-single-action.component.ts", lineNumber: 45 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function PolicyViolationsActionComponent_p_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, ctx_r0.data.description));
} }
function PolicyViolationsActionComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelement(1, "imx-policy-violations-action-multi-action", 5);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("formGroup", ctx_r0.formGroup)("data", ctx_r0.data);
} }
function PolicyViolationsActionComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelement(1, "imx-policy-violations-action-single-action", 5);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("formGroup", ctx_r0.formGroup)("data", ctx_r0.data);
} }
function PolicyViolationsActionComponent_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 6);
    i0.ɵɵlistener("click", function PolicyViolationsActionComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.sideSheetRef.close(true)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r0.formGroup.invalid);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Save"), " ");
} }
/**
 * Component displayed in a sidesheet to make a decision for one or more policy violations.
 *
 * Uses two alternate views
 * <ul>
 * <li>a) a simple view for a single policy violation</li>
 * <li>b) a complex view using bulk items for multiple policy violations.</li>
 * </ul>
 *
 * Therefore this component is not meant to be used directly but rather be called
 * from a service that does the pre-calculation and opens this component in a
 * sidesheet passing the pre-calculated values.
 *
 */
class PolicyViolationsActionComponent {
    data;
    sideSheetRef;
    /**
     * The form group to which the created form controls will be added.
     */
    formGroup = new UntypedFormGroup({});
    /**
     * Creates a new PolicyViolationsActionComponent
     * @param data The pre-calculated data object.
     * @param sideSheetRef A reference to the sidesheet containing this component.
     */
    constructor(data, sideSheetRef) {
        this.data = data;
        this.sideSheetRef = sideSheetRef;
    }
    static ɵfac = function PolicyViolationsActionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolicyViolationsActionComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetRef)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsActionComponent, selectors: [["ng-component"]], decls: 7, vars: 5, consts: [["eui-sidesheet-content", ""], [1, "imx-policy-violation-content", 3, "formGroup"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["data-imx-identifier", "policy-violation-action-button-save", "mat-flat-button", "", "color", "primary", 3, "disabled", "click", 4, "ngIf"], [3, "formGroup", "data"], ["data-imx-identifier", "policy-violation-action-button-save", "mat-flat-button", "", "color", "primary", 3, "click", "disabled"]], template: function PolicyViolationsActionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "form", 1);
            i0.ɵɵtemplate(2, PolicyViolationsActionComponent_p_2_Template, 3, 3, "p", 2)(3, PolicyViolationsActionComponent_ng_container_3_Template, 2, 2, "ng-container", 2)(4, PolicyViolationsActionComponent_ng_container_4_Template, 2, 2, "ng-container", 2);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "div", 3);
            i0.ɵɵtemplate(6, PolicyViolationsActionComponent_button_6_Template, 3, 4, "button", 4);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("formGroup", ctx.formGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.description);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.policyViolations.length > 1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.policyViolations.length === 1);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.formGroup);
        } }, dependencies: [i2$2.EuiSidesheetContentDirective, i2$2.EuiSidesheetActionsDirective, i5.MatButton, i9.NgIf, i4$1.ɵNgNoValidate, i4$1.NgControlStatusGroup, i4$1.FormGroupDirective, PolicyViolationsActionMultiActionComponent, PolicyViolationsActionSingleActionComponent, i4.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%;flex:1}.eui-sidesheet-actions.mat-mdc-card[_ngcontent-%COMP%]{margin:16px 32px}.imx-policy-violation-content[_ngcontent-%COMP%]{overflow:hidden;display:flex;flex-direction:column}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsActionComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\n  <form [formGroup]=\"formGroup\" class=\"imx-policy-violation-content\">\n    <p *ngIf=\"data.description\">{{ data.description | translate }}</p>\n    <ng-container *ngIf=\"data.policyViolations.length > 1\">\n      <imx-policy-violations-action-multi-action [formGroup]=\"formGroup\" [data]=\"data\"></imx-policy-violations-action-multi-action>\n    </ng-container>\n    <ng-container *ngIf=\"data.policyViolations.length === 1\">\n      <imx-policy-violations-action-single-action [formGroup]=\"formGroup\" [data]=\"data\"></imx-policy-violations-action-single-action>\n    </ng-container>\n  </form>\n</div>\n<div eui-sidesheet-actions>\n  <button\n    data-imx-identifier=\"policy-violation-action-button-save\"\n    mat-flat-button\n    color=\"primary\"\n    (click)=\"sideSheetRef.close(true)\"\n    *ngIf=\"formGroup\"\n    [disabled]=\"formGroup.invalid\"\n  >\n    {{ '#LDS#Save' | translate }}\n  </button>\n</div>\n", styles: [".eui-sidesheet-content{display:flex;flex-direction:column;overflow:hidden;height:100%;flex:1}.eui-sidesheet-actions.mat-mdc-card{margin:16px 32px}.imx-policy-violation-content{overflow:hidden;display:flex;flex-direction:column}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i2$2.EuiSidesheetRef }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PolicyViolationsActionComponent, { className: "PolicyViolationsActionComponent", filePath: "lib\\policy-violations\\policy-violations-action\\policy-violations-action.component.ts", lineNumber: 50 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PolicyViolationsService {
    justificationService;
    api;
    busyService;
    entityService;
    translate;
    snackBar;
    sideSheet;
    userService;
    applied = new Subject();
    constructor(justificationService, api, busyService, entityService, translate, snackBar, sideSheet, userService) {
        this.justificationService = justificationService;
        this.api = api;
        this.busyService = busyService;
        this.entityService = entityService;
        this.translate = translate;
        this.snackBar = snackBar;
        this.sideSheet = sideSheet;
        this.userService = userService;
    }
    get policyViolationsSchema() {
        return this.api.typedClient.PortalPoliciesViolationslist.GetSchema();
    }
    get mitigationSchema() {
        return this.api.typedClient.PortalPoliciesViolations.GetSchema();
    }
    async getConfig() {
        return this.api.client.portal_policy_config_get();
    }
    getPolicyViolationsDataModel() {
        return this.api.client.portal_policies_violations_datamodel_get();
    }
    async get(isApprovable, polDecisionParameters, signal) {
        const collection = await this.api.typedClient.PortalPoliciesViolationslist.Get_list({
            approvable: isApprovable,
            ...polDecisionParameters,
        }, { signal });
        return {
            tableName: collection.tableName,
            totalCount: collection.totalCount,
            Data: collection.Data.map((item, index) => {
                const extendedData = collection?.extendedData?.RelatedObjects?.[index] || [];
                return new PolicyViolation(item, extendedData);
            }),
        };
    }
    exportPolicyViolations() {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, navigationState, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_policies_violations_list_get({ ...navigationState, withProperties, PageSize, StartIndex: 0 });
                }
                else {
                    method = factory.portal_policies_violations_list_get({ ...navigationState, withProperties });
                }
                return new MethodDefinition(method);
            },
        };
    }
    getGroupInfo(parameters = {}, signal) {
        const { withProperties, OrderBy, search, ...params } = parameters;
        return this.api.client.portal_policies_violations_group_list_get({
            ...params,
            withcount: true,
        }, { signal });
    }
    // Methods for decision making
    async approve(policyViolations) {
        let justification;
        this.showBusyIndicator();
        try {
            justification = await this.justificationService.createCdr(JustificationType.approvePolicyViolation);
        }
        finally {
            this.busyService.hide();
        }
        const actionParameters = {
            justification,
            reason: this.createCdrReason(justification ? '#LDS#Additional comments about your decision' : undefined),
        };
        return this.editAction({
            title: policyViolations.length > 1 ? '#LDS#Heading Grant Exceptions' : '#LDS#Heading Grant Exception',
            message: '#LDS#Exceptions have been successfully granted for {0} policy violations.',
            discardChangesOnAbort: true,
            data: {
                policyViolations,
                approve: true,
                actionParameters,
            },
            apply: async (violation) => {
                await this.makeDecision(violation, {
                    Reason: actionParameters.reason.column.GetValue(),
                    UidJustification: actionParameters.justification?.column?.GetValue(),
                    Decision: true,
                });
            },
        });
    }
    async deny(policyViolations) {
        let justification;
        this.showBusyIndicator();
        try {
            justification = await this.justificationService.createCdr(JustificationType.denyPolicyViolation);
        }
        finally {
            this.busyService.hide();
        }
        const actionParameters = {
            justification,
            reason: this.createCdrReason(justification ? '#LDS#Additional comments about your decision' : undefined),
        };
        return this.editAction({
            title: policyViolations.length > 1 ? '#LDS#Heading Deny Exceptions' : '#LDS#Heading Deny Exception',
            message: '#LDS#Exceptions have been successfully denied for {0} policy violations.',
            discardChangesOnAbort: true,
            data: {
                policyViolations,
                actionParameters,
                customValidation: undefined,
            },
            apply: async (policyViolation) => {
                try {
                    await policyViolation.GetEntity().Commit(true);
                    await this.makeDecision(policyViolation, {
                        Reason: actionParameters.reason.column.GetValue(),
                        UidJustification: actionParameters.justification?.column?.GetValue(),
                        Decision: false,
                    });
                }
                catch (error) {
                    await policyViolation.GetEntity().DiscardChanges();
                    throw error;
                }
            },
        });
    }
    async getMitigatingContols(uidObject) {
        return this.api.typedClient.PortalPoliciesViolations.Get(uidObject);
    }
    async getCandidates(uid, data, parameter) {
        return this.api.client.portal_policies_violations_UID_MitigatingControl_candidates_post(uid, data, parameter);
    }
    createMitigatingControl(uid) {
        const entity = this.api.typedClient.PortalPoliciesViolations.createEntity({
            Columns: {
                UID_QERPolicyHasObject: { Value: uid },
            },
        });
        return entity;
    }
    async deleteMitigationControl(uidPolicaHasObject, uidMitigating) {
        try {
            await this.api.typedClient.PortalPoliciesViolations.Delete(uidPolicaHasObject, uidMitigating);
            return true;
        }
        catch (except) {
            return false;
        }
    }
    async makeDecision(pwo, decision) {
        await this.api.client.portal_policies_violations_approve_post(pwo.GetEntity().GetKeys()[0], decision);
    }
    createCdrReason(display) {
        const column = this.entityService.createLocalEntityColumn({
            ColumnName: 'ReasonHead',
            Type: ValType.Text,
            IsMultiLine: true,
        });
        return new BaseCdr(column, display || '#LDS#Reason for your decision');
    }
    async editAction(config) {
        const result = await this.sideSheet
            .open(PolicyViolationsActionComponent, {
            title: await this.translate.get(config.title).toPromise(),
            subTitle: config.data.policyViolations.length === 1 ? config.data.policyViolations[0].GetEntity().GetDisplay() : '',
            padding: '0',
            width: calculateSidesheetWidth(600, 0.4),
            testId: `policy-violations-action-${config.data.approve ? 'approve' : 'deny'}`,
            data: config.data,
        })
            .afterClosed()
            .toPromise();
        if (result) {
            this.showBusyIndicator();
            let success;
            try {
                for (const policyViolation of config.data.policyViolations) {
                    await config.apply(policyViolation);
                }
                success = true;
                await this.userService.reloadPendingItems();
            }
            finally {
                this.busyService.hide();
            }
            if (success) {
                this.snackBar.open({
                    key: config.message,
                    parameters: [
                        config.data.policyViolations.length,
                        config.data.actionParameters.uidPerson ? config.data.actionParameters.uidPerson.column.GetDisplayValue() : '',
                    ],
                });
                this.applied.next();
            }
        }
        else {
            if (config.discardChangesOnAbort) {
                for (const approval of config.data.policyViolations) {
                    await approval.GetEntity().DiscardChanges();
                }
            }
            this.snackBar.open({ key: '#LDS#You have canceled the action.' });
        }
        return result;
    }
    showBusyIndicator() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
    }
    static ɵfac = function PolicyViolationsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolicyViolationsService)(i0.ɵɵinject(i2.JustificationService), i0.ɵɵinject(ApiService), i0.ɵɵinject(i2$2.EuiLoadingService), i0.ɵɵinject(i3$1.EntityService), i0.ɵɵinject(i4.TranslateService), i0.ɵɵinject(i3$1.SnackBarService), i0.ɵɵinject(i2$2.EuiSidesheetService), i0.ɵɵinject(i2.UserModelService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PolicyViolationsService, factory: PolicyViolationsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2.JustificationService }, { type: ApiService }, { type: i2$2.EuiLoadingService }, { type: i3$1.EntityService }, { type: i4.TranslateService }, { type: i3$1.SnackBarService }, { type: i2$2.EuiSidesheetService }, { type: i2.UserModelService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PolicyViolationExtended extends PortalPoliciesViolations {
    editable;
    original;
    formControl = new FormControl('', { nonNullable: true });
    mitigatingCdr;
    constructor(editable, original) {
        super(original.GetEntity());
        this.editable = editable;
        this.original = original;
        if (!editable) {
            this.mitigatingCdr = new BaseReadonlyCdr(original.UID_MitigatingControl.Column);
        }
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MitigatingControlsComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 7)(1, "eui-alert-header");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "eui-alert-content");
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("colored", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 3, "#LDS#Heading Mitigating Controls Can Be Assigned Individually"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 5, "#LDS#Here you can assign mitigating controls to the policy violation. NOTE: If no mitigating controls have been assigned to the violated company policy, you cannot assign any mitigating controls to the policy violation either."));
} }
function MitigatingControlsComponent_div_3_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelement(1, "p", 11);
    i0.ɵɵelementStart(2, "button", 12);
    i0.ɵɵlistener("click", function MitigatingControlsComponent_div_3_ng_container_2_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.addMitigatingControl()); });
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("translate", "#LDS#There are currently no mitigating controls assigned to the policy violation.");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "#LDS#Assign mitigating controls"), " ");
} }
function MitigatingControlsComponent_div_3_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelement(1, "p", 11);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("translate", "#LDS#You cannot assign mitigating controls to the policy violation because no mitigating controls are assigned to the underlying company policy.");
} }
function MitigatingControlsComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8);
    i0.ɵɵelement(1, "eui-icon", 9);
    i0.ɵɵtemplate(2, MitigatingControlsComponent_div_3_ng_container_2_Template, 5, 4, "ng-container", 10)(3, MitigatingControlsComponent_div_3_ng_container_3_Template, 2, 1, "ng-container", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.options.length > 0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.options.length === 0);
} }
function MitigatingControlsComponent_form_4_div_1_eui_select_1_mat_error_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#This field is mandatory."), " ");
} }
function MitigatingControlsComponent_form_4_div_1_eui_select_1_mat_error_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once."), " ");
} }
function MitigatingControlsComponent_form_4_div_1_eui_select_1_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-select", 22);
    i0.ɵɵlistener("selectionChange", function MitigatingControlsComponent_form_4_div_1_eui_select_1_Template_eui_select_selectionChange_0_listener($event) { i0.ɵɵrestoreView(_r5); const mcontrol_r6 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onSelectionChange(mcontrol_r6, $event.values)); });
    i0.ɵɵtemplate(1, MitigatingControlsComponent_form_4_div_1_eui_select_1_mat_error_1_Template, 3, 3, "mat-error", 10)(2, MitigatingControlsComponent_form_4_div_1_eui_select_1_mat_error_2_Template, 3, 3, "mat-error", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r6 = i0.ɵɵnextContext();
    const mcontrol_r6 = ctx_r6.$implicit;
    const i_r8 = ctx_r6.index;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("label", ctx_r1.mitigatingCaption)("filterFunction", ctx_r1.filter)("enableFormFieldMargin", true)("options", ctx_r1.options)("inputControl", mcontrol_r6.formControl)("hideClearButton", true);
    i0.ɵɵattribute("data-imx-identifier", "mitigating-controls-" + i_r8 + "-select");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", mcontrol_r6.formControl.errors == null ? null : mcontrol_r6.formControl.errors["required"]);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", mcontrol_r6.formControl.errors == null ? null : mcontrol_r6.formControl.errors["duplicated"]);
} }
function MitigatingControlsComponent_form_4_div_1_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 23);
} if (rf & 2) {
    const ctx_r6 = i0.ɵɵnextContext();
    const mcontrol_r6 = ctx_r6.$implicit;
    const i_r8 = ctx_r6.index;
    i0.ɵɵproperty("cdr", mcontrol_r6.mitigatingCdr);
    i0.ɵɵattribute("data-imx-identifier", "mitigating-controls-" + i_r8 + "-readOnly");
} }
function MitigatingControlsComponent_form_4_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 17);
    i0.ɵɵtemplate(1, MitigatingControlsComponent_form_4_div_1_eui_select_1_Template, 3, 9, "eui-select", 18)(2, MitigatingControlsComponent_form_4_div_1_imx_cdr_editor_2_Template, 1, 2, "imx-cdr-editor", 19);
    i0.ɵɵelementStart(3, "button", 20);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵlistener("click", function MitigatingControlsComponent_form_4_div_1_Template_button_click_3_listener() { const i_r8 = i0.ɵɵrestoreView(_r4).index; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onDelete(i_r8)); });
    i0.ɵɵelement(5, "eui-icon", 21);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const mcontrol_r6 = ctx.$implicit;
    const i_r8 = ctx.index;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", mcontrol_r6.editable);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !mcontrol_r6.editable);
    i0.ɵɵadvance();
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(4, 4, "#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once."))("data-imx-identifier", "mitigating-controls-" + i_r8 + "-delete");
} }
function MitigatingControlsComponent_form_4_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "form", 13);
    i0.ɵɵtemplate(1, MitigatingControlsComponent_form_4_div_1_Template, 6, 6, "div", 14);
    i0.ɵɵelementStart(2, "button", 15);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵlistener("click", function MitigatingControlsComponent_form_4_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addMitigatingControl()); });
    i0.ɵɵelement(5, "eui-icon", 16);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("formGroup", ctx_r1.mitigatingForm);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r1.mControls);
    i0.ɵɵadvance();
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(3, 4, "#LDS#Assigns a mitigating control"));
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(4, 6, "#LDS#Assign mitigating control"));
} }
class MitigatingControlsComponent {
    violationService;
    loadingService;
    confirmationService;
    cd;
    snackbar;
    uidViolation;
    isMControlPerViolation;
    sidesheetRef;
    mControls;
    subscriptions$ = [];
    mitigatingForm;
    options = [];
    mitigatingCaption;
    controlsToDelete = [];
    constructor(violationService, loadingService, confirmationService, cd, snackbar, formBuilder) {
        this.violationService = violationService;
        this.loadingService = loadingService;
        this.confirmationService = confirmationService;
        this.cd = cd;
        this.snackbar = snackbar;
        this.mitigatingForm = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.mitigatingCaption = violationService.mitigationSchema.Columns.UID_MitigatingControl.Display ?? '';
    }
    filter = (option, searchInputValue) => option.value.toString().toUpperCase() === searchInputValue.toUpperCase();
    get formArray() {
        return this.mitigatingForm.get('formArray');
    }
    get notSaveable() {
        if (this.controlsToDelete.length !== 0) {
            this.mitigatingForm.markAsDirty();
        }
        if (!this.mitigatingForm.dirty || !this.mitigatingForm.valid) {
            return true;
        }
        return (this.mControls.length > 0 &&
            this.mControls.every((ctrl) => {
                return !ctrl.editable || ctrl.UID_MitigatingControl.value === null || ctrl.UID_MitigatingControl.value === '';
            }) &&
            this.controlsToDelete.length === 0);
    }
    get isDirty() {
        return this.mitigatingForm.dirty || this.controlsToDelete.length > 0;
    }
    async onSelectionChange(mcontrol, value) {
        mcontrol.UID_MitigatingControl.value = value;
        this.formArray.updateValueAndValidity();
        this.cd.detectChanges();
        return;
    }
    async ngOnInit() {
        this.subscriptions$.push(this.sidesheetRef.closeClicked().subscribe(async () => {
            if (!this.isDirty || (await this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close();
            }
        }));
        return this.loadMitigationControls();
    }
    isDuplicate(actrl) {
        const test = this.mControls.findIndex((ctrl) => ctrl.formControl != actrl && ctrl?.UID_MitigatingControl.value === actrl.value) !== -1;
        return test;
    }
    canDelete(index) {
        return (this.mControls[index]?.UID_MitigatingControl.Column.GetMetadata().CanEdit() || this.mControls[index].GetEntity().GetKeys() == null);
    }
    async onDelete(index) {
        const elem = this.mControls[index];
        if (elem.UID_MitigatingControl.value !== '' && !(await this.confirmationService.confirmDelete())) {
            return;
        }
        if (elem.GetEntity().GetKeys() != null) {
            this.controlsToDelete.push(elem);
        }
        //Remove the controls and update ui
        this.mControls.splice(index, 1);
        this.formArray.controls.splice(index, 1);
        this.formArray.controls.forEach((elem) => elem.updateValueAndValidity());
        this.cd.detectChanges();
    }
    async addMitigatingControl() {
        const newControl = new PolicyViolationExtended(true, this.violationService.createMitigatingControl(this.uidViolation));
        this.mControls.push(newControl);
        this.formArray.push(newControl.formControl);
        newControl.formControl.setValidators([
            Validators.required,
            (control) => (this.isDuplicate(control) ? { duplicated: true } : null),
        ]);
        this.cd.detectChanges();
        this.mitigatingForm.markAsDirty();
    }
    async save() {
        const overlay = this.loadingService.show();
        try {
            for (const ctrl of this.controlsToDelete) {
                await this.violationService.deleteMitigationControl(this.uidViolation, ctrl.UID_MitigatingControl.value);
            }
            for (const ctrl of this.mControls.filter((elem) => elem.editable)) {
                await ctrl.GetEntity().Commit(false);
            }
        }
        finally {
            this.loadingService.hide(overlay);
            this.snackbar.open({
                key: '#LDS#The mitigating controls have been successfully saved.',
                parameters: [this.sidesheetRef.componentInstance?.config.subTitle],
            });
            this.sidesheetRef.close();
        }
    }
    async loadMitigationControls() {
        const overlay = this.loadingService.show();
        try {
            //reload
            this.mControls = (await this.violationService.getMitigatingContols(this.uidViolation)).Data.map((elem) => new PolicyViolationExtended(false, elem));
            this.mControls.forEach((elem) => this.formArray.push(elem.formControl));
            await this.initOptions();
        }
        finally {
            this.loadingService.hide(overlay);
        }
    }
    async initOptions() {
        this.options =
            (await this.violationService.getCandidates(this.uidViolation, {}, {
                PageSize: 100000,
            })).Entities?.map((elem) => ({ display: elem.Display ?? '', value: elem.Keys?.[0] ?? '' })) ?? [];
    }
    static ɵfac = function MitigatingControlsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlsComponent)(i0.ɵɵdirectiveInject(PolicyViolationsService), i0.ɵɵdirectiveInject(i2$2.EuiLoadingService), i0.ɵɵdirectiveInject(i3$1.ConfirmationService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$1.SnackBarService), i0.ɵɵdirectiveInject(i4$1.UntypedFormBuilder)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsComponent, selectors: [["imx-mitigating-controls"]], inputs: { uidViolation: "uidViolation", isMControlPerViolation: "isMControlPerViolation", sidesheetRef: "sidesheetRef" }, decls: 9, vars: 7, consts: [["eui-sidesheet-content", ""], ["type", "info", 3, "colored", 4, "ngIf"], [1, "imx-centered-filled-card"], ["class", "imx-no-results", 4, "ngIf"], ["class", "imx-mitigating-form", 3, "formGroup", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["data-imx-identifier", "mitigating-controls-button-save", "color", "primary", "mat-flat-button", "", 3, "click", "disabled"], ["type", "info", 3, "colored"], [1, "imx-no-results"], ["icon", "table"], [4, "ngIf"], [3, "translate"], ["data-imx-identifier", "mitigating-controls-button-add", "mat-stroked-button", "", "color", "primary", 3, "click"], [1, "imx-mitigating-form", 3, "formGroup"], ["class", "imx-mitigating-control", 4, "ngFor", "ngForOf"], ["data-imx-identifier", "mitigating-controls-button-add", "mat-icon-button", "", 3, "click", "matTooltip"], ["icon", "add"], [1, "imx-mitigating-control"], [3, "label", "filterFunction", "enableFormFieldMargin", "options", "inputControl", "hideClearButton", "selectionChange", 4, "ngIf"], [3, "cdr", 4, "ngIf"], ["mat-button", "", 1, "mat-icon-button", "imx-delete-button", 3, "click"], ["icon", "delete"], [3, "selectionChange", "label", "filterFunction", "enableFormFieldMargin", "options", "inputControl", "hideClearButton"], [3, "cdr"]], template: function MitigatingControlsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, MitigatingControlsComponent_eui_alert_1_Template, 7, 7, "eui-alert", 1);
            i0.ɵɵelementStart(2, "mat-card", 2);
            i0.ɵɵtemplate(3, MitigatingControlsComponent_div_3_Template, 4, 2, "div", 3)(4, MitigatingControlsComponent_form_4_Template, 6, 8, "form", 4);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "div", 5)(6, "button", 6);
            i0.ɵɵlistener("click", function MitigatingControlsComponent_Template_button_click_6_listener() { return ctx.save(); });
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isMControlPerViolation);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.mControls && ctx.mControls.length > 0);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.notSaveable);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 5, "#LDS#Save"), " ");
        } }, dependencies: [i2$2.EuiAlertComponent, i2$2.EuiAlertContentDirective, i2$2.EuiAlertHeaderDirective, i2$2.EuiIconComponent, i2$2.EuiSelectComponent, i2$2.EuiSidesheetContentDirective, i2$2.EuiSidesheetActionsDirective, i5.MatButton, i5.MatIconButton, i1.MatCard, i6.MatError, i8.MatTooltip, i9.NgForOf, i9.NgIf, i4.TranslateDirective, i4$1.ɵNgNoValidate, i4$1.NgControlStatusGroup, i4$1.FormGroupDirective, i3$1.CdrEditorComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;padding:16px 20px}[_nghost-%COMP%]   .control-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}[_nghost-%COMP%]   .imx-mitigating-control.bordered[_ngcontent-%COMP%]{border-bottom:1px solid #797e80}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   eui-select[_ngcontent-%COMP%]{flex:1 1 auto}[_nghost-%COMP%]   .imx-mitigating-control-properties[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;margin-right:15px;gap:15px}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]   .content[_ngcontent-%COMP%]{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .imx-delete-button[_ngcontent-%COMP%]{margin-top:15px;align-self:flex-start}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0;justify-self:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#797e80}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .bordered[_ngcontent-%COMP%]{border-bottom:1px solid #dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .bordered[_ngcontent-%COMP%]{border-bottom:1px solid #ffffff}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsComponent, [{
        type: Component,
        args: [{ selector: 'imx-mitigating-controls', template: "<div eui-sidesheet-content>\n  <eui-alert type=\"info\" [colored]=\"true\" *ngIf=\"isMControlPerViolation\">\n    <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Can Be Assigned Individually' | translate }}</eui-alert-header>\n    <eui-alert-content>{{\n      '#LDS#Here you can assign mitigating controls to the policy violation. NOTE: If no mitigating controls have been assigned to the violated company policy, you cannot assign any mitigating controls to the policy violation either.'\n        | translate\n    }}</eui-alert-content>\n  </eui-alert>\n\n  <mat-card class=\"imx-centered-filled-card\">\n    <div class=\"imx-no-results\" *ngIf=\"!mControls || mControls.length == 0\">\n      <eui-icon icon=\"table\"></eui-icon>\n      <ng-container *ngIf=\"options.length > 0\">\n        <p [translate]=\"'#LDS#There are currently no mitigating controls assigned to the policy violation.'\"></p>\n        <button data-imx-identifier=\"mitigating-controls-button-add\" mat-stroked-button color=\"primary\" (click)=\"addMitigatingControl()\">\n          {{ '#LDS#Assign mitigating controls' | translate }}\n        </button>\n      </ng-container>\n      <ng-container *ngIf=\"options.length === 0\">\n        <p\n          [translate]=\"\n            '#LDS#You cannot assign mitigating controls to the policy violation because no mitigating controls are assigned to the underlying company policy.'\n          \"\n        ></p>\n      </ng-container>\n    </div>\n    <form class=\"imx-mitigating-form\" [formGroup]=\"mitigatingForm\" *ngIf=\"mControls && mControls.length > 0\">\n      <div *ngFor=\"let mcontrol of mControls; let i = index\" class=\"imx-mitigating-control\">\n        <eui-select\n          *ngIf=\"mcontrol.editable\"\n          (selectionChange)=\"onSelectionChange(mcontrol, $event.values)\"\n          [label]=\"mitigatingCaption\"\n          [filterFunction]=\"filter\"\n          [enableFormFieldMargin]=\"true\"\n          [options]=\"options\"\n          [inputControl]=\"mcontrol.formControl\"\n          [hideClearButton]=\"true\"\n          [attr.data-imx-identifier]=\"'mitigating-controls-' + i + '-select'\"\n        >\n          <mat-error *ngIf=\"mcontrol.formControl.errors?.['required']\">\n            {{ '#LDS#This field is mandatory.' | translate }}\n          </mat-error>\n          <mat-error *ngIf=\"mcontrol.formControl.errors?.['duplicated']\">\n            {{ '#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once.' | translate }}\n          </mat-error>\n        </eui-select>\n        <imx-cdr-editor\n          *ngIf=\"!mcontrol.editable\"\n          [cdr]=\"mcontrol.mitigatingCdr\"\n          [attr.data-imx-identifier]=\"'mitigating-controls-' + i + '-readOnly'\"\n        ></imx-cdr-editor>\n        <button\n          mat-button\n          class=\"mat-icon-button imx-delete-button\"\n          [attr.aria-label]=\"\n            '#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once.' | translate\n          \"\n          [attr.data-imx-identifier]=\"'mitigating-controls-' + i + '-delete'\"\n          (click)=\"onDelete(i)\"\n        >\n          <eui-icon icon=\"delete\"></eui-icon>\n        </button>\n      </div>\n      <button\n        [matTooltip]=\"'#LDS#Assigns a mitigating control' | translate\"\n        data-imx-identifier=\"mitigating-controls-button-add\"\n        [attr.aria-label]=\"'#LDS#Assign mitigating control' | translate\"\n        mat-icon-button\n        (click)=\"addMitigatingControl()\"\n      >\n        <eui-icon icon=\"add\"></eui-icon>\n      </button>\n    </form>\n  </mat-card>\n</div>\n<div eui-sidesheet-actions>\n  <button data-imx-identifier=\"mitigating-controls-button-save\" color=\"primary\" [disabled]=\"notSaveable\" mat-flat-button (click)=\"save()\">\n    {{ '#LDS#Save' | translate }}\n  </button>\n</div>\n", styles: [":host{height:100%;display:flex;flex-direction:column;justify-content:space-between}:host .eui-sidesheet-actions{display:flex;justify-content:flex-end;padding:16px 20px}:host .control-container{display:flex;flex-direction:column;overflow:auto}:host .imx-mitigating-control{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}:host .imx-mitigating-control.bordered{border-bottom:1px solid #797e80}:host .imx-mitigating-control eui-select{flex:1 1 auto}:host .imx-mitigating-control-properties{display:flex;flex-direction:column;width:100%;margin-right:15px;gap:15px}:host .imx-mitigating-control-content{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:auto}:host .imx-mitigating-control-content .content{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}:host .imx-mitigating-control .imx-delete-button{margin-top:15px;align-self:flex-start}:host .imx-no-mitigating-controls{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}:host .imx-no-results{text-align:center;margin:20px 0;justify-self:center}:host .imx-no-results p{margin:0;font-size:18px}:host .imx-no-results button{margin-top:10px}:host .imx-no-results p{color:#797e80}:host .imx-no-mitigating-controls{color:#797e80}.eui-dark-theme :host .imx-no-results p{color:#dfe4e6}.eui-dark-theme :host .imx-no-mitigating-controls{color:#dfe4e6}.eui-dark-theme :host .imx-mitigating-control .bordered{border-bottom:1px solid #dfe4e6}.eui-contrast-theme :host .imx-data-no-results p{color:#fff}.eui-contrast-theme :host .imx-no-mitigating-controls{color:#fff}.eui-contrast-theme :host .imx-mitigating-control .bordered{border-bottom:1px solid #ffffff}\n"] }]
    }], () => [{ type: PolicyViolationsService }, { type: i2$2.EuiLoadingService }, { type: i3$1.ConfirmationService }, { type: i0.ChangeDetectorRef }, { type: i3$1.SnackBarService }, { type: i4$1.UntypedFormBuilder }], { uidViolation: [{
            type: Input
        }], isMControlPerViolation: [{
            type: Input
        }], sidesheetRef: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MitigatingControlsComponent, { className: "MitigatingControlsComponent", filePath: "lib\\policy-violations\\mitigating-controls\\mitigating-controls.component.ts", lineNumber: 40 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_template_6_eui_icon_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 13);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
} }
function PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_template_6_eui_icon_3_Template, 2, 3, "eui-icon", 12);
} if (rf & 2) {
    i0.ɵɵnextContext();
    const mitig_r1 = i0.ɵɵreference(8);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 2, "#LDS#Heading Mitigating Controls"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", mitig_r1 == null ? null : mitig_r1.isDirty);
} }
function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_mat_option_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-option", 20);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const relatedOption_r4 = ctx.$implicit;
    i0.ɵɵproperty("value", relatedOption_r4);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", relatedOption_r4.Display, " ");
} }
function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_imx_object_hyperview_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-object-hyperview", 21);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(4);
    i0.ɵɵproperty("objectType", ctx_r2.selectedHyperviewType)("objectUid", ctx_r2.selectedHyperviewUID);
} }
function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 15)(1, "mat-form-field", 16)(2, "mat-label");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "mat-select", 17);
    i0.ɵɵlistener("selectionChange", function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_Template_mat_select_selectionChange_5_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r2.onHyperviewOptionSelected()); });
    i0.ɵɵtwoWayListener("valueChange", function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_Template_mat_select_valueChange_5_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(3); i0.ɵɵtwoWayBindingSet(ctx_r2.selectedOption, $event) || (ctx_r2.selectedOption = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵtemplate(6, PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_mat_option_6_Template, 2, 2, "mat-option", 18);
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(7, PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_imx_object_hyperview_7_Template, 1, 2, "imx-object-hyperview", 19);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 4, "#LDS#Related objects"));
    i0.ɵɵadvance(2);
    i0.ɵɵtwoWayProperty("value", ctx_r2.selectedOption);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.relatedOptions);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !!ctx_r2.selectedOption);
} }
function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab", 6);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵtemplate(2, PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_Template, 8, 6, "ng-template", 14);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Hyperview"));
} }
function PolicyViolationsSidesheetComponent_mat_tab_group_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab-group", 5)(1, "mat-tab", 6);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵtemplate(3, PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_container_3_Template, 1, 0, "ng-container", 7)(4, PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_container_4_Template, 1, 0, "ng-container", 7);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "mat-tab", 8);
    i0.ɵɵtemplate(6, PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_template_6_Template, 4, 4, "ng-template", 9);
    i0.ɵɵelement(7, "imx-mitigating-controls", 10, 3);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(9, PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_Template, 3, 3, "mat-tab", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_10_0;
    const ctx_r2 = i0.ɵɵnextContext();
    const singleContent_r5 = i0.ɵɵreference(4);
    const actions_r6 = i0.ɵɵreference(6);
    i0.ɵɵadvance();
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 7, "#LDS#Heading Information"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngTemplateOutlet", singleContent_r5);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", actions_r6);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("isMControlPerViolation", ctx_r2.data == null ? null : ctx_r2.data.isMControlPerViolation)("sidesheetRef", ctx_r2.sideSheetRef)("uidViolation", ctx_r2.data == null ? null : ctx_r2.data.policyViolation == null ? null : (tmp_10_0 = ctx_r2.data.policyViolation.GetEntity()) == null ? null : (tmp_10_0 = tmp_10_0.GetKeys()) == null ? null : tmp_10_0[0]);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.relatedOptions.length > 1);
} }
function PolicyViolationsSidesheetComponent_ng_template_1_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function PolicyViolationsSidesheetComponent_ng_template_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function PolicyViolationsSidesheetComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, PolicyViolationsSidesheetComponent_ng_template_1_ng_container_0_Template, 1, 0, "ng-container", 7)(1, PolicyViolationsSidesheetComponent_ng_template_1_ng_container_1_Template, 1, 0, "ng-container", 7);
} if (rf & 2) {
    i0.ɵɵnextContext();
    const singleContent_r5 = i0.ɵɵreference(4);
    const actions_r6 = i0.ɵɵreference(6);
    i0.ɵɵproperty("ngTemplateOutlet", singleContent_r5);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", actions_r6);
} }
function PolicyViolationsSidesheetComponent_ng_template_3_eui_badge_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 26);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("color", ctx_r2.data == null ? null : ctx_r2.data.policyViolation == null ? null : ctx_r2.data.policyViolation.stateBadge == null ? null : ctx_r2.data.policyViolation.stateBadge.color);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, ctx_r2.data.policyViolation.stateBadge.caption), " ");
} }
function PolicyViolationsSidesheetComponent_ng_template_3_imx_cdr_editor_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 27);
} if (rf & 2) {
    const cdr_r7 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r7);
} }
function PolicyViolationsSidesheetComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 22)(1, "mat-card")(2, "div", 23);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, PolicyViolationsSidesheetComponent_ng_template_3_eui_badge_4_Template, 3, 4, "eui-badge", 24)(5, PolicyViolationsSidesheetComponent_ng_template_3_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 25);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    let tmp_4_0;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", ctx_r2.data == null ? null : ctx_r2.data.policyViolation == null ? null : ctx_r2.data.policyViolation.State == null ? null : (tmp_4_0 = ctx_r2.data.policyViolation.State.GetMetadata()) == null ? null : tmp_4_0.GetDisplay(), " ");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.data == null ? null : ctx_r2.data.policyViolation == null ? null : ctx_r2.data.policyViolation.State == null ? null : ctx_r2.data.policyViolation.State.value);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.cdrList);
} }
function PolicyViolationsSidesheetComponent_ng_template_5_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 29)(1, "button", 30);
    i0.ɵɵlistener("click", function PolicyViolationsSidesheetComponent_ng_template_5_div_0_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r8); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.deny()); });
    i0.ɵɵelement(2, "eui-icon", 31);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "button", 32);
    i0.ɵɵlistener("click", function PolicyViolationsSidesheetComponent_ng_template_5_div_0_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r8); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.approve()); });
    i0.ɵɵelement(6, "eui-icon", 33);
    i0.ɵɵtext(7);
    i0.ɵɵpipe(8, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "#LDS#Deny exception"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 4, "#LDS#Grant exception"), " ");
} }
function PolicyViolationsSidesheetComponent_ng_template_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, PolicyViolationsSidesheetComponent_ng_template_5_div_0_Template, 9, 6, "div", 28);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngIf", !(ctx_r2.data == null ? null : ctx_r2.data.isReadOnly));
} }
class PolicyViolationsSidesheetComponent {
    data;
    policyViolationService;
    sideSheetRef;
    euiLoadingService;
    cdrList = [];
    selectedHyperviewType;
    selectedHyperviewUID;
    selectedOption;
    result = false;
    closeSubscription;
    get isPending() {
        return this.data.policyViolation.State.value?.toLocaleLowerCase() === 'pending';
    }
    get objectType() {
        return this.data.policyViolation.GetEntity().TypeName;
    }
    get objectUid() {
        return this.data.policyViolation.GetEntity().GetKeys().join(',');
    }
    constructor(data, policyViolationService, sideSheetRef, euiLoadingService) {
        this.data = data;
        this.policyViolationService = policyViolationService;
        this.sideSheetRef = sideSheetRef;
        this.euiLoadingService = euiLoadingService;
        this.cdrList = this.data.policyViolation.properties;
        this.closeSubscription = sideSheetRef.closeClicked().subscribe(() => {
            sideSheetRef.close(this.result);
        });
    }
    ngOnDestroy() {
        this.closeSubscription?.unsubscribe();
    }
    /**
     * Opens the Approve-Sidesheet for the current selected rule violations.
     */
    async approve() {
        if (await this.policyViolationService.approve([this.data.policyViolation])) {
            return this.reloadData();
        }
    }
    /**
     * Opens the Deny-Sidesheet for the current selected rule violations.
     */
    async deny() {
        if (await this.policyViolationService.deny([this.data.policyViolation])) {
            return this.reloadData();
        }
    }
    get relatedOptions() {
        return this.data.policyViolation.data || [];
    }
    setHyperviewObject(selectedRelatedObject) {
        const dbKey = DbObjectKey.FromXml(selectedRelatedObject.ObjectKey ?? '');
        this.selectedHyperviewType = dbKey.TableName;
        this.selectedHyperviewUID = dbKey.Keys.join(',');
    }
    onHyperviewOptionSelected() {
        this.setHyperviewObject(this.selectedOption);
    }
    async reloadData() {
        this.result = true;
        this.euiLoadingService.show();
        try {
            const value = await this.policyViolationService.get(true, {
                filter: [{ ColumnName: 'ObjectKey', Value1: this.data.policyViolation.ObjectKey.value }],
            });
            this.data.policyViolation = value.Data[0];
            this.cdrList = this.data.policyViolation.properties;
        }
        finally {
            this.euiLoadingService.hide();
        }
    }
    static ɵfac = function PolicyViolationsSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolicyViolationsSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(PolicyViolationsService), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2$2.EuiLoadingService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsSidesheetComponent, selectors: [["imx-policy-violations-sidesheet"]], decls: 7, vars: 2, consts: [["singleElement", ""], ["singleContent", ""], ["actions", ""], ["mitig", ""], ["mat-stretch-tabs", "false", 4, "ngIf", "ngIfElse"], ["mat-stretch-tabs", "false"], [3, "label"], [4, "ngTemplateOutlet"], ["data-imx-identifier", "policy-violations-tab-mig-controls"], ["mat-tab-label", ""], [3, "isMControlPerViolation", "sidesheetRef", "uidViolation"], [3, "label", 4, "ngIf"], ["icon", "save", "class", "imx-dirty-indicator", "size", "s", 4, "ngIf"], ["icon", "save", "size", "s", 1, "imx-dirty-indicator"], ["matTabContent", ""], ["eui-sidesheet-content", "", 1, "imx-policy-violations-hyperview"], ["appearance", "outline"], ["required", "", 3, "selectionChange", "valueChange", "value"], [3, "value", 4, "ngFor", "ngForOf"], [3, "objectType", "objectUid", 4, "ngIf"], [3, "value"], [3, "objectType", "objectUid"], ["eui-sidesheet-content", ""], [1, "imx-state-caption"], ["class", "imx-margin-bottom-20", 3, "color", 4, "ngIf"], [3, "cdr", 4, "ngFor", "ngForOf"], [1, "imx-margin-bottom-20", 3, "color"], [3, "cdr"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "color", "warn", "data-imx-identifier", "policy-violations-table-row-button-deny", 3, "click"], ["icon", "ignore"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "policy-violations-table-row-button-approve", 3, "click"], ["icon", "check"]], template: function PolicyViolationsSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, PolicyViolationsSidesheetComponent_mat_tab_group_0_Template, 10, 9, "mat-tab-group", 4)(1, PolicyViolationsSidesheetComponent_ng_template_1_Template, 2, 2, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor)(3, PolicyViolationsSidesheetComponent_ng_template_3_Template, 6, 3, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor)(5, PolicyViolationsSidesheetComponent_ng_template_5_Template, 1, 1, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            const singleElement_r9 = i0.ɵɵreference(2);
            i0.ɵɵproperty("ngIf", ctx.data == null ? null : ctx.data.isMControlPerViolation)("ngIfElse", singleElement_r9);
        } }, dependencies: [i2$2.EuiBadgeComponent, i2$2.EuiIconComponent, i2$2.EuiSidesheetContentDirective, i2$2.EuiSidesheetActionsDirective, i3$2.MatOption, i5.MatButton, i1.MatCard, i6.MatFormField, i6.MatLabel, i7.MatSelect, i8$1.MatTabContent, i8$1.MatTabLabel, i8$1.MatTab, i8$1.MatTabGroup, i9.NgForOf, i9.NgIf, i9.NgTemplateOutlet, i3$1.CdrEditorComponent, i2.ObjectHyperviewComponent, MitigatingControlsComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}[_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{margin-left:5px}[_nghost-%COMP%]   .imx-content[_ngcontent-%COMP%]{display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{margin-top:auto}[_nghost-%COMP%]   .eui-sidesheet-actions.mat-mdc-card[_ngcontent-%COMP%]{margin:16px 32px}[_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{font-size:12px;padding-bottom:5px}[_nghost-%COMP%]   .imx-policy-violations-hyperview[_ngcontent-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{color:#919799}[_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{color:#e36a00}.eui-dark-theme   [_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{color:#edbe8e}.eui-contrast-theme   [_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{color:#e36a00}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsSidesheetComponent, [{
        type: Component,
        args: [{ selector: 'imx-policy-violations-sidesheet', template: "<mat-tab-group mat-stretch-tabs=\"false\" *ngIf=\"data?.isMControlPerViolation; else singleElement\">\n  <mat-tab [label]=\"'#LDS#Heading Information' | translate\">\n    <ng-container *ngTemplateOutlet=\"singleContent\"></ng-container>\n    <ng-container *ngTemplateOutlet=\"actions\"></ng-container>\n  </mat-tab>\n\n  <mat-tab data-imx-identifier=\"policy-violations-tab-mig-controls\">\n    <ng-template mat-tab-label>\n      <span>{{ '#LDS#Heading Mitigating Controls' | translate }}</span>\n      <eui-icon\n        *ngIf=\"mitig?.isDirty\"\n        icon=\"save\"\n        class=\"imx-dirty-indicator\"\n        size=\"s\"\n        [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"\n      ></eui-icon>\n    </ng-template>\n    <imx-mitigating-controls\n      #mitig\n      [isMControlPerViolation]=\"data?.isMControlPerViolation\"\n      [sidesheetRef]=\"sideSheetRef\"\n      [uidViolation]=\"data?.policyViolation?.GetEntity()?.GetKeys()?.[0]\"\n    ></imx-mitigating-controls>\n  </mat-tab>\n  <mat-tab label=\"{{ '#LDS#Heading Hyperview' | translate }}\" *ngIf=\"this.relatedOptions.length > 1\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content class=\"imx-policy-violations-hyperview\">\n        <mat-form-field appearance=\"outline\">\n          <mat-label>{{ '#LDS#Related objects' | translate }}</mat-label>\n          <mat-select required (selectionChange)=\"onHyperviewOptionSelected()\" [(value)]=\"selectedOption\">\n            <mat-option *ngFor=\"let relatedOption of relatedOptions\" [value]=\"relatedOption\">\n              {{ relatedOption.Display }}\n            </mat-option>\n          </mat-select>\n        </mat-form-field>\n        <imx-object-hyperview *ngIf=\"!!selectedOption\" [objectType]=\"selectedHyperviewType\" [objectUid]=\"selectedHyperviewUID\">\n        </imx-object-hyperview>\n      </div>\n    </ng-template>\n  </mat-tab>\n</mat-tab-group>\n<ng-template #singleElement>\n  <ng-container *ngTemplateOutlet=\"singleContent\"></ng-container>\n  <ng-container *ngTemplateOutlet=\"actions\"></ng-container>\n</ng-template>\n\n<ng-template #singleContent>\n  <div eui-sidesheet-content>\n    <mat-card>\n      <div class=\"imx-state-caption\">\n        {{ data?.policyViolation?.State?.GetMetadata()?.GetDisplay() }}\n      </div>\n      <eui-badge\n        class=\"imx-margin-bottom-20\"\n        [color]=\"data?.policyViolation?.stateBadge?.color\"\n        *ngIf=\"data?.policyViolation?.State?.value\"\n      >\n        {{ data.policyViolation.stateBadge.caption | translate }}\n      </eui-badge>\n      <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\n    </mat-card>\n  </div>\n</ng-template>\n\n<ng-template #actions>\n  <div eui-sidesheet-actions *ngIf=\"!data?.isReadOnly\">\n    <button mat-flat-button color=\"warn\" (click)=\"deny()\" data-imx-identifier=\"policy-violations-table-row-button-deny\">\n      <eui-icon icon=\"ignore\"></eui-icon>\n      {{ '#LDS#Deny exception' | translate }}\n    </button>\n    <button mat-flat-button color=\"primary\" (click)=\"approve()\" data-imx-identifier=\"policy-violations-table-row-button-approve\">\n      <eui-icon icon=\"check\"></eui-icon>\n      {{ '#LDS#Grant exception' | translate }}\n    </button>\n  </div>\n</ng-template>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;height:100%}:host .imx-dirty-indicator{margin-left:5px}:host .imx-content{display:flex;flex:1 1 auto;flex-direction:column}:host .eui-sidesheet-actions{margin-top:auto}:host .eui-sidesheet-actions.mat-mdc-card{margin:16px 32px}:host .imx-state-caption{font-size:12px;padding-bottom:5px}:host .imx-policy-violations-hyperview{display:flex;flex-direction:column}:host .imx-state-caption{color:#919799}:host .imx-dirty-indicator{color:#e36a00}.eui-dark-theme :host .imx-state-caption{color:#dfe4e6}.eui-dark-theme :host .imx-dirty-indicator{color:#edbe8e}.eui-contrast-theme :host .imx-state-caption{color:#fff}.eui-contrast-theme :host .imx-dirty-indicator{color:#e36a00}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: PolicyViolationsService }, { type: i2$2.EuiSidesheetRef }, { type: i2$2.EuiLoadingService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PolicyViolationsSidesheetComponent, { className: "PolicyViolationsSidesheetComponent", filePath: "lib\\policy-violations\\policy-violations-sidesheet\\policy-violations-sidesheet.component.ts", lineNumber: 42 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function PolicyViolationsComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 11)(1, "h2", 12)(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(5, "imx-help-contextual");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "imx-data-view-toolbar", 13);
    i0.ɵɵlistener("updateConfig", function PolicyViolationsComponent_div_1_Template_imx_data_view_toolbar_updateConfig_6_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.updateConfig($event)); })("deleteConfigById", function PolicyViolationsComponent_div_1_Template_imx_data_view_toolbar_deleteConfigById_6_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.deleteConfigById($event)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#Heading Policy Violations"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("dataSource", ctx_r1.dataSource);
} }
function PolicyViolationsComponent_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "imx-data-view-toolbar", 14);
    i0.ɵɵlistener("updateConfig", function PolicyViolationsComponent_ng_container_2_Template_imx_data_view_toolbar_updateConfig_1_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.updateConfig($event)); })("deleteConfigById", function PolicyViolationsComponent_ng_container_2_Template_imx_data_view_toolbar_deleteConfigById_1_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.deleteConfigById($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("dataSource", ctx_r1.dataSource)("showGrouping", false);
} }
function PolicyViolationsComponent_ng_container_5_th_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns == null ? null : ctx_r1.entitySchema.Columns.UID_QERPolicy == null ? null : ctx_r1.entitySchema.Columns.UID_QERPolicy.Display, " ");
} }
function PolicyViolationsComponent_ng_container_5_td_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 16)(1, "div", 17)(2, "div");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div", 18);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(item_r4.UID_QERPolicy.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4.Description.Column.GetDisplayValue());
} }
function PolicyViolationsComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0, 6)(1);
    i0.ɵɵtemplate(2, PolicyViolationsComponent_ng_container_5_th_2_Template, 2, 1, "th", 7);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵtemplate(3, PolicyViolationsComponent_ng_container_5_td_3_Template, 6, 2, "td", 8);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("matColumnDef", ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns == null ? null : ctx_r1.entitySchema.Columns.UID_QERPolicy == null ? null : ctx_r1.entitySchema.Columns.UID_QERPolicy.ColumnName);
} }
function PolicyViolationsComponent_th_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 15);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Violating object"), " ");
} }
function PolicyViolationsComponent_td_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 16)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r5.ObjectKey.Column.GetDisplayValue(), " ");
} }
function PolicyViolationsComponent_th_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns == null ? null : ctx_r1.entitySchema.Columns.State == null ? null : ctx_r1.entitySchema.Columns.State.Display, " ");
} }
function PolicyViolationsComponent_td_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 16)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r6.State.Column.GetDisplayValue(), " ");
} }
function PolicyViolationsComponent_ng_container_14_th_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "th", 15);
} }
function PolicyViolationsComponent_ng_container_14_td_3_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "td", 16)(1, "div", 19)(2, "button", 20);
    i0.ɵɵlistener("click", function PolicyViolationsComponent_ng_container_14_td_3_Template_button_click_2_listener($event) { const item_r8 = i0.ɵɵrestoreView(_r7).$implicit; const ctx_r1 = i0.ɵɵnextContext(2); ctx_r1.decide(false, [item_r8]); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelement(3, "eui-icon", 21);
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "button", 22);
    i0.ɵɵlistener("click", function PolicyViolationsComponent_ng_container_14_td_3_Template_button_click_6_listener($event) { const item_r8 = i0.ɵɵrestoreView(_r7).$implicit; const ctx_r1 = i0.ɵɵnextContext(2); ctx_r1.decide(true, [item_r8]); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelement(7, "eui-icon", 23);
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "translate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(5, 2, "#LDS#Deny exception"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 4, "#LDS#Grant exception"), " ");
} }
function PolicyViolationsComponent_ng_container_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0, 6)(1);
    i0.ɵɵtemplate(2, PolicyViolationsComponent_ng_container_14_th_2_Template, 1, 0, "th", 7);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵtemplate(3, PolicyViolationsComponent_ng_container_14_td_3_Template, 10, 6, "td", 8);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵproperty("matColumnDef", "actions");
} }
function PolicyViolationsComponent_div_16_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 24);
    i0.ɵɵelement(1, "imx-data-view-selection", 25);
    i0.ɵɵelementStart(2, "button", 26);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵlistener("click", function PolicyViolationsComponent_div_16_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r9); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.decide(false, ctx_r1.selectedViolations)); });
    i0.ɵɵelement(4, "eui-icon", 21);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "button", 27);
    i0.ɵɵpipe(8, "translate");
    i0.ɵɵlistener("click", function PolicyViolationsComponent_div_16_Template_button_click_7_listener() { i0.ɵɵrestoreView(_r9); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.decide(true, ctx_r1.selectedViolations)); });
    i0.ɵɵelement(9, "eui-icon", 23);
    i0.ɵɵtext(10);
    i0.ɵɵpipe(11, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("dataSource", ctx_r1.dataSource);
    i0.ɵɵadvance();
    i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(3, 7, "#LDS#Denies an exception for the selected policy violations"));
    i0.ɵɵproperty("disabled", !ctx_r1.selectedViolations.length);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 9, "#LDS#Deny exception"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(8, 11, "#LDS#Grants an exception for the selected policy violations"));
    i0.ɵɵproperty("disabled", !ctx_r1.selectedViolations.length);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(11, 13, "#LDS#Grant exception"), " ");
} }
class PolicyViolationsComponent {
    policyViolationsService;
    viewConfigService;
    sidesheet;
    translate;
    actRoute;
    dataSource;
    selectedCompanyPolicy;
    isMControlPerViolation;
    DisplayColumns = DisplayColumns;
    selectedViolations = [];
    approveOnly;
    busyService = new BusyService();
    entitySchema;
    dataModel;
    displayedColumns = [];
    subscriptions = [];
    viewConfig;
    viewConfigPath = 'policies/violations';
    selectedPolicyUid;
    constructor(policyViolationsService, viewConfigService, sidesheet, translate, actRoute, dataSource) {
        this.policyViolationsService = policyViolationsService;
        this.viewConfigService = viewConfigService;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.actRoute = actRoute;
        this.dataSource = dataSource;
        this.entitySchema = this.policyViolationsService.policyViolationsSchema;
        this.subscriptions.push(this.policyViolationsService.applied.subscribe(async () => {
            this.getData();
        }));
    }
    async ngOnInit() {
        const queryParams = await this.actRoute.queryParams.pipe(first()).toPromise();
        this.selectedPolicyUid = queryParams?.['uid_qerpolicy'];
        if (!this.selectedCompanyPolicy)
            this.approveOnly = this.actRoute.snapshot.url[this.actRoute.snapshot.url.length - 1].path === 'approve';
        this.displayedColumns = [
            ...(!this.selectedCompanyPolicy ? [this.entitySchema?.Columns.UID_QERPolicy] : []),
            this.entitySchema?.Columns.ObjectKey,
            this.entitySchema?.Columns.State,
            ...(!this.selectedCompanyPolicy
                ? [
                    {
                        ColumnName: 'actions',
                        Type: ValType.String,
                        afterAdditionals: true,
                        untranslatedDisplay: '#LDS#Approval decision',
                    },
                ]
                : []),
        ];
        const isBusy = this.busyService.beginBusy();
        try {
            this.dataModel = await this.policyViolationsService.getPolicyViolationsDataModel();
            this.viewConfig = await this.viewConfigService.getInitialDSTExtension(this.dataModel, this.viewConfigPath);
            // If this wasn't already set, then we need to get it from the config
            this.isMControlPerViolation ??= (await this.policyViolationsService.getConfig()).MitigatingControlsPerViolation;
            this.subscriptions.push(this.actRoute.queryParams.subscribe((params) => this.updateFiltersFromRouteParams(params)));
        }
        finally {
            isBusy.endBusy();
        }
        return this.getData();
    }
    async viewDetails(selectedPolicyViolation) {
        const result = await this.sidesheet
            .open(PolicyViolationsSidesheetComponent, {
            title: this.translate.instant('#LDS#Heading View Policy Violation Details'),
            subTitle: selectedPolicyViolation.GetEntity().GetDisplay(),
            panelClass: 'imx-sidesheet',
            padding: '0',
            disableClose: true,
            width: calculateSidesheetWidth(600, 0.4),
            testId: 'policy-violations-details-sidesheet',
            data: {
                policyViolation: selectedPolicyViolation,
                isMControlPerViolation: this.isMControlPerViolation,
                isReadOnly: !!this.selectedCompanyPolicy,
            },
        })
            .afterClosed()
            .toPromise();
        if (result) {
            this.getData();
        }
    }
    async decide(approve, items) {
        let result = false;
        if (approve) {
            result = await this.policyViolationsService.approve(items);
        }
        else {
            result = await this.policyViolationsService.deny(items);
        }
        if (result) {
            this.getData();
        }
    }
    onSelectionChanged(cases) {
        this.selectedViolations = cases;
    }
    async updateConfig(config) {
        await this.viewConfigService.putViewConfig(config);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    async deleteConfigById(id) {
        await this.viewConfigService.deleteViewConfig(id);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    getData() {
        if (this.selectedCompanyPolicy) {
            this.dataModel = { ...this.dataModel, Filters: this.dataModel.Filters?.filter((filter) => filter.Name !== 'uid_qerpolicy') };
        }
        const dataViewInitParameters = {
            execute: (params, signal) => {
                if (this.selectedCompanyPolicy) {
                    const selectedCompanyPolicyKey = this.selectedCompanyPolicy.GetEntity().GetKeys()[0];
                    params = { ...params, uid_qerpolicy: selectedCompanyPolicyKey };
                }
                if (this.selectedPolicyUid) {
                    params = { ...params, uid_qerpolicy: this.selectedPolicyUid };
                }
                return this.policyViolationsService.get(this.approveOnly, params, signal);
            },
            schema: this.entitySchema,
            columnsToDisplay: this.displayedColumns,
            dataModel: this.dataModel,
            groupExecute: (column, params, signal) => {
                return this.policyViolationsService.getGroupInfo(this.getGroupParams(column, params), signal);
            },
            exportFunction: this.policyViolationsService.exportPolicyViolations(),
            viewConfig: this.viewConfig,
            highlightEntity: (identity) => {
                this.viewDetails(identity);
            },
            selectionChange: (selection) => this.onSelectionChanged(selection),
        };
        this.dataSource.init(dataViewInitParameters);
    }
    updateFiltersFromRouteParams(params) {
        if (this.viewConfigService.isDefaultConfigSet()) {
            // If there is a default config, we will not use our defaults
            return;
        }
        for (const [key, value] of Object.entries(params)) {
            this.tryApplyFilter(key, value);
        }
    }
    tryApplyFilter(name, value) {
        let filterOptions = this.dataModel?.Filters || [];
        const index = filterOptions.findIndex((elem) => elem.Name?.toLowerCase() === name.toLowerCase());
        if (index > -1) {
            const filter = filterOptions[index];
            if (filter) {
                filter.InitialValue = value;
                filter.CurrentValue = value;
                this.dataSource.state.update((state) => ({ ...state, [name.toLowerCase()]: value }));
            }
        }
    }
    getGroupParams(column, params) {
        if (this.dataModel.Properties?.find((property) => property.Property?.ColumnName === column)) {
            return { ...params, by: column };
        }
        else {
            return { ...params, def: column };
        }
    }
    static ɵfac = function PolicyViolationsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolicyViolationsComponent)(i0.ɵɵdirectiveInject(PolicyViolationsService), i0.ɵɵdirectiveInject(i2.ViewConfigService), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i3.ActivatedRoute), i0.ɵɵdirectiveInject(i3$1.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsComponent, selectors: [["imx-policy-violations"]], inputs: { selectedCompanyPolicy: "selectedCompanyPolicy", isMControlPerViolation: "isMControlPerViolation" }, features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 17, vars: 10, consts: [[1, "imx-policyviolation-page"], ["class", "imx-header-toolbar", 4, "ngIf"], [4, "ngIf"], [1, "imx-card-fill"], ["mode", "manual", 3, "dataSource", "selectable"], [3, "matColumnDef", 4, "ngIf"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], [3, "dataSource"], ["class", "imx-button-bar-transparent", 4, "ngIf"], [1, "imx-header-toolbar"], [1, "mat-headline-5"], [3, "updateConfig", "deleteConfigById", "dataSource"], [3, "updateConfig", "deleteConfigById", "dataSource", "showGrouping"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell"], ["data-imx-identifier", "rules-violations-table-row-button-view-details", 1, "imx-main-column"], ["subtitle", ""], [1, "imx-button-column"], ["mat-stroked-button", "", "color", "warn", "data-imx-identifier", "policy-violations-table-deny-button", 3, "click"], ["icon", "ignore"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "policy-violations-table-approve-button", 3, "click"], ["icon", "check"], [1, "imx-button-bar-transparent"], [1, "justify-start", 3, "dataSource"], ["mat-flat-button", "", "color", "warn", "data-imx-identifier", "policy-violations-table-button-deny", 3, "click", "title", "disabled"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "policy-violations-table-button-approve", 3, "click", "title", "disabled"]], template: function PolicyViolationsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, PolicyViolationsComponent_div_1_Template, 7, 4, "div", 1)(2, PolicyViolationsComponent_ng_container_2_Template, 2, 2, "ng-container", 2);
            i0.ɵɵelementStart(3, "mat-card", 3)(4, "imx-data-view-auto-table", 4);
            i0.ɵɵtemplate(5, PolicyViolationsComponent_ng_container_5_Template, 4, 1, "ng-container", 5);
            i0.ɵɵelementContainerStart(6, 6)(7);
            i0.ɵɵtemplate(8, PolicyViolationsComponent_th_8_Template, 3, 3, "th", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(9, PolicyViolationsComponent_td_9_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(10, 6)(11);
            i0.ɵɵtemplate(12, PolicyViolationsComponent_th_12_Template, 2, 1, "th", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(13, PolicyViolationsComponent_td_13_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(14, PolicyViolationsComponent_ng_container_14_Template, 4, 1, "ng-container", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(15, "imx-data-view-paginator", 9);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(16, PolicyViolationsComponent_div_16_Template, 12, 15, "div", 10);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.selectedCompanyPolicy);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.selectedCompanyPolicy);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("selectable", !ctx.selectedCompanyPolicy);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.selectedCompanyPolicy);
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns.ObjectKey == null ? null : ctx.entitySchema.Columns.ObjectKey.ColumnName);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns.State == null ? null : ctx.entitySchema.Columns.State.ColumnName);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngIf", !ctx.selectedCompanyPolicy);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.selectedCompanyPolicy);
        } }, dependencies: [i2$2.EuiIconComponent, i5.MatButton, i1.MatCard, i9$1.MatHeaderCellDef, i9$1.MatColumnDef, i9$1.MatCellDef, i9$1.MatHeaderCell, i9$1.MatCell, i9.NgIf, i3$1.HelpContextualComponent, i3$1.DataViewAutoTableComponent, i3$1.DataViewPaginatorComponent, i3$1.DataViewToolbarComponent, i3$1.DataViewSelectionComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]   .imx-main-column[_ngcontent-%COMP%]{flex-direction:column!important}.eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}.heading-wrapper[_ngcontent-%COMP%]{display:flex;flex-direction:row;flex:0 0 auto}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;width:inherit;max-width:100%}.imx-policyviolation-page[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-policyviolation-page[_ngcontent-%COMP%]   div.imx-policyviolation-table[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto}.imx-policyviolation-page[_ngcontent-%COMP%]   div.imx-policyviolation-table[_ngcontent-%COMP%]   .imx-column-container[_ngcontent-%COMP%]   .imx-main-column[_ngcontent-%COMP%]{max-width:600px;margin-right:10px}@media screen and (max-width: 768px){.imx-rules-violations-page[_ngcontent-%COMP%]   .heading-wrapper[_ngcontent-%COMP%]{display:block}}@media only screen and (max-width: 1024px){  .mat-column-decision{display:none}}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsComponent, [{
        type: Component,
        args: [{ selector: 'imx-policy-violations', providers: [DataViewSource], template: "<div class=\"imx-policyviolation-page\">\n  <div class=\"imx-header-toolbar\" *ngIf=\"!selectedCompanyPolicy\">\n    <h2 class=\"mat-headline-5\">\n      <span>{{ '#LDS#Heading Policy Violations' | translate }}</span>\n      <imx-help-contextual></imx-help-contextual>\n    </h2>\n    <imx-data-view-toolbar\n      [dataSource]=\"dataSource\"\n      (updateConfig)=\"updateConfig($event)\"\n      (deleteConfigById)=\"deleteConfigById($event)\"\n    ></imx-data-view-toolbar>\n  </div>\n  <ng-container *ngIf=\"selectedCompanyPolicy\">\n    <imx-data-view-toolbar\n      [dataSource]=\"dataSource\"\n      (updateConfig)=\"updateConfig($event)\"\n      [showGrouping]=\"false\"\n      (deleteConfigById)=\"deleteConfigById($event)\"\n    ></imx-data-view-toolbar>\n  </ng-container>\n  <mat-card class=\"imx-card-fill\">\n    <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\" [selectable]=\"!selectedCompanyPolicy\">\n      <ng-container [matColumnDef]=\"entitySchema?.Columns?.UID_QERPolicy?.ColumnName\" *ngIf=\"!selectedCompanyPolicy\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef>\n            {{ entitySchema?.Columns?.UID_QERPolicy?.Display }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <div class=\"imx-main-column\" data-imx-identifier=\"rules-violations-table-row-button-view-details\">\n            <div>{{ item.UID_QERPolicy.Column.GetDisplayValue() }}</div>\n            <div subtitle>{{ item.Description.Column.GetDisplayValue() }}</div>\n          </div>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"entitySchema?.Columns?.ObjectKey?.ColumnName\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef>\n            {{ '#LDS#Violating object' | translate }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <span>\n            {{ item.ObjectKey.Column.GetDisplayValue() }}\n          </span>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"entitySchema?.Columns?.State?.ColumnName\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef>\n            {{ entitySchema?.Columns?.State?.Display }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <span>\n            {{ item.State.Column.GetDisplayValue() }}\n          </span>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"'actions'\" *ngIf=\"!selectedCompanyPolicy\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef></th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <div class=\"imx-button-column\">\n            <button\n              mat-stroked-button\n              color=\"warn\"\n              (click)=\"decide(false, [item]); $event.stopPropagation()\"\n              data-imx-identifier=\"policy-violations-table-deny-button\"\n            >\n              <eui-icon icon=\"ignore\"></eui-icon>\n              {{ '#LDS#Deny exception' | translate }}\n            </button>\n            <button\n              mat-stroked-button\n              color=\"primary\"\n              (click)=\"decide(true, [item]); $event.stopPropagation()\"\n              data-imx-identifier=\"policy-violations-table-approve-button\"\n            >\n              <eui-icon icon=\"check\"></eui-icon>\n              {{ '#LDS#Grant exception' | translate }}\n            </button>\n          </div>\n        </td>\n      </ng-container>\n    </imx-data-view-auto-table>\n    <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n  </mat-card>\n  <div class=\"imx-button-bar-transparent\" *ngIf=\"!selectedCompanyPolicy\">\n    <imx-data-view-selection class=\"justify-start\" [dataSource]=\"dataSource\"></imx-data-view-selection>\n    <button\n      mat-flat-button\n      color=\"warn\"\n      data-imx-identifier=\"policy-violations-table-button-deny\"\n      title=\"{{ '#LDS#Denies an exception for the selected policy violations' | translate }}\"\n      (click)=\"decide(false, selectedViolations)\"\n      [disabled]=\"!selectedViolations.length\"\n    >\n      <eui-icon icon=\"ignore\"></eui-icon>\n      {{ '#LDS#Deny exception' | translate }}\n    </button>\n    <button\n      mat-flat-button\n      color=\"primary\"\n      data-imx-identifier=\"policy-violations-table-button-approve\"\n      title=\"{{ '#LDS#Grants an exception for the selected policy violations' | translate }}\"\n      (click)=\"decide(true, selectedViolations)\"\n      [disabled]=\"!selectedViolations.length\"\n    >\n      <eui-icon icon=\"check\"></eui-icon>\n      {{ '#LDS#Grant exception' | translate }}\n    </button>\n  </div>\n</div>\n", styles: [":host .imx-main-column{flex-direction:column!important}.eui-sidesheet-content{display:flex;flex-direction:column}.heading-wrapper{display:flex;flex-direction:row;flex:0 0 auto}:host{display:flex;flex-direction:column;overflow:hidden;height:inherit;width:inherit;max-width:100%}.imx-policyviolation-page{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-policyviolation-page div.imx-policyviolation-table{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto}.imx-policyviolation-page div.imx-policyviolation-table .imx-column-container .imx-main-column{max-width:600px;margin-right:10px}@media screen and (max-width: 768px){.imx-rules-violations-page .heading-wrapper{display:block}}@media only screen and (max-width: 1024px){::ng-deep .mat-column-decision{display:none}}\n"] }]
    }], () => [{ type: PolicyViolationsService }, { type: i2.ViewConfigService }, { type: i2$2.EuiSidesheetService }, { type: i4.TranslateService }, { type: i3.ActivatedRoute }, { type: i3$1.DataViewSource }], { selectedCompanyPolicy: [{
            type: Input
        }], isMControlPerViolation: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PolicyViolationsComponent, { className: "PolicyViolationsComponent", filePath: "lib\\policy-violations\\policy-violations.component.ts", lineNumber: 63 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MitigatingControlsPolicyComponent_eui_alert_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 4)(1, "eui-alert-header");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "eui-alert-content");
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 4, "#LDS#Heading Mitigating Controls Can Be Assigned Individually"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 6, "#LDS#Here you can get an overview of the mitigating controls that can be assigned to a violation of this company policy."));
} }
function MitigatingControlsPolicyComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 4)(1, "eui-alert-header");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "eui-alert-content");
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 4, "#LDS#Heading Mitigating Controls Applied Globally"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 6, "#LDS#Here you can get an overview of the mitigating controls that are automatically applied to every violation of this company policy."));
} }
function MitigatingControlsPolicyComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵelement(1, "eui-icon", 6);
    i0.ɵɵelementContainerStart(2);
    i0.ɵɵelement(3, "p", 7);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("translate", "#LDS#There are currently no mitigating controls assigned to this company policy.");
} }
function MitigatingControlsPolicyComponent_div_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵelement(1, "imx-cdr-editor", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const mControl_r1 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("cdr", mControl_r1);
} }
/**
 * Used to get and display mitigating controls for each policy
 */
class MitigatingControlsPolicyComponent {
    apiService;
    busyService;
    cdrService;
    objectUid;
    isMControlPerViolation;
    mControls;
    /**
     * @ignore only for dep injection
     */
    constructor(apiService, busyService, cdrService) {
        this.apiService = apiService;
        this.busyService = busyService;
        this.cdrService = cdrService;
    }
    /**
     * Setup component with mitigating controls
     */
    ngOnInit() {
        this.getMitigatingControls();
    }
    /**
     * Calls the api and map the results into display cdrs
     */
    async getMitigatingControls() {
        this.busyService.show();
        try {
            this.mControls = (await this.apiService.getMitigatingControls(this.objectUid)).Data.map((control) => this.cdrService.buildCdr(control.GetEntity(), control.UID_MitigatingControl.Column.ColumnName)).filter(Boolean);
        }
        finally {
            this.busyService.hide();
        }
    }
    static ɵfac = function MitigatingControlsPolicyComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlsPolicyComponent)(i0.ɵɵdirectiveInject(PoliciesService), i0.ɵɵdirectiveInject(i2$2.EuiLoadingService), i0.ɵɵdirectiveInject(i3$1.CdrFactoryService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsPolicyComponent, selectors: [["imx-mitigating-controls-policy"]], inputs: { objectUid: "objectUid", isMControlPerViolation: "isMControlPerViolation" }, decls: 5, vars: 4, consts: [["class", "imx-helper-alert", "type", "info", 3, "condensed", "colored", 4, "ngIf"], [1, "imx-centered-filled-card"], ["class", "imx-no-results", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["type", "info", 1, "imx-helper-alert", 3, "condensed", "colored"], [1, "imx-no-results"], ["icon", "table"], [3, "translate"], [3, "cdr"]], template: function MitigatingControlsPolicyComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, MitigatingControlsPolicyComponent_eui_alert_0_Template, 7, 8, "eui-alert", 0)(1, MitigatingControlsPolicyComponent_eui_alert_1_Template, 7, 8, "eui-alert", 0);
            i0.ɵɵelementStart(2, "mat-card", 1);
            i0.ɵɵtemplate(3, MitigatingControlsPolicyComponent_div_3_Template, 4, 1, "div", 2)(4, MitigatingControlsPolicyComponent_div_4_Template, 2, 1, "div", 3);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.isMControlPerViolation);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.isMControlPerViolation);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.mControls);
        } }, dependencies: [i9.NgForOf, i9.NgIf, i2$2.EuiAlertComponent, i2$2.EuiAlertContentDirective, i2$2.EuiAlertHeaderDirective, i2$2.EuiIconComponent, i4.TranslateDirective, i3$1.CdrEditorComponent, i1.MatCard, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .imx-helper-alert[_ngcontent-%COMP%]{margin-bottom:20px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]{text-align:center;margin:auto}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsPolicyComponent, [{
        type: Component,
        args: [{ selector: 'imx-mitigating-controls-policy', template: "<eui-alert class=\"imx-helper-alert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\" *ngIf=\"isMControlPerViolation\">\n  <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Can Be Assigned Individually' | translate }}</eui-alert-header>\n  <eui-alert-content>{{\n    '#LDS#Here you can get an overview of the mitigating controls that can be assigned to a violation of this company policy.' | translate\n  }}</eui-alert-content>\n</eui-alert>\n<eui-alert class=\"imx-helper-alert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\" *ngIf=\"!isMControlPerViolation\">\n  <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Applied Globally' | translate }}</eui-alert-header>\n  <eui-alert-content>{{\n    '#LDS#Here you can get an overview of the mitigating controls that are automatically applied to every violation of this company policy.'\n      | translate\n  }}</eui-alert-content>\n</eui-alert>\n\n<mat-card class=\"imx-centered-filled-card\">\n  <div class=\"imx-no-results\" *ngIf=\"!mControls || mControls.length == 0\">\n    <eui-icon icon=\"table\"></eui-icon>\n    <ng-container>\n      <p [translate]=\"'#LDS#There are currently no mitigating controls assigned to this company policy.'\"></p>\n    </ng-container>\n  </div>\n  <div *ngFor=\"let mControl of mControls\">\n    <imx-cdr-editor [cdr]=\"mControl\"></imx-cdr-editor>\n  </div>\n</mat-card>\n", styles: [":host{display:flex;flex:1 1 auto;flex-direction:column}:host .imx-helper-alert{margin-bottom:20px}:host .imx-no-results{text-align:center;margin:auto}:host .imx-no-results p{margin:0;font-size:18px}:host .imx-no-results button{margin-top:10px}:host .imx-no-results p{color:#797e80}.eui-dark-theme :host .imx-no-results p{color:#dfe4e6}.eui-contrast-theme :host .imx-no-results p{color:#fff}\n"] }]
    }], () => [{ type: PoliciesService }, { type: i2$2.EuiLoadingService }, { type: i3$1.CdrFactoryService }], { objectUid: [{
            type: Input
        }], isMControlPerViolation: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MitigatingControlsPolicyComponent, { className: "MitigatingControlsPolicyComponent", filePath: "lib\\policies\\mitigating-controls-policy\\mitigating-controls-policy.component.ts", lineNumber: 40 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function PoliciesSidesheetComponent_ng_template_3_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 9);
} if (rf & 2) {
    const cdr_r1 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r1);
} }
function PoliciesSidesheetComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5)(1, "mat-card");
    i0.ɵɵtemplate(2, PoliciesSidesheetComponent_ng_template_3_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 6);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(3, "div", 7)(4, "button", 8);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r1.cdrList);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("euiDownload", ctx_r1.reportDownload);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 3, "#LDS#Download report"), " ");
} }
function PoliciesSidesheetComponent_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵelement(1, "imx-policy-violations", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("selectedCompanyPolicy", ctx_r1.data.selectedPolicy)("isMControlPerViolation", ctx_r1.data.isMControlPerViolation);
} }
function PoliciesSidesheetComponent_mat_tab_7_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵelement(1, "imx-mitigating-controls-policy", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("objectUid", ctx_r1.objectUid)("isMControlPerViolation", ctx_r1.data.isMControlPerViolation);
} }
function PoliciesSidesheetComponent_mat_tab_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab", 1);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵtemplate(2, PoliciesSidesheetComponent_mat_tab_7_ng_template_2_Template, 2, 2, "ng-template", 2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Mitigating Controls"));
} }
function PoliciesSidesheetComponent_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵelement(1, "imx-statistics-for-objects", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("objectType", ctx_r1.objectType)("objectUid", ctx_r1.objectUid);
} }
function PoliciesSidesheetComponent_ng_template_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵelement(1, "imx-object-hyperview", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("objectType", ctx_r1.data == null ? null : ctx_r1.data.selectedPolicy == null ? null : (tmp_1_0 = ctx_r1.data.selectedPolicy.GetEntity()) == null ? null : tmp_1_0.TypeName)("objectUid", ctx_r1.data == null ? null : ctx_r1.data.selectedPolicy == null ? null : (tmp_2_0 = ctx_r1.data.selectedPolicy.GetEntity()) == null ? null : (tmp_2_0 = tmp_2_0.GetKeys()) == null ? null : tmp_2_0[0]);
} }
class PoliciesSidesheetComponent {
    data;
    sidesheetRef;
    policiesProvider;
    reportDownload;
    cdrList;
    uidNonCompliance;
    uidCompliance;
    subscriptions$ = [];
    constructor(data, sidesheetRef, policiesProvider, elementalUiConfigService) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.policiesProvider = policiesProvider;
        this.uidCompliance = data.selectedPolicy.GetEntity().GetKeys().join(',');
        this.cdrList = [
            new BaseReadonlyCdr(this.data.selectedPolicy.GetEntity().GetColumn(DisplayColumns.DISPLAY_PROPERTYNAME)),
            new BaseReadonlyCdr(this.data.selectedPolicy.Description.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.IsExceptionAllowed.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.IsInActive.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.RuleSeverity.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.RuleViolationThreshold.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.SignificancyClass.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.TransparencyIndex.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.UID_QERPolicyGroup.Column),
        ];
        if (data.hasRiskIndex) {
            // Stick this in position 4
            this.cdrList.splice(4, 0, new BaseReadonlyCdr(this.data.selectedPolicy.RiskIndex.Column));
        }
        this.reportDownload = {
            ...elementalUiConfigService.Config.downloadOptions,
            url: this.policiesProvider.policyReport(this.uidCompliance),
        };
    }
    get objectType() {
        return this.data.selectedPolicy.GetEntity().TypeName;
    }
    get objectUid() {
        return this.data.selectedPolicy.GetEntity().GetKeys().join(',');
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
    static ɵfac = function PoliciesSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PoliciesSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetRef), i0.ɵɵdirectiveInject(PoliciesService), i0.ɵɵdirectiveInject(i3$1.ElementalUiConfigService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PoliciesSidesheetComponent, selectors: [["imx-policies-sidesheet"]], decls: 14, vars: 13, consts: [["mat-stretch-tabs", "false"], [3, "label"], ["matTabContent", ""], [3, "label", 4, "ngIf"], ["data-imx-identifier", "policies-sidesheet-tab-statistics", 3, "label"], ["eui-sidesheet-content", ""], [3, "cdr", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "policies-sidesheet-button-download-report", 1, "justify-start", 3, "euiDownload"], [3, "cdr"], [3, "selectedCompanyPolicy", "isMControlPerViolation"], [3, "objectUid", "isMControlPerViolation"], [3, "objectType", "objectUid"]], template: function PoliciesSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group", 0)(1, "mat-tab", 1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵtemplate(3, PoliciesSidesheetComponent_ng_template_3_Template, 7, 5, "ng-template", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-tab", 1);
            i0.ɵɵpipe(5, "translate");
            i0.ɵɵtemplate(6, PoliciesSidesheetComponent_ng_template_6_Template, 2, 2, "ng-template", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, PoliciesSidesheetComponent_mat_tab_7_Template, 3, 3, "mat-tab", 3);
            i0.ɵɵelementStart(8, "mat-tab", 4);
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵtemplate(10, PoliciesSidesheetComponent_ng_template_10_Template, 2, 2, "ng-template", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(11, "mat-tab", 1);
            i0.ɵɵpipe(12, "translate");
            i0.ɵɵtemplate(13, PoliciesSidesheetComponent_ng_template_13_Template, 2, 2, "ng-template", 2);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 5, "#LDS#Heading Information"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(5, 7, "#LDS#Heading Policy Violations"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.data.hasRiskIndex);
            i0.ɵɵadvance();
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(9, 9, "#LDS#Heading Statistics"));
            i0.ɵɵadvance(3);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(12, 11, "#LDS#Heading Hyperview"));
        } }, dependencies: [i9.NgForOf, i9.NgIf, i2$2.EuiDownloadDirective, i2$2.EuiSidesheetContentDirective, i2$2.EuiSidesheetActionsDirective, i3$1.CdrEditorComponent, i5.MatButton, i1.MatCard, i8$1.MatTabContent, i8$1.MatTab, i8$1.MatTabGroup, i2.StatisticsForObjectsComponent, i2.ObjectHyperviewComponent, PolicyViolationsComponent, MitigatingControlsPolicyComponent, i4.TranslatePipe], encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PoliciesSidesheetComponent, [{
        type: Component,
        args: [{ selector: 'imx-policies-sidesheet', template: "<mat-tab-group mat-stretch-tabs=\"false\">\n  <mat-tab [label]=\"'#LDS#Heading Information' | translate\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <mat-card>\n          <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\n        </mat-card>\n      </div>\n\n      <div eui-sidesheet-actions>\n        <button\n          mat-stroked-button\n          [euiDownload]=\"reportDownload\"\n          class=\"justify-start\"\n          data-imx-identifier=\"policies-sidesheet-button-download-report\"\n        >\n          {{ '#LDS#Download report' | translate }}\n        </button>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab [label]=\"'#LDS#Heading Policy Violations' | translate\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <imx-policy-violations\n          [selectedCompanyPolicy]=\"data.selectedPolicy\"\n          [isMControlPerViolation]=\"data.isMControlPerViolation\"\n        ></imx-policy-violations>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab [label]=\"'#LDS#Heading Mitigating Controls' | translate\" *ngIf=\"data.hasRiskIndex\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <imx-mitigating-controls-policy\n          [objectUid]=\"objectUid\"\n          [isMControlPerViolation]=\"data.isMControlPerViolation\"\n        ></imx-mitigating-controls-policy>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab data-imx-identifier=\"policies-sidesheet-tab-statistics\" [label]=\"'#LDS#Heading Statistics' | translate\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <imx-statistics-for-objects [objectType]=\"objectType\" [objectUid]=\"objectUid\"></imx-statistics-for-objects>\n      </div>\n    </ng-template>\n  </mat-tab>\n  <mat-tab label=\"{{ '#LDS#Heading Hyperview' | translate }}\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <imx-object-hyperview\n          [objectType]=\"data?.selectedPolicy?.GetEntity()?.TypeName\"\n          [objectUid]=\"data?.selectedPolicy?.GetEntity()?.GetKeys()?.[0]\"\n        >\n        </imx-object-hyperview>\n      </div>\n    </ng-template>\n  </mat-tab>\n</mat-tab-group>\n" }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i2$2.EuiSidesheetRef }, { type: PoliciesService }, { type: i3$1.ElementalUiConfigService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PoliciesSidesheetComponent, { className: "PoliciesSidesheetComponent", filePath: "lib\\policies\\policies-sidesheet\\policies-sidesheet.component.ts", lineNumber: 40 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function PoliciesComponent_th_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.policySchema == null ? null : ctx_r0.policySchema.Columns == null ? null : ctx_r0.policySchema.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME] == null ? null : ctx_r0.policySchema.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME].Display, " ");
} }
function PoliciesComponent_td_12_eui_badge_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 18);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Deactivated"));
} }
function PoliciesComponent_td_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 12)(1, "div", 13)(2, "div", 14)(3, "div", 15);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "div", 16);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(7, PoliciesComponent_td_12_eui_badge_7_Template, 3, 3, "eui-badge", 17);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(item_r2.GetEntity().GetDisplay());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r2.Description.Column.GetDisplayValue());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r2.IsInActive.value);
} }
function PoliciesComponent_th_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 11);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Policy violations"), " ");
} }
function PoliciesComponent_td_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 19)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r3.CountOpen.value + item_r3.CountClosed.value, " ");
} }
function PoliciesComponent_th_19_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.policySchema == null ? null : ctx_r0.policySchema.Columns == null ? null : ctx_r0.policySchema.Columns.CountOpen == null ? null : ctx_r0.policySchema.Columns.CountOpen.Display, " ");
} }
function PoliciesComponent_td_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 19)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r4.CountOpen.Column.GetDisplayValue(), " ");
} }
class PoliciesComponent {
    policiesProvider;
    sideSheetService;
    systemInfoService;
    translate;
    euiBusysService;
    dataSource;
    dstSettings;
    DisplayColumns = DisplayColumns;
    policySchema;
    busyService = new BusyService();
    dataModel;
    displayedColumns = [];
    filterOptions = [];
    isMControlPerViolation;
    constructor(policiesProvider, sideSheetService, systemInfoService, translate, euiBusysService, dataSource) {
        this.policiesProvider = policiesProvider;
        this.sideSheetService = sideSheetService;
        this.systemInfoService = systemInfoService;
        this.translate = translate;
        this.euiBusysService = euiBusysService;
        this.dataSource = dataSource;
        this.policySchema = policiesProvider.policySchema;
        this.displayedColumns = [
            this.policySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            {
                ColumnName: 'cases',
                Type: ValType.Int,
            },
            this.policySchema.Columns.CountOpen,
        ];
    }
    async ngOnInit() {
        this.euiBusysService.show();
        try {
            this.dataModel = await this.policiesProvider.getDataModel();
            this.isMControlPerViolation = (await this.policiesProvider.featureConfig()).MitigatingControlsPerViolation;
        }
        finally {
            this.euiBusysService.hide();
        }
        await this.getData();
    }
    async showDetails(selectedPolicy) {
        const hasRiskIndex = (await this.systemInfoService.get())?.PreProps?.includes('RISKINDEX');
        await this.sideSheetService
            .open(PoliciesSidesheetComponent, {
            title: await this.translate.get('#LDS#Heading View Company Policy Details').toPromise(),
            subTitle: selectedPolicy.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(700, 0.4),
            testId: 'policy-details-sidesheet',
            data: {
                selectedPolicy: selectedPolicy,
                hasRiskIndex,
                isMControlPerViolation: this.isMControlPerViolation,
            },
        })
            .afterClosed()
            .toPromise();
    }
    async getData() {
        this.filterOptions = this.dataModel?.Filters || [];
        this.filterOptions.map((filter) => {
            if (filter.Name === 'active') {
                filter.CurrentValue = '1';
            }
        });
        this.dataSource.state.update((state) => ({ ...state, active: '1' }));
        const dataViewInitParameters = {
            execute: (params, signal) => this.policiesProvider.getPolicies(params, signal),
            schema: this.policySchema,
            columnsToDisplay: this.displayedColumns,
            dataModel: this.dataModel,
            highlightEntity: (entity) => {
                this.showDetails(entity);
            },
        };
        this.dataSource.init(dataViewInitParameters);
    }
    static ɵfac = function PoliciesComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PoliciesComponent)(i0.ɵɵdirectiveInject(PoliciesService), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$1.SystemInfoService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i2$2.EuiLoadingService), i0.ɵɵdirectiveInject(i3$1.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PoliciesComponent, selectors: [["imx-policies"]], features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 22, vars: 11, consts: [[1, "imx-header-toolbar"], [1, "mat-headline-5"], [3, "dataSource", "showSettings", "showGrouping"], [1, "imx-card-fill"], [1, "imx-table-container"], ["mode", "manual", 3, "dataSource"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], [3, "dataSource"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], ["data-imx-identifier", "runs-button-show-details", 1, "imx-display-column"], [1, "imx-display-column-main"], ["data-imx-identifier", "policies-table-display"], ["subtitle", "", "data-imx-identifier", "policies-table-description"], ["class", "imx-badge", "color", "gray", 4, "ngIf"], ["color", "gray", 1, "imx-badge"], ["mat-cell", "", "role", "gridcell"]], template: function PoliciesComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1)(2, "span");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(5, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(6, "imx-data-view-toolbar", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-card", 3)(8, "div", 4)(9, "imx-data-view-auto-table", 5);
            i0.ɵɵelementContainerStart(10, 6);
            i0.ɵɵtemplate(11, PoliciesComponent_th_11_Template, 2, 1, "th", 7)(12, PoliciesComponent_td_12_Template, 8, 3, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(13, 6)(14);
            i0.ɵɵtemplate(15, PoliciesComponent_th_15_Template, 3, 3, "th", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(16, PoliciesComponent_td_16_Template, 3, 1, "td", 9);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(17, 6)(18);
            i0.ɵɵtemplate(19, PoliciesComponent_th_19_Template, 2, 1, "th", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(20, PoliciesComponent_td_20_Template, 3, 1, "td", 9);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd();
            i0.ɵɵelement(21, "imx-data-view-paginator", 10);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 9, "#LDS#Heading Company Policies"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("showSettings", false)("showGrouping", false);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.DisplayColumns.DISPLAY_PROPERTYNAME);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", "cases");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("matColumnDef", ctx.policySchema == null ? null : ctx.policySchema.Columns == null ? null : ctx.policySchema.Columns.CountOpen == null ? null : ctx.policySchema.Columns.CountOpen.ColumnName);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
        } }, dependencies: [i9.NgIf, i2$2.EuiBadgeComponent, i1.MatCard, i3$1.HelpContextualComponent, i3$1.DataViewAutoTableComponent, i3$1.DataViewPaginatorComponent, i3$1.DataViewToolbarComponent, i9$1.MatHeaderCellDef, i9$1.MatColumnDef, i9$1.MatCellDef, i9$1.MatHeaderCell, i9$1.MatCell, i4.TranslatePipe], styles: ["div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit}.imx-display-column[_ngcontent-%COMP%]{width:100%!important;cursor:inherit!important}.imx-display-column-main[_ngcontent-%COMP%]{flex:1 1 auto;display:block!important;cursor:inherit!important}.imx-display-column[_ngcontent-%COMP%]   .imx-badge[_ngcontent-%COMP%]{align-self:flex-end}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PoliciesComponent, [{
        type: Component,
        args: [{ selector: 'imx-policies', providers: [DataViewSource], template: "<div class=\"imx-header-toolbar\">\n  <h2 class=\"mat-headline-5\">\n    <span>{{ '#LDS#Heading Company Policies' | translate }}</span>\n    <imx-help-contextual></imx-help-contextual>\n  </h2>\n  <imx-data-view-toolbar [dataSource]=\"dataSource\" [showSettings]=\"false\" [showGrouping]=\"false\"></imx-data-view-toolbar>\n</div>\n<mat-card class=\"imx-card-fill\">\n  <div class=\"imx-table-container\">\n    <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\">\n      <ng-container [matColumnDef]=\"DisplayColumns.DISPLAY_PROPERTYNAME\">\n        <th mat-header-cell *matHeaderCellDef>\n          {{ policySchema?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]?.Display }}\n        </th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n          <div class=\"imx-display-column\" data-imx-identifier=\"runs-button-show-details\">\n            <div class=\"imx-display-column-main\">\n              <div data-imx-identifier=\"policies-table-display\">{{ item.GetEntity().GetDisplay() }}</div>\n              <div subtitle data-imx-identifier=\"policies-table-description\">{{ item.Description.Column.GetDisplayValue() }}</div>\n            </div>\n            <eui-badge class=\"imx-badge\" *ngIf=\"item.IsInActive.value\" color=\"gray\">{{ '#LDS#Deactivated' | translate }}</eui-badge>\n          </div>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"'cases'\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef>\n            {{ '#LDS#Policy violations' | translate }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <span>\n            {{ item.CountOpen.value + item.CountClosed.value }}\n          </span>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"policySchema?.Columns?.CountOpen?.ColumnName\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef>\n            {{ policySchema?.Columns?.CountOpen?.Display }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <span>\n            {{ item.CountOpen.Column.GetDisplayValue() }}\n          </span>\n        </td>\n      </ng-container>\n    </imx-data-view-auto-table>\n    <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n  </div>\n</mat-card>\n", styles: ["div[subtitle]{font-size:smaller;color:#919799}:host{display:flex;flex-direction:column;overflow:hidden;height:inherit}.imx-display-column{width:100%!important;cursor:inherit!important}.imx-display-column-main{flex:1 1 auto;display:block!important;cursor:inherit!important}.imx-display-column .imx-badge{align-self:flex-end}\n"] }]
    }], () => [{ type: PoliciesService }, { type: i2$2.EuiSidesheetService }, { type: i3$1.SystemInfoService }, { type: i4.TranslateService }, { type: i2$2.EuiLoadingService }, { type: i3$1.DataViewSource }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PoliciesComponent, { className: "PoliciesComponent", filePath: "lib\\policies\\policies.component.ts", lineNumber: 58 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PolicyViolationsModule {
    static ɵfac = function PolicyViolationsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolicyViolationsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: PolicyViolationsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [EuiCoreModule,
            EuiMaterialModule,
            MatButtonModule,
            MatCardModule,
            MatListModule,
            MatTabsModule,
            MatFormFieldModule,
            MatTooltipModule,
            CommonModule,
            TranslateModule,
            ReactiveFormsModule,
            BulkPropertyEditorModule,
            CdrModule,
            FormsModule,
            JustificationModule,
            DataTableModule,
            DataSourceToolbarModule,
            SelectedElementsModule,
            StatisticsModule,
            HelpContextualModule,
            ObjectHyperviewModule,
            DataViewModule,
            MatTableModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    PolicyViolationsComponent,
                    PolicyViolationsActionComponent,
                    PolicyViolationsActionMultiActionComponent,
                    PolicyViolationsActionSingleActionComponent,
                    PolicyViolationsSidesheetComponent,
                    MitigatingControlsComponent,
                ],
                imports: [
                    EuiCoreModule,
                    EuiMaterialModule,
                    MatButtonModule,
                    MatCardModule,
                    MatListModule,
                    MatTabsModule,
                    MatFormFieldModule,
                    MatTooltipModule,
                    CommonModule,
                    TranslateModule,
                    ReactiveFormsModule,
                    BulkPropertyEditorModule,
                    CdrModule,
                    FormsModule,
                    JustificationModule,
                    DataTableModule,
                    DataSourceToolbarModule,
                    SelectedElementsModule,
                    StatisticsModule,
                    HelpContextualModule,
                    ObjectHyperviewModule,
                    DataViewModule,
                    MatTableModule,
                ],
                exports: [PolicyViolationsComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(PolicyViolationsModule, { declarations: [PolicyViolationsComponent,
        PolicyViolationsActionComponent,
        PolicyViolationsActionMultiActionComponent,
        PolicyViolationsActionSingleActionComponent,
        PolicyViolationsSidesheetComponent,
        MitigatingControlsComponent], imports: [EuiCoreModule,
        EuiMaterialModule,
        MatButtonModule,
        MatCardModule,
        MatListModule,
        MatTabsModule,
        MatFormFieldModule,
        MatTooltipModule,
        CommonModule,
        TranslateModule,
        ReactiveFormsModule,
        BulkPropertyEditorModule,
        CdrModule,
        FormsModule,
        JustificationModule,
        DataTableModule,
        DataSourceToolbarModule,
        SelectedElementsModule,
        StatisticsModule,
        HelpContextualModule,
        ObjectHyperviewModule,
        DataViewModule,
        MatTableModule], exports: [PolicyViolationsComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PoliciesModule {
    static ɵfac = function PoliciesModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PoliciesModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: PoliciesModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            EuiCoreModule,
            TranslateModule,
            CdrModule,
            DataTableModule,
            DataSourceToolbarModule,
            MatButtonModule,
            MatCardModule,
            MatTabsModule,
            StatisticsModule,
            ObjectHyperviewModule,
            HelpContextualModule,
            PolicyViolationsModule,
            DataViewModule,
            MatTableModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PoliciesModule, [{
        type: NgModule,
        args: [{
                declarations: [PoliciesComponent, PoliciesSidesheetComponent, MitigatingControlsPolicyComponent],
                imports: [
                    CommonModule,
                    EuiCoreModule,
                    TranslateModule,
                    CdrModule,
                    DataTableModule,
                    DataSourceToolbarModule,
                    MatButtonModule,
                    MatCardModule,
                    MatTabsModule,
                    StatisticsModule,
                    ObjectHyperviewModule,
                    HelpContextualModule,
                    PolicyViolationsModule,
                    DataViewModule,
                    MatTableModule,
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(PoliciesModule, { declarations: [PoliciesComponent, PoliciesSidesheetComponent, MitigatingControlsPolicyComponent], imports: [CommonModule,
        EuiCoreModule,
        TranslateModule,
        CdrModule,
        DataTableModule,
        DataSourceToolbarModule,
        MatButtonModule,
        MatCardModule,
        MatTabsModule,
        StatisticsModule,
        ObjectHyperviewModule,
        HelpContextualModule,
        PolicyViolationsModule,
        DataViewModule,
        MatTableModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'compliance/policyviolations/approve',
        component: PolicyViolationsComponent,
        canActivate: [PolicyAdminGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.CompliancePolicyViolations,
        },
    },
    {
        path: 'compliance/policyviolations',
        component: PolicyViolationsComponent,
        canActivate: [PolicyAdminGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.CompliancePolicyViolations,
        },
    },
    {
        path: 'compliance/policies',
        component: PoliciesComponent,
        canActivate: [PolicyAdminOrOwnerGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.CompanyPolicies,
        },
    },
];
class PolConfigModule {
    initializer;
    logger;
    constructor(initializer, logger) {
        this.initializer = initializer;
        this.logger = logger;
        this.logger.info(this, '🔥 POL loaded');
        this.initializer.onInit(routes);
        this.logger.info(this, '▶️ POL initialized');
    }
    static ɵfac = function PolConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PolConfigModule)(i0.ɵɵinject(InitService), i0.ɵɵinject(i3$1.ClassloggerService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: PolConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            TilesModule,
            RouterModule.forChild(routes),
            MatIconModule,
            MatListModule,
            TranslateModule,
            EuiCoreModule,
            PoliciesModule,
            PolicyViolationsModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolConfigModule, [{
        type: NgModule,
        args: [{
                declarations: [DashboardPluginComponent],
                imports: [
                    CommonModule,
                    TilesModule,
                    RouterModule.forChild(routes),
                    MatIconModule,
                    MatListModule,
                    TranslateModule,
                    EuiCoreModule,
                    PoliciesModule,
                    PolicyViolationsModule,
                ],
            }]
    }], () => [{ type: InitService }, { type: i3$1.ClassloggerService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(PolConfigModule, { declarations: [DashboardPluginComponent], imports: [CommonModule,
        TilesModule, i3.RouterModule, MatIconModule,
        MatListModule,
        TranslateModule,
        EuiCoreModule,
        PoliciesModule,
        PolicyViolationsModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of pol
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApiService, PermissionsService, PolConfigModule, PolicyAdminGuardService, PolicyViolationsComponent, PolicyViolationsModule };
//# sourceMappingURL=pol.mjs.map
