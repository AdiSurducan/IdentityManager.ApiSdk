/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="hds" />
export * from './public_api';
