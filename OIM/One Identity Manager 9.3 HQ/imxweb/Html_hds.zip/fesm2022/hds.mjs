import * as i0 from '@angular/core';
import { Injectable, Component, Inject, Input, ElementRef, NgModule } from '@angular/core';
import * as i1$2 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i4 from 'qbm';
import { BaseCdr, calculateSidesheetWidth, DataViewSource, DynamicDataSource, HELP_CONTEXTUAL, BusyService, HelpContextualComponent, CdrModule, DataSourceToolbarModule, DataTableModule, LdsReplaceModule, FkAdvancedPickerModule, SidenavTreeComponent, DataTreeWrapperModule, HelpContextualModule, DataViewModule, RouteGuardService } from 'qbm';
import * as i1 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiDownloadDirective, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i2$1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i6$1 from '@imx-modules/imx-api-hds';
import { V2Client, TypedClient, V2ApiClientMethodFactory } from '@imx-modules/imx-api-hds';
import * as i2 from '@angular/forms';
import { UntypedFormGroup, FormGroup, FormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i3 from 'qer';
import * as i6 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i5 from '@angular/material/button';
import * as i4$1 from '@angular/material/card';
import * as i9 from '@angular/material/tabs';
import * as i5$1 from '@angular/cdk/overlay';
import { FlatTreeControl } from '@angular/cdk/tree';
import * as i4$2 from '@angular/common/http';
import * as i1$1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MethodDefinition } from '@imx-modules/imx-qbm-dbts';
import * as i6$2 from '@angular/material/form-field';
import * as i7 from '@angular/material/input';
import * as i11 from '@angular/material/progress-spinner';
import * as i7$1 from '@angular/material/sort';
import * as i8 from '@angular/material/table';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class HdsApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function HdsApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || HdsApiService)(i0.ɵɵinject(i4.AppConfigService), i0.ɵɵinject(i4.ClassloggerService), i0.ɵɵinject(i4.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: HdsApiService, factory: HdsApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(HdsApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i4.AppConfigService }, { type: i4.ClassloggerService }, { type: i4.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function CallsHistorySidesheetComponent_imx_cdr_editor_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 4);
    i0.ɵɵlistener("controlCreated", function CallsHistorySidesheetComponent_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { const cdr_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.detailsFormGroup.addControl(cdr_r2.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r2 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r2);
} }
class CallsHistorySidesheetComponent {
    portalCallsHistory;
    euiLoadingService;
    formBuilder;
    detailsFormGroup;
    cdrList = [];
    constructor(portalCallsHistory, euiLoadingService, formBuilder) {
        this.portalCallsHistory = portalCallsHistory;
        this.euiLoadingService = euiLoadingService;
        this.formBuilder = formBuilder;
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    async ngOnInit() {
        await this.setup();
    }
    async setup() {
        let entity = this.portalCallsHistory.GetEntity();
        let columnNames = await this.getColumnNames();
        columnNames.forEach((columnName) => {
            let column = entity.GetColumn(columnName);
            if (column)
                this.cdrList.push(new BaseCdr(column));
        });
    }
    async getColumnNames() {
        let columnNames = [];
        columnNames.push('UID_TroubleTicket');
        columnNames.push('TroubleHistoryDate');
        columnNames.push('ActionHotline');
        columnNames.push('ObjectKeyPerson');
        columnNames.push('UID_TroubleCallState');
        columnNames.push('ObjectKeySupporter');
        return columnNames;
    }
    static ɵfac = function CallsHistorySidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CallsHistorySidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.UntypedFormBuilder)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsHistorySidesheetComponent, selectors: [["imx-calls-history-sidesheet"]], decls: 4, vars: 2, consts: [["eui-sidesheet-content", ""], [1, "imx-card"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [3, "controlCreated", "cdr"]], template: function CallsHistorySidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card", 1)(2, "form", 2);
            i0.ɵɵtemplate(3, CallsHistorySidesheetComponent_imx_cdr_editor_3_Template, 1, 1, "imx-cdr-editor", 3);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.detailsFormGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
        } }, dependencies: [i6.NgForOf, i2.ɵNgNoValidate, i2.NgControlStatusGroup, i2.FormGroupDirective, i1.EuiSidesheetContentDirective, i4$1.MatCard, i4.CdrEditorComponent], styles: [".calls-history-sidesheet[_ngcontent-%COMP%]{background-color:#f9fbfc;height:100%;display:flex;flex-direction:column;overflow:hidden}@media screen and (max-width: 480px){.calls-history-sidesheet__tab-content[_ngcontent-%COMP%]{display:block}}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsHistorySidesheetComponent, [{
        type: Component,
        args: [{ selector: 'imx-calls-history-sidesheet', template: "<div eui-sidesheet-content>\n  <mat-card class=\"imx-card\">\n    <form [formGroup]=\"detailsFormGroup\">\n      <imx-cdr-editor\n        *ngFor=\"let cdr of cdrList\"\n        [cdr]=\"cdr\"\n        (controlCreated)=\"detailsFormGroup.addControl(cdr.column.ColumnName, $event)\"\n      ></imx-cdr-editor>\n    </form>\n  </mat-card>\n</div>\n", styles: [".calls-history-sidesheet{background-color:#f9fbfc;height:100%;display:flex;flex-direction:column;overflow:hidden}@media screen and (max-width: 480px){.calls-history-sidesheet__tab-content{display:block}}\n"] }]
    }], () => [{ type: i6$1.PortalCallsHistory, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1.EuiLoadingService }, { type: i2.UntypedFormBuilder }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CallsHistorySidesheetComponent, { className: "CallsHistorySidesheetComponent", filePath: "lib\\calls\\calls-history-sidesheet\\calls-history-sidesheet.component.ts", lineNumber: 37 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class CallsHistoryComponent {
    sidesheet;
    translate;
    hdsApiService;
    dataSource;
    ticket;
    entitySchema;
    displayedColumns = [];
    constructor(sidesheet, translate, hdsApiService, dataSource) {
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.hdsApiService = hdsApiService;
        this.dataSource = dataSource;
        this.entitySchema = this.hdsApiService.typedClient.PortalCallsHistory.GetSchema();
    }
    async ngOnInit() {
        this.displayedColumns = [
            this.entitySchema.Columns['UID_TroubleTicket'],
            this.entitySchema.Columns['TroubleHistoryDate'],
            this.entitySchema.Columns['ObjectKeyPerson'],
            this.entitySchema.Columns['UID_TroubleCallState'],
            this.entitySchema.Columns['ObjectKeySupporter'],
        ];
        const dataViewInitParameters = {
            execute: (params, signal) => this.hdsApiService.typedClient.PortalCallsHistory.Get(this.ticket?.EntityKeysData?.Keys?.[0] || '', params),
            schema: this.entitySchema,
            columnsToDisplay: this.displayedColumns,
            highlightEntity: (identity) => {
                this.onSelected(identity);
            },
        };
        this.dataSource.init(dataViewInitParameters);
    }
    async onSelected(history) {
        if (history) {
            let title = await this.translate.get('#LDS#Heading View Change Details').toPromise();
            this.sidesheet.open(CallsHistorySidesheetComponent, {
                testId: 'calls-history-sidesheet',
                title: title,
                subTitle: history.GetEntity().GetDisplay(),
                padding: '0px',
                width: calculateSidesheetWidth(700, 0.4),
                data: history,
            });
        }
    }
    static ɵfac = function CallsHistoryComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CallsHistoryComponent)(i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2$1.TranslateService), i0.ɵɵdirectiveInject(HdsApiService), i0.ɵɵdirectiveInject(i4.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsHistoryComponent, selectors: [["imx-calls-history"]], inputs: { ticket: "ticket" }, features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 8, vars: 10, consts: [["type", "info", 3, "condensed", "colored", "dismissable"], [1, "imx-centered-filled-card"], [3, "dataSource", "showSettings"], [3, "dataSource"]], template: function CallsHistoryComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "eui-alert", 0)(1, "span");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(4, "mat-card", 1);
            i0.ɵɵelement(5, "imx-data-view-toolbar", 2)(6, "imx-data-view-auto-table", 3)(7, "imx-data-view-paginator", 3);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 8, "#LDS#Here you can get an overview of all changes to this ticket."), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("showSettings", false);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
        } }, dependencies: [i1.EuiAlertComponent, i4$1.MatCard, i4.DataViewAutoTableComponent, i4.DataViewPaginatorComponent, i4.DataViewToolbarComponent, i2$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsHistoryComponent, [{
        type: Component,
        args: [{ selector: 'imx-calls-history', providers: [DataViewSource], template: "<eui-alert type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"true\">\n  <span> {{ '#LDS#Here you can get an overview of all changes to this ticket.' | translate }} </span>\n</eui-alert>\n<mat-card class=\"imx-centered-filled-card\">\n  <imx-data-view-toolbar [dataSource]=\"dataSource\" [showSettings]=\"false\"></imx-data-view-toolbar>\n  <imx-data-view-auto-table [dataSource]=\"dataSource\"> </imx-data-view-auto-table>\n  <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n</mat-card>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}\n"] }]
    }], () => [{ type: i1.EuiSidesheetService }, { type: i2$1.TranslateService }, { type: HdsApiService }, { type: i4.DataViewSource }], { ticket: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CallsHistoryComponent, { className: "CallsHistoryComponent", filePath: "lib\\calls\\calls-history\\calls-history.component.ts", lineNumber: 42 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
var CallsAttachmentType;
(function (CallsAttachmentType) {
    CallsAttachmentType[CallsAttachmentType["folder"] = 0] = "folder";
    CallsAttachmentType[CallsAttachmentType["file"] = 1] = "file";
})(CallsAttachmentType || (CallsAttachmentType = {}));
var CallsAttachmentActionType;
(function (CallsAttachmentActionType) {
    CallsAttachmentActionType[CallsAttachmentActionType["addFolder"] = 0] = "addFolder";
    CallsAttachmentActionType[CallsAttachmentActionType["deleteFile"] = 1] = "deleteFile";
    CallsAttachmentActionType[CallsAttachmentActionType["deleteFolder"] = 2] = "deleteFolder";
})(CallsAttachmentActionType || (CallsAttachmentActionType = {}));

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function CallsAttachmentDialogComponent_ng_container_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0, 9);
    i0.ɵɵelementStart(1, "mat-form-field", 10)(2, "mat-label");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(5, "input", 11);
    i0.ɵɵelementStart(6, "mat-error");
    i0.ɵɵtext(7);
    i0.ɵɵpipe(8, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("formGroup", ctx_r0.form);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 3, "#LDS#Folder name"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 5, "#LDS#Enter a name for the folder."), " ");
} }
function CallsAttachmentDialogComponent_button_14_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 12);
    i0.ɵɵlistener("click", function CallsAttachmentDialogComponent_button_14_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.closeDialog("confirm", ctx_r0.form.controls.folderName.value)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r0.form.invalid);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Create"), " ");
} }
function CallsAttachmentDialogComponent_button_15_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 13);
    i0.ɵɵlistener("click", function CallsAttachmentDialogComponent_button_15_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.closeDialog("confirm")); });
    i0.ɵɵelement(1, "eui-icon", 14);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Yes"), " ");
} }
class CallsAttachmentDialogComponent {
    matDialogRef;
    data;
    form = new FormGroup({
        folderName: new FormControl(null, [Validators.required]),
    });
    constructor(matDialogRef, data) {
        this.matDialogRef = matDialogRef;
        this.data = data;
    }
    ngOnInit() { }
    closeDialog(action, value) {
        this.matDialogRef.close({ action, value });
    }
    get dialogTitle() {
        if (this.data.actionType === CallsAttachmentActionType.addFolder) {
            return '#LDS#Heading Create Folder';
        }
        if (this.data.actionType === CallsAttachmentActionType.deleteFile) {
            return '#LDS#Heading Delete File';
        }
        return '#LDS#Heading Delete Folder';
    }
    get dialogSubHeading() {
        switch (this.data.actionType) {
            case CallsAttachmentActionType.addFolder:
                return '#LDS#Create new folder under: {0}';
            case CallsAttachmentActionType.deleteFolder:
                return '#LDS#Are you sure you want to delete the folder "{0}"?';
            default:
                return '#LDS#Are you sure you want to delete the file "{0}"?';
        }
    }
    get isActionAddFolder() {
        return this.data.actionType === CallsAttachmentActionType.addFolder;
    }
    static ɵfac = function CallsAttachmentDialogComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CallsAttachmentDialogComponent)(i0.ɵɵdirectiveInject(i1$1.MatDialogRef), i0.ɵɵdirectiveInject(MAT_DIALOG_DATA)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsAttachmentDialogComponent, selectors: [["imx-calls-attachment-dialog"]], decls: 16, vars: 15, consts: [[1, "dialog-container"], ["mat-dialog-title", "", 1, "dialog-title"], [1, "dialog-content"], [1, "dialog-subheading"], [3, "formGroup", 4, "ngIf"], [1, "dialog-actions"], ["mat-stroked-button", "", 3, "click"], ["mat-flat-button", "", "color", "primary", 3, "disabled", "click", 4, "ngIf"], ["mat-flat-button", "", "color", "warn", 3, "click", 4, "ngIf"], [3, "formGroup"], ["appearance", "fill", 1, "imx-form-field-width-full"], ["matInput", "", "formControlName", "folderName"], ["mat-flat-button", "", "color", "primary", 3, "click", "disabled"], ["mat-flat-button", "", "color", "warn", 3, "click"], ["icon", "close", "size", "small"]], template: function CallsAttachmentDialogComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1);
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-dialog-content", 2)(5, "div", 3);
            i0.ɵɵtext(6);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵpipe(8, "ldsReplace");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(9, CallsAttachmentDialogComponent_ng_container_9_Template, 9, 7, "ng-container", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "mat-dialog-actions", 5)(11, "button", 6);
            i0.ɵɵlistener("click", function CallsAttachmentDialogComponent_Template_button_click_11_listener() { return ctx.closeDialog(); });
            i0.ɵɵtext(12);
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(14, CallsAttachmentDialogComponent_button_14_Template, 3, 4, "button", 7)(15, CallsAttachmentDialogComponent_button_15_Template, 4, 3, "button", 8);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 6, ctx.dialogTitle));
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind2(8, 10, i0.ɵɵpipeBind1(7, 8, ctx.dialogSubHeading), ctx.data.itemInfo));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.isActionAddFolder);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 13, "#LDS#Cancel"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.isActionAddFolder);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.isActionAddFolder);
        } }, dependencies: [i6.NgIf, i2.DefaultValueAccessor, i2.NgControlStatus, i2.NgControlStatusGroup, i2.FormGroupDirective, i2.FormControlName, i1.EuiIconComponent, i5.MatButton, i1$1.MatDialogTitle, i1$1.MatDialogActions, i1$1.MatDialogContent, i6$2.MatFormField, i6$2.MatLabel, i6$2.MatError, i7.MatInput, i2$1.TranslatePipe, i4.LdsReplacePipe] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsAttachmentDialogComponent, [{
        type: Component,
        args: [{ selector: 'imx-calls-attachment-dialog', template: "<div class=\"dialog-container\">\n  <h2 mat-dialog-title class=\"dialog-title\">{{ dialogTitle | translate }}</h2>\n  <mat-dialog-content class=\"dialog-content\">\n    <div class=\"dialog-subheading\">{{ dialogSubHeading | translate | ldsReplace: data.itemInfo }}</div>\n    <ng-container [formGroup]=\"form\" *ngIf=\"isActionAddFolder\">\n      <mat-form-field class=\"imx-form-field-width-full\" appearance=\"fill\">\n        <mat-label>{{ '#LDS#Folder name' | translate }}</mat-label>\n        <input matInput formControlName=\"folderName\" />\n        <mat-error>\n          {{ '#LDS#Enter a name for the folder.' | translate }}\n        </mat-error>\n      </mat-form-field>\n    </ng-container>\n  </mat-dialog-content>\n\n  <mat-dialog-actions class=\"dialog-actions\">\n    <button mat-stroked-button (click)=\"closeDialog()\">\n      {{ '#LDS#Cancel' | translate }}\n    </button>\n    <button\n      mat-flat-button\n      color=\"primary\"\n      (click)=\"closeDialog('confirm', form.controls.folderName.value)\"\n      [disabled]=\"form.invalid\"\n      *ngIf=\"isActionAddFolder\"\n    >\n      {{ '#LDS#Create' | translate }}\n    </button>\n    <button mat-flat-button color=\"warn\" (click)=\"closeDialog('confirm')\" *ngIf=\"!isActionAddFolder\">\n      <eui-icon icon=\"close\" size=\"small\"></eui-icon>\n      {{ '#LDS#Yes' | translate }}\n    </button>\n  </mat-dialog-actions>\n</div>\n" }]
    }], () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                type: Inject,
                args: [MAT_DIALOG_DATA]
            }] }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CallsAttachmentDialogComponent, { className: "CallsAttachmentDialogComponent", filePath: "lib\\calls\\calls-attachment\\calls-attachment-dialog\\calls-attachment-dialog.component.ts", lineNumber: 37 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class CallsAttachmentServiceService {
    hdsApiService;
    errorHandler;
    translator;
    constructor(hdsApiService, errorHandler, translator) {
        this.hdsApiService = hdsApiService;
        this.errorHandler = errorHandler;
        this.translator = translator;
    }
    async getInitialData(callId) {
        let initalFormatData = {
            name: 'Attachments',
            path: '',
            level: 0,
            isSelected: false,
            type: CallsAttachmentType.folder,
        };
        let initialData = await this.hdsApiService.client.portal_calls_attachments_directory_get(callId);
        initalFormatData.children = this.formatData(initialData, 1, initalFormatData);
        return initalFormatData;
    }
    async getFilesOfDirectory(callId, parent) {
        let data = await this.hdsApiService.client.portal_calls_attachments_directory_bypath_get(callId, parent.path);
        let formatData = this.formatData(data, parent.level + 1, parent);
        return formatData;
    }
    getCallsConfig() {
        return this.hdsApiService.client.portal_calls_configuration_get();
    }
    createDirectory(callId, path) {
        return this.hdsApiService.client.portal_calls_attachments_directory_bypath_post(callId, path);
    }
    deleteDirectory(callId, path) {
        return this.hdsApiService.client.portal_calls_attachments_directory_bypath_delete(callId, path);
    }
    deleteFile(callId, path) {
        return this.hdsApiService.client.portal_calls_attachments_file_delete(callId, path);
    }
    uploadFile(callId, path, file) {
        return this.hdsApiService.client.portal_calls_attachments_file_post(callId, path, file);
    }
    formatData(obj, level, parent) {
        let formattedData = [];
        obj.Directories?.map((item) => {
            formattedData.push({
                name: item.Name || '',
                children: [],
                type: CallsAttachmentType.folder,
                path: !!parent && !!parent.path ? `${parent.path}/${item.Name}` : item.Name || '',
                level: level,
                isSelected: false,
                parent: parent,
            });
        });
        obj.Files?.map((item) => {
            formattedData.push({
                name: item.Name || '',
                type: CallsAttachmentType.file,
                path: !!parent && !!parent.path ? `${parent.path}/${item.Name}` : item.Name || '',
                level: level,
                isSelected: false,
                parent: parent,
            });
        });
        return formattedData;
    }
    static ɵfac = function CallsAttachmentServiceService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CallsAttachmentServiceService)(i0.ɵɵinject(HdsApiService), i0.ɵɵinject(i0.ErrorHandler), i0.ɵɵinject(i2$1.TranslateService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: CallsAttachmentServiceService, factory: CallsAttachmentServiceService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsAttachmentServiceService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: HdsApiService }, { type: i0.ErrorHandler }, { type: i2$1.TranslateService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0 = a0 => ({ "calls-attachment__attachments-tree--hidden": a0 });
const _c1 = a0 => ({ "imx-tree-root--selected": a0 });
function CallsAttachmentComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 11);
    i0.ɵɵelement(1, "mat-spinner");
    i0.ɵɵelementEnd();
} }
function CallsAttachmentComponent_eui_alert_2_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-alert", 12);
    i0.ɵɵlistener("dismissed", function CallsAttachmentComponent_eui_alert_2_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onAlertDismissed()); });
    i0.ɵɵelementStart(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("colored", true)("dismissable", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 3, ctx_r2.alertText));
} }
function CallsAttachmentComponent_div_4_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "button", 16);
    i0.ɵɵlistener("click", function CallsAttachmentComponent_div_4_ng_container_2_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r4); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.onAddFolder(ctx_r2.selectedNode)); });
    i0.ɵɵelement(2, "eui-icon", 17);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "button", 16);
    i0.ɵɵlistener("click", function CallsAttachmentComponent_div_4_ng_container_2_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r4); const fileInput_r5 = i0.ɵɵreference(10); return i0.ɵɵresetView(fileInput_r5.click()); });
    i0.ɵɵelement(6, "eui-icon", 18);
    i0.ɵɵtext(7);
    i0.ɵɵpipe(8, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(9, "input", 19, 3);
    i0.ɵɵlistener("change", function CallsAttachmentComponent_div_4_ng_container_2_Template_input_change_9_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.attachFile($event.target)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 3, "#LDS#Create folder"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 5, "#LDS#Attach file"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r2.isNodeTypeFolder(ctx_r2.selectedNode));
} }
function CallsAttachmentComponent_div_4_ng_template_3_button_4_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 16);
    i0.ɵɵlistener("click", function CallsAttachmentComponent_div_4_ng_template_3_button_4_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r6); const ctx_r2 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r2.downloadFile(ctx_r2.selectedNode)); });
    i0.ɵɵelement(1, "eui-icon", 23);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Download selected file"), " ");
} }
function CallsAttachmentComponent_div_4_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "button", 20);
    i0.ɵɵelement(1, "eui-icon", 21);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, CallsAttachmentComponent_div_4_ng_template_3_button_4_Template, 4, 3, "button", 22);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("disabled", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 3, "#LDS#Create folder"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.selectedNode);
} }
function CallsAttachmentComponent_div_4_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "button", 24);
    i0.ɵɵlistener("click", function CallsAttachmentComponent_div_4_ng_container_5_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r7); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.onDeleteItem(ctx_r2.selectedNode)); });
    i0.ɵɵelement(2, "eui-icon", 25);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(4, 1, "#LDS#Delete selected item"), " ");
} }
function CallsAttachmentComponent_div_4_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "button", 26);
    i0.ɵɵelement(1, "eui-icon", 27);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("disabled", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(3, 2, "#LDS#Delete selected item"), " ");
} }
function CallsAttachmentComponent_div_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 13)(1, "div", 14);
    i0.ɵɵtemplate(2, CallsAttachmentComponent_div_4_ng_container_2_Template, 11, 7, "ng-container", 15)(3, CallsAttachmentComponent_div_4_ng_template_3_Template, 5, 5, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(5, CallsAttachmentComponent_div_4_ng_container_5_Template, 5, 3, "ng-container", 15)(6, CallsAttachmentComponent_div_4_ng_template_6_Template, 4, 4, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const fileNode_r8 = i0.ɵɵreference(4);
    const deleteDisabled_r9 = i0.ɵɵreference(7);
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.isNodeTypeFolder(ctx_r2.selectedNode))("ngIfElse", fileNode_r8);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r2.isNodeDeletable(ctx_r2.selectedNode))("ngIfElse", deleteDisabled_r9);
} }
function CallsAttachmentComponent_ng_template_7_div_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 29)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r9 = i0.ɵɵnextContext();
    const node_r11 = ctx_r9.$implicit;
    const selected_r12 = ctx_r9.selected;
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(2, _c1, selected_r12));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(node_r11.name);
} }
function CallsAttachmentComponent_ng_template_7_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 29);
    i0.ɵɵelement(1, "eui-icon", 30);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r9 = i0.ɵɵnextContext();
    const node_r11 = ctx_r9.$implicit;
    const selected_r12 = ctx_r9.selected;
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(4, _c1, selected_r12));
    i0.ɵɵadvance();
    i0.ɵɵclassMap(selected_r12 ? "imx-icon-warning" : "imx-icon-info");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(node_r11.name);
} }
function CallsAttachmentComponent_ng_template_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, CallsAttachmentComponent_ng_template_7_div_0_Template, 3, 4, "div", 28)(1, CallsAttachmentComponent_ng_template_7_div_1_Template, 4, 6, "div", 28);
} if (rf & 2) {
    const node_r11 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngIf", !ctx_r2.isNodeTypeFolder(node_r11));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.isNodeTypeFolder(node_r11));
} }
function CallsAttachmentComponent_div_9_div_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 36)(1, "ul")(2, "li");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "li");
    i0.ɵɵtext(6);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "li");
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "translate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 4, "#LDS#Here you can attach files to this ticket."));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(7, 6, "#LDS#Optionally, you can create folders and add files to these folders."));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate2("", i0.ɵɵpipeBind1(10, 8, "#LDS#The maximum file size is:"), " ", ctx_r2.convertedMaxAttachmentSize, "");
} }
function CallsAttachmentComponent_div_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 31)(1, "div", 32);
    i0.ɵɵelement(2, "eui-icon", 33);
    i0.ɵɵelementStart(3, "div")(4, "h2", 34);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()()();
    i0.ɵɵtemplate(7, CallsAttachmentComponent_div_9_div_7_Template, 11, 10, "div", 35);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 2, "#LDS#Upload file attachments"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.hasMaxAttachmentSize);
} }
class CallsAttachmentComponent {
    attachmentService;
    dialog;
    config;
    http;
    injector;
    overlay;
    elementalUiConfigService;
    translator;
    errorHandler;
    ldsReplace;
    downloadService;
    callId = '';
    // Set FlatTreeControl node order and node expendable
    treeControl = new FlatTreeControl((node) => node.level, (node) => node.type === CallsAttachmentType.folder);
    attachmentTreeData;
    selectedNode = null;
    showAlert = false;
    overlayRef;
    alertText = '';
    apiControls;
    dynamicDataSource;
    loadingOverlay = false;
    callsConfig;
    hasMaxAttachmentSize;
    convertedMaxAttachmentSize;
    noResultText = '#LDS#There are no attachments.';
    initialized;
    constructor(attachmentService, dialog, config, 
    // File download directive needs HttpClient, Injector, Overlay, ElementalUiConfigService
    http, injector, overlay, elementalUiConfigService, translator, errorHandler, ldsReplace, downloadService) {
        this.attachmentService = attachmentService;
        this.dialog = dialog;
        this.config = config;
        this.http = http;
        this.injector = injector;
        this.overlay = overlay;
        this.elementalUiConfigService = elementalUiConfigService;
        this.translator = translator;
        this.errorHandler = errorHandler;
        this.ldsReplace = ldsReplace;
        this.downloadService = downloadService;
    }
    // Setup apiControls and dynamicDataSource and get initial attachment tree data
    async ngOnInit() {
        this.apiControls = {
            setup: async () => {
                try {
                    const rootNode = await this.attachmentService.getInitialData(this.callId);
                    this.attachmentTreeData = rootNode;
                    this.initialized = true;
                    return { rootNode };
                }
                catch {
                    this.initialized = false;
                    throw new Error(this.translator.instant('#LDS#The attachments folder could not be found.'));
                }
            },
            getChildren: async (node, onlyCheck = true) => {
                try {
                    if (node.children && node.children.length > 0 && onlyCheck) {
                        return node.children;
                    }
                    node.isLoading = true;
                    node.children = await this.attachmentService.getFilesOfDirectory(this.callId, node);
                }
                finally {
                    node.isLoading = false;
                }
                return node.children;
            },
            changeSelection: (data) => data,
        };
        this.dynamicDataSource = new DynamicDataSource(this.treeControl, this.apiControls);
        this.callsConfig = await this.attachmentService.getCallsConfig();
        this.hasMaxAttachmentSize = this.callsConfig.AttachmentMaxSize > 0;
        if (this.hasMaxAttachmentSize)
            this.convertedMaxAttachmentSize = await this.byteConverter(this.callsConfig.AttachmentMaxSize);
        try {
            this.changeLoadingOverlayStatus(true);
            await this.dynamicDataSource.setup(true);
        }
        finally {
            this.changeLoadingOverlayStatus(false);
        }
    }
    // Open attachment dialog and call createFolder action
    async onAddFolder(node) {
        this.dialog
            .open(CallsAttachmentDialogComponent, {
            data: {
                actionType: CallsAttachmentActionType.addFolder,
                itemInfo: node && node?.path.length ? node.path : await this.translator.get('#LDS#Root folder').toPromise(),
            },
        })
            .afterClosed()
            .subscribe((dialogResult) => {
            if (!!dialogResult && !!dialogResult.action && !!dialogResult.value) {
                this.createFolder(dialogResult.value, node || undefined);
            }
        });
    }
    onDeleteItem(node) {
        if (!!node) {
            if (node.type === CallsAttachmentType.file) {
                this.openDeleteFileDialog(node);
            }
            else {
                this.openDeleteFolderDialog(node);
            }
        }
    }
    // Open attachment dialog and call deleteFile action
    openDeleteFileDialog(node) {
        this.dialog
            .open(CallsAttachmentDialogComponent, {
            data: {
                actionType: CallsAttachmentActionType.deleteFile,
                itemInfo: node.name,
            },
        })
            .afterClosed()
            .subscribe((dialogResult) => {
            if (!!dialogResult?.action) {
                this.deleteFile(node);
            }
        });
    }
    /**
     * Check the selected folder has any child elements.
     * If it is empty open confirmation dialog and call deleteFolder action
     * @param node Selected node
     */
    async openDeleteFolderDialog(node) {
        if (!node.children || node.children.length == 0) {
            const children = await this.attachmentService.getFilesOfDirectory(this.callId, node);
            if (children.length > 0) {
                this.errorHandler.handleError(this.translator.instant('#LDS#You cannot delete the folder. The folder is not empty. First delete the contents of the folder and try again.'));
                return;
            }
        }
        this.dialog
            .open(CallsAttachmentDialogComponent, {
            data: {
                actionType: CallsAttachmentActionType.deleteFolder,
                itemInfo: node.name,
            },
        })
            .afterClosed()
            .subscribe((dialogResult) => {
            if (!!dialogResult?.action) {
                this.deleteFolder(node);
            }
        });
    }
    // Attaching a file inside a folder or at parent level
    async attachFile(event) {
        const val = event?.files;
        if (!val) {
            return;
        }
        this.changeLoadingOverlayStatus(true);
        const fileToUpload = val[0];
        const fileExtension = fileToUpload?.name.split('.').pop();
        try {
            if (fileToUpload && this.callsConfig.AttachmentFileTypes?.includes(`.${fileExtension}`)) {
                const obj = { name: fileToUpload?.name, type: CallsAttachmentType.file, path: '', file: fileToUpload };
                const blob = new Blob([fileToUpload], { type: fileToUpload.type });
                if (this.hasMaxAttachmentSize && fileToUpload.size > this.callsConfig?.AttachmentMaxSize) {
                    throw new Error(this.ldsReplace.transform(await this.translator
                        .get('#LDS#You cannot upload the file. The file is too big. You can upload files up to {0}.')
                        .toPromise(), this.convertedMaxAttachmentSize));
                }
                //when attaching inside a parent
                if (this.selectedNode) {
                    obj.path = this.selectedNode.path + '/' + fileToUpload.name;
                    fileToUpload && this.uploadFile(obj.path, blob, this.selectedNode);
                    //when attaching it at root level
                }
                else {
                    obj.path = fileToUpload.name;
                    fileToUpload && this.uploadFile(obj.path, blob, this.attachmentTreeData);
                }
            }
            else {
                throw new Error(this.ldsReplace.transform(await this.translator
                    .get('#LDS#You cannot upload the file. The maximum number of files has been reached. You can attach a total of {0} files.')
                    .toPromise(), this.callsConfig.AttachmentFileTypes?.join(', ')));
            }
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        finally {
            this.changeLoadingOverlayStatus(false);
        }
    }
    // Setup download directive and download file
    async downloadFile(node) {
        const def = new MethodDefinition(new V2ApiClientMethodFactory().portal_calls_attachments_file_get(this.callId, node.path));
        const directive = new EuiDownloadDirective(new ElementRef('') /* no element */, this.http, this.overlay, this.injector, this.downloadService);
        directive.downloadOptions = {
            ...this.elementalUiConfigService.Config.downloadOptions,
            fileMimeType: '',
            url: this.config.BaseUrl + def.path,
            disableElement: false,
            fileName: node.name,
        };
        directive.onClick();
    }
    onNodeSelection(node) {
        this.attachmentTreeData.isSelected = false;
        this.updateSelectionState(this.attachmentTreeData.children || []);
        if (this.selectedNode == node) {
            this.selectedNode = null;
        }
        else {
            this.selectedNode = node;
            node.isSelected = !node.isSelected;
        }
    }
    updateSelectionState(data) {
        data.forEach((element) => {
            element.isSelected = false;
            if (element.children)
                this.updateSelectionState(element.children);
        });
    }
    isDuplicateName(name, node) {
        let element = node.find((element) => name == element.name);
        let elementFound = element ? true : false;
        return elementFound;
    }
    hasChild(_, node) {
        return !!node.children ? node.children?.length > 0 : false;
    }
    onAlertDismissed() {
        this.showAlert = false;
        this.alertText = '';
    }
    // Attach file is only available in folder node
    isNodeTypeFolder(node) {
        return node?.type === CallsAttachmentType.folder || !node;
    }
    // If isLoading return true the progressbar next to the node will shown
    isLoading(node) {
        return !!node.isLoading;
    }
    // Only empty folders and files can be deleted
    isNodeDeletable(node) {
        return this.isNodeFolderEmpty(node) || this.isNodeFile(node);
    }
    // Show information instead of attachment file tree
    get showInformation() {
        return this.attachmentTreeData?.children?.length === 0;
    }
    async uploadFile(path, blob, node) {
        try {
            await this.attachmentService.uploadFile(this.callId, path, blob);
            await this.apiControls.getChildren(node, false);
            this.expandNode(node);
        }
        catch {
            this.errorHandler.handleError(this.translator.instant('#LDS#You cannot upload the file. You do not have permission to upload files.'));
        }
    }
    async byteConverter(byte) {
        if (byte >= 1073741824)
            return this.ldsReplace.transform(await this.translator.get('#LDS#{0} GB').toPromise(), this.getFlooredFixed(byte / Math.pow(1024, 3)));
        else if (byte >= 1048576)
            return this.ldsReplace.transform(await this.translator.get('#LDS#{0} MB').toPromise(), this.getFlooredFixed(byte / Math.pow(1024, 2)));
        else if (byte >= 1024)
            return this.ldsReplace.transform(await this.translator.get('#LDS#{0} kB').toPromise(), this.getFlooredFixed(byte / Math.pow(1024, 1)));
        else
            return this.ldsReplace.transform(await this.translator.get('#LDS#{0} byte').toPromise(), byte);
    }
    getFlooredFixed(value, fractionDigits = 2) {
        return (Math.floor(value * Math.pow(10, fractionDigits)) / Math.pow(10, fractionDigits)).toFixed(fractionDigits);
    }
    isNodeFolderEmpty(node) {
        return !!node && node.type === CallsAttachmentType.folder && (!node.children || node.children.length === 0);
    }
    isNodeFile(node) {
        return !!node && node.type === CallsAttachmentType.file;
    }
    async deleteFolder(node) {
        try {
            this.changeLoadingOverlayStatus(true);
            const parent = node.parent;
            await this.attachmentService.deleteDirectory(this.callId, node.path);
            if (parent) {
                await this.apiControls.getChildren(parent, false);
                this.expandNode(parent);
            }
            else {
                this.attachmentTreeData.children = this.attachmentTreeData.children?.filter((childNode) => childNode.name !== node.name);
                this.expandNode(this.attachmentTreeData);
            }
        }
        catch {
            this.errorHandler.handleError(this.translator.instant('#LDS#You cannot delete the folder. You do not have permission to delete folders.'));
        }
        finally {
            this.changeLoadingOverlayStatus(false);
            this.selectedNode = null;
        }
    }
    async deleteFile(node) {
        try {
            this.changeLoadingOverlayStatus(true);
            await this.attachmentService.deleteFile(this.callId, node.path);
            if (node.parent) {
                await this.apiControls.getChildren(node.parent, false);
                this.expandNode(node.parent);
            }
            this.selectedNode = null;
        }
        catch {
            this.errorHandler.handleError(this.translator.instant('#LDS#You cannot delete the attachment. You do not have permission to delete attachments.'));
        }
        finally {
            this.changeLoadingOverlayStatus(false);
        }
    }
    async createFolder(val, node) {
        if (val) {
            let obj = {
                name: val,
                children: [],
                type: CallsAttachmentType.folder,
                path: '',
                level: 1,
                isSelected: false,
                parent: node,
            };
            if (node) {
                if (this.isDuplicateName(val, node.children)) {
                    this.showAlertMessage('#LDS#You cannot create the folder. A folder with the entered name already exists. Enter a different folder name.');
                }
                else {
                    obj.path = node.path + '/' + val;
                    obj.level = node.level + 1;
                    await this.apiControls.getChildren(node);
                    await this.attachmentService.createDirectory(this.callId, obj.path);
                    node.children?.unshift(obj);
                    this.expandNode(node);
                }
            }
            else {
                if (this.isDuplicateName(val, this.attachmentTreeData.children)) {
                    this.showAlertMessage('#LDS#You cannot create the folder. A folder with the entered name already exists. Enter a different folder name.');
                }
                else {
                    obj.path = `${val}`;
                    await this.attachmentService.createDirectory(this.callId, obj.path);
                    this.attachmentTreeData.children?.unshift(obj);
                    this.expandNode(this.attachmentTreeData);
                }
            }
        }
    }
    expandNode(node) {
        this.treeControl.collapse(node);
        this.treeControl.expand(node);
    }
    showAlertMessage(error) {
        this.alertText = error;
        this.showAlert = true;
    }
    changeLoadingOverlayStatus(status) {
        this.loadingOverlay = status;
    }
    static ɵfac = function CallsAttachmentComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CallsAttachmentComponent)(i0.ɵɵdirectiveInject(CallsAttachmentServiceService), i0.ɵɵdirectiveInject(i1$1.MatDialog), i0.ɵɵdirectiveInject(i4.AppConfigService), i0.ɵɵdirectiveInject(i4$2.HttpClient), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i5$1.Overlay), i0.ɵɵdirectiveInject(i4.ElementalUiConfigService), i0.ɵɵdirectiveInject(i2$1.TranslateService), i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i4.LdsReplacePipe), i0.ɵɵdirectiveInject(i1.EuiDownloadService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsAttachmentComponent, selectors: [["imx-calls-attachment"]], inputs: { callId: "callId" }, decls: 10, vars: 17, consts: [["nodeContent", ""], ["fileNode", ""], ["deleteDisabled", ""], ["fileInput", ""], [1, "calls-attachment"], ["class", "loading-overlay", 4, "ngIf"], ["type", "warning", 3, "colored", "dismissable", "dismissed", 4, "ngIf"], ["class", "imx-button-bar-transparent", 4, "ngIf"], [1, "calls-attachment__attachments-tree", 3, "ngClass"], [3, "selectedNode", "dynamicDataSource", "treeControl", "nodeContent", "hasChild", "isLoading", "expandWidth", "sideNavExpanded", "manageExpandedExternally", "showSidenavHeader", "noResultText"], ["class", "calls-attachment__information", 4, "ngIf"], [1, "loading-overlay"], ["type", "warning", 3, "dismissed", "colored", "dismissable"], [1, "imx-button-bar-transparent"], [1, "justify-start"], [4, "ngIf", "ngIfElse"], ["mat-button", "", "color", "primary", 1, "imx-button-icon-20", 3, "click"], ["icon", "folder", 1, "imx-icon-info"], ["icon", "add", "for", "root-file", 1, "imx-icon-info"], ["type", "file", "id", "root-file", 1, "imx-hidden", 3, "change", "disabled"], ["mat-button", "", "color", "primary", 1, "imx-button-icon-20", 3, "disabled"], ["icon", "folder", 1, "imx-icon-disabled"], ["mat-button", "", "class", "imx-button-icon-20", "color", "primary", 3, "click", 4, "ngIf"], ["icon", "download", 1, "imx-icon-info"], ["mat-button", "", "color", "warn", 1, "imx-button-icon-20", 3, "click"], ["icon", "delete", 1, "imx-icon-error"], ["mat-button", "", "color", "warn", 1, "imx-button-icon-20", 3, "disabled"], ["icon", "delete", 1, "imx-icon-disabled"], ["class", "imx-tree-root", 3, "ngClass", 4, "ngIf"], [1, "imx-tree-root", 3, "ngClass"], ["icon", "folder"], [1, "calls-attachment__information"], [1, "static-text"], ["icon", "upload", 1, "imx-icon-upload"], [1, "strong"], ["class", "file-size", 4, "ngIf"], [1, "file-size"]], template: function CallsAttachmentComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 4);
            i0.ɵɵtemplate(1, CallsAttachmentComponent_div_1_Template, 2, 0, "div", 5)(2, CallsAttachmentComponent_eui_alert_2_Template, 4, 5, "eui-alert", 6);
            i0.ɵɵelementStart(3, "mat-card");
            i0.ɵɵtemplate(4, CallsAttachmentComponent_div_4_Template, 8, 4, "div", 7);
            i0.ɵɵelementStart(5, "div", 8)(6, "imx-sidenav-tree", 9);
            i0.ɵɵlistener("selectedNode", function CallsAttachmentComponent_Template_imx_sidenav_tree_selectedNode_6_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onNodeSelection($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, CallsAttachmentComponent_ng_template_7_Template, 2, 2, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(9, CallsAttachmentComponent_div_9_Template, 8, 4, "div", 10);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            const nodeContent_r13 = i0.ɵɵreference(8);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.loadingOverlay);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showAlert);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.initialized);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(15, _c0, ctx.showInformation));
            i0.ɵɵadvance();
            i0.ɵɵproperty("dynamicDataSource", ctx.dynamicDataSource)("treeControl", ctx.treeControl)("nodeContent", nodeContent_r13)("hasChild", ctx.hasChild)("isLoading", ctx.isLoading)("expandWidth", "100%")("sideNavExpanded", true)("manageExpandedExternally", true)("showSidenavHeader", false)("noResultText", ctx.noResultText);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.showInformation);
        } }, dependencies: [i6.NgClass, i6.NgIf, i1.EuiAlertComponent, i1.EuiIconComponent, i5.MatButton, i4$1.MatCard, i11.MatProgressSpinner, i4.SidenavTreeComponent, i2$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.calls-attachment[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%;position:relative;gap:20px}.calls-attachment[_ngcontent-%COMP%]   .mat-mdc-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%;gap:10px;border:1px solid rgba(0,0,0,.12);margin:3px}.calls-attachment__information[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%;justify-content:center;background-color:#f2fcff;border:1px solid #cbe8f2;border-radius:4px;gap:20px}.calls-attachment__information[_ngcontent-%COMP%]   .static-text[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;color:#8acbe3;opacity:.6;gap:20px}.calls-attachment__information[_ngcontent-%COMP%]   .static-text[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{width:310px;font-size:48px;font-weight:700}.calls-attachment__information[_ngcontent-%COMP%]   .file-size[_ngcontent-%COMP%]{display:flex;justify-content:center;color:#0a96d1;font-size:14px}.calls-attachment__information[_ngcontent-%COMP%]   .file-size[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{list-style:disc}.calls-attachment__attachments-tree[_ngcontent-%COMP%]{height:100%}.calls-attachment__attachments-tree--hidden[_ngcontent-%COMP%]{display:none}.calls-attachment[_ngcontent-%COMP%]   .strong[_ngcontent-%COMP%]{font-weight:600}.calls-attachment[_ngcontent-%COMP%]   .loading-overlay[_ngcontent-%COMP%]{position:absolute;z-index:999;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#00000052}[_nghost-%COMP%]   .imx-tree-root[_ngcontent-%COMP%] > eui-icon[_ngcontent-%COMP%]{margin-right:10px}.eui-dark-theme   [_nghost-%COMP%]   .calls-attachment__information[_ngcontent-%COMP%]{background-color:#00384d;border:1px solid #016b91}.eui-dark-theme   [_nghost-%COMP%]   .calls-attachment__information[_ngcontent-%COMP%]   .file-size[_ngcontent-%COMP%], .eui-dark-theme   [_nghost-%COMP%]   .calls-attachment__information[_ngcontent-%COMP%]   .static-text[_ngcontent-%COMP%]{color:#fff}.eui-dark-theme   [_nghost-%COMP%]   .calls-attachment__new-folder[_ngcontent-%COMP%]   .mat-primary[_ngcontent-%COMP%]{color:#fff}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsAttachmentComponent, [{
        type: Component,
        args: [{ selector: 'imx-calls-attachment', template: "<div class=\"calls-attachment\">\n  <div class=\"loading-overlay\" *ngIf=\"loadingOverlay\">\n    <mat-spinner></mat-spinner>\n  </div>\n  <eui-alert type=\"warning\" [colored]=\"true\" *ngIf=\"showAlert\" [dismissable]=\"true\" (dismissed)=\"onAlertDismissed()\">\n    <span>{{ alertText | translate }}</span>\n  </eui-alert>\n  <mat-card>\n    <div class=\"imx-button-bar-transparent\" *ngIf=\"initialized\">\n      <div class=\"justify-start\">\n        <ng-container *ngIf=\"isNodeTypeFolder(selectedNode); else fileNode\">\n          <button mat-button class=\"imx-button-icon-20\" color=\"primary\" (click)=\"onAddFolder(selectedNode)\">\n            <eui-icon class=\"imx-icon-info\" icon=\"folder\"></eui-icon>\n            {{ '#LDS#Create folder' | translate }}\n          </button>\n          <button mat-button class=\"imx-button-icon-20\" color=\"primary\" (click)=\"fileInput.click()\">\n            <eui-icon class=\"imx-icon-info\" icon=\"add\" for=\"root-file\"></eui-icon>\n            {{ '#LDS#Attach file' | translate }}\n          </button>\n          <input\n            class=\"imx-hidden\"\n            type=\"file\"\n            id=\"root-file\"\n            (change)=\"attachFile($event.target)\"\n            [disabled]=\"!isNodeTypeFolder(selectedNode)\"\n            #fileInput\n          />\n        </ng-container>\n        <ng-template #fileNode>\n          <button mat-button class=\"imx-button-icon-20\" color=\"primary\" [disabled]=\"true\">\n            <eui-icon class=\"imx-icon-disabled\" icon=\"folder\"></eui-icon>\n            {{ '#LDS#Create folder' | translate }}\n          </button>\n          <button mat-button class=\"imx-button-icon-20\" color=\"primary\" (click)=\"downloadFile(selectedNode)\" *ngIf=\"selectedNode\">\n            <eui-icon class=\"imx-icon-info\" icon=\"download\"></eui-icon>\n            {{ '#LDS#Download selected file' | translate }}\n          </button>\n        </ng-template>\n      </div>\n      <ng-container *ngIf=\"isNodeDeletable(selectedNode); else deleteDisabled\">\n        <button mat-button class=\"imx-button-icon-20\" color=\"warn\" (click)=\"onDeleteItem(selectedNode)\">\n          <eui-icon class=\"imx-icon-error\" icon=\"delete\"></eui-icon>{{ '#LDS#Delete selected item' | translate }}\n        </button>\n      </ng-container>\n      <ng-template #deleteDisabled>\n        <button mat-button class=\"imx-button-icon-20\" color=\"warn\" [disabled]=\"true\">\n          <eui-icon class=\"imx-icon-disabled\" icon=\"delete\"></eui-icon>{{ '#LDS#Delete selected item' | translate }}\n        </button>\n      </ng-template>\n    </div>\n    <div class=\"calls-attachment__attachments-tree\" [ngClass]=\"{ 'calls-attachment__attachments-tree--hidden': showInformation }\">\n      <imx-sidenav-tree\n        [dynamicDataSource]=\"dynamicDataSource\"\n        [treeControl]=\"treeControl\"\n        [nodeContent]=\"nodeContent\"\n        [hasChild]=\"hasChild\"\n        [isLoading]=\"isLoading\"\n        [expandWidth]=\"'100%'\"\n        [sideNavExpanded]=\"true\"\n        [manageExpandedExternally]=\"true\"\n        [showSidenavHeader]=\"false\"\n        (selectedNode)=\"onNodeSelection($event)\"\n        [noResultText]=\"noResultText\"\n      ></imx-sidenav-tree>\n      <ng-template #nodeContent let-node let-selected=\"selected\">\n        <div class=\"imx-tree-root\" [ngClass]=\"{ 'imx-tree-root--selected': selected }\" *ngIf=\"!isNodeTypeFolder(node)\">\n          <span>{{ node.name }}</span>\n        </div>\n        <div class=\"imx-tree-root\" [ngClass]=\"{ 'imx-tree-root--selected': selected }\" *ngIf=\"isNodeTypeFolder(node)\">\n          <eui-icon [class]=\"selected ? 'imx-icon-warning' : 'imx-icon-info'\" icon=\"folder\"></eui-icon>\n          <span>{{ node.name }}</span>\n        </div>\n      </ng-template>\n    </div>\n    <div class=\"calls-attachment__information\" *ngIf=\"showInformation\">\n      <div class=\"static-text\">\n        <eui-icon class=\"imx-icon-upload\" icon=\"upload\"></eui-icon>\n        <div>\n          <h2 class=\"strong\">{{ '#LDS#Upload file attachments' | translate }}</h2>\n        </div>\n      </div>\n      <div class=\"file-size\" *ngIf=\"hasMaxAttachmentSize\">\n        <ul>\n          <li>{{ '#LDS#Here you can attach files to this ticket.' | translate }}</li>\n          <li>{{ '#LDS#Optionally, you can create folders and add files to these folders.' | translate }}</li>\n          <li>{{ '#LDS#The maximum file size is:' | translate }} {{ convertedMaxAttachmentSize }}</li>\n        </ul>\n      </div>\n    </div>\n  </mat-card>\n</div>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.calls-attachment{display:flex;flex-direction:column;height:100%;position:relative;gap:20px}.calls-attachment .mat-mdc-card{display:flex;flex-direction:column;height:100%;gap:10px;border:1px solid rgba(0,0,0,.12);margin:3px}.calls-attachment__information{display:flex;flex-direction:column;height:100%;justify-content:center;background-color:#f2fcff;border:1px solid #cbe8f2;border-radius:4px;gap:20px}.calls-attachment__information .static-text{display:flex;align-items:center;justify-content:center;color:#8acbe3;opacity:.6;gap:20px}.calls-attachment__information .static-text h2{width:310px;font-size:48px;font-weight:700}.calls-attachment__information .file-size{display:flex;justify-content:center;color:#0a96d1;font-size:14px}.calls-attachment__information .file-size li{list-style:disc}.calls-attachment__attachments-tree{height:100%}.calls-attachment__attachments-tree--hidden{display:none}.calls-attachment .strong{font-weight:600}.calls-attachment .loading-overlay{position:absolute;z-index:999;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#00000052}:host .imx-tree-root>eui-icon{margin-right:10px}.eui-dark-theme :host .calls-attachment__information{background-color:#00384d;border:1px solid #016b91}.eui-dark-theme :host .calls-attachment__information .file-size,.eui-dark-theme :host .calls-attachment__information .static-text{color:#fff}.eui-dark-theme :host .calls-attachment__new-folder .mat-primary{color:#fff}\n"] }]
    }], () => [{ type: CallsAttachmentServiceService }, { type: i1$1.MatDialog }, { type: i4.AppConfigService }, { type: i4$2.HttpClient }, { type: i0.Injector }, { type: i5$1.Overlay }, { type: i4.ElementalUiConfigService }, { type: i2$1.TranslateService }, { type: i0.ErrorHandler }, { type: i4.LdsReplacePipe }, { type: i1.EuiDownloadService }], { callId: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CallsAttachmentComponent, { className: "CallsAttachmentComponent", filePath: "lib\\calls\\calls-attachment\\calls-attachment.component.ts", lineNumber: 53 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function CallsSidesheetComponent_imx_help_contextual_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-help-contextual", 11);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("contextId", ctx_r0.contextId)("title", "#LDS#Information about this tab:");
} }
function CallsSidesheetComponent_imx_cdr_editor_8_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 12);
    i0.ɵɵlistener("controlCreated", function CallsSidesheetComponent_imx_cdr_editor_8_Template_imx_cdr_editor_controlCreated_0_listener($event) { const cdr_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.detailsFormGroup.addControl(cdr_r3.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r3);
} }
function CallsSidesheetComponent_span_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 13);
    i0.ɵɵtext(1, "#LDS#Create");
    i0.ɵɵelementEnd();
} }
function CallsSidesheetComponent_span_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 13);
    i0.ɵɵtext(1, "#LDS#Save");
    i0.ɵɵelementEnd();
} }
function CallsSidesheetComponent_mat_tab_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab", 2);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵelementStart(2, "div", 14);
    i0.ɵɵelement(3, "imx-calls-history", 15);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 2, "#LDS#Heading History"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ticket", ctx_r0.ticket);
} }
function CallsSidesheetComponent_mat_tab_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab", 2);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵelementStart(2, "div", 16);
    i0.ɵɵelement(3, "imx-calls-attachment", 17);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 2, "#LDS#Heading Attachments"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("callId", ctx_r0.getTicketId);
} }
class CallsSidesheetComponent {
    sidesheetData;
    errorHandler;
    sidesheetRef;
    snackBarService;
    euiLoadingService;
    projectConfigurationService;
    formBuilder;
    confirmationService;
    hdsApiService;
    detailsFormGroup;
    cdrList = [];
    ticket;
    contextId = HELP_CONTEXTUAL.HelpDeskSupportTicketsEdit;
    constructor(sidesheetData, errorHandler, sidesheetRef, snackBarService, euiLoadingService, projectConfigurationService, formBuilder, confirmationService, hdsApiService) {
        this.sidesheetData = sidesheetData;
        this.errorHandler = errorHandler;
        this.sidesheetRef = sidesheetRef;
        this.snackBarService = snackBarService;
        this.euiLoadingService = euiLoadingService;
        this.projectConfigurationService = projectConfigurationService;
        this.formBuilder = formBuilder;
        this.confirmationService = confirmationService;
        this.hdsApiService = hdsApiService;
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.sidesheetRef.closeClicked().subscribe(async () => {
            if (!this.detailsFormGroup.dirty || (await this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close();
            }
        });
    }
    async ngOnInit() {
        await this.setup();
    }
    async setup() {
        this.ticket = this.sidesheetData.ticket;
        let entity = this.sidesheetData.ticket.GetEntity();
        let columnNames = await this.getColumnNames();
        columnNames.forEach((columnName) => {
            let column = entity.GetColumn(columnName);
            if (column)
                this.cdrList.push(new BaseCdr(column));
        });
    }
    async getColumnNames() {
        let columnNames = [];
        let overlayRef = this.euiLoadingService.show();
        try {
            let config = await this.projectConfigurationService.getConfig();
            if (this.sidesheetData.isNew)
                columnNames = config.OwnershipConfig?.PrimaryFields?.['TroubleTicket'] || [];
            else
                columnNames = config.OwnershipConfig?.EditableFields?.['TroubleTicket'] || [];
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        finally {
            this.euiLoadingService.hide(overlayRef);
        }
        return columnNames;
    }
    async save() {
        if (this.detailsFormGroup.valid) {
            let overlayRef = this.euiLoadingService.show();
            try {
                await this.sidesheetData.ticket
                    .GetEntity()
                    .Commit(true)
                    .then(() => {
                    this.detailsFormGroup.markAsPristine();
                    this.sidesheetRef.close();
                    let textContainer;
                    if (this.sidesheetData.isNew)
                        textContainer = {
                            key: '#LDS#The ticket with the number {0} has been successfully created.',
                            parameters: [this.sidesheetData.ticket.CallNumber.value.toString()],
                        };
                    else
                        textContainer = {
                            key: '#LDS#The ticket has been successfully saved.',
                            parameters: [this.sidesheetData.ticket.CallNumber.value.toString()],
                        };
                    this.snackBarService.open(textContainer, '#LDS#Close', { duration: 6000 });
                });
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                this.euiLoadingService.hide(overlayRef);
            }
        }
    }
    cancel() {
        this.sidesheetRef.close();
    }
    get getTicketId() {
        return !!this.sidesheetData.ticket.EntityKeysData.Keys ? this.sidesheetData.ticket.EntityKeysData.Keys[0] : '';
    }
    static ɵfac = function CallsSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CallsSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i4.SnackBarService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i3.ProjectConfigurationService), i0.ɵɵdirectiveInject(i2.UntypedFormBuilder), i0.ɵɵdirectiveInject(i4.ConfirmationService), i0.ɵɵdirectiveInject(HdsApiService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsSidesheetComponent, selectors: [["imx-calls-sidesheet"]], decls: 15, vars: 12, consts: [[1, "calls-sidesheet"], ["mat-stretch-tabs", "false"], [3, "label"], ["eui-sidesheet-content", "", 3, "ngClass"], [3, "contextId", "title", 4, "ngIf"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["data-imx-identifier", "create-ticket-button", "mat-flat-button", "", "color", "primary", 3, "click", "disabled"], ["translate", "", 4, "ngIf"], [3, "label", 4, "ngIf"], [3, "contextId", "title"], [3, "controlCreated", "cdr"], ["translate", ""], ["eui-sidesheet-content", ""], [3, "ticket"], ["eui-sidesheet-content", "", 1, "imx-tab-content"], [3, "callId"]], template: function CallsSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-tab-group", 1)(2, "mat-tab", 2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementStart(4, "div", 3);
            i0.ɵɵtemplate(5, CallsSidesheetComponent_imx_help_contextual_5_Template, 1, 2, "imx-help-contextual", 4);
            i0.ɵɵelementStart(6, "mat-card")(7, "form", 5);
            i0.ɵɵtemplate(8, CallsSidesheetComponent_imx_cdr_editor_8_Template, 1, 1, "imx-cdr-editor", 6);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(9, "div", 7)(10, "button", 8);
            i0.ɵɵlistener("click", function CallsSidesheetComponent_Template_button_click_10_listener() { return ctx.save(); });
            i0.ɵɵtemplate(11, CallsSidesheetComponent_span_11_Template, 2, 0, "span", 9)(12, CallsSidesheetComponent_span_12_Template, 2, 0, "span", 9);
            i0.ɵɵelementEnd()()();
            i0.ɵɵtemplate(13, CallsSidesheetComponent_mat_tab_13_Template, 4, 4, "mat-tab", 10)(14, CallsSidesheetComponent_mat_tab_14_Template, 4, 4, "mat-tab", 10);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(3, 10, "#LDS#Heading Details"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngClass", !ctx.sidesheetData.isNew ? "eui-sidesheet-content--no-padding-top" : "");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.sidesheetData.isNew);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.detailsFormGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.detailsFormGroup.pristine || ctx.detailsFormGroup.invalid);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.sidesheetData.isNew);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.sidesheetData.isNew);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !(ctx.sidesheetData == null ? null : ctx.sidesheetData.isNew));
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !(ctx.sidesheetData == null ? null : ctx.sidesheetData.isNew));
        } }, dependencies: [i6.NgClass, i6.NgForOf, i6.NgIf, i2.ɵNgNoValidate, i2.NgControlStatusGroup, i2.FormGroupDirective, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i5.MatButton, i4$1.MatCard, i9.MatTab, i9.MatTabGroup, i4.CdrEditorComponent, i2$1.TranslateDirective, i4.HelpContextualComponent, CallsHistoryComponent, CallsAttachmentComponent, i2$1.TranslatePipe], styles: [".calls-sidesheet[_ngcontent-%COMP%]{overflow:hidden;height:100%}imx-help-contextual[_ngcontent-%COMP%]{justify-content:end}.eui-sidesheet-content.eui-sidesheet-content--no-padding-top[_ngcontent-%COMP%]{padding-top:0}@media screen and (max-width: 480px){.calls-sidesheet__tab-content[_ngcontent-%COMP%]{display:block}}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsSidesheetComponent, [{
        type: Component,
        args: [{ selector: 'imx-calls-sidesheet', template: "<div class=\"calls-sidesheet\">\n  <mat-tab-group mat-stretch-tabs=\"false\">\n    <mat-tab [label]=\"'#LDS#Heading Details' | translate\">\n      <div eui-sidesheet-content [ngClass]=\"!sidesheetData.isNew ? 'eui-sidesheet-content--no-padding-top' : ''\">\n        <imx-help-contextual\n          [contextId]=\"contextId\"\n          [title]=\"'#LDS#Information about this tab:'\"\n          *ngIf=\"!sidesheetData.isNew\"\n        ></imx-help-contextual>\n        <mat-card>\n          <form [formGroup]=\"detailsFormGroup\">\n            <imx-cdr-editor\n              *ngFor=\"let cdr of cdrList\"\n              [cdr]=\"cdr\"\n              (controlCreated)=\"detailsFormGroup.addControl(cdr.column.ColumnName, $event)\"\n            ></imx-cdr-editor>\n          </form>\n        </mat-card>\n      </div>\n      <div eui-sidesheet-actions>\n        <button\n          data-imx-identifier=\"create-ticket-button\"\n          mat-flat-button\n          color=\"primary\"\n          [disabled]=\"detailsFormGroup.pristine || detailsFormGroup.invalid\"\n          (click)=\"save()\"\n        >\n          <span *ngIf=\"sidesheetData.isNew\" translate>#LDS#Create</span>\n          <span *ngIf=\"!sidesheetData.isNew\" translate>#LDS#Save</span>\n        </button>\n      </div>\n    </mat-tab>\n    <mat-tab *ngIf=\"!sidesheetData?.isNew\" [label]=\"'#LDS#Heading History' | translate\">\n      <div eui-sidesheet-content>\n        <imx-calls-history [ticket]=\"ticket\"></imx-calls-history>\n      </div>\n    </mat-tab>\n    <mat-tab *ngIf=\"!sidesheetData?.isNew\" [label]=\"'#LDS#Heading Attachments' | translate\">\n      <div eui-sidesheet-content class=\"imx-tab-content\">\n        <imx-calls-attachment [callId]=\"getTicketId\"></imx-calls-attachment>\n      </div>\n    </mat-tab>\n  </mat-tab-group>\n</div>\n", styles: [".calls-sidesheet{overflow:hidden;height:100%}imx-help-contextual{justify-content:end}.eui-sidesheet-content.eui-sidesheet-content--no-padding-top{padding-top:0}@media screen and (max-width: 480px){.calls-sidesheet__tab-content{display:block}}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i0.ErrorHandler }, { type: i1.EuiSidesheetRef }, { type: i4.SnackBarService }, { type: i1.EuiLoadingService }, { type: i3.ProjectConfigurationService }, { type: i2.UntypedFormBuilder }, { type: i4.ConfirmationService }, { type: HdsApiService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CallsSidesheetComponent, { className: "CallsSidesheetComponent", filePath: "lib\\calls\\calls-sidesheet\\calls-sidesheet.component.ts", lineNumber: 45 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function CallsComponent_th_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.DescriptionHotline == null ? null : ctx_r0.entitySchema.Columns.DescriptionHotline.Display, " ");
} }
function CallsComponent_td_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div", 16);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵpropertyInterpolate("title", ctx_r0.getTicketItemValue(item_r2, "DescriptionHotline"));
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.getTicketItemValue(item_r2, "DescriptionHotline"), " ");
} }
function CallsComponent_th_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.ActionHotline == null ? null : ctx_r0.entitySchema.Columns.ActionHotline.Display, " ");
} }
function CallsComponent_td_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div", 16);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵpropertyInterpolate("title", ctx_r0.getTicketItemValue(item_r3, "ActionHotline"));
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.getTicketItemValue(item_r3, "ActionHotline"), " ");
} }
function CallsComponent_th_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.CallNumber == null ? null : ctx_r0.entitySchema.Columns.CallNumber.Display, " ");
} }
function CallsComponent_td_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r4.CallNumber.Column.GetDisplayValue());
} }
function CallsComponent_th_19_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.IsClosed == null ? null : ctx_r0.entitySchema.Columns.IsClosed.Display, " ");
} }
function CallsComponent_td_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r5.entity.columns.IsClosed.GetDisplayValue());
} }
function CallsComponent_th_22_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.IsHistory == null ? null : ctx_r0.entitySchema.Columns.IsHistory.Display, " ");
} }
function CallsComponent_td_23_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r6.entity.columns.IsHistory.GetDisplayValue());
} }
function CallsComponent_th_25_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.IsHold == null ? null : ctx_r0.entitySchema.Columns.IsHold.Display, " ");
} }
function CallsComponent_td_26_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r7 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r7.entity.columns.IsHold.GetDisplayValue());
} }
function CallsComponent_th_28_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_PersonHotline == null ? null : ctx_r0.entitySchema.Columns.UID_PersonHotline.Display, " ");
} }
function CallsComponent_td_29_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r8 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r8.entity.columns.UID_PersonHotline.GetDisplayValue());
} }
function CallsComponent_th_31_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_PersonInTrouble == null ? null : ctx_r0.entitySchema.Columns.UID_PersonInTrouble.Display, " ");
} }
function CallsComponent_td_32_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r9 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r9.UID_PersonInTrouble.Column.GetDisplayValue());
} }
function CallsComponent_th_34_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_PersonInTroubleAdditional == null ? null : ctx_r0.entitySchema.Columns.UID_PersonInTroubleAdditional.Display, " ");
} }
function CallsComponent_td_35_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r10 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r10.entity.columns.UID_PersonInTroubleAdditional.GetDisplayValue());
} }
function CallsComponent_th_37_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleCallState == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleCallState.Display, " ");
} }
function CallsComponent_td_38_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r11 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r11.entity.columns.UID_TroubleCallState.GetDisplayValue());
} }
function CallsComponent_th_40_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleEscalationLevel_E == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleEscalationLevel_E.Display, " ");
} }
function CallsComponent_td_41_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r12 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r12.entity.columns.UID_TroubleEscalationLevel_E.GetDisplayValue());
} }
function CallsComponent_th_43_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleProduct == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleProduct.Display, " ");
} }
function CallsComponent_td_44_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r13 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r13.entity.columns.UID_TroubleProduct.GetDisplayValue());
} }
function CallsComponent_th_46_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleSeverity == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleSeverity.Display, " ");
} }
function CallsComponent_td_47_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r14 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r14.UID_TroubleSeverity.Column.GetDisplayValue());
} }
function CallsComponent_th_49_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleTypeHotline == null ? null : ctx_r0.entitySchema.Columns.UID_TroubleTypeHotline.Display, " ");
} }
function CallsComponent_td_50_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 15)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r15 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r15.entity.columns.UID_TroubleTypeHotline.GetDisplayValue());
} }
class CallsComponent {
    errorHandler;
    sidesheet;
    translate;
    hdsApiService;
    euiLoadingService;
    replacePipe;
    helpContextualService;
    dataSource;
    entitySchema;
    displayedColumns = [];
    filterOptions = [];
    dataModel;
    busyService = new BusyService();
    constructor(errorHandler, sidesheet, translate, hdsApiService, euiLoadingService, replacePipe, helpContextualService, dataSource) {
        this.errorHandler = errorHandler;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.hdsApiService = hdsApiService;
        this.euiLoadingService = euiLoadingService;
        this.replacePipe = replacePipe;
        this.helpContextualService = helpContextualService;
        this.dataSource = dataSource;
        this.entitySchema = this.hdsApiService.typedClient.PortalCalls.GetSchema();
    }
    async ngOnInit() {
        const isBusy = this.busyService.beginBusy();
        try {
            this.displayedColumns = [
                this.entitySchema.Columns.CallNumber,
                this.entitySchema.Columns.DescriptionHotline,
                this.entitySchema.Columns.IsClosed,
                this.entitySchema.Columns.IsHistory,
                this.entitySchema.Columns.IsHold,
                this.entitySchema.Columns.UID_PersonHotline,
                this.entitySchema.Columns.UID_PersonInTrouble,
                this.entitySchema.Columns.UID_PersonInTroubleAdditional,
                this.entitySchema.Columns.UID_TroubleCallState,
                this.entitySchema.Columns.UID_TroubleEscalationLevel_E,
                this.entitySchema.Columns.UID_TroubleProduct,
                this.entitySchema.Columns.UID_TroubleSeverity,
                this.entitySchema.Columns.UID_TroubleTypeHotline,
                this.entitySchema.Columns.ActionHotline,
            ];
            await this.setFilter();
            const dataViewInitParameters = {
                execute: (params, signal) => this.hdsApiService.typedClient.PortalCalls.Get(params),
                schema: this.entitySchema,
                columnsToDisplay: this.displayedColumns,
                dataModel: this.dataModel,
                highlightEntity: (call) => {
                    this.onSelected(call);
                },
            };
            this.dataSource.init(dataViewInitParameters);
        }
        finally {
            isBusy.endBusy();
        }
    }
    async createTicket() {
        let ticket = await this.getNewTicket();
        if (ticket)
            await this.viewTicket(ticket, true);
    }
    async viewTicket(ticket, isNew) {
        if (ticket) {
            let title = isNew
                ? await this.translate.get('#LDS#Heading Create Ticket').toPromise()
                : await this.translate.get('#LDS#Heading Edit Ticket').toPromise();
            let sidesheetData = {
                isNew: isNew,
                ticket: ticket,
            };
            let euiSidesheetConfig = {
                testId: 'calls-sidesheet',
                title: title,
                subTitle: isNew ? undefined : ticket.GetEntity().GetDisplay(),
                padding: '0px',
                width: calculateSidesheetWidth(),
                data: sidesheetData,
                disableClose: true,
                headerComponent: isNew ? HelpContextualComponent : undefined,
            };
            if (!isNew) {
                euiSidesheetConfig.subTitle = this.replacePipe.transform(await this.translate.get('#LDS#Heading Ticket Number: {0}').toPromise(), ticket.CallNumber.value.toString());
                this.helpContextualService.setHelpContextId(HELP_CONTEXTUAL.HelpDeskSupportTicketsEdit);
            }
            else {
                this.helpContextualService.setHelpContextId(HELP_CONTEXTUAL.HelpDeskSupportTicketsCreate);
            }
            let sidesheetRef = this.sidesheet.open(CallsSidesheetComponent, euiSidesheetConfig);
            sidesheetRef.afterClosed().subscribe(() => this.dataSource.updateState());
        }
    }
    async getNewTicket() {
        let overlayRef = this.euiLoadingService.show();
        try {
            let tickets = (await this.hdsApiService.typedClient.PortalCallsInteractive.Get()).Data;
            return tickets[0];
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        finally {
            this.euiLoadingService.hide(overlayRef);
        }
    }
    async onSelected(ticket) {
        let overlayRef = this.euiLoadingService.show();
        try {
            if (!!ticket.EntityKeysData?.Keys && ticket.EntityKeysData?.Keys?.length > 0) {
                let interactiveTickets = (await this.hdsApiService.typedClient.PortalCallsInteractive.Get_byid(ticket.EntityKeysData.Keys[0])).Data;
                if (interactiveTickets?.length > 0)
                    this.viewTicket(interactiveTickets[0], false);
            }
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        finally {
            this.euiLoadingService.hide(overlayRef);
        }
    }
    getTicketItemValue(ticket, column) {
        return ticket.GetEntity().GetColumn(column).GetValue();
    }
    async setFilter() {
        this.dataModel = await this.hdsApiService.client.portal_calls_datamodel_get();
        this.filterOptions = this.dataModel?.Filters || [];
        this.filterOptions.map((filter) => {
            if (filter.Name === 'callstate') {
                filter.CurrentValue = 'HDS-2B3E666A806E7CDC288CAE36AE8623DC';
            }
        });
        this.dataSource.state.update((state) => ({ ...state, callstate: 'HDS-2B3E666A806E7CDC288CAE36AE8623DC' }));
        this.dataSource.predefinedFilters.set(this.filterOptions);
    }
    static ɵfac = function CallsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CallsComponent)(i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2$1.TranslateService), i0.ɵɵdirectiveInject(HdsApiService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i4.LdsReplacePipe), i0.ɵɵdirectiveInject(i4.HelpContextualService), i0.ɵɵdirectiveInject(i4.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsComponent, selectors: [["imx-calls"]], features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 57, vars: 23, consts: [[1, "imx-header-toolbar"], [1, "mat-headline-5"], [3, "dataSource", "showSettings"], [1, "imx-card-fill"], ["mode", "manual", "matSort", "", 3, "matSortChange", "dataSource", "matSortActive", "matSortDirection"], [3, "matColumnDef"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], [3, "dataSource"], [1, "imx-button-bar-transparent"], ["data-imx-identifier", "create-help-desk-support-call", "mat-flat-button", "", "color", "primary", 1, "mat-focus-indicator", "mat-button-base", "mat-primary", "create-ticket-button", 3, "click"], ["icon", "add"], ["translate", ""], ["mat-header-cell", "", "mat-sort-header", ""], ["mat-cell", "", "role", "gridcell"], [1, "imx-table-column-ellipsis", 3, "title"], ["mat-header-cell", ""]], template: function CallsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1)(2, "span");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(5, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(6, "imx-data-view-toolbar", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-card", 3)(8, "imx-data-view-auto-table", 4);
            i0.ɵɵlistener("matSortChange", function CallsComponent_Template_imx_data_view_auto_table_matSortChange_8_listener($event) { return ctx.dataSource == null ? null : ctx.dataSource.sortChange($event); });
            i0.ɵɵelementContainerStart(9, 5);
            i0.ɵɵtemplate(10, CallsComponent_th_10_Template, 2, 1, "th", 6)(11, CallsComponent_td_11_Template, 3, 2, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(12, 5);
            i0.ɵɵtemplate(13, CallsComponent_th_13_Template, 2, 1, "th", 6)(14, CallsComponent_td_14_Template, 3, 2, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(15, 5);
            i0.ɵɵtemplate(16, CallsComponent_th_16_Template, 2, 1, "th", 6)(17, CallsComponent_td_17_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(18, 5);
            i0.ɵɵtemplate(19, CallsComponent_th_19_Template, 2, 1, "th", 6)(20, CallsComponent_td_20_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(21, 5);
            i0.ɵɵtemplate(22, CallsComponent_th_22_Template, 2, 1, "th", 6)(23, CallsComponent_td_23_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(24, 5);
            i0.ɵɵtemplate(25, CallsComponent_th_25_Template, 2, 1, "th", 6)(26, CallsComponent_td_26_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(27, 5);
            i0.ɵɵtemplate(28, CallsComponent_th_28_Template, 2, 1, "th", 8)(29, CallsComponent_td_29_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(30, 5);
            i0.ɵɵtemplate(31, CallsComponent_th_31_Template, 2, 1, "th", 8)(32, CallsComponent_td_32_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(33, 5);
            i0.ɵɵtemplate(34, CallsComponent_th_34_Template, 2, 1, "th", 8)(35, CallsComponent_td_35_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(36, 5);
            i0.ɵɵtemplate(37, CallsComponent_th_37_Template, 2, 1, "th", 8)(38, CallsComponent_td_38_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(39, 5);
            i0.ɵɵtemplate(40, CallsComponent_th_40_Template, 2, 1, "th", 8)(41, CallsComponent_td_41_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(42, 5);
            i0.ɵɵtemplate(43, CallsComponent_th_43_Template, 2, 1, "th", 8)(44, CallsComponent_td_44_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(45, 5);
            i0.ɵɵtemplate(46, CallsComponent_th_46_Template, 2, 1, "th", 8)(47, CallsComponent_td_47_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(48, 5);
            i0.ɵɵtemplate(49, CallsComponent_th_49_Template, 2, 1, "th", 8)(50, CallsComponent_td_50_Template, 3, 1, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd();
            i0.ɵɵelement(51, "imx-data-view-paginator", 9);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(52, "div", 10)(53, "button", 11);
            i0.ɵɵlistener("click", function CallsComponent_Template_button_click_53_listener() { return ctx.createTicket(); });
            i0.ɵɵelement(54, "eui-icon", 12);
            i0.ɵɵelementStart(55, "span", 13);
            i0.ɵɵtext(56, "#LDS#Create ticket");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 21, "#LDS#Heading Tickets"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("showSettings", false);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("matSortActive", ctx.dataSource.sortId())("matSortDirection", ctx.dataSource.sortDirection());
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.DescriptionHotline.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.ActionHotline.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.CallNumber.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.IsClosed.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.IsHistory.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.IsHold.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_PersonHotline.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_PersonInTrouble.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_PersonInTroubleAdditional.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_TroubleCallState.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_TroubleEscalationLevel_E.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_TroubleProduct.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_TroubleSeverity.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema.Columns.UID_TroubleTypeHotline.ColumnName);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
        } }, dependencies: [i1.EuiIconComponent, i5.MatButton, i4$1.MatCard, i7$1.MatSort, i7$1.MatSortHeader, i8.MatHeaderCellDef, i8.MatColumnDef, i8.MatCellDef, i8.MatHeaderCell, i8.MatCell, i2$1.TranslateDirective, i4.HelpContextualComponent, i4.DataViewAutoTableComponent, i4.DataViewPaginatorComponent, i4.DataViewToolbarComponent, i2$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}.create-ticket-button[_ngcontent-%COMP%]{align-self:flex-start}.calls-data-table[_ngcontent-%COMP%]{flex-grow:1;overflow:auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsComponent, [{
        type: Component,
        args: [{ selector: 'imx-calls', providers: [DataViewSource], template: "<div class=\"imx-header-toolbar\">\n  <h2 class=\"mat-headline-5\">\n    <span>{{ '#LDS#Heading Tickets' | translate }}</span>\n    <imx-help-contextual></imx-help-contextual>\n  </h2>\n  <imx-data-view-toolbar [dataSource]=\"dataSource\" [showSettings]=\"false\"></imx-data-view-toolbar>\n</div>\n\n<mat-card class=\"imx-card-fill\">\n  <imx-data-view-auto-table\n    [dataSource]=\"dataSource\"\n    mode=\"manual\"\n    matSort\n    (matSortChange)=\"dataSource?.sortChange($event)\"\n    [matSortActive]=\"dataSource.sortId()\"\n    [matSortDirection]=\"dataSource.sortDirection()\"\n  >\n    <ng-container [matColumnDef]=\"entitySchema.Columns.DescriptionHotline.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header>\n        {{ entitySchema?.Columns?.DescriptionHotline?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div class=\"imx-table-column-ellipsis\" title=\"{{ getTicketItemValue(item, 'DescriptionHotline') }}\">\n          {{ getTicketItemValue(item, 'DescriptionHotline') }}\n        </div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.ActionHotline.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header>\n        {{ entitySchema?.Columns?.ActionHotline?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div class=\"imx-table-column-ellipsis\" title=\"{{ getTicketItemValue(item, 'ActionHotline') }}\">\n          {{ getTicketItemValue(item, 'ActionHotline') }}\n        </div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.CallNumber.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header>\n        {{ entitySchema?.Columns?.CallNumber?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.CallNumber.Column.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.IsClosed.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header>\n        {{ entitySchema?.Columns?.IsClosed?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.entity.columns.IsClosed.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.IsHistory.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header>\n        {{ entitySchema?.Columns?.IsHistory?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.entity.columns.IsHistory.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.IsHold.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef mat-sort-header>\n        {{ entitySchema?.Columns?.IsHold?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.entity.columns.IsHold.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.UID_PersonHotline.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ entitySchema?.Columns?.UID_PersonHotline?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.entity.columns.UID_PersonHotline.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.UID_PersonInTrouble.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ entitySchema?.Columns?.UID_PersonInTrouble?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.UID_PersonInTrouble.Column.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.UID_PersonInTroubleAdditional.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ entitySchema?.Columns?.UID_PersonInTroubleAdditional?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.entity.columns.UID_PersonInTroubleAdditional.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.UID_TroubleCallState.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ entitySchema?.Columns?.UID_TroubleCallState?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.entity.columns.UID_TroubleCallState.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.UID_TroubleEscalationLevel_E.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ entitySchema?.Columns?.UID_TroubleEscalationLevel_E?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.entity.columns.UID_TroubleEscalationLevel_E.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.UID_TroubleProduct.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ entitySchema?.Columns?.UID_TroubleProduct?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.entity.columns.UID_TroubleProduct.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.UID_TroubleSeverity.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ entitySchema?.Columns?.UID_TroubleSeverity?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.UID_TroubleSeverity.Column.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"entitySchema.Columns.UID_TroubleTypeHotline.ColumnName\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ entitySchema?.Columns?.UID_TroubleTypeHotline?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n        <div>{{ item.entity.columns.UID_TroubleTypeHotline.GetDisplayValue() }}</div>\n      </td>\n    </ng-container>\n  </imx-data-view-auto-table>\n  <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n</mat-card>\n<div class=\"imx-button-bar-transparent\">\n  <button\n    data-imx-identifier=\"create-help-desk-support-call\"\n    mat-flat-button\n    color=\"primary\"\n    class=\"mat-focus-indicator mat-button-base mat-primary create-ticket-button\"\n    (click)=\"createTicket()\"\n  >\n    <eui-icon icon=\"add\"></eui-icon>\n    <span translate>#LDS#Create ticket</span>\n  </button>\n</div>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;height:100%}.create-ticket-button{align-self:flex-start}.calls-data-table{flex-grow:1;overflow:auto}\n"] }]
    }], () => [{ type: i0.ErrorHandler }, { type: i1.EuiSidesheetService }, { type: i2$1.TranslateService }, { type: HdsApiService }, { type: i1.EuiLoadingService }, { type: i4.LdsReplacePipe }, { type: i4.HelpContextualService }, { type: i4.DataViewSource }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CallsComponent, { className: "CallsComponent", filePath: "lib\\calls\\calls.component.ts", lineNumber: 59 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    router;
    extService;
    constructor(router, extService) {
        this.router = router;
        this.extService = extService;
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register('mastHead', {
            instance: CallsComponent,
            inputData: {
                id: 'helpdeskTickets',
                label: '#LDS#Menu Entry Help desk tickets',
                url: 'help-desk-support/tickets',
            },
        });
        /*
        this.dataExplorerRegistryService.registerFactory(
          (preProps: string[], groups: string[]) => {
            if (!this.isRoleAdmin(groups)) {
              return;
            }
            return {
              instance: RolesOverviewComponent,
              data: {
                TableName: this.esetTag,
                Count: 0,
              },
              sortOrder: 8,
              name: 'systemroles',
              caption: '#LDS#Menu Entry System roles',
            };
          }
        );
        */
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i1$2.Router), i0.ɵɵinject(i4.ExtService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i1$2.Router }, { type: i4.ExtService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class CallsModule {
    static ɵfac = function CallsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CallsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: CallsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            EuiCoreModule,
            EuiMaterialModule,
            CdrModule,
            TranslateModule,
            DataSourceToolbarModule,
            DataTableModule,
            LdsReplaceModule,
            FkAdvancedPickerModule,
            SidenavTreeComponent,
            DataTreeWrapperModule,
            HelpContextualModule,
            DataViewModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    CallsComponent,
                    CallsSidesheetComponent,
                    CallsHistoryComponent,
                    CallsHistorySidesheetComponent,
                    CallsAttachmentComponent,
                    CallsAttachmentDialogComponent,
                ],
                imports: [
                    CommonModule,
                    FormsModule,
                    ReactiveFormsModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    CdrModule,
                    TranslateModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    LdsReplaceModule,
                    FkAdvancedPickerModule,
                    SidenavTreeComponent,
                    DataTreeWrapperModule,
                    HelpContextualModule,
                    DataViewModule,
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(CallsModule, { declarations: [CallsComponent,
        CallsSidesheetComponent,
        CallsHistoryComponent,
        CallsHistorySidesheetComponent,
        CallsAttachmentComponent,
        CallsAttachmentDialogComponent], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        CdrModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule,
        LdsReplaceModule,
        FkAdvancedPickerModule,
        SidenavTreeComponent,
        DataTreeWrapperModule,
        HelpContextualModule,
        DataViewModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'help-desk-support/tickets',
        component: CallsComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.HelpDeskSupportTickets,
        },
    },
];
class HdsConfigModule {
    initializer;
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 HDS loaded');
        this.initializer.onInit(routes);
        console.log('▶️ HDS initialized');
    }
    static ɵfac = function HdsConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || HdsConfigModule)(i0.ɵɵinject(InitService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: HdsConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CallsModule, RouterModule.forChild(routes)] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(HdsConfigModule, [{
        type: NgModule,
        args: [{
                imports: [CallsModule, RouterModule.forChild(routes)],
            }]
    }], () => [{ type: InitService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(HdsConfigModule, { imports: [CallsModule, i1$2.RouterModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of hds
 */

/**
 * Generated bundle index. Do not edit.
 */

export { HdsConfigModule };
//# sourceMappingURL=hds.mjs.map
