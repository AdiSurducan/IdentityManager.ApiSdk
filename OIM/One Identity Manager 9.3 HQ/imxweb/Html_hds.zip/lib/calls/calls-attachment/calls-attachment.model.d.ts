export interface CallsAttachmentNode {
    name: string;
    path: string;
    level: number;
    isSelected: boolean;
    type: CallsAttachmentType;
    children?: CallsAttachmentNode[];
    file?: File;
    parent?: CallsAttachmentNode;
    isLoading?: boolean;
    temporary?: boolean;
}
export declare enum CallsAttachmentType {
    folder = 0,
    file = 1
}
export declare enum CallsAttachmentActionType {
    addFolder = 0,
    deleteFile = 1,
    deleteFolder = 2
}
export interface CallsAttachmentDialogData {
    actionType: CallsAttachmentActionType;
    itemInfo: string;
}
