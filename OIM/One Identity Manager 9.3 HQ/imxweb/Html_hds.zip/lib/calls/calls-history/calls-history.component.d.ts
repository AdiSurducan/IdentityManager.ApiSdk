import { OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { PortalCalls, PortalCallsHistory } from '@imx-modules/imx-api-hds';
import { EntitySchema, IClientProperty } from '@imx-modules/imx-qbm-dbts';
import { TranslateService } from '@ngx-translate/core';
import { DataViewSource } from 'qbm';
import { HdsApiService } from '../../hds-api-client.service';
import * as i0 from "@angular/core";
export declare class CallsHistoryComponent implements OnInit {
    private readonly sidesheet;
    private readonly translate;
    private readonly hdsApiService;
    dataSource: DataViewSource<PortalCallsHistory>;
    ticket: PortalCalls;
    entitySchema: EntitySchema;
    displayedColumns: IClientProperty[];
    constructor(sidesheet: EuiSidesheetService, translate: TranslateService, hdsApiService: HdsApiService, dataSource: DataViewSource<PortalCallsHistory>);
    ngOnInit(): Promise<void>;
    onSelected(history: PortalCallsHistory): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CallsHistoryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CallsHistoryComponent, "imx-calls-history", never, { "ticket": { "alias": "ticket"; "required": false; }; }, {}, never, never, false, never>;
}
