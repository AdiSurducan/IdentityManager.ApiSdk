import { Router, Route } from '@angular/router';
import { ExtService } from 'qbm';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly router;
    private readonly extService;
    constructor(router: Router, extService: ExtService);
    onInit(routes: Route[]): void;
    private addRoutes;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
