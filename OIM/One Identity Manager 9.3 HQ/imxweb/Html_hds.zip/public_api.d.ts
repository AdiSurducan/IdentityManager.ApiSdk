export { HdsConfigModule } from './lib/hds-config.module';
