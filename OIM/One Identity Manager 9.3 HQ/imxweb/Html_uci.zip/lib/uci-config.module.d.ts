import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/router";
import * as i3 from "./changeview/changeview.module";
import * as i4 from "@ngx-translate/core";
export declare class UciConfigModule {
    private readonly initializer;
    constructor(initializer: InitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<UciConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UciConfigModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.ChangeViewModule, typeof i4.TranslateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UciConfigModule>;
}
