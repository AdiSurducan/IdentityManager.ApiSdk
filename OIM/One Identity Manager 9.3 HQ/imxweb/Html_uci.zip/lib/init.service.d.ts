import { Route, Router } from '@angular/router';
import { MenuService } from 'qbm';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly router;
    private readonly menuService;
    constructor(router: Router, menuService: MenuService);
    onInit(routes: Route[]): void;
    private addRoutes;
    private setupMenu;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
