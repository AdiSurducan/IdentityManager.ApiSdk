import * as i4 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, Inject, NgModule } from '@angular/core';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i5 from 'qbm';
import { DataSourceWrapper, calculateSidesheetWidth, DataSourceToolbarModule, DataTableModule, CdrModule, QbmModule, RouteGuardService } from 'qbm';
import * as i2 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import { LocalEntityColumn, DbObjectKey } from '@imx-modules/imx-qbm-dbts';
import { V2Client, TypedClient } from '@imx-modules/imx-api-uci';
import * as i5$1 from '@angular/material/button';
import * as i6 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class UciApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing UCI API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function UciApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || UciApiService)(i0.ɵɵinject(i5.AppConfigService), i0.ɵɵinject(i5.ClassloggerService), i0.ɵɵinject(i5.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: UciApiService, factory: UciApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UciApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i5.AppConfigService }, { type: i5.ClassloggerService }, { type: i5.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$1 = (a0, a1) => [a0, a1];
function ChangeSidesheetComponent_div_1_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const idx_r1 = i0.ɵɵnextContext().index;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate2("(", idx_r1 + 1, "/", ctx_r1.changeDetail.length, ")");
} }
function ChangeSidesheetComponent_div_1_eui_badge_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 10);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Successful"));
} }
function ChangeSidesheetComponent_div_1_eui_badge_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 11);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Pending"));
} }
function ChangeSidesheetComponent_div_1_eui_badge_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 12);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Failed"));
} }
function ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if creating the object in the cloud application was successful or failed."), " ");
} }
function ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if deleting the object in the cloud application was successful or failed."), " ");
} }
function ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if changing the object in the cloud application was successful or failed."), " ");
} }
function ChangeSidesheetComponent_div_1_eui_alert_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 13);
    i0.ɵɵtemplate(1, ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_1_Template, 3, 3, "ng-container", 3)(2, ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_2_Template, 3, 3, "ng-container", 3)(3, ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_3_Template, 3, 3, "ng-container", 3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdetail_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", cdetail_r3.Operation.value == "I");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", cdetail_r3.Operation.value == "D");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", cdetail_r3.Operation.value == "U");
} }
function ChangeSidesheetComponent_div_1_div_12_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 14)(1, "button", 15);
    i0.ɵɵlistener("click", function ChangeSidesheetComponent_div_1_div_12_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r4); const cdetail_r3 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.markAsDone(cdetail_r3)); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 16);
    i0.ɵɵlistener("click", function ChangeSidesheetComponent_div_1_div_12_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r4); const cdetail_r3 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.markAsError(cdetail_r3)); });
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Mark as successful"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 4, "#LDS#Mark as failed"), " ");
} }
function ChangeSidesheetComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "mat-card")(2, "h4", 2);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵtemplate(5, ChangeSidesheetComponent_div_1_ng_container_5_Template, 2, 2, "ng-container", 3)(6, ChangeSidesheetComponent_div_1_eui_badge_6_Template, 3, 3, "eui-badge", 4)(7, ChangeSidesheetComponent_div_1_eui_badge_7_Template, 3, 3, "eui-badge", 5)(8, ChangeSidesheetComponent_div_1_eui_badge_8_Template, 3, 3, "eui-badge", 6);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(9, ChangeSidesheetComponent_div_1_eui_alert_9_Template, 4, 5, "eui-alert", 7);
    i0.ɵɵelement(10, "imx-property-viewer", 8)(11, "imx-property-viewer", 8);
    i0.ɵɵtemplate(12, ChangeSidesheetComponent_div_1_div_12_Template, 7, 6, "div", 9);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const cdetail_r3 = ctx.$implicit;
    const idx_r1 = ctx.index;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 9, "#LDS#Heading Requested Operation"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.changeDetail.length > 1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", cdetail_r3.IsProcessed.value == 1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", cdetail_r3.IsProcessed.value == 0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", cdetail_r3.IsProcessed.value == 2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.canMarkAsDone(cdetail_r3));
    i0.ɵɵadvance();
    i0.ɵɵproperty("properties", i0.ɵɵpureFunction2(11, _c0$1, cdetail_r3.Operation.Column, cdetail_r3.CreationDate.Column));
    i0.ɵɵadvance();
    i0.ɵɵproperty("properties", ctx_r1.changeProperties[idx_r1]);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.canMarkAsDone(cdetail_r3));
} }
class ChangeSidesheetComponent {
    uciApi;
    sidesheetRef;
    confirmation;
    changeDetail = [];
    manualChangeData = [];
    changeProperties = [];
    constructor(change, uciApi, sidesheetRef, confirmation) {
        this.uciApi = uciApi;
        this.sidesheetRef = sidesheetRef;
        this.confirmation = confirmation;
        this.changeDetail = change.Data;
        this.manualChangeData = change?.extendedData?.Operations ?? [];
        // build entity columns from extended data
        this.changeProperties = this.manualChangeData.map((d) => {
            return d.map((c) => {
                const prop = new LocalEntityColumn(c.Property, undefined, undefined, {
                    Value: c.DiffValue,
                });
                return prop;
            });
        });
    }
    async markAsDone(detail) {
        if (await this.confirmation.confirm({
            Title: '#LDS#Heading Mark As Successful',
            Message: '#LDS#The provisioning process will be marked as successful. Are you sure you have made the requested change in the cloud application?',
        })) {
            await this.save(detail, true);
        }
    }
    async markAsError(detail) {
        if (await this.confirmation.confirm({
            Title: '#LDS#Heading Mark As Failed',
            Message: '#LDS#The provisioning process will be marked as failed. Are you sure you cannot make the requested change in the cloud application?',
        })) {
            await this.save(detail, false);
        }
    }
    canMarkAsDone(detail) {
        return detail.IsProcessed.value === 0;
    }
    async save(detail, success) {
        await this.uciApi.client.opsupport_uci_changes_post(detail.GetEntity().GetKeys()[0], { Success: success });
        this.sidesheetRef.close(true /* reload */);
    }
    static ɵfac = function ChangeSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ChangeSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(UciApiService), i0.ɵɵdirectiveInject(i2.EuiSidesheetRef), i0.ɵɵdirectiveInject(i5.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ChangeSidesheetComponent, selectors: [["ng-component"]], decls: 2, vars: 1, consts: [["eui-sidesheet-content", ""], [4, "ngFor", "ngForOf"], ["mat-card-title", ""], [4, "ngIf"], ["color", "green", 4, "ngIf"], ["color", "orange", 4, "ngIf"], ["color", "red", 4, "ngIf"], ["type", "info", 3, "condensed", "colored", 4, "ngIf"], [3, "properties"], ["class", "imx-button-bar-transparent", 4, "ngIf"], ["color", "green"], ["color", "orange"], ["color", "red"], ["type", "info", 3, "condensed", "colored"], [1, "imx-button-bar-transparent"], ["data-imx-identifier", "imx-changeview-markdone", "mat-flat-button", "", "color", "primary", 3, "click"], ["data-imx-identifier", "imx-changeview-markerror", "mat-flat-button", "", "color", "warn", 3, "click"]], template: function ChangeSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, ChangeSidesheetComponent_div_1_Template, 13, 14, "div", 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.changeDetail);
        } }, dependencies: [i4.NgForOf, i4.NgIf, i2.EuiAlertComponent, i2.EuiBadgeComponent, i2.EuiSidesheetContentDirective, i5$1.MatButton, i6.MatCard, i6.MatCardTitle, i5.PropertyViewerComponent, i1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:auto;height:100%}.mat-mdc-card[_ngcontent-%COMP%]{margin-bottom:10px}.eui-dark-theme   [_nghost-%COMP%]{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChangeSidesheetComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\n  <div *ngFor=\"let cdetail of changeDetail; let idx = index\">\n    <mat-card>\n      <h4 mat-card-title>\n        {{ '#LDS#Heading Requested Operation' | translate }}\n        <ng-container *ngIf=\"changeDetail.length > 1\">({{ idx + 1 }}/{{ changeDetail.length }})</ng-container>\n        <eui-badge *ngIf=\"cdetail.IsProcessed.value == 1\" color=\"green\">{{ '#LDS#Successful' | translate }}</eui-badge>\n        <eui-badge *ngIf=\"cdetail.IsProcessed.value == 0\" color=\"orange\">{{ '#LDS#Pending' | translate }}</eui-badge>\n        <eui-badge *ngIf=\"cdetail.IsProcessed.value == 2\" color=\"red\">{{ '#LDS#Failed' | translate }}</eui-badge>\n      </h4>\n\n      <eui-alert *ngIf=\"canMarkAsDone(cdetail)\" type=\"info\" [condensed]=\"true\" [colored]=\"true\">\n        <ng-container *ngIf=\"cdetail.Operation.value == 'I'\">\n          {{\n            '#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if creating the object in the cloud application was successful or failed.'\n              | translate\n          }}\n        </ng-container>\n        <ng-container *ngIf=\"cdetail.Operation.value == 'D'\">\n          {{\n            '#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if deleting the object in the cloud application was successful or failed.'\n              | translate\n          }}\n        </ng-container>\n        <ng-container *ngIf=\"cdetail.Operation.value == 'U'\">\n          {{\n            '#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if changing the object in the cloud application was successful or failed.'\n              | translate\n          }}\n        </ng-container>\n      </eui-alert>\n\n      <imx-property-viewer [properties]=\"[cdetail.Operation.Column, cdetail.CreationDate.Column]\"></imx-property-viewer>\n\n      <imx-property-viewer [properties]=\"changeProperties[idx]\"></imx-property-viewer>\n\n      <div class=\"imx-button-bar-transparent\" *ngIf=\"canMarkAsDone(cdetail)\">\n        <button data-imx-identifier=\"imx-changeview-markdone\" mat-flat-button color=\"primary\" (click)=\"markAsDone(cdetail)\">\n          {{ '#LDS#Mark as successful' | translate }}\n        </button>\n        <button data-imx-identifier=\"imx-changeview-markerror\" mat-flat-button color=\"warn\" (click)=\"markAsError(cdetail)\">\n          {{ '#LDS#Mark as failed' | translate }}\n        </button>\n      </div>\n    </mat-card>\n  </div>\n</div>\n", styles: [":host{display:flex;flex-direction:column;overflow:auto;height:100%}.mat-mdc-card{margin-bottom:10px}.eui-dark-theme :host{background-color:#2f3233}.eui-contrast-theme :host{background-color:#000}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: UciApiService }, { type: i2.EuiSidesheetRef }, { type: i5.ConfirmationService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ChangeSidesheetComponent, { className: "ChangeSidesheetComponent", filePath: "lib\\changeview\\change-sidesheet.component.ts", lineNumber: 41 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ChangeViewService {
    busyService;
    constructor(busyService) {
        this.busyService = busyService;
    }
    handleOpenLoader() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
    }
    handleCloseLoader() {
        this.busyService.hide();
    }
    static ɵfac = function ChangeViewService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ChangeViewService)(i0.ɵɵinject(i2.EuiLoadingService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ChangeViewService, factory: ChangeViewService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChangeViewService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2.EuiLoadingService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0 = () => ["search", "filter"];
function ChangeViewComponent_mat_card_4_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "div", 11);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const prod_r3 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(prod_r3.ObjectKeyElement.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r1.getTableDisplay(prod_r3));
} }
function ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 15);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Successful"));
} }
function ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 16);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Pending"));
} }
function ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 17);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Failed"));
} }
function ChangeViewComponent_mat_card_4_ng_template_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_1_Template, 3, 3, "eui-badge", 12)(2, ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_2_Template, 3, 3, "eui-badge", 13)(3, ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_3_Template, 3, 3, "eui-badge", 14);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const prod_r4 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", prod_r4.IsProcessed.value == 1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", prod_r4.IsProcessed.value == 0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", prod_r4.IsProcessed.value == 2);
} }
function ChangeViewComponent_mat_card_4_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 5)(1, "imx-data-source-toolbar", 6, 0);
    i0.ɵɵlistener("search", function ChangeViewComponent_mat_card_4_Template_imx_data_source_toolbar_search_1_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.getData({ search: $event })); })("navigationStateChanged", function ChangeViewComponent_mat_card_4_Template_imx_data_source_toolbar_navigationStateChanged_1_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.getData($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "imx-data-table", 7, 1);
    i0.ɵɵlistener("highlightedEntityChanged", function ChangeViewComponent_mat_card_4_Template_imx_data_table_highlightedEntityChanged_3_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.viewDetails($event)); });
    i0.ɵɵelementStart(5, "imx-data-table-generic-column", 8);
    i0.ɵɵtemplate(6, ChangeViewComponent_mat_card_4_ng_template_6_Template, 4, 2, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "imx-data-table-column", 9);
    i0.ɵɵtemplate(8, ChangeViewComponent_mat_card_4_ng_template_8_Template, 4, 3, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(9, "imx-data-table-column", 9)(10, "imx-data-table-column", 9);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(11, "imx-data-source-paginator", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const dst_r5 = i0.ɵɵreference(2);
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("options", i0.ɵɵpureFunction0(9, _c0))("settings", ctx_r1.dstSettings);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("dst", dst_r5)("detailViewVisible", false);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("columnLabel", ctx_r1.entitySchema.Columns.ObjectKeyElement.Display);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("entityColumn", ctx_r1.entitySchema.Columns.IsProcessed);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("entityColumn", ctx_r1.entitySchema.Columns.UID_UCIRoot);
    i0.ɵɵadvance();
    i0.ɵɵproperty("entityColumn", ctx_r1.entitySchema.Columns.XDateInserted);
    i0.ɵɵadvance();
    i0.ɵɵproperty("dst", dst_r5);
} }
class ChangeViewComponent {
    translator;
    uciApi;
    changeviewService;
    sidesheet;
    metadatasvc;
    dstWrapper;
    dstSettings;
    selectedChange;
    entitySchema;
    filterOptions = [];
    constructor(translator, uciApi, changeviewService, sidesheet, metadatasvc) {
        this.translator = translator;
        this.uciApi = uciApi;
        this.changeviewService = changeviewService;
        this.sidesheet = sidesheet;
        this.metadatasvc = metadatasvc;
        this.entitySchema = this.uciApi.typedClient.OpsupportUciChanges.GetSchema();
    }
    async ngOnInit() {
        const dataModel = await this.getDataModel();
        this.filterOptions = dataModel.Filters ?? [];
        // set initial value for state =0 (only pending processes)
        const idx = this.filterOptions.findIndex((elem) => elem.Name === 'state');
        if (idx > -1) {
            this.filterOptions[idx].InitialValue = '0';
        }
        this.dstWrapper = new DataSourceWrapper((state) => this.uciApi.typedClient.OpsupportUciChanges.Get(state), [
            this.entitySchema.Columns.ObjectKeyElement,
            this.entitySchema.Columns.IsProcessed,
            this.entitySchema.Columns.UID_UCIRoot,
            this.entitySchema.Columns.XDateInserted,
        ], this.entitySchema, {
            dataModel: dataModel,
        });
        await this.getData({ state: '0' });
    }
    async getData(newState) {
        this.changeviewService.handleOpenLoader();
        try {
            const settings = await this.dstWrapper.getDstSettings(newState);
            if (settings) {
                for (var d of settings.dataSource?.Data ?? []) {
                    const tableName = DbObjectKey.FromXml(d.GetEntity().GetColumn('ObjectKeyElement').GetValue()).TableName;
                    await this.metadatasvc.updateNonExisting([tableName]);
                }
                this.dstSettings = settings;
            }
        }
        finally {
            this.changeviewService.handleCloseLoader();
        }
    }
    getTableDisplay(d) {
        const tableName = DbObjectKey.FromXml(d.GetEntity().GetColumn('ObjectKeyElement').GetValue()).TableName;
        return this.metadatasvc.tables?.[tableName]?.DisplaySingular;
    }
    async viewDetails(change) {
        this.changeviewService.handleOpenLoader();
        var details;
        try {
            const uidChange = change.GetEntity().GetKeys()[0];
            details = await this.uciApi.typedClient.OpsupportUciChangedetail.Get(uidChange);
        }
        finally {
            this.changeviewService.handleCloseLoader();
        }
        const result = await this.sidesheet
            .open(ChangeSidesheetComponent, {
            title: await this.translator.get('#LDS#Heading View Provisioning Process Details').toPromise(),
            subTitle: change.GetEntity().GetColumn('ObjectKeyElement').GetDisplayValue(),
            padding: '0',
            width: calculateSidesheetWidth(600, 0.4),
            testId: 'changeview-details-sidesheet',
            data: details,
        })
            .afterClosed()
            .toPromise();
        if (result) {
            this.getData();
        }
    }
    async getDataModel() {
        return this.uciApi.client.opsupport_uci_changes_datamodel_get();
    }
    static ɵfac = function ChangeViewComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ChangeViewComponent)(i0.ɵɵdirectiveInject(i1.TranslateService), i0.ɵɵdirectiveInject(UciApiService), i0.ɵɵdirectiveInject(ChangeViewService), i0.ɵɵdirectiveInject(i2.EuiSidesheetService), i0.ɵɵdirectiveInject(i5.MetadataService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ChangeViewComponent, selectors: [["imx-change-view"]], decls: 5, vars: 4, consts: [["dst", ""], ["dataTable", ""], [1, "imx-content-header"], [1, "mat-headline-5"], ["class", "imx-table-container", 4, "ngIf"], [1, "imx-table-container"], ["data-imx-identifier", "changeview-dst", 3, "search", "navigationStateChanged", "options", "settings"], ["mode", "manual", "noDataText", "#LDS#There are currently no pending provisioning processes.", "noDataText", "#LDS#There are currently no pending provisioning processes.", "data-imx-identifier", "changeview-datatable", 1, "imx-changeview-table", 3, "highlightedEntityChanged", "dst", "detailViewVisible"], ["columnName", "ObjectKeyElement", 3, "columnLabel"], [3, "entityColumn"], ["data-imx-identifier", "changeview-paginator", 3, "dst"], [1, "subtitle"], ["color", "green", 4, "ngIf"], ["color", "orange", 4, "ngIf"], ["color", "red", 4, "ngIf"], ["color", "green"], ["color", "orange"], ["color", "red"]], template: function ChangeViewComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 2)(1, "h2", 3);
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(4, ChangeViewComponent_mat_card_4_Template, 12, 10, "mat-card", 4);
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Heading Pending Provisioning Processes"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.dstWrapper && ctx.dstSettings);
        } }, dependencies: [i4.NgIf, i2.EuiBadgeComponent, i6.MatCard, i5.DataSourceToolbarComponent, i5.DataSourcePaginatorComponent, i5.DataTableComponent, i5.DataTableColumnComponent, i5.DataTableGenericColumnComponent, i1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex-grow:1}.subtitle[_ngcontent-%COMP%]{font-size:smaller;color:#919799;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.imx-table-container[_ngcontent-%COMP%], .imx-table-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto;margin:2px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChangeViewComponent, [{
        type: Component,
        args: [{ selector: 'imx-change-view', template: "<div class=\"imx-content-header\">\n  <h2 class=\"mat-headline-5\">\n    {{ '#LDS#Heading Pending Provisioning Processes' | translate }}\n  </h2>\n</div>\n\n<mat-card class=\"imx-table-container\" *ngIf=\"dstWrapper && dstSettings\">\n  <imx-data-source-toolbar\n    #dst\n    [options]=\"['search', 'filter']\"\n    [settings]=\"dstSettings\"\n    (search)=\"getData({ search: $event })\"\n    (navigationStateChanged)=\"getData($event)\"\n    data-imx-identifier=\"changeview-dst\"\n  >\n  </imx-data-source-toolbar>\n  <imx-data-table\n    #dataTable\n    [dst]=\"dst\"\n    class=\"imx-changeview-table\"\n    [detailViewVisible]=\"false\"\n    mode=\"manual\"\n    noDataText=\"#LDS#There are currently no pending provisioning processes.\"\n    (highlightedEntityChanged)=\"viewDetails($event)\"\n    noDataText=\"#LDS#There are currently no pending provisioning processes.\"\n    data-imx-identifier=\"changeview-datatable\"\n  >\n    <imx-data-table-generic-column columnName=\"ObjectKeyElement\" [columnLabel]=\"entitySchema.Columns.ObjectKeyElement.Display\">\n      <ng-template let-prod>\n        <div>{{ prod.ObjectKeyElement.Column.GetDisplayValue() }}</div>\n        <div class=\"subtitle\">{{ getTableDisplay(prod) }}</div>\n      </ng-template>\n    </imx-data-table-generic-column>\n    <imx-data-table-column [entityColumn]=\"entitySchema.Columns.IsProcessed\">\n      <ng-template let-prod>\n        <div>\n          <eui-badge *ngIf=\"prod.IsProcessed.value == 1\" color=\"green\">{{ '#LDS#Successful' | translate }}</eui-badge>\n          <eui-badge *ngIf=\"prod.IsProcessed.value == 0\" color=\"orange\">{{ '#LDS#Pending' | translate }}</eui-badge>\n          <eui-badge *ngIf=\"prod.IsProcessed.value == 2\" color=\"red\">{{ '#LDS#Failed' | translate }}</eui-badge>\n        </div>\n      </ng-template>\n    </imx-data-table-column>\n    <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_UCIRoot\"> </imx-data-table-column>\n    <imx-data-table-column [entityColumn]=\"entitySchema.Columns.XDateInserted\"> </imx-data-table-column>\n  </imx-data-table>\n  <imx-data-source-paginator data-imx-identifier=\"changeview-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\n</mat-card>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;flex-grow:1}.subtitle{font-size:smaller;color:#919799;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.imx-table-container,.imx-table-card{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto;margin:2px}\n"] }]
    }], () => [{ type: i1.TranslateService }, { type: UciApiService }, { type: ChangeViewService }, { type: i2.EuiSidesheetService }, { type: i5.MetadataService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ChangeViewComponent, { className: "ChangeViewComponent", filePath: "lib\\changeview\\change-view.component.ts", lineNumber: 50 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ChangeViewModule {
    static ɵfac = function ChangeViewModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ChangeViewModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ChangeViewModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            EuiCoreModule,
            EuiMaterialModule,
            DataSourceToolbarModule,
            DataTableModule,
            MatCardModule,
            CdrModule,
            QbmModule,
            TranslateModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChangeViewModule, [{
        type: NgModule,
        args: [{
                declarations: [ChangeViewComponent, ChangeSidesheetComponent],
                imports: [
                    CommonModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    MatCardModule,
                    CdrModule,
                    QbmModule,
                    TranslateModule,
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ChangeViewModule, { declarations: [ChangeViewComponent, ChangeSidesheetComponent], imports: [CommonModule,
        EuiCoreModule,
        EuiMaterialModule,
        DataSourceToolbarModule,
        DataTableModule,
        MatCardModule,
        CdrModule,
        QbmModule,
        TranslateModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    router;
    menuService;
    constructor(router, menuService) {
        this.router = router;
        this.menuService = menuService;
        this.setupMenu();
    }
    onInit(routes) {
        this.addRoutes(routes);
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, groups) => {
            const items = [];
            if (groups.includes('UCI_4_CLOUD_OPERATOR') ||
                // || groups.includes('UCI_4_CLOUD_AUDITOR')
                groups.includes('UCI_4_CLOUD_ADMINISTRATOR')) {
                items.push({
                    id: 'UCI_PendingOperations',
                    route: 'provisioning',
                    title: '#LDS#Menu Entry Pending provisioning processes',
                    sorting: '30-40',
                });
            }
            if (items.length === 0) {
                return undefined;
            }
            return {
                id: 'OpsWeb_ROOT_Synchronization',
                title: '#LDS#Synchronization',
                sorting: '30',
                items,
            };
        });
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i1$1.Router), i0.ɵɵinject(i5.MenuService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i1$1.Router }, { type: i5.MenuService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'provisioning',
        component: ChangeViewComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService],
    },
];
class UciConfigModule {
    initializer;
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 UCI loaded');
        this.initializer.onInit(routes);
        console.log('▶️ UCI initialized');
    }
    static ɵfac = function UciConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || UciConfigModule)(i0.ɵɵinject(InitService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: UciConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, RouterModule.forChild(routes), ChangeViewModule, TranslateModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UciConfigModule, [{
        type: NgModule,
        args: [{
                declarations: [],
                imports: [CommonModule, RouterModule.forChild(routes), ChangeViewModule, TranslateModule],
            }]
    }], () => [{ type: InitService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(UciConfigModule, { imports: [CommonModule, i1$1.RouterModule, ChangeViewModule, TranslateModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

/**
 * Generated bundle index. Do not edit.
 */

export { UciConfigModule };
//# sourceMappingURL=uci.mjs.map
