export { UciConfigModule } from './lib/uci-config.module';
