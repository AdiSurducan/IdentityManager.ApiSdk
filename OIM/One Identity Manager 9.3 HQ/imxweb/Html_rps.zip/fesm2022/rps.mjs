import * as i0 from '@angular/core';
import { Injectable, EventEmitter, ElementRef, Component, Inject, Input, forwardRef, ViewChild, NgModule } from '@angular/core';
import * as i1$2 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i1 from 'qbm';
import { BaseCdr, calculateSidesheetWidth, BusyService, DataViewSource, DataViewModule, RouteGuardService, CdrModule, ConfirmationModule, DataSourceToolbarModule, DataTableModule, LdsReplaceModule, MultiSelectFormcontrolModule, UserMessageModule, BusyIndicatorModule, BaseReadonlyCdr, SqlWizardComponent, HELP_CONTEXTUAL, HelpContextualComponent, SqlWizardApiService, OrderedListModule, SqlWizardModule, SelectedElementsModule, HelpContextualModule } from 'qbm';
import * as i5 from 'qer';
import { ParameterContainer, RequestableEntitlementType } from 'qer';
import * as i4 from '@angular/cdk/overlay';
import { OverlayModule } from '@angular/cdk/overlay';
import * as i3 from '@angular/common/http';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import * as i1$1 from '@elemental-ui/core';
import { EuiDownloadDirective, EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i3$2 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import { V2Client, TypedClient, V2ApiClientMethodFactory, PortalReports, PortalReportsEdit } from '@imx-modules/imx-api-rps';
import { TypedEntityBuilder, MethodDefinition, DisplayColumns, ValType, isExpressionInvalid } from '@imx-modules/imx-qbm-dbts';
import * as i10 from '@angular/forms';
import { UntypedFormGroup, UntypedFormControl, NG_VALUE_ACCESSOR, FormGroup, FormControl, Validators, FormArray, UntypedFormArray, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i3$1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i4$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i5$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i9 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i10$1 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i9$1 from '@angular/material/radio';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';
import * as i5$2 from '@angular/material/form-field';
import * as i6 from '@angular/material/input';
import * as i7 from '@angular/material/list';
import { BehaviorSubject } from 'rxjs';
import * as i5$3 from '@angular/material/stepper';
import { ScrollingModule } from '@angular/cdk/scrolling';
import _ from 'lodash';
import * as i8 from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import { DragDropModule } from '@angular/cdk/drag-drop';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RpsApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing RPS API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function RpsApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RpsApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RpsApiService, factory: RpsApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RpsApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i1.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportParameterWrapper {
    translationService;
    logger;
    parameters;
    getFkProviderItems;
    typedEntity;
    startWriteData = new EventEmitter();
    endWriteData = new EventEmitter();
    columns;
    container;
    constructor(translationService, logger, parameters, getFkProviderItems, typedEntity) {
        this.translationService = translationService;
        this.logger = logger;
        this.parameters = parameters;
        this.getFkProviderItems = getFkProviderItems;
        this.typedEntity = typedEntity;
        this.container = new ParameterContainer(this.translationService, this.getFkProviderItems, this.logger, this.typedEntity);
        this.container.updateExtendedDataTriggered.subscribe((columnName) => {
            this.logger.debug(this, 'Start writing');
            this.startWriteData.emit(columnName);
        });
        this.columns = this.createInteractiveParameterColumns();
    }
    unsubscribeEvents() {
        this.container.updateExtendedDataTriggered.unsubscribe();
    }
    /** Builds a set of entity columns for a simple array of parameters. */
    createInteractiveParameterColumns() {
        const columns = [];
        if (this.typedEntity?.onChangeExtendedDataRead) {
            this.typedEntity?.onChangeExtendedDataRead(() => {
                // new parameters from server --> sync local entity
                const newParameters = this.typedEntity.extendedDataRead[0];
                newParameters.forEach((parameter) => {
                    if (parameter.Property?.ColumnName) {
                        this.container.update(parameter.Property.ColumnName, parameter);
                    }
                    // TODO: remove parameters not returned by the server
                });
                this.logger.debug(this, 'End writing');
                this.endWriteData.emit();
            });
        }
        this.parameters?.forEach((parameter) => {
            if (parameter.Property?.ColumnName) {
                const extendedDataGenerator = (newValue) => [
                    [
                        {
                            Name: parameter?.Property?.ColumnName,
                            Value: newValue,
                        },
                    ],
                ];
                const column = this.container.add(parameter.Property.ColumnName, parameter, extendedDataGenerator);
                if (column)
                    columns.push(column);
            }
        });
        return columns;
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportSubscription {
    subscription;
    getFkProviderItem;
    columnsWithParameterReload = ['UID_RPSReport'];
    reportEntityWrapper;
    hasParameter;
    parameterColumns = [];
    parameterNames;
    startWriteData = new EventEmitter();
    endWriteData = new EventEmitter();
    constructor(subscription, translationService, getFkProviderItem, parameterDataService) {
        this.subscription = subscription;
        this.getFkProviderItem = getFkProviderItem;
        this.reportEntityWrapper = new ReportParameterWrapper(translationService, parameterDataService.logger, this.subscription?.extendedDataRead?.length ? this.subscription.extendedDataRead[0] : [], (parameterData) => this.getFkProviderItem(this.subscription, parameterData), this.subscription);
        this.hasParameter = this.subscription?.extendedDataRead?.[0]?.length > 0;
        this.parameterColumns = this.hasParameter ? this.reportEntityWrapper.columns : [];
        this.parameterNames = this.parameterColumns.map((elem) => elem.ColumnName);
        this.reportEntityWrapper.startWriteData.subscribe((elem) => this.startWriteData.emit(elem));
        this.reportEntityWrapper.endWriteData.subscribe(() => this.endWriteData.emit());
    }
    getCdrs(properties) {
        if (!this.subscription) {
            return [];
        }
        const columns = properties.length === 0
            ? [
                this.subscription.Ident_RPSSubscription.Column,
                this.subscription.UID_RPSReport.Column,
                this.subscription.UID_DialogSchedule.Column,
                this.subscription.ExportFormat.Column,
                this.subscription.AddtlSubscribers.Column,
            ]
            : properties.map((prop) => this.subscription.GetEntity().GetColumn(prop.ColumnName ?? ''));
        return columns.map((col) => new BaseCdr(col));
    }
    getParameterCdr(hiddenColumns = []) {
        return this.parameterColumns.filter(elem => hiddenColumns.indexOf(elem.ColumnName) === -1).map((col) => new BaseCdr(col));
    }
    async fillColumnsWithPreset(presetParameter) {
        Object.entries(presetParameter).forEach(async ([key, value]) => {
            const test = this.parameterColumns.find((elem) => elem.ColumnName === key);
            await test?.PutValue(value);
        });
    }
    getParameterDictionary() {
        const ret = {};
        this.parameterColumns.forEach((elem) => (ret[elem.ColumnName] = elem.GetValue()));
        return ret;
    }
    getDisplayableColums() {
        return [
            this.subscription.Ident_RPSSubscription.Column,
            this.subscription.UID_RPSReport.Column,
            this.subscription.UID_DialogSchedule.Column,
            this.subscription.ExportFormat.Column,
            this.subscription.AddtlSubscribers.Column,
        ].concat(this.parameterColumns);
    }
    async submit(reload = false) {
        this.subscription.extendedData = [this.parameterColumns.map((col) => ({ Name: col.ColumnName, Value: col.GetValue() }))];
        return this.subscription.GetEntity().Commit(reload);
    }
    unsubscribeEvents() {
        this.reportEntityWrapper.endWriteData.unsubscribe();
        this.reportEntityWrapper.startWriteData.unsubscribe();
        this.reportEntityWrapper.unsubscribeEvents();
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportSubscriptionService {
    api;
    elementalUiConfigService;
    config;
    http;
    overlay;
    injector;
    translator;
    parameterDataService;
    downloadService;
    apiMethodFactory = new V2ApiClientMethodFactory();
    constructor(api, elementalUiConfigService, config, http, overlay, injector, translator, parameterDataService, downloadService) {
        this.api = api;
        this.elementalUiConfigService = elementalUiConfigService;
        this.config = config;
        this.http = http;
        this.overlay = overlay;
        this.injector = injector;
        this.translator = translator;
        this.parameterDataService = parameterDataService;
        this.downloadService = downloadService;
    }
    get PortalSubscriptionInteractiveSchema() {
        return this.api.typedClient.PortalSubscriptionInteractive.GetSchema();
    }
    async getReportCandidates(parameter) {
        const candidates = await this.api.client.portal_subscription_interactive_UID_RPSReport_candidates_get(parameter);
        const reportBuilder = new TypedEntityBuilder(PortalReports);
        return reportBuilder.buildReadWriteEntities(candidates, this.api.typedClient.PortalReports.GetSchema());
    }
    buildRpsSubscription(subscription) {
        return new ReportSubscription(subscription, this.translator, (entity, data) => this.getFkProvider(entity, data), this.parameterDataService);
    }
    async createNewSubscription(uidReport, suffix) {
        const subscription = await this.api.typedClient.PortalSubscriptionInteractive.Get();
        await subscription.Data[0].UID_RPSReport.Column.PutValue(uidReport);
        await subscription.Data[0].Ident_RPSSubscription.Column.PutValue(subscription.Data[0].UID_RPSReport.Column.GetDisplayValue() + (suffix ?? ''));
        const allowedFormats = subscription.Data[0].ExportFormat.Column.GetMetadata().GetLimitedValues();
        if (allowedFormats && allowedFormats.filter((f) => f.Value == 'PDF').length > 0) {
            await subscription.Data[0].ExportFormat.Column.PutValue('PDF');
        }
        return this.buildRpsSubscription(subscription.Data[0]);
    }
    downloadSubsciption(subscription) {
        const parameters = subscription.subscription.enrichMethodCallParameters();
        const def = new MethodDefinition(this.apiMethodFactory.portal_subscription_interactive_report_get(parameters.entityid, parameters));
        // not pretty, but the download directive does not support dynamic URLs
        const directive = new EuiDownloadDirective(new ElementRef('') /* no element */, this.http, this.overlay, this.injector, this.downloadService);
        directive.downloadOptions = {
            ...this.elementalUiConfigService.Config.downloadOptions,
            fileMimeType: '', // override elementalUiConfigService; get mime type from server
            url: this.config.BaseUrl + def.path,
            disableElement: false,
        };
        // start the report download
        directive.onClick();
    }
    getFkProvider(subscription, parameterData) {
        var api = this.api;
        return new (class {
            getProviderItem(_columnName, fkTableName) {
                if (parameterData?.Property?.FkRelation) {
                    return this.getFkProviderItem(subscription, _columnName, parameterData?.Property?.FkRelation?.ParentTableName, parameterData?.Property?.FkRelation?.ParentColumnName);
                }
                if (parameterData?.Property?.ValidReferencedTables) {
                    const t = parameterData.Property.ValidReferencedTables.map((parentTableRef) => this.getFkProviderItem(subscription, parameterData?.Property?.ColumnName, parentTableRef?.TableName, 'XObjectKey')).filter((t) => t.fkTableName == fkTableName);
                    if (t.length == 1)
                        return t[0];
                }
                return this.getFkProviderItem(subscription);
            }
            getFkProviderItem(subscription, columnName = '', fkTableName = '', fkColumnName = '') {
                return {
                    columnName,
                    fkTableName,
                    fkColumnName,
                    parameterNames: ['OrderBy', 'StartIndex', 'PageSize', 'filter', 'withProperties', 'search'],
                    load: async (__entity, parameters) => {
                        return api.client.portal_subscription_interactive_parameter_candidates_post(columnName, fkTableName, subscription.InteractiveEntityWriteData, parameters);
                    },
                    getDataModel: async () => ({}),
                    getFilterTree: async (__entity, parentkey) => {
                        return api.client.portal_subscription_interactive_parameter_candidates_filtertree_post(columnName, fkTableName, subscription.InteractiveEntityWriteData, { parentkey });
                    },
                };
            }
        })();
    }
    async sendViaMail(uid) {
        return this.api.client.portal_subscription_sendmail_post(uid);
    }
    static ɵfac = function ReportSubscriptionService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ReportSubscriptionService)(i0.ɵɵinject(RpsApiService), i0.ɵɵinject(i1.ElementalUiConfigService), i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i3.HttpClient), i0.ɵɵinject(i4.Overlay), i0.ɵɵinject(i0.Injector), i0.ɵɵinject(i1.ImxTranslationProviderService), i0.ɵɵinject(i5.ParameterDataService), i0.ɵɵinject(i1$1.EuiDownloadService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ReportSubscriptionService, factory: ReportSubscriptionService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportSubscriptionService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: RpsApiService }, { type: i1.ElementalUiConfigService }, { type: i1.AppConfigService }, { type: i3.HttpClient }, { type: i4.Overlay }, { type: i0.Injector }, { type: i1.ImxTranslationProviderService }, { type: i5.ParameterDataService }, { type: i1$1.EuiDownloadService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ParameterSidesheetComponent_imx_cdr_editor_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 6);
    i0.ɵɵlistener("controlCreated", function ParameterSidesheetComponent_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { const cdr_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.addFormControl(cdr_r2.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r2 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r2);
} }
function ParameterSidesheetComponent_mat_spinner_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner", 7);
} }
class ParameterSidesheetComponent {
    sidesheetRef;
    changeDetectorRef;
    data;
    reportFormGroup = new UntypedFormGroup({});
    cdrs;
    writeOperators = 1;
    constructor(sidesheetRef, changeDetectorRef, data, logger) {
        this.sidesheetRef = sidesheetRef;
        this.changeDetectorRef = changeDetectorRef;
        this.data = data;
        data.subscription.reportEntityWrapper.startWriteData.subscribe(() => {
            this.writeOperators = this.writeOperators + 1;
            logger.debug(this, 'number of write operations:', this.writeOperators);
            changeDetectorRef.detectChanges();
        });
        data.subscription.reportEntityWrapper.endWriteData.subscribe(() => {
            this.writeOperators = this.writeOperators - 1;
            logger.debug(this, 'number of write operations:', this.writeOperators);
            changeDetectorRef.detectChanges();
        });
    }
    async ngOnInit() {
        if (this.data.presetParameter) {
            await this.data.subscription.fillColumnsWithPreset(this.data.presetParameter);
            this.cdrs = this.data.subscription.getParameterCdr(Object.entries(this.data.presetParameter).map((elem) => elem[0]));
        }
        else {
            this.cdrs = this.data.subscription.getParameterCdr();
        }
    }
    addFormControl(name, control) {
        this.reportFormGroup.addControl(name, control);
        this.changeDetectorRef.detectChanges();
    }
    async viewReport() {
        this.sidesheetRef.close(true);
    }
    static ɵfac = function ParameterSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ParameterSidesheetComponent)(i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.ClassloggerService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ParameterSidesheetComponent, selectors: [["imx-parameter-sidesheet"]], decls: 9, vars: 7, consts: [["eui-sidesheet-content", ""], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["diameter", "30", "class", "imx-margin-right-10", 4, "ngIf"], ["data-imx-identifier", "parameter-sidesheet-show-report-button", "mat-flat-button", "", "color", "primary", 3, "click", "disabled"], [3, "controlCreated", "cdr"], ["diameter", "30", 1, "imx-margin-right-10"]], template: function ParameterSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "form", 1);
            i0.ɵɵtemplate(3, ParameterSidesheetComponent_imx_cdr_editor_3_Template, 1, 1, "imx-cdr-editor", 2);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(4, "div", 3);
            i0.ɵɵtemplate(5, ParameterSidesheetComponent_mat_spinner_5_Template, 1, 0, "mat-spinner", 4);
            i0.ɵɵelementStart(6, "button", 5);
            i0.ɵɵlistener("click", function ParameterSidesheetComponent_Template_button_click_6_listener() { return ctx.viewReport(); });
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.reportFormGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.cdrs);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.writeOperators > 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("disabled", ctx.reportFormGroup.invalid || ctx.writeOperators > 0);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 5, "#LDS#View report"), " ");
        } }, dependencies: [i3$1.NgForOf, i3$1.NgIf, i1.CdrEditorComponent, i4$1.MatButton, i5$1.MatProgressSpinner, i9.MatCard, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i10.ɵNgNoValidate, i10.NgControlStatusGroup, i10.FormGroupDirective, i3$2.TranslatePipe], encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ParameterSidesheetComponent, [{
        type: Component,
        args: [{ selector: 'imx-parameter-sidesheet', template: "<div eui-sidesheet-content>\n  <mat-card>\n    <form [formGroup]=\"reportFormGroup\">\n      <imx-cdr-editor *ngFor=\"let cdr of cdrs\" [cdr]=\"cdr\" (controlCreated)=\"addFormControl(cdr.column.ColumnName, $event)\">\n      </imx-cdr-editor>\n    </form>\n  </mat-card>\n</div>\n<div eui-sidesheet-actions>\n  <mat-spinner diameter=\"30\" class=\"imx-margin-right-10\" *ngIf=\"writeOperators > 0\"></mat-spinner>\n  <button\n    data-imx-identifier=\"parameter-sidesheet-show-report-button\"\n    mat-flat-button\n    color=\"primary\"\n    [disabled]=\"reportFormGroup.invalid || writeOperators > 0\"\n    (click)=\"viewReport()\"\n  >\n    {{ '#LDS#View report' | translate }}\n  </button>\n</div>\n" }]
    }], () => [{ type: i1$1.EuiSidesheetRef }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1.ClassloggerService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ParameterSidesheetComponent, { className: "ParameterSidesheetComponent", filePath: "lib\\report-button\\parameter-sidesheet\\parameter-sidesheet.component.ts", lineNumber: 37 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ReportButtonComponent_button_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 1);
    i0.ɵɵlistener("click", function ReportButtonComponent_button_0_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.viewReport()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, ctx_r1.inputData.caption), "\n");
} }
class ReportButtonComponent {
    elementalUiConfigService;
    config;
    http;
    injector;
    reportSubscriptionService;
    overlay;
    busy;
    system;
    sideSheet;
    translator;
    userModelService;
    downloadService;
    downloadOptions;
    inputData;
    isButtonRendered = true;
    referrer;
    subscription;
    apiMethodFactory = new V2ApiClientMethodFactory();
    constructor(elementalUiConfigService, config, http, injector, reportSubscriptionService, overlay, busy, system, sideSheet, translator, userModelService, downloadService) {
        this.elementalUiConfigService = elementalUiConfigService;
        this.config = config;
        this.http = http;
        this.injector = injector;
        this.reportSubscriptionService = reportSubscriptionService;
        this.overlay = overlay;
        this.busy = busy;
        this.system = system;
        this.sideSheet = sideSheet;
        this.translator = translator;
        this.userModelService = userModelService;
        this.downloadService = downloadService;
    }
    ngOnDestroy() {
        this.subscription?.unsubscribeEvents;
    }
    async ngOnInit() {
        if (this.inputData.groups && this.inputData.preprop) {
            this.isButtonRendered = true;
            return;
        }
        const over = this.busy.show();
        try {
            const preprops = (await this.system.get())?.PreProps?.map((elem) => elem?.toUpperCase() ?? '') ?? [];
            const user = (await this.userModelService.getGroups()).map((elem) => elem?.Name?.toUpperCase() ?? '');
            const userFeatures = (await this.userModelService.getFeatures()).Features ?? [];
            const pre = !this.inputData.preprop || this.inputData.preprop.some((elem) => preprops.find((item) => item === elem.toUpperCase()));
            const groups = !this.inputData.groups || this.inputData.groups.some((elem) => user.find((item) => item.toUpperCase() === elem.toUpperCase()));
            const features = this.inputData?.features?.some((feature) => userFeatures.find((userFeature) => feature === userFeature));
            this.isButtonRendered = pre && (groups || !!features);
        }
        finally {
            this.busy.hide(over);
        }
    }
    async viewReport() {
        const over = this.busy.show();
        if (this.subscription) {
            this.subscription.unsubscribeEvents();
            this.subscription = undefined;
        }
        try {
            this.subscription = await this.reportSubscriptionService.createNewSubscription(this.inputData.uidReport);
        }
        finally {
            this.busy.hide(over);
        }
        this.subscription.subscription.ExportFormat.value = 'PDF';
        if (this.subscription.hasParameter) {
            const result = await this.sideSheet
                .open(ParameterSidesheetComponent, {
                title: await this.translator.get('#LDS#Heading Specify Parameters').toPromise(),
                subTitle: await this.translator.get(this.inputData.caption).toPromise(),
                padding: '0px',
                width: calculateSidesheetWidth(),
                testId: 'report-button-view-parameter-sidesheet',
                data: { subscription: this.subscription },
            })
                .afterClosed()
                .toPromise();
            if (!result) {
                return;
            }
        }
        const parameters = this.subscription.subscription.enrichMethodCallParameters();
        const def = new MethodDefinition(this.apiMethodFactory.portal_subscription_interactive_report_get(parameters.entityid, parameters));
        // not pretty, but the download directive does not support dynamic URLs
        const directive = new EuiDownloadDirective(new ElementRef('') /* no element */, this.http, this.overlay, this.injector, this.downloadService);
        directive.downloadOptions = {
            ...this.elementalUiConfigService.Config.downloadOptions,
            fileMimeType: '', // override elementalUiConfigService; get mime type from server
            url: this.config.BaseUrl + def.path,
            disableElement: false,
        };
        // start the report download
        directive.onClick();
    }
    static ɵfac = function ReportButtonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ReportButtonComponent)(i0.ɵɵdirectiveInject(i1.ElementalUiConfigService), i0.ɵɵdirectiveInject(i1.AppConfigService), i0.ɵɵdirectiveInject(i3.HttpClient), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(ReportSubscriptionService), i0.ɵɵdirectiveInject(i4.Overlay), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i1.SystemInfoService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$2.TranslateService), i0.ɵɵdirectiveInject(i5.UserModelService), i0.ɵɵdirectiveInject(i1$1.EuiDownloadService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ReportButtonComponent, selectors: [["imx-report-button"]], decls: 1, vars: 1, consts: [["mat-menu-item", "", "data-imx-identifier", "report-button-ext-menu-item", 3, "click", 4, "ngIf"], ["mat-menu-item", "", "data-imx-identifier", "report-button-ext-menu-item", 3, "click"]], template: function ReportButtonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, ReportButtonComponent_button_0_Template, 3, 3, "button", 0);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.isButtonRendered);
        } }, dependencies: [i3$1.NgIf, i10$1.MatMenuItem, i3$2.TranslatePipe] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportButtonComponent, [{
        type: Component,
        args: [{ selector: 'imx-report-button', template: "<button *ngIf=\"isButtonRendered\" mat-menu-item data-imx-identifier=\"report-button-ext-menu-item\" (click)=\"viewReport()\">\n  {{ inputData.caption | translate }}\n</button>\n" }]
    }], () => [{ type: i1.ElementalUiConfigService }, { type: i1.AppConfigService }, { type: i3.HttpClient }, { type: i0.Injector }, { type: ReportSubscriptionService }, { type: i4.Overlay }, { type: i1$1.EuiLoadingService }, { type: i1.SystemInfoService }, { type: i1$1.EuiSidesheetService }, { type: i3$2.TranslateService }, { type: i5.UserModelService }, { type: i1$1.EuiDownloadService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ReportButtonComponent, { className: "ReportButtonComponent", filePath: "lib\\report-button\\report-button.component.ts", lineNumber: 47 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportButtonMailComponent {
    reportSubscriptionService;
    busy;
    sideSheet;
    translator;
    snackbarService;
    referrer;
    subscription;
    constructor(reportSubscriptionService, busy, sideSheet, translator, snackbarService) {
        this.reportSubscriptionService = reportSubscriptionService;
        this.busy = busy;
        this.sideSheet = sideSheet;
        this.translator = translator;
        this.snackbarService = snackbarService;
    }
    ngOnDestroy() {
        this.subscription?.unsubscribeEvents;
    }
    async sendReport() {
        let over = this.busy.show();
        try {
            if (this.subscription != null) {
                this.subscription.unsubscribeEvents();
                this.subscription = undefined;
            }
            this.subscription = await this.reportSubscriptionService.createNewSubscription(this.referrer.uid, Date.now().toFixed());
        }
        finally {
            this.busy.hide(over);
        }
        if (!this.subscription) {
            return;
        }
        this.subscription.subscription.ExportFormat.value = 'PDF';
        if (this.hasParametersToCompleteByUser()) {
            const result = await this.sideSheet
                .open(ParameterSidesheetComponent, {
                title: await this.translator.get('#LDS#Heading Specify Parameters').toPromise(),
                padding: '0px',
                width: calculateSidesheetWidth(),
                testId: 'report-button-view-parameter-sidesheet',
                data: { subscription: this.subscription, presetParameter: this.referrer?.presetParameters },
            })
                .afterClosed()
                .toPromise();
            if (!result) {
                return;
            }
        }
        let errors = false;
        over = this.busy.show();
        try {
            await this.subscription.submit();
            await this.reportSubscriptionService.sendViaMail(this.subscription.subscription.GetEntity().GetKeys()[0]);
        }
        catch {
            errors = true;
        }
        finally {
            this.busy.hide(over);
            if (!errors) {
                this.snackbarService.open({
                    key: '#LDS#The report "{0}" will be sent to you.',
                    parameters: [this.subscription.subscription.UID_RPSReport.Column.GetDisplayValue()],
                });
            }
        }
    }
    hasParametersToCompleteByUser() {
        if (!this.referrer?.presetParameters) {
            return this.subscription?.hasParameter || false;
        }
        const presetParameter = Object.entries(this.referrer.presetParameters).map((elem) => elem[0]);
        return !!this.subscription?.parameterNames.filter((elem) => presetParameter.indexOf(elem) === -1);
    }
    static ɵfac = function ReportButtonMailComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ReportButtonMailComponent)(i0.ɵɵdirectiveInject(ReportSubscriptionService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$2.TranslateService), i0.ɵɵdirectiveInject(i1.SnackBarService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ReportButtonMailComponent, selectors: [["ng-component"]], decls: 3, vars: 3, consts: [["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "report-button-ext-button", 3, "click"]], template: function ReportButtonMailComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵlistener("click", function ReportButtonMailComponent_Template_button_click_0_listener() { return ctx.sendReport(); });
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Send report to me"), "\n");
        } }, dependencies: [i4$1.MatButton, i3$2.TranslatePipe] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportButtonMailComponent, [{
        type: Component,
        args: [{ template: "<button mat-stroked-button color=\"primary\" data-imx-identifier=\"report-button-ext-button\" (click)=\"sendReport()\">\n  {{ '#LDS#Send report to me' | translate }}\n</button>\n" }]
    }], () => [{ type: ReportSubscriptionService }, { type: i1$1.EuiLoadingService }, { type: i1$1.EuiSidesheetService }, { type: i3$2.TranslateService }, { type: i1.SnackBarService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ReportButtonMailComponent, { className: "ReportButtonMailComponent", filePath: "lib\\report-button\\report-button-mail.component.ts", lineNumber: 40 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * A component, that displays the data of a list report
 *
 * Example:
 * code behind:
 *          dataService:ListReportDataProvider = {...};
 *          reportParameter:{ [key: string]: any } = {...};
 * html:
 *          <imx-list-report-viewer [dataService]="dataService" [reportParameter]="reportParameter"></imx-list-report-viewer>
 */
class ListReportViewerComponent {
    logger;
    dataSource;
    /**
     * the data service, that is used for API communication
     */
    dataService;
    /**
     * Report parameter, that are necessary for the report generation
     */
    reportParameter;
    busyService = new BusyService();
    dstSettings;
    entitySchema;
    groupedData = {};
    dataModel;
    reportColumns;
    navigationState = {};
    constructor(logger, dataSource) {
        this.logger = logger;
        this.dataSource = dataSource;
    }
    async ngOnInit() {
        const isBusy = this.busyService.beginBusy();
        try {
            await this.initData();
            await this.navigate();
        }
        finally {
            isBusy.endBusy();
        }
    }
    /**
     * navigates the list report data
     */
    async navigate() {
        const columnsToDisplay = this.reportColumns.map((elem) => this.entitySchema.Columns[elem]).filter((elem) => !!elem);
        if (columnsToDisplay.length === 0) {
            columnsToDisplay.push(DisplayColumns.DISPLAY_PROPERTY);
            this.logger.warn(this, 'There was a problem, loading the columns. The displays of the objects will be shown instead');
        }
        const dataViewInitParameters = {
            execute: async (params) => {
                this.navigationState = { ...this.navigationState, ...params };
                const data = await this.dataService.get(this.navigationState);
                //Apply new schema to data
                data.Data.forEach((elem) => elem.GetEntity().ApplySchema(this.entitySchema));
                return data;
            },
            groupExecute: (column, params, signal) => {
                return this.dataService.getGroupInfo({
                    ...{ by: column },
                    ...params,
                });
            },
            schema: this.entitySchema,
            columnsToDisplay,
            dataModel: this.dataModel,
            exportFunction: this.dataService.exportReports?.(),
        };
        await this.dataSource.init(dataViewInitParameters);
    }
    /**
     * Initializes the data, that is used for the view
     */
    async initData() {
        this.dataModel = await this.dataService.getDataModel();
        const data = await this.dataService.get({ PageSize: -1 });
        if (data.extendedData?.Columns) {
            this.reportColumns = data.extendedData.Columns;
        }
        // create a copy of listReportSchema and add additional columns to it (because the schema only provides the display at this point) and update the TypeName property
        this.entitySchema = { ...this.dataService.entitySchema, TypeName: data.tableName };
        for (const column of this.reportColumns) {
            this.entitySchema.Columns[column] = data.extendedData?.AdditionalProperties?.find((elem) => elem.ColumnName === column);
        }
        this.navigationState = { ...this.navigationState };
        if (this.reportParameter) {
            this.navigationState.parameters = this.reportParameter;
        }
    }
    static ɵfac = function ListReportViewerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ListReportViewerComponent)(i0.ɵɵdirectiveInject(i1.ClassloggerService), i0.ɵɵdirectiveInject(i1.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ListReportViewerComponent, selectors: [["imx-list-report-viewer"]], inputs: { dataService: "dataService", reportParameter: "reportParameter" }, features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 4, vars: 3, consts: [[1, "imx-card-fill", "imx-margin-right-3", "imx-margin-bottom-3"], [3, "dataSource"], ["mode", "auto", 3, "dataSource"]], template: function ListReportViewerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card", 0);
            i0.ɵɵelement(1, "imx-data-view-toolbar", 1)(2, "imx-data-view-auto-table", 2)(3, "imx-data-view-paginator", 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataSource", ctx.dataSource);
        } }, dependencies: [i9.MatCard, i1.DataViewAutoTableComponent, i1.DataViewPaginatorComponent, i1.DataViewToolbarComponent], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListReportViewerComponent, [{
        type: Component,
        args: [{ selector: 'imx-list-report-viewer', providers: [DataViewSource], template: "<mat-card class=\"imx-card-fill imx-margin-right-3 imx-margin-bottom-3\">\n  <imx-data-view-toolbar [dataSource]=\"dataSource\"></imx-data-view-toolbar>\n  <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"auto\"></imx-data-view-auto-table>\n  <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n</mat-card>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}\n"] }]
    }], () => [{ type: i1.ClassloggerService }, { type: i1.DataViewSource }], { dataService: [{
            type: Input
        }], reportParameter: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ListReportViewerComponent, { className: "ListReportViewerComponent", filePath: "lib\\list-report-viewer\\list-report-viewer.component.ts", lineNumber: 64 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ListReportViewerSidesheetComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 3)(1, "button", 4);
    i0.ɵɵlistener("click", function ListReportViewerSidesheetComponent_div_2_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.downloadReport()); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Download report"), " ");
} }
/**
 * Represents the content of a side sheet, that shows the data of a list report
 * Uses the following side sheet data:
 *  dataService:   a {@link ListReportDataProvider} that handles the api calls
 *  subscription:  an optional {@link ReportSubscription}
 */
class ListReportViewerSidesheetComponent {
    data;
    reportSubscriptionService;
    /**
     * A set of report parameter
     */
    reportParameter;
    constructor(data, reportSubscriptionService) {
        this.data = data;
        this.reportSubscriptionService = reportSubscriptionService;
        if (data.subscription) {
            this.reportParameter = data.subscription.getParameterDictionary();
        }
    }
    /**
     * Downloads the subscription
     */
    async downloadReport() {
        if (this.data.subscription) {
            this.reportSubscriptionService.downloadSubsciption(this.data.subscription);
        }
    }
    static ɵfac = function ListReportViewerSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ListReportViewerSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(ReportSubscriptionService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ListReportViewerSidesheetComponent, selectors: [["imx-list-report-viewer-sidesheet"]], decls: 3, vars: 3, consts: [["eui-sidesheet-content", "", 1, "imx-flex-content"], [3, "dataService", "reportParameter"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["color", "primary", "mat-flat-button", "", "data-imx-identifier", "view-config-download-report-button", 3, "click"]], template: function ListReportViewerSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "imx-list-report-viewer", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(2, ListReportViewerSidesheetComponent_div_2_Template, 4, 3, "div", 2);
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("dataService", ctx.data.dataService)("reportParameter", ctx.reportParameter);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.subscription);
        } }, dependencies: [i3$1.NgIf, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i4$1.MatButton, ListReportViewerComponent, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   .imx-flex-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListReportViewerSidesheetComponent, [{
        type: Component,
        args: [{ selector: 'imx-list-report-viewer-sidesheet', template: "<div eui-sidesheet-content class=\"imx-flex-content\">\n  <imx-list-report-viewer [dataService]=\"data.dataService\" [reportParameter]=\"reportParameter\"></imx-list-report-viewer>\n</div>\n<div eui-sidesheet-actions *ngIf=\"data.subscription\">\n  <button color=\"primary\" mat-flat-button (click)=\"downloadReport()\" data-imx-identifier=\"view-config-download-report-button\">\n    {{ '#LDS#Download report' | translate }}\n  </button>\n</div>\n", styles: [":host{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}:host .imx-flex-content{display:flex;flex-direction:column}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: ReportSubscriptionService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ListReportViewerSidesheetComponent, { className: "ListReportViewerSidesheetComponent", filePath: "lib\\subscriptions\\list-report-viewer-sidesheet\\list-report-viewer-sidesheet.component.ts", lineNumber: 44 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Implements a {@link ListReportDataProvider} to get the list report data for a statistic
 */
class StatisticReportButtonService {
    api;
    constructor(api) {
        this.api = api;
    }
    idStatistic;
    /**
     * Sets the statistic id used by this service
     * @param value the id of a statistic
     */
    setIdStatistic(value) {
        this.idStatistic = value;
    }
    get entitySchema() {
        return this.api.typedClient.PortalStatisticsData.GetSchema();
    }
    async getDataModel() {
        if (!this.idStatistic) {
            throw 'setIdStatistic(...) has to be called with a valid id';
        }
        return this.api.client.portal_statistics_data_datamodel_get(this.idStatistic);
    }
    async get(param) {
        if (!this.idStatistic) {
            throw 'setIdStatistic(...) has to be called with a valid id';
        }
        return this.api.typedClient.PortalStatisticsData.Get(this.idStatistic, param);
    }
    getGroupInfo(parameters = {}) {
        if (!this.idStatistic) {
            throw 'setIdStatistic(...) has to be called with a valid id';
        }
        const { withProperties, OrderBy, search, ...params } = parameters;
        return this.api.client.portal_statistics_data_group_get(this.idStatistic, { ...params });
    }
    static ɵfac = function StatisticReportButtonService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StatisticReportButtonService)(i0.ɵɵinject(RpsApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: StatisticReportButtonService, factory: StatisticReportButtonService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StatisticReportButtonService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: RpsApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function StatisticReportButtonComponent_button_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 1);
    i0.ɵɵlistener("click", function StatisticReportButtonComponent_button_0_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.viewReport()); });
    i0.ɵɵelement(1, "eui-icon", 2);
    i0.ɵɵelementStart(2, "span", 3);
    i0.ɵɵtext(3, "#LDS#View source data");
    i0.ɵɵelementEnd()();
} }
class StatisticReportButtonComponent {
    statisticService;
    sideSheet;
    translate;
    referrer;
    constructor(statisticService, sideSheet, translate) {
        this.statisticService = statisticService;
        this.sideSheet = sideSheet;
        this.translate = translate;
    }
    /**
     * Shows the related list report data in a {@link ListReportViewerSidesheetComponent} sidesheet
     */
    viewReport() {
        this.statisticService.setIdStatistic(this.referrer.Id.value);
        const data = { dataService: this.statisticService };
        this.sideSheet.open(ListReportViewerSidesheetComponent, {
            title: this.translate.instant('#LDS#Heading View Source Data'),
            subTitle: this.referrer.GetDisplay(),
            padding: '0',
            width: calculateSidesheetWidth(),
            testId: 'statistic-report-button-report-viewer',
            data,
        });
    }
    static ɵfac = function StatisticReportButtonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StatisticReportButtonComponent)(i0.ɵɵdirectiveInject(StatisticReportButtonService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$2.TranslateService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: StatisticReportButtonComponent, selectors: [["imx-statistic-report-button"]], decls: 1, vars: 1, consts: [["mat-stroked-button", "", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", 3, "click"], ["icon", "reports"], ["translate", ""]], template: function StatisticReportButtonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, StatisticReportButtonComponent_button_0_Template, 4, 0, "button", 0);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.referrer.HasListReport == null ? null : ctx.referrer.HasListReport.value);
        } }, dependencies: [i3$1.NgIf, i4$1.MatButton, i3$2.TranslateDirective, i1$1.EuiIconComponent], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:row}[_nghost-%COMP%]   button[_ngcontent-%COMP%]{display:flex;transition:all .4s ease}[_nghost-%COMP%]   button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{margin-right:4px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StatisticReportButtonComponent, [{
        type: Component,
        args: [{ selector: 'imx-statistic-report-button', template: "<button mat-stroked-button (click)=\"viewReport()\" *ngIf=\"referrer.HasListReport?.value\">\n  <eui-icon icon=\"reports\"></eui-icon>\n  <span translate>#LDS#View source data</span>\n</button>\n", styles: [":host{display:flex;flex-direction:row}:host button{display:flex;transition:all .4s ease}:host button eui-icon{margin-right:4px}\n"] }]
    }], () => [{ type: StatisticReportButtonService }, { type: i1$1.EuiSidesheetService }, { type: i3$2.TranslateService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(StatisticReportButtonComponent, { className: "StatisticReportButtonComponent", filePath: "lib\\statistic-report-button\\statistic-report-button.component.ts", lineNumber: 41 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Implements a {@link ListReportDataProvider} to get the list report data for a given report id
 */
class ListReportViewerService {
    api;
    constructor(api) {
        this.api = api;
    }
    uidReport;
    /**
     * Sets the uid of the report used by this service
     * @param value the uid of a list report
     */
    setUidReport(value) {
        this.uidReport = value;
    }
    get entitySchema() {
        return this.api.typedClient.PortalReportData.GetSchema();
    }
    async getDataModel() {
        if (!this.uidReport) {
            throw 'setUidReport(...) has to be called with a valid uid';
        }
        return this.api.client.portal_report_data_datamodel_get(this.uidReport);
    }
    async get(parameter) {
        if (!this.uidReport) {
            throw 'setUidReport(...) has to be called with a valid uid';
        }
        return this.api.typedClient.PortalReportData.Get(this.uidReport, parameter);
    }
    getGroupInfo(parameters = {}) {
        if (!this.uidReport) {
            throw 'setUidReport(...) has to be called with a valid uid';
        }
        const { withProperties, OrderBy, search, ...params } = parameters;
        return this.api.client.portal_report_data_group_get(this.uidReport, { ...params });
    }
    exportReports() {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, navigationState, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_report_data_get(this.uidReport, { ...navigationState, withProperties, PageSize, StartIndex: 0 });
                }
                else {
                    method = factory.portal_report_data_get(this.uidReport, { ...navigationState, withProperties });
                }
                return new MethodDefinition(method);
            },
        };
    }
    static ɵfac = function ListReportViewerService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ListReportViewerService)(i0.ɵɵinject(RpsApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ListReportViewerService, factory: ListReportViewerService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListReportViewerService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: RpsApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$2 = a0 => ({ height: a0 });
function ReportSelectorComponent_mat_spinner_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner", 7);
} }
function ReportSelectorComponent_mat_list_option_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-list-option", 8)(1, "div", 9)(2, "div", 10);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div", 11);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const candidate_r1 = ctx.$implicit;
    const i_r2 = ctx.index;
    i0.ɵɵproperty("value", candidate_r1);
    i0.ɵɵattribute("data-imx-identifier", "report-selector-selectionList-element-" + i_r2);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(candidate_r1.GetEntity().GetDisplay());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(candidate_r1.Description.Column.GetDisplayValue());
} }
class ReportSelectorComponent {
    changeDetectorRef;
    settings;
    reportSubscriptionService;
    candidatesTotalCount;
    loading = false;
    candidates;
    onChange;
    onTouch;
    searchControl = new UntypedFormControl();
    uidReport;
    parameters;
    subscribers = [];
    controlHeigth = 200;
    constructor(changeDetectorRef, settings, reportSubscriptionService) {
        this.changeDetectorRef = changeDetectorRef;
        this.settings = settings;
        this.reportSubscriptionService = reportSubscriptionService;
    }
    async ngOnInit() {
        this.initSearchControl();
        await this.loadReports({
            StartIndex: 0,
            PageSize: this.settings.PageSizeForAllElements,
            filter: undefined,
            search: undefined,
        });
        this.changeDetectorRef.detectChanges();
    }
    writeValue(filter) {
        this.uidReport = filter;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouch = fn;
    }
    async ngAfterViewInit() {
        this.parameters = { PageSize: this.settings.PageSizeForAllElements, StartIndex: 0 };
        await this.loadReports(this.parameters);
    }
    ngOnDestroy() {
        this.subscribers.forEach((s) => s.unsubscribe());
    }
    updateSelected(elem) {
        // Only one can be selected
        const chosenElem = elem.options.find((ele) => ele.selected);
        if (chosenElem) {
            this.writeValue(chosenElem.value.GetEntity().GetKeys()[0]);
            this.onChange(chosenElem.value.GetEntity().GetKeys()[0]);
        }
    }
    async loadReports(newState) {
        this.loading = true;
        try {
            this.parameters = { ...this.parameters, ...newState };
            this.candidates = (await this.reportSubscriptionService.getReportCandidates(this.parameters)).Data;
        }
        finally {
            this.loading = false;
        }
    }
    initSearchControl() {
        this.searchControl.setValue('');
        this.subscribers.push(this.searchControl.valueChanges.pipe(distinctUntilChanged(), debounceTime(300)).subscribe(async (value) => {
            await this.loadReports({ StartIndex: 0, PageSize: this.settings.PageSizeForAllElements, search: value });
            this.changeDetectorRef.detectChanges();
        }));
    }
    static ɵfac = function ReportSelectorComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ReportSelectorComponent)(i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i1.SettingsService), i0.ɵɵdirectiveInject(ReportSubscriptionService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ReportSelectorComponent, selectors: [["imx-report-selector"]], inputs: { controlHeigth: "controlHeigth" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => ReportSelectorComponent),
                    multi: true,
                },
            ])], decls: 12, vars: 15, consts: [[1, "imx-report-listing"], ["data-imx-identifier", "report-selector-eui-search", "size", "small", 1, "report-selector-eui-search", 3, "placeholder", "searchControl"], ["class", "imx-margin-top-10 imx-margin-left-5", "diameter", "16", 4, "ngIf"], ["appearance", "outline"], ["value", "_hidden", "matInput", "", "hidden", "", 1, "input-hidden", 3, "required"], ["data-imx-identifier", "report-selector-selectionList", 1, "imx-candidate-list", 3, "selectionChange", "multiple", "ngStyle", "hideSingleSelectionIndicator"], ["class", "imx-candidate-option", 3, "value", 4, "ngFor", "ngForOf"], ["diameter", "16", 1, "imx-margin-top-10", "imx-margin-left-5"], [1, "imx-candidate-option", 3, "value"], [1, "imx-candidate-content"], [1, "imx-candidate-display"], [1, "imx-candidate-longdisplay"]], template: function ReportSelectorComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "eui-search", 1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementStart(3, "div");
            i0.ɵɵtemplate(4, ReportSelectorComponent_mat_spinner_4_Template, 1, 0, "mat-spinner", 2);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "mat-form-field", 3)(6, "mat-label");
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(9, "input", 4);
            i0.ɵɵelementStart(10, "mat-selection-list", 5);
            i0.ɵɵlistener("selectionChange", function ReportSelectorComponent_Template_mat_selection_list_selectionChange_10_listener($event) { return ctx.updateSelected($event); });
            i0.ɵɵtemplate(11, ReportSelectorComponent_mat_list_option_11_Template, 6, 4, "mat-list-option", 6);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("placeholder", i0.ɵɵpipeBind1(2, 9, "#LDS#Search"))("searchControl", ctx.searchControl);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.loading);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(8, 11, "#LDS#Report"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("required", true);
            i0.ɵɵadvance();
            i0.ɵɵproperty("multiple", false)("ngStyle", i0.ɵɵpureFunction1(13, _c0$2, ctx.controlHeigth + "px"))("hideSingleSelectionIndicator", true);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.candidates);
        } }, dependencies: [i3$1.NgForOf, i3$1.NgIf, i3$1.NgStyle, i1$1.EuiSearchComponent, i5$2.MatFormField, i5$2.MatLabel, i6.MatInput, i7.MatSelectionList, i7.MatListOption, i5$1.MatProgressSpinner, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{flex:1;display:flex;flex-direction:column}.report-selector-eui-search[_ngcontent-%COMP%]{display:flex}.imx-candidate-list[_ngcontent-%COMP%]{overflow-y:auto;overflow-x:hidden}.imx-candidate-option[_ngcontent-%COMP%]{display:flex;height:auto;margin:10px 0}.imx-candidate-content[_ngcontent-%COMP%]{flex:1;overflow:hidden}.imx-candidate-display[_ngcontent-%COMP%]{font-size:14px;line-height:17px;text-overflow:ellipsis;overflow:hidden}.imx-candidate-longdisplay[_ngcontent-%COMP%]{color:#919799;font-size:12px;text-overflow:ellipsis;overflow:hidden;line-height:17px}.imx-report-listing[_ngcontent-%COMP%]{flex:1;display:grid;grid-template-columns:1fr 21px;margin-right:-21px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportSelectorComponent, [{
        type: Component,
        args: [{ selector: 'imx-report-selector', providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => ReportSelectorComponent),
                        multi: true,
                    },
                ], template: "<div class=\"imx-report-listing\">\n  <eui-search\n    class=\"report-selector-eui-search\"\n    data-imx-identifier=\"report-selector-eui-search\"\n    [placeholder]=\"'#LDS#Search' | translate\"\n    [searchControl]=\"searchControl\"\n    size=\"small\"\n  >\n  </eui-search>\n  <div>\n    <mat-spinner class=\"imx-margin-top-10 imx-margin-left-5\" diameter=\"16\" *ngIf=\"loading\"></mat-spinner>\n  </div>\n</div>\n<mat-form-field appearance=\"outline\">\n  <mat-label>{{ '#LDS#Report' | translate }}</mat-label>\n  <input value=\"_hidden\" matInput hidden [required]=\"true\" class=\"input-hidden\" />\n  <mat-selection-list\n    class=\"imx-candidate-list\"\n    [multiple]=\"false\"\n    [ngStyle]=\"{ height: controlHeigth + 'px' }\"\n    [hideSingleSelectionIndicator]=\"true\"\n    (selectionChange)=\"updateSelected($event)\"\n    data-imx-identifier=\"report-selector-selectionList\"\n  >\n    <mat-list-option\n      *ngFor=\"let candidate of candidates; index as i\"\n      [value]=\"candidate\"\n      class=\"imx-candidate-option\"\n      [attr.data-imx-identifier]=\"'report-selector-selectionList-element-' + i\"\n    >\n      <div class=\"imx-candidate-content\">\n        <div class=\"imx-candidate-display\">{{ candidate.GetEntity().GetDisplay() }}</div>\n        <div class=\"imx-candidate-longdisplay\">{{ candidate.Description.Column.GetDisplayValue() }}</div>\n      </div>\n    </mat-list-option>\n  </mat-selection-list>\n</mat-form-field>\n", styles: [":host{flex:1;display:flex;flex-direction:column}.report-selector-eui-search{display:flex}.imx-candidate-list{overflow-y:auto;overflow-x:hidden}.imx-candidate-option{display:flex;height:auto;margin:10px 0}.imx-candidate-content{flex:1;overflow:hidden}.imx-candidate-display{font-size:14px;line-height:17px;text-overflow:ellipsis;overflow:hidden}.imx-candidate-longdisplay{color:#919799;font-size:12px;text-overflow:ellipsis;overflow:hidden;line-height:17px}.imx-report-listing{flex:1;display:grid;grid-template-columns:1fr 21px;margin-right:-21px}\n"] }]
    }], () => [{ type: i0.ChangeDetectorRef }, { type: i1.SettingsService }, { type: ReportSubscriptionService }], { controlHeigth: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ReportSelectorComponent, { className: "ReportSelectorComponent", filePath: "lib\\subscriptions\\subscription-wizard\\report-selector\\report-selector.component.ts", lineNumber: 50 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ReportViewConfigComponent_mat_card_5_imx_busy_indicator_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-busy-indicator");
} }
function ReportViewConfigComponent_mat_card_5_div_2_mat_radio_group_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-radio-group", 18)(1, "mat-radio-button", 19);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-radio-button", 20);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("value", "view");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 4, "#LDS#View in browser"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("value", "export");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 6, "#LDS#Export"), " ");
} }
function ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 21);
    i0.ɵɵlistener("controlCreated", function ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.addExportControl($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵproperty("cdr", ctx_r1.formatCdr);
} }
function ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_4_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 21);
    i0.ɵɵlistener("controlCreated", function ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_4_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.addFormControl($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r4 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r4);
} }
function ReportViewConfigComponent_mat_card_5_div_2_div_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 22);
    i0.ɵɵelement(1, "eui-icon", 7);
    i0.ɵɵelementStart(2, "p", 8);
    i0.ɵɵtext(3, "#LDS#For this report, no parameters must be specified.");
    i0.ɵɵelementEnd()();
} }
function ReportViewConfigComponent_mat_card_5_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 12)(1, "div", 13);
    i0.ɵɵtemplate(2, ReportViewConfigComponent_mat_card_5_div_2_mat_radio_group_2_Template, 7, 8, "mat-radio-group", 14)(3, ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_3_Template, 1, 1, "imx-cdr-editor", 15);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_4_Template, 1, 1, "imx-cdr-editor", 16)(5, ReportViewConfigComponent_mat_card_5_div_2_div_5_Template, 4, 0, "div", 17);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.isListReport);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.formatCdr && (ctx_r1.reportFormGroup.controls.viewType.value === "export" || !ctx_r1.isListReport));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r1.parameterCdrList);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r1.hasParameter);
} }
function ReportViewConfigComponent_mat_card_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card", 9);
    i0.ɵɵtemplate(1, ReportViewConfigComponent_mat_card_5_imx_busy_indicator_1_Template, 1, 0, "imx-busy-indicator", 10)(2, ReportViewConfigComponent_mat_card_5_div_2_Template, 6, 4, "div", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.isLoading);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r1.isLoading);
} }
class ReportViewConfigComponent {
    sidesheetRef;
    sideSheet;
    reportSubscriptionService;
    cdref;
    translate;
    viewReportService;
    reportFormGroup = new FormGroup({
        viewType: new FormControl('view', { nonNullable: true }),
        reportTable: new FormControl(undefined, { nonNullable: true, validators: Validators.required }),
        exportType: new FormControl(undefined, { nonNullable: true }),
        parameters: new FormArray([]),
    });
    newSubscription;
    parameterCdrList = [];
    formatCdr;
    busyService = new BusyService();
    isLoading = false;
    reportIsLoaded = false;
    isListReport = false;
    uidReport = '';
    subscriptions = [];
    disposable;
    get formControls() {
        return this.reportFormGroup.controls.parameters;
    }
    get hasParameter() {
        return this.reportFormGroup.controls.viewType.value === 'view' && this.isListReport
            ? this.parameterCdrList.filter((elem) => elem.column.ColumnName !== 'ExportFormat').length > 0
            : this.parameterCdrList.length > 0;
    }
    constructor(sidesheetRef, sideSheet, reportSubscriptionService, cdref, translate, viewReportService, errorService) {
        this.sidesheetRef = sidesheetRef;
        this.sideSheet = sideSheet;
        this.reportSubscriptionService = reportSubscriptionService;
        this.cdref = cdref;
        this.translate = translate;
        this.viewReportService = viewReportService;
        this.subscriptions.push(this.sidesheetRef.closeClicked().subscribe(async () => {
            this.sidesheetRef.close(false);
        }));
        this.subscriptions.push(this.busyService.busyStateChanged.subscribe((elem) => {
            this.isLoading = elem;
            this.cdref.detectChanges();
        }));
        this.subscriptions.push(this.reportFormGroup.controls.reportTable.valueChanges.subscribe(async (val) => {
            const isBusy = this.busyService.beginBusy();
            try {
                this.uidReport = val ?? '';
                this.formControls.clear();
                // Standard caption is "Format (e-mail attachment)" -> change
                const format = await this.translate.get('#LDS#Format').toPromise();
                if (val) {
                    this.newSubscription = await this.reportSubscriptionService.createNewSubscription(this.uidReport);
                    this.isListReport = this.newSubscription.subscription.IsListReport.value;
                    // Set PDF as default, but only if the report supports PDF
                    const xformat = this.newSubscription.subscription.ExportFormat;
                    const allowedFormats = xformat.Column.GetMetadata().GetLimitedValues();
                    if (allowedFormats && allowedFormats.filter((f) => f.Value == 'PDF').length > 0) {
                        xformat.value = 'PDF';
                    }
                    this.formatCdr = new BaseCdr(this.newSubscription.subscription.ExportFormat.Column, format);
                    this.parameterCdrList = [...this.newSubscription.getParameterCdr()];
                    this.cdref.detectChanges();
                }
                else
                    this.newSubscription = undefined;
            }
            finally {
                isBusy.endBusy();
                this.reportIsLoaded = !!this.newSubscription;
            }
        }));
        this.disposable = errorService.setTarget('sidesheet');
    }
    ngOnDestroy() {
        // sometimes there are problems with usage of disposed components
        setTimeout(() => {
            this.disposable();
            this.subscriptions.forEach((sub) => sub.unsubscribe());
            this.newSubscription?.unsubscribeEvents();
        });
    }
    async viewReport() {
        if (this.reportFormGroup.controls.viewType.value === 'view' && this.isListReport) {
            await this.viewReportInTable();
        }
        else {
            if (this.newSubscription) {
                this.reportSubscriptionService.downloadSubsciption(this.newSubscription);
            }
        }
    }
    addFormControl(control) {
        this.formControls.push(control);
        this.cdref.detectChanges();
    }
    addExportControl(control) {
        this.reportFormGroup.controls.exportType = control.value;
    }
    async viewReportInTable() {
        this.viewReportService.setUidReport(this.uidReport);
        const data = { dataService: this.viewReportService, subscription: this.newSubscription };
        this.sideSheet.open(ListReportViewerSidesheetComponent, {
            title: await this.translate.get('#LDS#Heading View Report').toPromise(),
            subTitle: this.newSubscription?.subscription.GetEntity().GetDisplay(),
            padding: '0',
            width: calculateSidesheetWidth(),
            testId: 'report-view-config-report-viewer',
            data,
        });
    }
    static ɵfac = function ReportViewConfigComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ReportViewConfigComponent)(i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(ReportSubscriptionService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$2.TranslateService), i0.ɵɵdirectiveInject(ListReportViewerService), i0.ɵɵdirectiveInject(i1.ErrorService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ReportViewConfigComponent, selectors: [["imx-report-view-config"]], decls: 11, vars: 5, consts: [["eui-sidesheet-content", "", 1, "imx-flex-content"], ["panelClass", "imx-small-message", 1, "errormessages", 3, "target"], [1, "imx-report-form", 3, "formGroup"], ["formControlName", "reportTable", 3, "controlHeigth"], ["class", "imx-flex-card", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["color", "primary", "mat-flat-button", "", "data-imx-identifier", "view-config-view-report-button", 3, "click", "disabled"], ["icon", "reports"], ["translate", ""], [1, "imx-flex-card"], [4, "ngIf"], ["class", "imx-cdr-container", 4, "ngIf"], [1, "imx-cdr-container"], [1, "imx-export-type"], ["formControlName", "viewType", 4, "ngIf"], [3, "cdr", "controlCreated", 4, "ngIf"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["class", "imx-no-results", 4, "ngIf"], ["formControlName", "viewType"], ["data-imx-identifier", "export-view-config-view-in-browser", 3, "value"], ["data-imx-identifier", "export-view-config-export", 3, "value"], [3, "controlCreated", "cdr"], [1, "imx-no-results"]], template: function ReportViewConfigComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "imx-usermessage", 1);
            i0.ɵɵelementStart(2, "form", 2)(3, "mat-card");
            i0.ɵɵelement(4, "imx-report-selector", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, ReportViewConfigComponent_mat_card_5_Template, 3, 2, "mat-card", 4);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(6, "div", 5)(7, "button", 6);
            i0.ɵɵlistener("click", function ReportViewConfigComponent_Template_button_click_7_listener() { return ctx.viewReport(); });
            i0.ɵɵelement(8, "eui-icon", 7);
            i0.ɵɵelementStart(9, "span", 8);
            i0.ɵɵtext(10, "#LDS#View report");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("target", "sidesheet");
            i0.ɵɵadvance();
            i0.ɵɵproperty("formGroup", ctx.reportFormGroup);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("controlHeigth", 400);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.reportFormGroup.controls.reportTable.value);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.reportFormGroup.invalid || ctx.isLoading);
        } }, dependencies: [i1.CdrEditorComponent, i3$1.NgForOf, i3$1.NgIf, i1$1.EuiIconComponent, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i4$1.MatButton, i9.MatCard, i9$1.MatRadioGroup, i9$1.MatRadioButton, i10.ɵNgNoValidate, i10.NgControlStatus, i10.NgControlStatusGroup, i10.FormGroupDirective, i10.FormControlName, i3$2.TranslateDirective, i1.UserMessageComponent, i1.BusyIndicatorComponent, ReportSelectorComponent, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   imx-usermessage[_ngcontent-%COMP%]{margin-bottom:16px}[_nghost-%COMP%]   .imx-flex-card[_ngcontent-%COMP%], [_nghost-%COMP%]   .imx-flex-content[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   .imx-export-type[_ngcontent-%COMP%]{display:flex;flex-direction:row}[_nghost-%COMP%]   .imx-export-type[_ngcontent-%COMP%]   imx-cdr-editor[_ngcontent-%COMP%]{flex:1 1 auto}[_nghost-%COMP%]   .mat-mdc-card[_ngcontent-%COMP%]{margin:3px}[_nghost-%COMP%]   .imx-flex-card[_ngcontent-%COMP%]{margin-top:20px;overflow:hidden}@media only screen and (max-height: 870px){[_nghost-%COMP%]   .imx-flex-card[_ngcontent-%COMP%]{overflow:visible}}[_nghost-%COMP%]   .mat-radio-group[_ngcontent-%COMP%]{margin-bottom:10px}[_nghost-%COMP%]   .mat-radio-group[_ngcontent-%COMP%] > .mat-radio-button[_ngcontent-%COMP%]{margin-right:10px}[_nghost-%COMP%]   .imx-report-form[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;overflow-x:hidden}[_nghost-%COMP%]   .imx-report-form[_ngcontent-%COMP%]   imx-report-selector[_ngcontent-%COMP%]{flex:0 0 auto}[_nghost-%COMP%]   .imx-report-form[_ngcontent-%COMP%]   .imx-cdr-container[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}[_nghost-%COMP%]   .hidden[_ngcontent-%COMP%]{display:none}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]{text-align:center;display:flex;margin:20px 0;flex-direction:column;flex:1 1 auto;align-items:center;justify-content:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#919799}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportViewConfigComponent, [{
        type: Component,
        args: [{ selector: 'imx-report-view-config', template: "<div eui-sidesheet-content class=\"imx-flex-content\">\n  <!-- report generation errors should appear here -->\n  <imx-usermessage class=\"errormessages\" panelClass=\"imx-small-message\" [target]=\"'sidesheet'\"></imx-usermessage>\n\n  <form [formGroup]=\"reportFormGroup\" class=\"imx-report-form\">\n    <mat-card>\n      <imx-report-selector [controlHeigth]=\"400\" formControlName=\"reportTable\"></imx-report-selector>\n    </mat-card>\n    <mat-card *ngIf=\"reportFormGroup.controls.reportTable.value\" class=\"imx-flex-card\">\n      <imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\n\n      <div class=\"imx-cdr-container\" *ngIf=\"!isLoading\">\n        <div class=\"imx-export-type\">\n          <mat-radio-group formControlName=\"viewType\" *ngIf=\"isListReport\">\n            <mat-radio-button [value]=\"'view'\" data-imx-identifier=\"export-view-config-view-in-browser\">\n              {{ '#LDS#View in browser' | translate }}\n            </mat-radio-button>\n            <mat-radio-button [value]=\"'export'\" data-imx-identifier=\"export-view-config-export\">\n              {{ '#LDS#Export' | translate }}\n            </mat-radio-button>\n          </mat-radio-group>\n          <imx-cdr-editor\n            *ngIf=\"formatCdr && (reportFormGroup.controls.viewType.value === 'export' || !isListReport)\"\n            [cdr]=\"formatCdr\"\n            (controlCreated)=\"addExportControl($event)\"\n          >\n          </imx-cdr-editor>\n        </div>\n        <imx-cdr-editor *ngFor=\"let cdr of parameterCdrList\" [cdr]=\"cdr\" (controlCreated)=\"addFormControl($event)\"> </imx-cdr-editor>\n        <div class=\"imx-no-results\" *ngIf=\"!hasParameter\">\n          <eui-icon icon=\"reports\"></eui-icon>\n          <p translate>#LDS#For this report, no parameters must be specified.</p>\n        </div>\n      </div>\n    </mat-card>\n  </form>\n</div>\n\n<div eui-sidesheet-actions>\n  <button\n    color=\"primary\"\n    mat-flat-button\n    (click)=\"viewReport()\"\n    [disabled]=\"reportFormGroup.invalid || isLoading\"\n    data-imx-identifier=\"view-config-view-report-button\"\n  >\n    <eui-icon icon=\"reports\"></eui-icon>\n    <span translate>#LDS#View report</span>\n  </button>\n</div>\n", styles: [":host{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}:host imx-usermessage{margin-bottom:16px}:host .imx-flex-card,:host .imx-flex-content{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}:host .imx-export-type{display:flex;flex-direction:row}:host .imx-export-type imx-cdr-editor{flex:1 1 auto}:host .mat-mdc-card{margin:3px}:host .imx-flex-card{margin-top:20px;overflow:hidden}@media only screen and (max-height: 870px){:host .imx-flex-card{overflow:visible}}:host .mat-radio-group{margin-bottom:10px}:host .mat-radio-group>.mat-radio-button{margin-right:10px}:host .imx-report-form{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;overflow-x:hidden}:host .imx-report-form imx-report-selector{flex:0 0 auto}:host .imx-report-form .imx-cdr-container{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}:host .justify-start{margin-right:auto}:host .hidden{display:none}:host .imx-no-results{text-align:center;display:flex;margin:20px 0;flex-direction:column;flex:1 1 auto;align-items:center;justify-content:center}:host .imx-no-results p{margin:0;font-size:18px}:host .imx-no-results p{color:#919799}.eui-dark-theme :host .imx-no-results p{color:#dfe4e6}.eui-contrast-theme :host .imx-no-results p{color:#fff}\n"] }]
    }], () => [{ type: i1$1.EuiSidesheetRef }, { type: i1$1.EuiSidesheetService }, { type: ReportSubscriptionService }, { type: i0.ChangeDetectorRef }, { type: i3$2.TranslateService }, { type: ListReportViewerService }, { type: i1.ErrorService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ReportViewConfigComponent, { className: "ReportViewConfigComponent", filePath: "lib\\subscriptions\\report-view-config\\report-view-config.component.ts", lineNumber: 50 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function SubscriptionPropertiesComponent_div_0_imx_cdr_editor_5_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 5);
    i0.ɵɵlistener("valueChange", function SubscriptionPropertiesComponent_div_0_imx_cdr_editor_5_Template_imx_cdr_editor_valueChange_0_listener() { const cdr_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.valueHasChanged(cdr_r2.column.ColumnName)); })("controlCreated", function SubscriptionPropertiesComponent_div_0_imx_cdr_editor_5_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.addFormControl(ctx_r2.subscriptionPropertiesFormArray, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r2 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r2);
} }
function SubscriptionPropertiesComponent_div_0_div_10_imx_cdr_editor_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 7);
    i0.ɵɵlistener("controlCreated", function SubscriptionPropertiesComponent_div_0_div_10_imx_cdr_editor_1_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r2 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r2.addFormControl(ctx_r2.subscriptionParameterFormArray, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r5 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r5);
} }
function SubscriptionPropertiesComponent_div_0_div_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, SubscriptionPropertiesComponent_div_0_div_10_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 6);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.parameterCdrList);
} }
function SubscriptionPropertiesComponent_div_0_div_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#There are no parameters for this subscription."), " ");
} }
function SubscriptionPropertiesComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2)(1, "div")(2, "h4");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(5, SubscriptionPropertiesComponent_div_0_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "div")(7, "h4");
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(10, SubscriptionPropertiesComponent_div_0_div_10_Template, 2, 1, "div", 4)(11, SubscriptionPropertiesComponent_div_0_div_11_Template, 3, 3, "div", 4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 5, "#LDS#Heading Subscription Details"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r2.cdrList);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 7, "#LDS#Heading Parameters"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.parameterCdrList.length > 0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.parameterCdrList.length === 0 && ctx_r2.withTitles);
} }
function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 5);
    i0.ɵɵlistener("valueChange", function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_1_Template_imx_cdr_editor_valueChange_0_listener() { const cdr_r7 = i0.ɵɵrestoreView(_r6).$implicit; const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.valueHasChanged(cdr_r7.column.ColumnName)); })("controlCreated", function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_1_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.addFormControl(ctx_r2.subscriptionPropertiesFormArray, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r7 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r7);
} }
function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 7);
    i0.ɵɵlistener("controlCreated", function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.addFormControl(ctx_r2.subscriptionParameterFormArray, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r9 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r9);
} }
function SubscriptionPropertiesComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵtemplate(1, SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 3)(2, SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 6);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.cdrList);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.parameterCdrList);
} }
class SubscriptionPropertiesComponent {
    cdrList = [];
    parameterCdrList = [];
    subscriptionPropertiesFormArray = new UntypedFormArray([]);
    subscriptionParameterFormArray = new UntypedFormArray([]);
    withSeparateParameterList;
    subscription;
    formGroup;
    withTitles = true;
    displayedColumns = [];
    ngOnInit() {
        if (this.formGroup) {
            this.formGroup.addControl('subscriptionProperties', this.subscriptionPropertiesFormArray);
            this.formGroup.addControl('subscriptionParameter', this.subscriptionParameterFormArray);
        }
    }
    ngOnChanges() {
        this.subscriptionPropertiesFormArray.clear();
        this.cdrList = this.subscription == null ? [] : this.subscription.getCdrs(this.displayedColumns);
        this.subscriptionParameterFormArray.clear();
        this.parameterCdrList = this.subscription == null ? [] : this.subscription.getParameterCdr();
        this.withSeparateParameterList = this.withTitles || this.parameterCdrList.length > 0;
    }
    valueHasChanged(name) {
        if (this.subscription.columnsWithParameterReload.indexOf(name) !== -1) {
            this.subscriptionParameterFormArray.clear();
            this.parameterCdrList = this.subscription.getParameterCdr();
        }
    }
    addFormControl(array, control) {
        setTimeout(() => {
            array.push(control);
        });
    }
    static ɵfac = function SubscriptionPropertiesComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SubscriptionPropertiesComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionPropertiesComponent, selectors: [["imx-subscription-properties"]], inputs: { subscription: "subscription", formGroup: "formGroup", withTitles: "withTitles", displayedColumns: "displayedColumns" }, features: [i0.ɵɵNgOnChangesFeature], decls: 3, vars: 2, consts: [["singleMode", ""], ["class", "imx-parameter-grid", 4, "ngIf", "ngIfElse"], [1, "imx-parameter-grid"], [3, "cdr", "valueChange", "controlCreated", 4, "ngFor", "ngForOf"], [4, "ngIf"], [3, "valueChange", "controlCreated", "cdr"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [3, "controlCreated", "cdr"]], template: function SubscriptionPropertiesComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, SubscriptionPropertiesComponent_div_0_Template, 12, 9, "div", 1)(1, SubscriptionPropertiesComponent_ng_template_1_Template, 3, 2, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            const singleMode_r10 = i0.ɵɵreference(2);
            i0.ɵɵproperty("ngIf", ctx.withSeparateParameterList)("ngIfElse", singleMode_r10);
        } }, dependencies: [i1.CdrEditorComponent, i3$1.NgForOf, i3$1.NgIf, i3$2.TranslatePipe], styles: [".imx-parameter-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:20px 40px}h4[_ngcontent-%COMP%]{font-size:medium;font-weight:600;margin-bottom:40px}@media only screen and (max-width: 1024px){.imx-parameter-grid[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{grid-column-start:1;grid-column-end:3}}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionPropertiesComponent, [{
        type: Component,
        args: [{ selector: 'imx-subscription-properties', template: "<div class=\"imx-parameter-grid\" *ngIf=\"withSeparateParameterList; else singleMode\">\n  <div>\n    <h4>\n      {{ '#LDS#Heading Subscription Details' | translate }}\n    </h4>\n    <imx-cdr-editor\n      *ngFor=\"let cdr of cdrList\"\n      [cdr]=\"cdr\"\n      (valueChange)=\"valueHasChanged(cdr.column.ColumnName)\"\n      (controlCreated)=\"addFormControl(subscriptionPropertiesFormArray, $event)\"\n    >\n    </imx-cdr-editor>\n  </div>\n\n  <div>\n    <h4>\n      {{ '#LDS#Heading Parameters' | translate }}\n    </h4>\n    <div *ngIf=\"parameterCdrList.length > 0\">\n      <imx-cdr-editor\n        *ngFor=\"let cdr of parameterCdrList\"\n        [cdr]=\"cdr\"\n        (controlCreated)=\"addFormControl(subscriptionParameterFormArray, $event)\"\n      >\n      </imx-cdr-editor>\n    </div>\n    <div *ngIf=\"parameterCdrList.length === 0 && withTitles\">\n      {{ '#LDS#There are no parameters for this subscription.' | translate }}\n    </div>\n  </div>\n</div>\n\n<ng-template #singleMode>\n  <div class=\"imx-parameter-grid\">\n    <imx-cdr-editor\n      *ngFor=\"let cdr of cdrList\"\n      [cdr]=\"cdr\"\n      (valueChange)=\"valueHasChanged(cdr.column.ColumnName)\"\n      (controlCreated)=\"addFormControl(subscriptionPropertiesFormArray, $event)\"\n    >\n    </imx-cdr-editor>\n    <imx-cdr-editor\n      *ngFor=\"let cdr of parameterCdrList\"\n      [cdr]=\"cdr\"\n      (controlCreated)=\"addFormControl(subscriptionParameterFormArray, $event)\"\n    >\n    </imx-cdr-editor>\n  </div>\n</ng-template>\n", styles: [".imx-parameter-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px 40px}h4{font-size:medium;font-weight:600;margin-bottom:40px}@media only screen and (max-width: 1024px){.imx-parameter-grid>div{grid-column-start:1;grid-column-end:3}}\n"] }]
    }], null, { subscription: [{
            type: Input
        }], formGroup: [{
            type: Input
        }], withTitles: [{
            type: Input
        }], displayedColumns: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SubscriptionPropertiesComponent, { className: "SubscriptionPropertiesComponent", filePath: "lib\\subscriptions\\subscription-properties\\subscription-properties.component.ts", lineNumber: 39 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SubscriptionDetailsComponent {
    subscription;
    sidesheetRef;
    busyService;
    confirmation;
    formGroup = new UntypedFormGroup({});
    cdrList;
    closeClickSubscription;
    reload = false;
    constructor(subscription, sidesheetRef, busyService, confirmation) {
        this.subscription = subscription;
        this.sidesheetRef = sidesheetRef;
        this.busyService = busyService;
        this.confirmation = confirmation;
        this.closeClickSubscription = this.sidesheetRef.closeClicked().subscribe(async () => {
            if (!this.formGroup.dirty || (await this.confirmation.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close(this.reload);
            }
        });
    }
    ngOnDestroy() {
        this.closeClickSubscription.unsubscribe();
    }
    async submit() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            await this.subscription.submit(true);
        }
        finally {
            this.busyService.hide();
            this.reload = true;
            this.formGroup.markAsPristine();
        }
    }
    static ɵfac = function SubscriptionDetailsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SubscriptionDetailsComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i1.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionDetailsComponent, selectors: [["ng-component"]], decls: 8, vars: 7, consts: [["eui-sidesheet-content", ""], [3, "formGroup"], [3, "formGroup", "subscription"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "subscription-details-button-save", 3, "click", "disabled"]], template: function SubscriptionDetailsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "form", 1);
            i0.ɵɵelement(3, "imx-subscription-properties", 2);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(4, "div", 3)(5, "button", 4);
            i0.ɵɵlistener("click", function SubscriptionDetailsComponent_Template_button_click_5_listener() { return ctx.submit(); });
            i0.ɵɵtext(6);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.formGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("formGroup", ctx.formGroup)("subscription", ctx.subscription);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.formGroup.dirty || ctx.formGroup.invalid);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 5, "#LDS#Save"), " ");
        } }, dependencies: [i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i4$1.MatButton, i9.MatCard, i10.ɵNgNoValidate, i10.NgControlStatusGroup, i10.FormGroupDirective, SubscriptionPropertiesComponent, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;max-height:100%}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionDetailsComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\n  <mat-card>\n    <form [formGroup]=\"formGroup\">\n      <imx-subscription-properties [formGroup]=\"formGroup\" [subscription]=\"subscription\"></imx-subscription-properties>\n    </form>\n  </mat-card>\n</div>\n\n<div eui-sidesheet-actions>\n  <button\n    mat-flat-button\n    color=\"primary\"\n    [disabled]=\"!formGroup.dirty || formGroup.invalid\"\n    data-imx-identifier=\"subscription-details-button-save\"\n    (click)=\"submit()\"\n  >\n    {{ '#LDS#Save' | translate }}\n  </button>\n</div>\n", styles: [":host{display:flex;flex-direction:column;max-height:100%}\n"] }]
    }], () => [{ type: ReportSubscription, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1$1.EuiSidesheetRef }, { type: i1$1.EuiLoadingService }, { type: i1.ConfirmationService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SubscriptionDetailsComponent, { className: "SubscriptionDetailsComponent", filePath: "lib\\subscriptions\\subscription-details\\subscription-details.component.ts", lineNumber: 39 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function SubscriptionOverviewComponent_div_0_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "eui-alert", 4)(2, "eui-alert-header", 5);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("dismissable", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "#LDS#You cannot receive the report. You have not specified an email address. Please add an email address to your user account."), " ");
} }
function SubscriptionOverviewComponent_div_0_div_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "eui-alert", 6)(2, "eui-alert-header", 5);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "eui-alert-content");
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("dismissable", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 3, "#LDS#The following subscribers cannot receive the report. No email addresses have been specified for the user accounts of these subscribers."), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.additionalRecipientWithoutEmail.join("; "), " ");
} }
function SubscriptionOverviewComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "div", 2);
    i0.ɵɵelement(2, "imx-property-viewer", 3);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, SubscriptionOverviewComponent_div_0_div_3_Template, 5, 4, "div", 0)(4, SubscriptionOverviewComponent_div_0_div_4_Template, 7, 5, "div", 0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("properties", ctx_r0.setProperties);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.userIsMissingEMail);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.additionalRecipientWithoutEmail.length > 0);
} }
function SubscriptionOverviewComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 7);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#The overview is calculated. Please wait."), "\n");
} }
class SubscriptionOverviewComponent {
    multiValue;
    busyService;
    personService;
    userIsMissingEMail = false;
    additionalRecipientWithoutEmail = [];
    setProperties = [];
    subscription;
    subscribersChanged;
    isWaitingForLoad;
    currentUserId;
    constructor(multiValue, busyService, personService, authentication) {
        this.multiValue = multiValue;
        this.busyService = busyService;
        this.personService = personService;
        authentication.onSessionResponse.subscribe((state) => (this.currentUserId = state.UserUid ?? ''));
    }
    ngOnInit() {
        if (this.subscribersChanged) {
            this.subscribersChanged.subscribe(async () => {
                if (this.subscription) {
                    this.setProperties = this.subscription.getDisplayableColums();
                }
                await this.checkEmailAddresses();
            });
        }
    }
    ngOnDestroy() {
        if (this.subscribersChanged) {
            this.subscribersChanged.unsubscribe();
        }
    }
    async checkEmailAddresses() {
        if (!this.subscription) {
            return;
        }
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            this.userIsMissingEMail = (await this.getPersonNameAndAddress(this.currentUserId)).address === '';
            const subscribers = this.multiValue.getValues(this.subscription.subscription.AddtlSubscribers.value) ?? [];
            const subscriberMails = [];
            for (const value of subscribers) {
                const mail = await this.getPersonNameAndAddress(value);
                subscriberMails.push(mail);
            }
            this.additionalRecipientWithoutEmail = subscriberMails
                .filter((elem) => elem.address == null || elem.address === '')
                .map((elem) => elem.name);
        }
        finally {
            this.busyService.hide();
        }
    }
    async getPersonNameAndAddress(uid) {
        const user = await this.personService.get(uid);
        return user.Data.length > 0
            ? {
                name: user.Data[0].GetEntity().GetDisplay(),
                address: user.Data[0].DefaultEmailAddress.value,
            }
            : { name: '', address: '' };
    }
    static ɵfac = function SubscriptionOverviewComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SubscriptionOverviewComponent)(i0.ɵɵdirectiveInject(i1.MultiValueService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i5.PersonService), i0.ɵɵdirectiveInject(i1.AuthenticationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionOverviewComponent, selectors: [["imx-subscription-overview"]], inputs: { subscription: "subscription", subscribersChanged: "subscribersChanged", isWaitingForLoad: "isWaitingForLoad" }, decls: 2, vars: 2, consts: [[4, "ngIf"], ["class", "imx-wait-for-overview-load", 4, "ngIf"], [1, "imx-report-table"], [3, "properties"], ["type", "warning", "data-imx-identifier", "subscription-overview-alert-no-mail", 1, "mat-elevation-z0", 3, "dismissable"], [1, "mat-elevation-z0"], ["type", "warning", "data-imx-identifier", "subscription-overview-alert-no-mail-for-subscribers", 1, "mat-elevation-z0", 3, "dismissable"], [1, "imx-wait-for-overview-load"]], template: function SubscriptionOverviewComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, SubscriptionOverviewComponent_div_0_Template, 5, 3, "div", 0)(1, SubscriptionOverviewComponent_div_1_Template, 3, 3, "div", 1);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", !ctx.isWaitingForLoad);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isWaitingForLoad);
        } }, dependencies: [i1.PropertyViewerComponent, i3$1.NgIf, i1$1.EuiAlertComponent, i1$1.EuiAlertContentDirective, i1$1.EuiAlertHeaderDirective, i3$2.TranslatePipe], styles: [".imx-report-table[_ngcontent-%COMP%]{display:flex;margin-top:10px}.imx-user-warning[_ngcontent-%COMP%]{color:#e36a00}imx-property-viewer[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.imx-wait-for-overview-load[_ngcontent-%COMP%]{margin:10px 0}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionOverviewComponent, [{
        type: Component,
        args: [{ selector: 'imx-subscription-overview', template: "<div *ngIf=\"!isWaitingForLoad\">\n  <div class=\"imx-report-table\">\n    <imx-property-viewer [properties]=\"setProperties\"></imx-property-viewer>\n  </div>\n  <div *ngIf=\"userIsMissingEMail\">\n    <eui-alert [dismissable]=\"true\" type=\"warning\" class=\"mat-elevation-z0\" data-imx-identifier=\"subscription-overview-alert-no-mail\">\n      <eui-alert-header class=\"mat-elevation-z0\">\n        {{\n          '#LDS#You cannot receive the report. You have not specified an email address. Please add an email address to your user account.'\n            | translate\n        }}\n      </eui-alert-header>\n    </eui-alert>\n  </div>\n  <div *ngIf=\"additionalRecipientWithoutEmail.length >  0\">\n    <eui-alert\n      [dismissable]=\"true\"\n      type=\"warning\"\n      class=\"mat-elevation-z0\"\n      data-imx-identifier=\"subscription-overview-alert-no-mail-for-subscribers\"\n    >\n      <eui-alert-header class=\"mat-elevation-z0\">\n        {{\n          '#LDS#The following subscribers cannot receive the report. No email addresses have been specified for the user accounts of these subscribers.'\n            | translate\n        }}\n      </eui-alert-header>\n      <eui-alert-content>\n        {{ additionalRecipientWithoutEmail.join('; ') }}\n      </eui-alert-content>\n    </eui-alert>\n  </div>\n</div>\n<div *ngIf=\"isWaitingForLoad\" class=\"imx-wait-for-overview-load\">\n  {{ '#LDS#The overview is calculated. Please wait.' | translate }}\n</div>\n", styles: [".imx-report-table{display:flex;margin-top:10px}.imx-user-warning{color:#e36a00}imx-property-viewer{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.imx-wait-for-overview-load{margin:10px 0}\n"] }]
    }], () => [{ type: i1.MultiValueService }, { type: i1$1.EuiLoadingService }, { type: i5.PersonService }, { type: i1.AuthenticationService }], { subscription: [{
            type: Input
        }], subscribersChanged: [{
            type: Input
        }], isWaitingForLoad: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SubscriptionOverviewComponent, { className: "SubscriptionOverviewComponent", filePath: "lib\\subscriptions\\subscription-wizard\\subscription-overview\\subscription-overview.component.ts", lineNumber: 43 }); })();

const _c0$1 = ["additionalApprover"];
function SubscriptionWizardComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(1, 1, "#LDS#Select report"));
} }
function SubscriptionWizardComponent_ng_template_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(1, 1, "#LDS#Configure subscription"));
} }
function SubscriptionWizardComponent_ng_template_25_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(1, 1, "#LDS#Add additional subscribers"));
} }
function SubscriptionWizardComponent_ng_template_40_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(1, 1, "#LDS#Check and create subscription"));
} }
class SubscriptionWizardComponent {
    sidesheetRef;
    reportSubscriptionService;
    confirmation;
    busyService;
    reportFormGroup = new UntypedFormGroup({
        reportTable: new UntypedFormControl(undefined, Validators.required),
    });
    reportParameterFormGroup = new UntypedFormGroup({});
    additionalSubscribersFormGroup = new UntypedFormGroup({
        additionalSubscribers: new UntypedFormControl(undefined),
    });
    isLoadingOverview = false;
    newSubscription;
    entitySchema;
    subscribersChangedSubject = new BehaviorSubject(undefined);
    columnsForEdit;
    additional;
    closeClickSubscription;
    constructor(sidesheetRef, reportSubscriptionService, confirmation, busyService) {
        this.sidesheetRef = sidesheetRef;
        this.reportSubscriptionService = reportSubscriptionService;
        this.confirmation = confirmation;
        this.busyService = busyService;
        this.entitySchema = reportSubscriptionService.PortalSubscriptionInteractiveSchema;
        this.columnsForEdit = [
            this.entitySchema.Columns.Ident_RPSSubscription,
            this.entitySchema.Columns.UID_DialogSchedule,
            this.entitySchema.Columns.ExportFormat,
        ];
        this.closeClickSubscription = this.sidesheetRef.closeClicked().subscribe(async () => {
            if ((!this.reportFormGroup.dirty && !this.reportParameterFormGroup.dirty && !this.additionalSubscribersFormGroup.dirty) ||
                (await this.confirmation.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close(false);
            }
        });
    }
    ngOnDestroy() {
        this.closeClickSubscription.unsubscribe();
    }
    async selectedStepChanged(event) {
        if (event.selectedIndex === 1 && event.previouslySelectedIndex === 0) {
            if (this.busyService.overlayRefs.length === 0) {
                this.busyService.show();
            }
            try {
                this.newSubscription = await this.reportSubscriptionService.createNewSubscription(this.reportFormGroup.get('reportTable')?.value);
                this.additionalSubscribersFormGroup
                    .get('additionalSubscribers')
                    ?.setValue(this.newSubscription.subscription.AddtlSubscribers.Column);
            }
            finally {
                this.busyService.hide();
            }
        }
        if (event.selectedIndex === 3) {
            this.isLoadingOverview = true;
            await this.additional.pushValue();
            this.isLoadingOverview = false;
            this.subscribersChangedSubject.next();
        }
    }
    async submit() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            await this.newSubscription.submit();
            this.newSubscription.unsubscribeEvents();
            this.sidesheetRef.close(true);
        }
        finally {
            this.busyService.hide();
        }
    }
    static ɵfac = function SubscriptionWizardComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SubscriptionWizardComponent)(i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(ReportSubscriptionService), i0.ɵɵdirectiveInject(i1.ConfirmationService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionWizardComponent, selectors: [["imx-subscription-wizard"]], viewQuery: function SubscriptionWizardComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$1, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.additional = _t.first);
        } }, decls: 49, vars: 45, consts: [["stepper", ""], ["additionalApprover", ""], ["orientation", "vertical", 3, "selectionChange", "linear"], ["data-imx-identifier", "subscription-wizard-step-1-choose-report", 3, "stepControl"], [3, "formGroup"], ["matStepLabel", ""], [1, "imx-report-table"], ["formControlName", "reportTable", 3, "controlHeigth"], [1, "imx-button-stepper"], ["mat-stroked-button", "", "color", "primary", "matStepperNext", "", "data-imx-identifier", "subscription-wizard-nextTo-step-2", 3, "disabled"], ["data-imx-identifier", "subscription-wizard-step-2-edit-parameter", 3, "stepControl"], [1, "imx-subscription-properties"], [3, "displayedColumns", "withTitles", "formGroup", "subscription"], ["mat-stroked-button", "", "matStepperPrevious", "", "data-imx-identifier", "subscription-wizard-backtTo-step-1"], ["mat-stroked-button", "", "color", "primary", "matStepperNext", "", "data-imx-identifier", "subscription-wizard-nextTo-step-3", 3, "disabled"], ["data-imx-identifier", "subscription-wizard-step-3-add-subscribers", 3, "stepControl"], [1, "imx-wizard-info"], ["formControlName", "additionalSubscribers", 3, "pushMethod", "selectedElementsCaption"], ["mat-stroked-button", "", "matStepperPrevious", "", "data-imx-identifier", "subscription-wizard-backTo-step-2"], ["mat-stroked-button", "", "color", "primary", "matStepperNext", "", "data-imx-identifier", "subscription-wizard-nextTo-step-4"], ["data-imx-identifier", "subscription-wizard-step-4-overview"], [3, "isWaitingForLoad", "subscription", "subscribersChanged"], ["mat-stroked-button", "", "matStepperPrevious", "", "data-imx-identifier", "subscription-wizard-backTo-step-3"], ["color", "primary", "mat-stroked-button", "", "data-imx-identifier", "subscription-wizard-create-subscription", 3, "click"]], template: function SubscriptionWizardComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "mat-stepper", 2, 0);
            i0.ɵɵlistener("selectionChange", function SubscriptionWizardComponent_Template_mat_stepper_selectionChange_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.selectedStepChanged($event)); });
            i0.ɵɵelementStart(2, "mat-step", 3)(3, "form", 4);
            i0.ɵɵtemplate(4, SubscriptionWizardComponent_ng_template_4_Template, 2, 3, "ng-template", 5);
            i0.ɵɵelementStart(5, "div", 6);
            i0.ɵɵelement(6, "imx-report-selector", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div", 8)(8, "button", 9);
            i0.ɵɵtext(9);
            i0.ɵɵpipe(10, "translate");
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(11, "mat-step", 10)(12, "form", 4);
            i0.ɵɵtemplate(13, SubscriptionWizardComponent_ng_template_13_Template, 2, 3, "ng-template", 5);
            i0.ɵɵelementStart(14, "div", 11);
            i0.ɵɵelement(15, "imx-subscription-properties", 12);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(16, "div", 8)(17, "button", 13);
            i0.ɵɵtext(18);
            i0.ɵɵpipe(19, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(20, "button", 14);
            i0.ɵɵtext(21);
            i0.ɵɵpipe(22, "translate");
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(23, "mat-step", 15)(24, "form", 4);
            i0.ɵɵtemplate(25, SubscriptionWizardComponent_ng_template_25_Template, 2, 3, "ng-template", 5);
            i0.ɵɵelementStart(26, "div", 16);
            i0.ɵɵtext(27);
            i0.ɵɵpipe(28, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(29, "imx-multi-select-formcontrol", 17, 1);
            i0.ɵɵpipe(31, "translate");
            i0.ɵɵelementStart(32, "div", 8)(33, "button", 18);
            i0.ɵɵtext(34);
            i0.ɵɵpipe(35, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(36, "button", 19);
            i0.ɵɵtext(37);
            i0.ɵɵpipe(38, "translate");
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(39, "mat-step", 20);
            i0.ɵɵtemplate(40, SubscriptionWizardComponent_ng_template_40_Template, 2, 3, "ng-template", 5);
            i0.ɵɵelement(41, "imx-subscription-overview", 21);
            i0.ɵɵelementStart(42, "div", 8)(43, "button", 22);
            i0.ɵɵtext(44);
            i0.ɵɵpipe(45, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(46, "button", 23);
            i0.ɵɵlistener("click", function SubscriptionWizardComponent_Template_button_click_46_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.submit()); });
            i0.ɵɵtext(47);
            i0.ɵɵpipe(48, "translate");
            i0.ɵɵelementEnd()()()();
        } if (rf & 2) {
            i0.ɵɵproperty("linear", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("stepControl", ctx.reportFormGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("formGroup", ctx.reportFormGroup);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("controlHeigth", 500);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.reportFormGroup.dirty);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(10, 27, "#LDS#Next"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("stepControl", ctx.reportParameterFormGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("formGroup", ctx.reportParameterFormGroup);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("displayedColumns", ctx.columnsForEdit)("withTitles", false)("formGroup", ctx.reportParameterFormGroup)("subscription", ctx.newSubscription);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(19, 29, "#LDS#Back"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.reportParameterFormGroup.invalid);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(22, 31, "#LDS#Next"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("stepControl", ctx.additionalSubscribersFormGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("formGroup", ctx.additionalSubscribersFormGroup);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(28, 33, "#LDS#Here you can select identities that should also receive these reports."), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("pushMethod", "manual")("selectedElementsCaption", i0.ɵɵpipeBind1(31, 35, "#LDS#Selected subscribers"));
            i0.ɵɵadvance(5);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(35, 37, "#LDS#Back"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(38, 39, "#LDS#Next"), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("isWaitingForLoad", ctx.isLoadingOverview)("subscription", ctx.newSubscription)("subscribersChanged", ctx.subscribersChangedSubject);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(45, 41, "#LDS#Back"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(48, 43, "#LDS#Create"), " ");
        } }, dependencies: [i4$1.MatButton, i5$3.MatStep, i5$3.MatStepLabel, i5$3.MatStepper, i5$3.MatStepperNext, i5$3.MatStepperPrevious, i10.ɵNgNoValidate, i10.NgControlStatus, i10.NgControlStatusGroup, i1.MultiSelectFormcontrolComponent, i10.FormGroupDirective, i10.FormControlName, ReportSelectorComponent, SubscriptionPropertiesComponent, SubscriptionOverviewComponent, i3$2.TranslatePipe], styles: [".imx-report-table[_ngcontent-%COMP%]{display:flex;margin-top:10px}.imx-subscription-properties[_ngcontent-%COMP%]{margin-top:20px}imx-property-viewer[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.imx-wizard-info[_ngcontent-%COMP%]{margin:30px 0}@media only screen and (max-width: 1024px){.imx-wizard-info[_ngcontent-%COMP%]{margin:0}}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionWizardComponent, [{
        type: Component,
        args: [{ selector: 'imx-subscription-wizard', template: "<mat-stepper orientation=\"vertical\" [linear]=\"true\" #stepper (selectionChange)=\"selectedStepChanged($event)\">\n  <mat-step [stepControl]=\"reportFormGroup\" data-imx-identifier=\"subscription-wizard-step-1-choose-report\">\n    <form [formGroup]=\"reportFormGroup\">\n      <ng-template matStepLabel>{{ '#LDS#Select report' | translate }}</ng-template>\n      <div class=\"imx-report-table\">\n        <imx-report-selector [controlHeigth]=\"500\" formControlName=\"reportTable\"></imx-report-selector>\n      </div>\n      <div class=\"imx-button-stepper\">\n        <button\n          [disabled]=\"!reportFormGroup.dirty\"\n          mat-stroked-button\n          color=\"primary\"\n          matStepperNext\n          data-imx-identifier=\"subscription-wizard-nextTo-step-2\"\n        >\n          {{ '#LDS#Next' | translate }}\n        </button>\n      </div>\n    </form>\n  </mat-step>\n  <mat-step [stepControl]=\"reportParameterFormGroup\" data-imx-identifier=\"subscription-wizard-step-2-edit-parameter\">\n    <form [formGroup]=\"reportParameterFormGroup\">\n      <ng-template matStepLabel>{{ '#LDS#Configure subscription' | translate }}</ng-template>\n      <div class=\"imx-subscription-properties\">\n        <imx-subscription-properties\n          [displayedColumns]=\"columnsForEdit\"\n          [withTitles]=\"false\"\n          [formGroup]=\"reportParameterFormGroup\"\n          [subscription]=\"newSubscription\"\n        ></imx-subscription-properties>\n      </div>\n      <div class=\"imx-button-stepper\">\n        <button mat-stroked-button matStepperPrevious data-imx-identifier=\"subscription-wizard-backtTo-step-1\">\n          {{ '#LDS#Back' | translate }}\n        </button>\n        <button\n          [disabled]=\"reportParameterFormGroup.invalid\"\n          mat-stroked-button\n          color=\"primary\"\n          matStepperNext\n          data-imx-identifier=\"subscription-wizard-nextTo-step-3\"\n        >\n          {{ '#LDS#Next' | translate }}\n        </button>\n      </div>\n    </form>\n  </mat-step>\n  <mat-step [stepControl]=\"additionalSubscribersFormGroup\" data-imx-identifier=\"subscription-wizard-step-3-add-subscribers\">\n    <form [formGroup]=\"additionalSubscribersFormGroup\">\n      <ng-template matStepLabel>{{ '#LDS#Add additional subscribers' | translate }}</ng-template>\n      <div class=\"imx-wizard-info\">\n        {{ '#LDS#Here you can select identities that should also receive these reports.' | translate }}\n      </div>\n      <imx-multi-select-formcontrol\n        #additionalApprover\n        [pushMethod]=\"'manual'\"\n        [selectedElementsCaption]=\"'#LDS#Selected subscribers' | translate\"\n        formControlName=\"additionalSubscribers\"\n      >\n      </imx-multi-select-formcontrol>\n      <div class=\"imx-button-stepper\">\n        <button mat-stroked-button matStepperPrevious data-imx-identifier=\"subscription-wizard-backTo-step-2\">\n          {{ '#LDS#Back' | translate }}\n        </button>\n        <button mat-stroked-button color=\"primary\" matStepperNext data-imx-identifier=\"subscription-wizard-nextTo-step-4\">\n          {{ '#LDS#Next' | translate }}\n        </button>\n      </div>\n    </form>\n  </mat-step>\n  <mat-step data-imx-identifier=\"subscription-wizard-step-4-overview\">\n    <ng-template matStepLabel>{{ '#LDS#Check and create subscription' | translate }}</ng-template>\n    <imx-subscription-overview\n      [isWaitingForLoad]=\"isLoadingOverview\"\n      [subscription]=\"newSubscription\"\n      [subscribersChanged]=\"subscribersChangedSubject\"\n    ></imx-subscription-overview>\n    <div class=\"imx-button-stepper\">\n      <button mat-stroked-button matStepperPrevious data-imx-identifier=\"subscription-wizard-backTo-step-3\">\n        {{ '#LDS#Back' | translate }}\n      </button>\n      <button color=\"primary\" mat-stroked-button (click)=\"submit()\" data-imx-identifier=\"subscription-wizard-create-subscription\">\n        {{ '#LDS#Create' | translate }}\n      </button>\n    </div>\n  </mat-step>\n</mat-stepper>\n", styles: [".imx-report-table{display:flex;margin-top:10px}.imx-subscription-properties{margin-top:20px}imx-property-viewer{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.imx-wizard-info{margin:30px 0}@media only screen and (max-width: 1024px){.imx-wizard-info{margin:0}}\n"] }]
    }], () => [{ type: i1$1.EuiSidesheetRef }, { type: ReportSubscriptionService }, { type: i1.ConfirmationService }, { type: i1$1.EuiLoadingService }], { additional: [{
            type: ViewChild,
            args: ['additionalApprover']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SubscriptionWizardComponent, { className: "SubscriptionWizardComponent", filePath: "lib\\subscriptions\\subscription-wizard\\subscription-wizard.component.ts", lineNumber: 43 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SubscriptionsService {
    api;
    constructor(api) {
        this.api = api;
    }
    get PortalSubscriptionSchema() {
        return this.api.typedClient.PortalSubscription.GetSchema();
    }
    async getSubscriptions(parameters) {
        return this.api.typedClient.PortalSubscription.Get(parameters);
    }
    async deleteSubscription(uid) {
        return this.api.client.portal_subscription_delete(uid);
    }
    async getSubscriptionInteractive(uid) {
        return this.api.typedClient.PortalSubscriptionInteractive.Get_byid(uid);
    }
    async sendMail(uidPort, withCc) {
        if (withCc) {
            await this.api.client.portal_subscription_sendmailcc_post(uidPort);
        }
        return this.api.client.portal_subscription_sendmail_post(uidPort);
    }
    async hasReports() {
        return (await this.api.typedClient.PortalReports.Get({ PageSize: -1 })).totalCount > 0;
    }
    static ɵfac = function SubscriptionsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SubscriptionsService)(i0.ɵɵinject(RpsApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: SubscriptionsService, factory: SubscriptionsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: RpsApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0 = () => ["search"];
function SubscriptionsComponent_ng_template_9_button_16_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 18);
    i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_button_16_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r5); const subscription_r3 = i0.ɵɵnextContext().$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.viewReportSubscription(subscription_r3)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#View report"), " ");
} }
function SubscriptionsComponent_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 13);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r2); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelement(2, "eui-icon", 14);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "mat-menu", 15, 1)(7, "button", 16);
    i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_Template_button_click_7_listener() { const subscription_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.delete(subscription_r3)); });
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(10, "button", 17);
    i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_Template_button_click_10_listener() { const subscription_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.sendMail(subscription_r3, false)); });
    i0.ɵɵtext(11);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "button", 18);
    i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_Template_button_click_13_listener() { const subscription_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.sendMail(subscription_r3, true)); });
    i0.ɵɵtext(14);
    i0.ɵɵpipe(15, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(16, SubscriptionsComponent_ng_template_9_button_16_Template, 3, 3, "button", 19);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const subscription_r3 = ctx.$implicit;
    const actionsMenu_r6 = i0.ɵɵreference(6);
    i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(1, 7, "#LDS#Actions"));
    i0.ɵɵproperty("matMenuTriggerFor", actionsMenu_r6);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 9, "#LDS#Actions"), " ");
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 11, "#LDS#Unsubscribe"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(12, 13, "#LDS#Send report to me"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(15, 15, "#LDS#Send report to all subscribers"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", subscription_r3.IsListReport.value);
} }
class SubscriptionsComponent {
    subscriptionService;
    rpsReportService;
    confirmationService;
    sideSheet;
    snackbar;
    translate;
    busyServiceElemental;
    listReportViewerService;
    entitySchema;
    DisplayColumns = DisplayColumns;
    dstSettings;
    canAddSubscription = false;
    displayedColumns;
    navigationState = { PageSize: 25, StartIndex: 0 };
    busyService = new BusyService();
    constructor(subscriptionService, rpsReportService, confirmationService, sideSheet, snackbar, translate, busyServiceElemental, listReportViewerService) {
        this.subscriptionService = subscriptionService;
        this.rpsReportService = rpsReportService;
        this.confirmationService = confirmationService;
        this.sideSheet = sideSheet;
        this.snackbar = snackbar;
        this.translate = translate;
        this.busyServiceElemental = busyServiceElemental;
        this.listReportViewerService = listReportViewerService;
        this.entitySchema = subscriptionService.PortalSubscriptionSchema;
        this.displayedColumns = [
            this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            {
                ColumnName: 'actions',
                Type: ValType.String,
                afterAdditionals: true,
                untranslatedDisplay: '#LDS#Actions',
            },
        ];
    }
    async ngOnInit() {
        const isBusy = this.busyService.beginBusy();
        try {
            this.canAddSubscription = await this.subscriptionService.hasReports();
        }
        finally {
            isBusy.endBusy();
        }
        await this.navigate();
    }
    async onNavigationStateChanged(newState) {
        this.navigationState = newState;
        await this.navigate();
    }
    async onSearch(keywords) {
        this.navigationState = {
            PageSize: this.navigationState.PageSize,
            StartIndex: 0,
            search: keywords,
        };
        return this.navigate();
    }
    async sendMail(subscription, withCc) {
        await this.subscriptionService.sendMail(subscription.GetEntity().GetKeys()[0], withCc);
        this.snackbar.open({
            key: withCc ? '#LDS#The report "{0}" will be sent to all subscribers.' : '#LDS#The report "{0}" will be sent to you.',
            parameters: [subscription.UID_RPSReport.Column.GetDisplayValue()],
        });
    }
    async viewReportSubscription(subscription) {
        let reportSub;
        const over = this.busyServiceElemental.show();
        try {
            const sub = await this.subscriptionService.getSubscriptionInteractive(subscription.GetEntity().GetKeys()[0]);
            reportSub = await this.rpsReportService.buildRpsSubscription(sub.Data[0]);
        }
        finally {
            this.busyServiceElemental.hide(over);
        }
        if (!reportSub) {
            return;
        }
        this.listReportViewerService.setUidReport(subscription.UID_RPSReport.value);
        const data = { dataService: this.listReportViewerService, subscription: reportSub };
        this.sideSheet.open(ListReportViewerSidesheetComponent, {
            title: await this.translate.get('#LDS#Heading View Report').toPromise(),
            subTitle: subscription.GetEntity().GetDisplay(),
            padding: '0',
            width: calculateSidesheetWidth(),
            testId: 'subscription-report-viewer',
            data,
        });
    }
    async delete(subscription) {
        if (await this.confirmationService.confirm({
            Title: '#LDS#Heading Unsubscribe Report',
            Message: '#LDS#Do you want to unsubscribe from this report?',
            identifier: 'subscriptions-confirm-unsubscribe-report',
        })) {
            if (this.busyServiceElemental.overlayRefs.length === 0) {
                this.busyServiceElemental.show();
            }
            try {
                await this.subscriptionService.deleteSubscription(subscription.GetEntity().GetKeys()[0]);
            }
            finally {
                this.busyServiceElemental.hide();
            }
            const message = {
                key: '#LDS#You have successfully unsubscribed from the report "{0}".',
                parameters: [subscription.GetEntity().GetDisplay()],
            };
            this.navigate();
            this.snackbar.open(message);
        }
    }
    async editSubscription(subscription) {
        let rpsSubscription = undefined;
        if (this.busyServiceElemental.overlayRefs.length === 0) {
            this.busyServiceElemental.show();
        }
        try {
            const sub = await this.subscriptionService.getSubscriptionInteractive(subscription.GetEntity().GetKeys()[0]);
            if (sub.Data.length > 0) {
                rpsSubscription = this.rpsReportService.buildRpsSubscription(sub.Data[0]);
            }
        }
        finally {
            this.busyServiceElemental.hide();
        }
        if (rpsSubscription) {
            const sidesheetRef = this.sideSheet.open(SubscriptionDetailsComponent, {
                title: await this.translate.get('#LDS#Heading Edit Subscription').toPromise(),
                subTitle: subscription.GetEntity().GetDisplay(),
                testId: 'edit-subscription-sidesheet',
                padding: '0px',
                width: calculateSidesheetWidth(1000),
                disableClose: true,
                data: rpsSubscription,
            });
            if (await sidesheetRef.afterClosed().toPromise()) {
                return this.navigate();
            }
        }
    }
    async createSubscription() {
        const sidesheetRef = this.sideSheet.open(SubscriptionWizardComponent, {
            title: await this.translate.get('#LDS#Heading Add Report Subscription').toPromise(),
            padding: '0px',
            width: calculateSidesheetWidth(1000),
            disableClose: true,
            testId: 'subscriptions-create',
        });
        if (await sidesheetRef.afterClosed().toPromise()) {
            this.snackbar.open({ key: '#LDS#The subscription has been successfully created.' });
            return this.navigate();
        }
    }
    async viewReport() {
        const sidesheetRef = this.sideSheet.open(ReportViewConfigComponent, {
            title: await this.translate.get('#LDS#Heading View a Report').toPromise(),
            padding: '0px',
            width: calculateSidesheetWidth(1000, 70),
            testId: 'subscriptions-view-config',
        });
        if (await sidesheetRef.afterClosed().toPromise()) {
            this.snackbar.open({ key: '#LDS#The subscription has been successfully created.' });
            return this.navigate();
        }
    }
    async navigate() {
        const isBusy = this.busyService.beginBusy();
        try {
            const subscriptions = await this.subscriptionService.getSubscriptions(this.navigationState);
            this.dstSettings = {
                displayedColumns: this.displayedColumns,
                dataSource: subscriptions,
                entitySchema: this.entitySchema,
                navigationState: this.navigationState,
            };
        }
        finally {
            isBusy.endBusy();
        }
    }
    static ɵfac = function SubscriptionsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SubscriptionsComponent)(i0.ɵɵdirectiveInject(SubscriptionsService), i0.ɵɵdirectiveInject(ReportSubscriptionService), i0.ɵɵdirectiveInject(i1.ConfirmationService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i1.SnackBarService), i0.ɵɵdirectiveInject(i3$2.TranslateService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(ListReportViewerService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionsComponent, selectors: [["imx-subscriptions"]], decls: 19, vars: 19, consts: [["dst", ""], ["actionsMenu", "matMenu"], [1, "imx-card-fill"], [1, "imx-table-container"], ["data-imx-identifier", "subscriptions-table-toolbar", 3, "search", "navigationStateChanged", "settings", "busyService", "options"], ["mode", "manual", "data-imx-identifier", "subscriptions-table", 3, "highlightedEntityChanged", "dst", "detailViewVisible"], [3, "entityColumn", "columnLabel"], ["columnName", "actions", "columnLabel", ""], ["data-imx-identifier", "subscriptions-table-paginator", 3, "dst"], [1, "imx-button-bar-transparent"], ["mat-stroked-button", "", "data-imx-identifier", "subscriptions-view-report", 3, "click", "disabled"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "subscriptions-create-new-subscription", 3, "click", "disabled"], ["icon", "add"], ["mat-stroked-button", "", "data-imx-identifier", "subscriptions-actions", 1, "imx-right-button", 3, "click", "title", "matMenuTriggerFor"], ["icon", "ellipsisvertical"], ["data-imx-identifier", "subscriptions-actions-menu"], ["mat-menu-item", "", "color", "primary", "data-imx-identifier", "subscriptions-show-edit", 3, "click"], ["mat-menu-item", "", "color", "primary", "data-imx-identifier", "subscriptions-send-mail", 1, "imx-separate-menu-item", 3, "click"], ["mat-menu-item", "", "color", "primary", "data-imx-identifier", "subscriptions-send-mail-to-subscribers", 3, "click"], ["mat-menu-item", "", "color", "primary", "data-imx-identifier", "subscriptions-send-mail-to-subscribers", 3, "click", 4, "ngIf"]], template: function SubscriptionsComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "mat-card", 2)(1, "mat-card-content")(2, "div", 3)(3, "imx-data-source-toolbar", 4, 0);
            i0.ɵɵlistener("search", function SubscriptionsComponent_Template_imx_data_source_toolbar_search_3_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSearch($event)); })("navigationStateChanged", function SubscriptionsComponent_Template_imx_data_source_toolbar_navigationStateChanged_3_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onNavigationStateChanged($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "imx-data-table", 5);
            i0.ɵɵlistener("highlightedEntityChanged", function SubscriptionsComponent_Template_imx_data_table_highlightedEntityChanged_5_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.editSubscription($event)); });
            i0.ɵɵelement(6, "imx-data-table-column", 6);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelementStart(8, "imx-data-table-generic-column", 7);
            i0.ɵɵtemplate(9, SubscriptionsComponent_ng_template_9_Template, 17, 17, "ng-template");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(10, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(11, "div", 9)(12, "button", 10);
            i0.ɵɵlistener("click", function SubscriptionsComponent_Template_button_click_12_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.viewReport()); });
            i0.ɵɵtext(13);
            i0.ɵɵpipe(14, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(15, "button", 11);
            i0.ɵɵlistener("click", function SubscriptionsComponent_Template_button_click_15_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.createSubscription()); });
            i0.ɵɵelement(16, "eui-icon", 12);
            i0.ɵɵtext(17);
            i0.ɵɵpipe(18, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            const dst_r7 = i0.ɵɵreference(4);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("settings", ctx.dstSettings)("busyService", ctx.busyService)("options", i0.ɵɵpureFunction0(18, _c0));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", dst_r7)("detailViewVisible", false);
            i0.ɵɵadvance();
            i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(7, 12, "#LDS#Subscription"));
            i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dst", dst_r7);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.canAddSubscription);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(14, 14, "#LDS#View a report"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.canAddSubscription);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(18, 16, "#LDS#Add subscription"), " ");
        } }, dependencies: [i3$1.NgIf, i1.DataSourceToolbarComponent, i1.DataSourcePaginatorComponent, i1.DataTableComponent, i1.DataTableColumnComponent, i1.DataTableGenericColumnComponent, i1$1.EuiIconComponent, i4$1.MatButton, i9.MatCard, i9.MatCardContent, i10$1.MatMenu, i10$1.MatMenuItem, i10$1.MatMenuTrigger, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}imx-data-table[_ngcontent-%COMP%]{flex:1 1 auto}.imx-right-button[_ngcontent-%COMP%]{float:right;margin-right:10px}.imx-separate-menu-item[_ngcontent-%COMP%]{border-top:1px solid #c4cacc}.mat-mdc-card[_ngcontent-%COMP%]   .mat-mdc-card-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto;overflow-y:auto;overflow-x:hidden}.mat-mdc-outlined-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionsComponent, [{
        type: Component,
        args: [{ selector: 'imx-subscriptions', template: "<mat-card class=\"imx-card-fill\">\n  <mat-card-content>\n    <div class=\"imx-table-container\">\n      <imx-data-source-toolbar\n        #dst\n        [settings]=\"dstSettings\"\n        [busyService]=\"busyService\"\n        data-imx-identifier=\"subscriptions-table-toolbar\"\n        [options]=\"['search']\"\n        (search)=\"onSearch($event)\"\n        (navigationStateChanged)=\"onNavigationStateChanged($event)\"\n      >\n      </imx-data-source-toolbar>\n\n      <imx-data-table\n        [dst]=\"dst\"\n        [detailViewVisible]=\"false\"\n        mode=\"manual\"\n        data-imx-identifier=\"subscriptions-table\"\n        (highlightedEntityChanged)=\"editSubscription($event)\"\n      >\n        <imx-data-table-column\n          [entityColumn]=\"entitySchema?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]\"\n          columnLabel=\"{{ '#LDS#Subscription' | translate }}\"\n        >\n        </imx-data-table-column>\n        <imx-data-table-generic-column columnName=\"actions\" columnLabel=\"\">\n          <ng-template let-subscription>\n            <button\n              mat-stroked-button\n              class=\"imx-right-button\"\n              data-imx-identifier=\"subscriptions-actions\"\n              (click)=\"$event.stopPropagation()\"\n              title=\"{{ '#LDS#Actions' | translate }}\"\n              [matMenuTriggerFor]=\"actionsMenu\"\n            >\n              <eui-icon icon=\"ellipsisvertical\"></eui-icon>\n              {{ '#LDS#Actions' | translate }}\n            </button>\n            <mat-menu data-imx-identifier=\"subscriptions-actions-menu\" #actionsMenu=\"matMenu\">\n              <button mat-menu-item color=\"primary\" (click)=\"delete(subscription)\" data-imx-identifier=\"subscriptions-show-edit\">\n                {{ '#LDS#Unsubscribe' | translate }}\n              </button>\n              <button\n                mat-menu-item\n                color=\"primary\"\n                class=\"imx-separate-menu-item\"\n                (click)=\"sendMail(subscription, false)\"\n                data-imx-identifier=\"subscriptions-send-mail\"\n              >\n                {{ '#LDS#Send report to me' | translate }}\n              </button>\n              <button\n                mat-menu-item\n                color=\"primary\"\n                (click)=\"sendMail(subscription, true)\"\n                data-imx-identifier=\"subscriptions-send-mail-to-subscribers\"\n              >\n                {{ '#LDS#Send report to all subscribers' | translate }}\n              </button>\n              <button\n                mat-menu-item\n                color=\"primary\"\n                *ngIf=\"subscription.IsListReport.value\"\n                (click)=\"viewReportSubscription(subscription)\"\n                data-imx-identifier=\"subscriptions-send-mail-to-subscribers\"\n              >\n                {{ '#LDS#View report' | translate }}\n              </button>\n            </mat-menu>\n          </ng-template>\n        </imx-data-table-generic-column>\n      </imx-data-table>\n      <imx-data-source-paginator data-imx-identifier=\"subscriptions-table-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\n    </div>\n  </mat-card-content>\n</mat-card>\n\n<div class=\"imx-button-bar-transparent\">\n  <button [disabled]=\"!canAddSubscription\" mat-stroked-button (click)=\"viewReport()\" data-imx-identifier=\"subscriptions-view-report\">\n    {{ '#LDS#View a report' | translate }}\n  </button>\n  <button\n    [disabled]=\"!canAddSubscription\"\n    mat-flat-button\n    (click)=\"createSubscription()\"\n    color=\"primary\"\n    data-imx-identifier=\"subscriptions-create-new-subscription\"\n  >\n    <eui-icon icon=\"add\"></eui-icon>\n    {{ '#LDS#Add subscription' | translate }}\n  </button>\n</div>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}imx-data-table{flex:1 1 auto}.imx-right-button{float:right;margin-right:10px}.imx-separate-menu-item{border-top:1px solid #c4cacc}.mat-mdc-card .mat-mdc-card-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto;overflow-y:auto;overflow-x:hidden}.mat-mdc-outlined-button eui-icon{font-size:14px;margin-right:4px}\n"] }]
    }], () => [{ type: SubscriptionsService }, { type: ReportSubscriptionService }, { type: i1.ConfirmationService }, { type: i1$1.EuiSidesheetService }, { type: i1.SnackBarService }, { type: i3$2.TranslateService }, { type: i1$1.EuiLoadingService }, { type: ListReportViewerService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SubscriptionsComponent, { className: "SubscriptionsComponent", filePath: "lib\\subscriptions\\subscriptions.component.ts", lineNumber: 55 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    router;
    entlTypeService;
    apiService;
    dynamicMethodService;
    extService;
    constructor(router, entlTypeService, apiService, dynamicMethodService, extService) {
        this.router = router;
        this.entlTypeService = entlTypeService;
        this.apiService = apiService;
        this.dynamicMethodService = dynamicMethodService;
        this.extService = extService;
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register('profile', {
            instance: SubscriptionsComponent,
            inputData: {
                id: 'subscriptions',
                label: '#LDS#Heading Report Subscriptions',
                checkVisibility: async (_) => true,
            },
            SortOrder: 0,
        });
        this.extService.register('identityReportsManager', {
            instance: ReportButtonComponent,
            inputData: {
                uidReport: 'CPL-77d3c04ac2084a968433ef7daf7e56ff',
                caption: '#LDS#View rule violations by identities you are directly responsible for',
                preprop: ['COMPLIANCE'],
                features: ['Portal_UI_PersonManager']
            }
        });
        this.extService.register('statisticButton', {
            instance: StatisticReportButtonComponent
        });
        // FIXME Add auditor and fix report button component
        this.extService.register('identityReports', {
            instance: ReportButtonComponent,
            inputData: {
                uidReport: 'TSB-C1848795DA424F46B2ACC101888361B1',
                caption: '#LDS#Compare identities',
                preprop: undefined,
                features: ['Portal_UI_PersonAdmin', 'Portal_UI_PersonManager'],
                groups: ['VI_4_AUDITING_AUDITOR']
            }
        });
        this.extService.register('identityReportsManager', {
            instance: ReportButtonComponent,
            inputData: {
                uidReport: 'TSB-0D509AC9C160394693CEF814A9CE1FD0',
                caption: '#LDS#Compare identities who report directly to you',
                preprop: undefined,
                features: ['Portal_UI_PersonAdmin', 'Portal_UI_PersonManager']
            }
        });
        this.extService.register('identityReportsManager', {
            instance: ReportButtonComponent,
            inputData: {
                uidReport: 'TSB-1BDEF479FF239A47BCA4EBEFC899C006',
                caption: '#LDS#Compare identities who report to you (directly and indirectly)',
                preprop: undefined,
                features: ['Portal_UI_PersonAdmin', 'Portal_UI_PersonManager']
            }
        });
        this.extService.register('presetReportButton', {
            instance: ReportButtonMailComponent,
        });
        this.entlTypeService.Register(async () => [
            new RequestableEntitlementType('RPSReport', this.apiService.apiClient, 'UID_RPSReport', this.dynamicMethodService),
        ]);
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i1$2.Router), i0.ɵɵinject(i5.RequestableEntitlementTypeService), i0.ɵɵinject(RpsApiService), i0.ɵɵinject(i1.DynamicMethodService), i0.ɵɵinject(i1.ExtService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i1$2.Router }, { type: i5.RequestableEntitlementTypeService }, { type: RpsApiService }, { type: i1.DynamicMethodService }, { type: i1.ExtService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ListReportViewerModule {
    static ɵfac = function ListReportViewerModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ListReportViewerModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ListReportViewerModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, MatCardModule, DataViewModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListReportViewerModule, [{
        type: NgModule,
        args: [{
                declarations: [ListReportViewerComponent],
                imports: [CommonModule, MatCardModule, DataViewModule],
                exports: [ListReportViewerComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ListReportViewerModule, { declarations: [ListReportViewerComponent], imports: [CommonModule, MatCardModule, DataViewModule], exports: [ListReportViewerComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes$1 = [
    {
        path: 'reportsubscriptions',
        component: SubscriptionsComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService],
    },
];
class SubscriptionsModule {
    static ɵfac = function SubscriptionsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SubscriptionsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: SubscriptionsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [ReportSubscriptionService, SubscriptionsService, provideHttpClient(withInterceptorsFromDi())], imports: [CdrModule,
            CommonModule,
            ConfirmationModule,
            DataSourceToolbarModule,
            DataTableModule,
            EuiCoreModule,
            EuiMaterialModule,
            FormsModule,
            LdsReplaceModule,
            MultiSelectFormcontrolModule,
            OverlayModule,
            ReactiveFormsModule,
            RouterModule.forChild(routes$1),
            ScrollingModule,
            TranslateModule,
            UserMessageModule,
            BusyIndicatorModule,
            ListReportViewerModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionsModule, [{
        type: NgModule,
        args: [{ declarations: [
                    ReportSelectorComponent,
                    ReportViewConfigComponent,
                    SubscriptionDetailsComponent,
                    SubscriptionPropertiesComponent,
                    SubscriptionOverviewComponent,
                    SubscriptionWizardComponent,
                    SubscriptionsComponent,
                    ListReportViewerSidesheetComponent,
                ], imports: [CdrModule,
                    CommonModule,
                    ConfirmationModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    FormsModule,
                    LdsReplaceModule,
                    MultiSelectFormcontrolModule,
                    OverlayModule,
                    ReactiveFormsModule,
                    RouterModule.forChild(routes$1),
                    ScrollingModule,
                    TranslateModule,
                    UserMessageModule,
                    BusyIndicatorModule,
                    ListReportViewerModule], providers: [ReportSubscriptionService, SubscriptionsService, provideHttpClient(withInterceptorsFromDi())] }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(SubscriptionsModule, { declarations: [ReportSelectorComponent,
        ReportViewConfigComponent,
        SubscriptionDetailsComponent,
        SubscriptionPropertiesComponent,
        SubscriptionOverviewComponent,
        SubscriptionWizardComponent,
        SubscriptionsComponent,
        ListReportViewerSidesheetComponent], imports: [CdrModule,
        CommonModule,
        ConfirmationModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        EuiMaterialModule,
        FormsModule,
        LdsReplaceModule,
        MultiSelectFormcontrolModule,
        OverlayModule,
        ReactiveFormsModule, i1$2.RouterModule, ScrollingModule,
        TranslateModule,
        UserMessageModule,
        BusyIndicatorModule,
        ListReportViewerModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isRpsAdmin(groups) {
    return groups.find((item) => item === 'vi_4_RPSADMIN_ADMIN') != null;
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RpsPermissionsService {
    userService;
    constructor(userService) {
        this.userService = userService;
    }
    async isRpsAdmin() {
        return isRpsAdmin((await this.userService.getGroups()).map((group) => group.Name));
    }
    static ɵfac = function RpsPermissionsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RpsPermissionsService)(i0.ɵɵinject(i5.UserModelService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RpsPermissionsService, factory: RpsPermissionsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RpsPermissionsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i5.UserModelService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EditReportSqlWizardService {
    api;
    constructor(api) {
        this.api = api;
    }
    async getFilterProperties(table) {
        return (await this.api.client.portal_reports_sqlwizard_tables_columns_get(table)).Properties ?? [];
    }
    async getCandidates(parentTable, options) {
        return await this.api.client.portal_reports_sqlwizard_candidates_get(parentTable, options);
    }
    static ɵfac = function EditReportSqlWizardService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EditReportSqlWizardService)(i0.ɵɵinject(RpsApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EditReportSqlWizardService, factory: EditReportSqlWizardService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportSqlWizardService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: RpsApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EditReportSidesheetComponent_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 5);
    i0.ɵɵlistener("controlCreated", function EditReportSidesheetComponent_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.addCdr($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r3);
} }
function EditReportSidesheetComponent_mat_card_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(4, "imx-ordered-list", 6);
    i0.ɵɵpipe(5, "translate");
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(3, 7, "#LDS#Columns to be included"), "*");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("isReadOnly", ctx_r1.data.isReadonly)("addNewText", i0.ɵɵpipeBind1(5, 9, "#LDS#Add column"))("deleteText", i0.ɵɵpipeBind1(6, 11, "#LDS#Delete"))("placeholder", i0.ɵɵpipeBind1(7, 13, "#LDS#Column name"))("data", ctx_r1.definition.SelectedColumns)("dataSource", ctx_r1.definition.AvailableColumns);
} }
function EditReportSidesheetComponent_ng_container_4_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 8);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, ctx_r1.ldsUnsupportedExpression), " ");
} }
function EditReportSidesheetComponent_ng_container_4_mat_card_2_eui_alert_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 8);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, ctx_r1.ldsAllRowsInfoText), " ");
} }
function EditReportSidesheetComponent_ng_container_4_mat_card_2_imx_sqlwizard_5_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-sqlwizard", 10);
    i0.ɵɵlistener("change", function EditReportSidesheetComponent_ng_container_4_mat_card_2_imx_sqlwizard_5_Template_imx_sqlwizard_change_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.checkChanges()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵproperty("tableName", ctx_r1.definition.TableName)("apiService", ctx_r1.svc)("expression", ctx_r1.sqlExpression.Expression);
} }
function EditReportSidesheetComponent_ng_container_4_mat_card_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, EditReportSidesheetComponent_ng_container_4_mat_card_2_eui_alert_4_Template, 3, 5, "eui-alert", 7)(5, EditReportSidesheetComponent_ng_container_4_mat_card_2_imx_sqlwizard_5_Template, 1, 3, "imx-sqlwizard", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(3, 3, "#LDS#Conditions"), "*");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.isCondition);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r1.sqlExpression.IsUnsupported);
} }
function EditReportSidesheetComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, EditReportSidesheetComponent_ng_container_4_eui_alert_1_Template, 3, 5, "eui-alert", 7)(2, EditReportSidesheetComponent_ng_container_4_mat_card_2_Template, 6, 5, "mat-card", 2);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.sqlExpression.IsUnsupported);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r1.sqlExpression.IsUnsupported);
} }
class EditReportSidesheetComponent {
    svc;
    data;
    snackBar;
    sideSheetRef;
    api;
    entityService;
    busyService;
    cdref;
    config;
    cdrFactoryService;
    get formArray() {
        return this.detailsFormGroup.get('formArray');
    }
    cdrList = [];
    detailsFormGroup;
    definition;
    report;
    ldsUnsupportedExpression = '#LDS#You cannot edit the conditions of this report in the Web Portal.';
    ldsAllRowsInfoText = '#LDS#All data from the selected table will be included in the report.';
    get controlsInvalid() {
        return ((this.detailsFormGroup.pristine && this.exprHasntChanged) ||
            this.detailsFormGroup.invalid ||
            (!this.sqlExpression?.IsUnsupported && this.isConditionInvalid()));
    }
    get isCondition() {
        return !!this.sqlExpression?.Expression?.Expressions && this.sqlExpression?.Expression?.Expressions?.length < 1;
    }
    closeSubscription;
    sqlExpression;
    lastSavedExpression;
    exprHasntChanged = true;
    checkChanges() {
        this.exprHasntChanged = _.isEqual(this.sqlExpression?.Expression, this.lastSavedExpression);
    }
    sqlwizard;
    constructor(formBuilder, svc, data, snackBar, sideSheetRef, api, entityService, busyService, cdref, config, cdrFactoryService, confirmation) {
        this.svc = svc;
        this.data = data;
        this.snackBar = snackBar;
        this.sideSheetRef = sideSheetRef;
        this.api = api;
        this.entityService = entityService;
        this.busyService = busyService;
        this.cdref = cdref;
        this.config = config;
        this.cdrFactoryService = cdrFactoryService;
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.closeSubscription = this.sideSheetRef.closeClicked().subscribe(async () => {
            if ((!this.detailsFormGroup.dirty && this.exprHasntChanged) || (await confirmation.confirmLeaveWithUnsavedChanges())) {
                this.sideSheetRef.close();
            }
        });
        this.report = data.report.Data[0];
        // Save a local copy of the definition object. The entity will change with every update
        // of the interactive entity that comes back from the server
        if (!!this.report.extendedDataRead?.Definition) {
            this.definition = this.report.extendedDataRead.Definition[0];
        }
        if (this.definition?.Data) {
            this.sqlExpression = this.definition.Data;
        }
        this.lastSavedExpression = _.cloneDeep(this.sqlExpression?.Expression);
    }
    async ngOnInit() {
        const c = await this.config.getConfig();
        this.cdrList = this.cdrFactoryService.buildCdrFromColumnList(this.report.GetEntity(), c?.OwnershipConfig?.EditableFields?.[this.report.GetEntity().TypeName] ?? [], this.data.isReadonly);
        if (this.definition) {
            // is it a list report?
            this.cdrList.push(await this.buildTableCdr());
        }
        this.cdrList.push(this.data.isReadonly ? new BaseReadonlyCdr(this.report.AvailableTo.Column) : new BaseCdr(this.report.AvailableTo.Column));
    }
    addCdr(control) {
        this.formArray.push(control);
        this.cdref.detectChanges();
    }
    ngOnDestroy() {
        if (this.closeSubscription) {
            this.closeSubscription.unsubscribe();
        }
    }
    async save() {
        if (!this.detailsFormGroup.valid) {
            return;
        }
        const busy = this.busyService.show();
        try {
            if (this.definition) {
                this.report.extendedData = {
                    Definition: [
                        {
                            SelectedColumns: this.definition.SelectedColumns,
                            Data: {
                                Filters: this.definition.Data?.Expression ? [this.definition.Data?.Expression] : [],
                            },
                        },
                    ],
                };
            }
            await this.report.GetEntity().Commit(false);
            this.detailsFormGroup.markAsPristine();
            this.sideSheetRef.close(true);
            this.snackBar.open({ key: '#LDS#The report has been successfully saved.' });
        }
        finally {
            this.busyService.hide(busy);
        }
    }
    isConditionInvalid() {
        if (!this.definition) {
            return false;
        } // not a list report?
        if (!this.definition.SelectedColumns || this.definition.SelectedColumns?.filter((elem) => !!elem).length === 0) {
            return true;
        } // must select at least one column
        // not initialized? avoid NG1000
        if (!this.sqlwizard || !this.sqlwizard.viewSettings) {
            return true;
        }
        // check if the sqlWizard has a valid expression
        return isExpressionInvalid(this.sqlExpression) || !this.hasValuesSet(this.sqlExpression.Expression);
    }
    hasValuesSet(sqlExpression, checkCurrent = false) {
        if (!sqlExpression) {
            return false;
        }
        const current = !checkCurrent || sqlExpression.Value != null;
        if (sqlExpression.Expressions) {
            return current && sqlExpression.Expressions?.every((elem) => this.hasValuesSet(elem, true));
        }
        return current;
    }
    async buildTableCdr() {
        const fkProviderItem = {
            columnName: 'uid_dialogtable',
            fkTableName: 'DialogTable',
            parameterNames: ['search'],
            load: async (_, parameters) => {
                return this.api.client.portal_reports_tables_get(parameters);
            },
            getDataModel: async (_) => {
                return {};
            },
        };
        const tableCol = this.entityService.createLocalEntityColumn({
            ColumnName: fkProviderItem.columnName,
            Type: ValType.String,
            FkRelation: {
                IsMemberRelation: false,
                ParentTableName: fkProviderItem.fkTableName,
                ParentColumnName: 'TableName',
            },
            ValidReferencedTables: [{ TableName: fkProviderItem.fkTableName }],
            MinLen: 1,
        }, [fkProviderItem]);
        await tableCol.PutValueStruct({
            DataValue: this.definition.TableName,
            DisplayValue: this.definition.TableNameDisplay,
        });
        tableCol.ColumnChanged.subscribe(async () => {
            // send an extended data update to the server, wait for the updated column object to get back
            await this.report.setExtendedData({
                Definition: [
                    {
                        TableName: tableCol.GetValue(),
                    },
                ],
            });
            if (!!this.report.extendedDataRead?.Definition) {
                this.definition = this.report.extendedDataRead.Definition[0];
            }
            if (this.definition.Data) {
                this.sqlExpression = this.definition.Data;
            }
            this.cdref.detectChanges();
        });
        const tableCdr = this.data.isReadonly
            ? new BaseReadonlyCdr(tableCol, '#LDS#Include data from the table')
            : new BaseCdr(tableCol, '#LDS#Include data from the table');
        return tableCdr;
    }
    static ɵfac = function EditReportSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EditReportSidesheetComponent)(i0.ɵɵdirectiveInject(i10.UntypedFormBuilder), i0.ɵɵdirectiveInject(EditReportSqlWizardService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.SnackBarService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(RpsApiService), i0.ɵɵdirectiveInject(i1.EntityService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i5.ProjectConfigurationService), i0.ɵɵdirectiveInject(i1.CdrFactoryService), i0.ɵɵdirectiveInject(i1.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditReportSidesheetComponent, selectors: [["ng-component"]], viewQuery: function EditReportSidesheetComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(SqlWizardComponent, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.sqlwizard = _t.first);
        } }, decls: 9, vars: 7, consts: [["eui-sidesheet-content", ""], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "report-sidesheet-button", 3, "click", "disabled"], [3, "controlCreated", "cdr"], [3, "isReadOnly", "addNewText", "deleteText", "placeholder", "data", "dataSource"], ["type", "info", 3, "condensed", "colored", 4, "ngIf"], ["type", "info", 3, "condensed", "colored"], [3, "tableName", "apiService", "expression", "change", 4, "ngIf"], [3, "change", "tableName", "apiService", "expression"]], template: function EditReportSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card");
            i0.ɵɵtemplate(2, EditReportSidesheetComponent_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(3, EditReportSidesheetComponent_mat_card_3_Template, 8, 15, "mat-card", 2)(4, EditReportSidesheetComponent_ng_container_4_Template, 3, 2, "ng-container", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "div", 3)(6, "button", 4);
            i0.ɵɵlistener("click", function EditReportSidesheetComponent_Template_button_click_6_listener() { return ctx.save(); });
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.definition == null ? null : ctx.definition.TableName);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", (ctx.definition == null ? null : ctx.definition.TableName) && ctx.sqlExpression);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.controlsInvalid || ctx.data.isReadonly);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 5, ctx.data.isNew ? "#LDS#Create" : "#LDS#Save"), " ");
        } }, dependencies: [i1.CdrEditorComponent, i3$1.NgForOf, i3$1.NgIf, i1$1.EuiAlertComponent, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i4$1.MatButton, i9.MatCard, i9.MatCardTitle, i1.OrderedListComponent, i1.SqlWizardComponent, i3$2.TranslatePipe] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportSidesheetComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\n  <mat-card>\n    <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"addCdr($event)\"></imx-cdr-editor>\n  </mat-card>\n\n  <mat-card *ngIf=\"definition?.TableName\">\n    <mat-card-title>{{ '#LDS#Columns to be included' | translate }}*</mat-card-title>\n\n    <imx-ordered-list\n      [isReadOnly]=\"data.isReadonly\"\n      [addNewText]=\"'#LDS#Add column' | translate\"\n      [deleteText]=\"'#LDS#Delete' | translate\"\n      [placeholder]=\"'#LDS#Column name' | translate\"\n      [data]=\"definition.SelectedColumns\"\n      [dataSource]=\"definition.AvailableColumns\"\n    ></imx-ordered-list>\n  </mat-card>\n\n  <ng-container *ngIf=\"definition?.TableName && sqlExpression\">\n    <eui-alert *ngIf=\"sqlExpression.IsUnsupported\" [condensed]=\"true\" [colored]=\"true\" type=\"info\">\n      {{ ldsUnsupportedExpression | translate }}\n    </eui-alert>\n\n    <mat-card *ngIf=\"!sqlExpression.IsUnsupported\">\n      <mat-card-title>{{ '#LDS#Conditions' | translate }}*</mat-card-title>\n\n      <eui-alert *ngIf=\"isCondition\" [condensed]=\"true\" [colored]=\"true\" type=\"info\">\n        {{ ldsAllRowsInfoText | translate }}\n      </eui-alert>\n      <imx-sqlwizard\n        *ngIf=\"!sqlExpression.IsUnsupported\"\n        [tableName]=\"definition.TableName\"\n        [apiService]=\"svc\"\n        [expression]=\"sqlExpression.Expression\"\n        (change)=\"checkChanges()\"\n      >\n      </imx-sqlwizard>\n    </mat-card>\n  </ng-container>\n</div>\n<div eui-sidesheet-actions>\n  <button\n    mat-flat-button\n    color=\"primary\"\n    data-imx-identifier=\"report-sidesheet-button\"\n    [disabled]=\"controlsInvalid || data.isReadonly\"\n    (click)=\"save()\"\n  >\n    {{ (data.isNew ? '#LDS#Create' : '#LDS#Save') | translate }}\n  </button>\n</div>\n" }]
    }], () => [{ type: i10.UntypedFormBuilder }, { type: EditReportSqlWizardService }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1.SnackBarService }, { type: i1$1.EuiSidesheetRef }, { type: RpsApiService }, { type: i1.EntityService }, { type: i1$1.EuiLoadingService }, { type: i0.ChangeDetectorRef }, { type: i5.ProjectConfigurationService }, { type: i1.CdrFactoryService }, { type: i1.ConfirmationService }], { sqlwizard: [{
            type: ViewChild,
            args: [SqlWizardComponent]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EditReportSidesheetComponent, { className: "EditReportSidesheetComponent", filePath: "lib\\reports\\edit-report-sidesheet\\edit-report-sidesheet.component.ts", lineNumber: 61 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EditReportService {
    api;
    constructor(api) {
        this.api = api;
    }
    reportSchema = PortalReportsEdit.GetEntitySchema();
    async getReport(id) {
        return await this.api.typedClient.PortalReportsEditInteractive.Get_byid(id);
    }
    async createNew() {
        return this.api.typedClient.PortalReportsEditInteractive.Get();
    }
    async getReportsOwnedByUser(navigationState, signal) {
        return this.api.typedClient.PortalReports.Get({ owned: true, ...navigationState }, { signal });
    }
    async getAllReports(navigationState, signal) {
        return this.api.typedClient.PortalReports.Get(navigationState, { signal });
    }
    async deleteReport(report) {
        await this.api.client.portal_reports_edit_delete(report.GetEntity().GetKeys()[0]);
    }
    static ɵfac = function EditReportService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EditReportService)(i0.ɵɵinject(RpsApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EditReportService, factory: EditReportService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: RpsApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EditReportComponent_th_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 16);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Display name"), " ");
} }
function EditReportComponent_td_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 17)(1, "div", 18);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 19);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r1.GetEntity().GetDisplay());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r1.Description.Column.GetDisplayValue());
} }
class EditReportComponent {
    reportService;
    busy;
    sidesheet;
    translate;
    confirmationService;
    rpsPermissionService;
    snackBarService;
    helpContextualService;
    dataSource;
    DisplayColumns = DisplayColumns;
    selectedReports = [];
    displayedColumns;
    busyService = new BusyService();
    entitySchema;
    isRpsAdmin;
    constructor(reportService, busy, sidesheet, translate, confirmationService, rpsPermissionService, snackBarService, helpContextualService, dataSource) {
        this.reportService = reportService;
        this.busy = busy;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.confirmationService = confirmationService;
        this.rpsPermissionService = rpsPermissionService;
        this.snackBarService = snackBarService;
        this.helpContextualService = helpContextualService;
        this.dataSource = dataSource;
        this.entitySchema = this.reportService.reportSchema;
    }
    async ngOnInit() {
        this.isRpsAdmin = await this.rpsPermissionService.isRpsAdmin();
        this.displayedColumns = [this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]];
        this.getData();
    }
    getData() {
        const dataViewInitParameters = {
            execute: (params, signal) => this.isRpsAdmin ? this.reportService.getAllReports(params, signal) : this.reportService.getReportsOwnedByUser(params, signal),
            schema: this.entitySchema,
            columnsToDisplay: this.displayedColumns,
            highlightEntity: (entity) => {
                this.viewDetails(entity);
            },
            selectionChange: (selection) => this.onSelectionChanged(selection),
        };
        this.dataSource.init(dataViewInitParameters);
    }
    onSelectionChanged(items) {
        this.selectedReports = items;
    }
    async createNew() {
        const overlay = this.busy.show();
        let report;
        try {
            report = await this.reportService.createNew();
        }
        finally {
            this.busy.hide(overlay);
        }
        if (report) {
            await this.openSidesheet(report, true, false);
        }
    }
    async viewDetails(selectedReport) {
        const overlay = this.busy.show();
        const entity = selectedReport.GetEntity();
        const report = await this.reportService.getReport(entity.GetKeys()[0]);
        this.busy.hide(overlay);
        if (report) {
            await this.openSidesheet(report, false, entity.GetColumn('IsOob').GetValue());
        }
    }
    async openSidesheet(report, isNew, isReadonly) {
        this.helpContextualService.setHelpContextId(isNew ? HELP_CONTEXTUAL.ReportsCreate : HELP_CONTEXTUAL.ReportsEdit);
        const result = await this.sidesheet
            .open(EditReportSidesheetComponent, {
            title: await this.translate.get(isNew ? '#LDS#Heading Create Report' : '#LDS#Heading Edit Report').toPromise(),
            subTitle: isNew ? '' : report.Data[0].GetEntity().GetDisplay(),
            panelClass: 'imx-sidesheet',
            disableClose: true,
            padding: '0',
            width: calculateSidesheetWidth(1100, 0.7),
            testId: isNew ? 'report-create-sidesheet' : 'report-details-sidesheet',
            data: {
                report,
                isNew,
                isReadonly,
            },
            headerComponent: HelpContextualComponent,
        })
            .afterClosed()
            .toPromise();
        if (result) {
            this.dataSource.updateState();
        }
    }
    canDeleteSelected() {
        return this.selectedReports.length > 0 && this.selectedReports.filter((i) => i.GetEntity().GetColumn('IsOob').GetValue()).length == 0;
    }
    async deleteSelected() {
        if (await this.confirmationService.confirm({
            Title: '#LDS#Heading Delete Reports',
            Message: '#LDS#Are you sure you want to delete the selected reports?',
            identifier: 'report-confirm-delete',
        })) {
            const overlay = this.busy.show();
            try {
                for (var report of this.selectedReports) {
                    await this.reportService.deleteReport(report);
                }
                this.snackBarService.open({ key: '#LDS#The reports have been successfully deleted.' }, '#LDS#Close');
                this.dataSource.selection.clear();
                this.dataSource.updateState();
                await this.getData();
            }
            finally {
                this.busy.hide(overlay);
            }
        }
    }
    static ɵfac = function EditReportComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EditReportComponent)(i0.ɵɵdirectiveInject(EditReportService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$2.TranslateService), i0.ɵɵdirectiveInject(i1.ConfirmationService), i0.ɵɵdirectiveInject(RpsPermissionsService), i0.ɵɵdirectiveInject(i1.SnackBarService), i0.ɵɵdirectiveInject(i1.HelpContextualService), i0.ɵɵdirectiveInject(i1.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditReportComponent, selectors: [["ng-component"]], features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 24, vars: 17, consts: [[1, "imx-reports-page"], [1, "imx-header-toolbar"], [1, "mat-headline-5"], [3, "dataSource", "showSettings"], [1, "imx-card-fill"], ["mode", "manual", 3, "dataSource", "selectable"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], [3, "dataSource"], [1, "imx-button-bar-transparent"], [1, "justify-start", 3, "dataSource"], ["mat-stroked-button", "", "color", "warn", 3, "click", "disabled"], ["icon", "delete"], ["mat-flat-button", "", "color", "primary", 3, "click"], ["icon", "add"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], ["data-imx-identifier", "report-table-display"], ["subtitle", "", "data-imx-identifier", "report-table-description"]], template: function EditReportComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
            i0.ɵɵtext(4);
            i0.ɵɵpipe(5, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(6, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(7, "imx-data-view-toolbar", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(8, "mat-card", 4)(9, "imx-data-view-auto-table", 5);
            i0.ɵɵelementContainerStart(10, 6);
            i0.ɵɵtemplate(11, EditReportComponent_th_11_Template, 3, 3, "th", 7)(12, EditReportComponent_td_12_Template, 5, 2, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd();
            i0.ɵɵelement(13, "imx-data-view-paginator", 9);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(14, "div", 10);
            i0.ɵɵelement(15, "imx-data-view-selection", 11);
            i0.ɵɵelementStart(16, "button", 12);
            i0.ɵɵlistener("click", function EditReportComponent_Template_button_click_16_listener() { return ctx.deleteSelected(); });
            i0.ɵɵelement(17, "eui-icon", 13);
            i0.ɵɵtext(18);
            i0.ɵɵpipe(19, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(20, "button", 14);
            i0.ɵɵlistener("click", function EditReportComponent_Template_button_click_20_listener() { return ctx.createNew(); });
            i0.ɵɵelement(21, "eui-icon", 15);
            i0.ɵɵtext(22);
            i0.ɵɵpipe(23, "translate");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 11, "#LDS#Heading Reports"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("showSettings", false);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("selectable", true);
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.DisplayColumns.DISPLAY_PROPERTYNAME);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("disabled", !ctx.canDeleteSelected());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(19, 13, "#LDS#Delete"), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(23, 15, "#LDS#Create report"), " ");
        } }, dependencies: [i1$1.EuiIconComponent, i4$1.MatButton, i9.MatCard, i8.MatHeaderCellDef, i8.MatColumnDef, i8.MatCellDef, i8.MatHeaderCell, i8.MatCell, i1.HelpContextualComponent, i1.DataViewAutoTableComponent, i1.DataViewPaginatorComponent, i1.DataViewToolbarComponent, i1.DataViewSelectionComponent, i3$2.TranslatePipe], styles: [".heading-wrapper[_ngcontent-%COMP%]{display:flex;flex-direction:row;flex:0 0 auto}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%;max-width:100%}.imx-reports-page[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;background-color:inherit;flex:1 1 auto}@media screen and (max-width: 768px){.imx-reports-page[_ngcontent-%COMP%]   .heading-wrapper[_ngcontent-%COMP%]{display:block}}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportComponent, [{
        type: Component,
        args: [{ providers: [DataViewSource], template: "<div class=\"imx-reports-page\">\n  <div class=\"imx-header-toolbar\">\n    <h2 class=\"mat-headline-5\">\n      <span>{{ '#LDS#Heading Reports' | translate }}</span>\n      <imx-help-contextual></imx-help-contextual>\n    </h2>\n    <imx-data-view-toolbar [dataSource]=\"dataSource\" [showSettings]=\"false\"></imx-data-view-toolbar>\n  </div>\n  <mat-card class=\"imx-card-fill\">\n    <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\" [selectable]=\"true\">\n      <ng-container [matColumnDef]=\"DisplayColumns.DISPLAY_PROPERTYNAME\">\n        <th mat-header-cell *matHeaderCellDef>\n          {{ '#LDS#Display name' | translate }}\n        </th>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n          <div data-imx-identifier=\"report-table-display\">{{ item.GetEntity().GetDisplay() }}</div>\n          <div subtitle data-imx-identifier=\"report-table-description\">{{ item.Description.Column.GetDisplayValue() }}</div>\n        </td>\n      </ng-container>\n    </imx-data-view-auto-table>\n    <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n  </mat-card>\n\n  <div class=\"imx-button-bar-transparent\">\n    <imx-data-view-selection class=\"justify-start\" [dataSource]=\"dataSource\"></imx-data-view-selection>\n    <button mat-stroked-button color=\"warn\" [disabled]=\"!canDeleteSelected()\" (click)=\"deleteSelected()\">\n      <eui-icon icon=\"delete\"></eui-icon>\n      {{ '#LDS#Delete' | translate }}\n    </button>\n    <button mat-flat-button color=\"primary\" (click)=\"createNew()\">\n      <eui-icon icon=\"add\"></eui-icon>\n      {{ '#LDS#Create report' | translate }}\n    </button>\n  </div>\n</div>\n", styles: [".heading-wrapper{display:flex;flex-direction:row;flex:0 0 auto}:host{display:flex;flex-direction:column;overflow:hidden;height:100%;max-width:100%}.imx-reports-page{display:flex;flex-direction:column;overflow:hidden;background-color:inherit;flex:1 1 auto}@media screen and (max-width: 768px){.imx-reports-page .heading-wrapper{display:block}}\n"] }]
    }], () => [{ type: EditReportService }, { type: i1$1.EuiLoadingService }, { type: i1$1.EuiSidesheetService }, { type: i3$2.TranslateService }, { type: i1.ConfirmationService }, { type: RpsPermissionsService }, { type: i1.SnackBarService }, { type: i1.HelpContextualService }, { type: i1.DataViewSource }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EditReportComponent, { className: "EditReportComponent", filePath: "lib\\reports\\edit-report.component.ts", lineNumber: 61 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EditReportModule {
    menuService;
    constructor(menuService) {
        this.menuService = menuService;
        this.setupMenu();
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features) => {
            const items = [];
            if (preProps.includes('REPORT_SUBSCRIPTION')) {
                items.push({
                    id: 'RPS_Reports',
                    navigationCommands: {
                        commands: ['reports'],
                    },
                    title: '#LDS#Menu Entry Reports',
                    sorting: '60-70',
                });
            }
            if (items.length === 0) {
                return undefined;
            }
            return {
                id: 'ROOT_Setup',
                title: '#LDS#Setup',
                sorting: '60',
                items,
            };
        });
    }
    static ɵfac = function EditReportModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EditReportModule)(i0.ɵɵinject(i1.MenuService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: EditReportModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
            {
                // This does not work for some reason!
                provide: SqlWizardApiService,
                useClass: EditReportSqlWizardService,
            },
            RpsPermissionsService,
        ], imports: [CdrModule,
            CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            DragDropModule,
            EuiCoreModule,
            EuiMaterialModule,
            FormsModule,
            MatCardModule,
            OrderedListModule,
            ReactiveFormsModule,
            TranslateModule,
            SqlWizardModule,
            SelectedElementsModule,
            HelpContextualModule,
            MatTableModule,
            DataViewModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportModule, [{
        type: NgModule,
        args: [{
                declarations: [EditReportComponent, EditReportSidesheetComponent],
                providers: [
                    {
                        // This does not work for some reason!
                        provide: SqlWizardApiService,
                        useClass: EditReportSqlWizardService,
                    },
                    RpsPermissionsService,
                ],
                imports: [
                    CdrModule,
                    CommonModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    DragDropModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    FormsModule,
                    MatCardModule,
                    OrderedListModule,
                    ReactiveFormsModule,
                    TranslateModule,
                    SqlWizardModule,
                    SelectedElementsModule,
                    HelpContextualModule,
                    MatTableModule,
                    DataViewModule,
                ],
            }]
    }], () => [{ type: i1.MenuService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(EditReportModule, { declarations: [EditReportComponent, EditReportSidesheetComponent], imports: [CdrModule,
        CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        DragDropModule,
        EuiCoreModule,
        EuiMaterialModule,
        FormsModule,
        MatCardModule,
        OrderedListModule,
        ReactiveFormsModule,
        TranslateModule,
        SqlWizardModule,
        SelectedElementsModule,
        HelpContextualModule,
        MatTableModule,
        DataViewModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportButtonModule {
    static ɵfac = function ReportButtonModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ReportButtonModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ReportButtonModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            CdrModule,
            MatMenuModule,
            MatButtonModule,
            MatProgressSpinnerModule,
            MatCardModule,
            EuiCoreModule,
            TranslateModule,
            ReactiveFormsModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportButtonModule, [{
        type: NgModule,
        args: [{
                declarations: [ReportButtonComponent, ReportButtonMailComponent, ParameterSidesheetComponent],
                imports: [
                    CommonModule,
                    CdrModule,
                    MatMenuModule,
                    MatButtonModule,
                    MatProgressSpinnerModule,
                    MatCardModule,
                    EuiCoreModule,
                    TranslateModule,
                    ReactiveFormsModule,
                ],
                exports: [ReportButtonComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ReportButtonModule, { declarations: [ReportButtonComponent, ReportButtonMailComponent, ParameterSidesheetComponent], imports: [CommonModule,
        CdrModule,
        MatMenuModule,
        MatButtonModule,
        MatProgressSpinnerModule,
        MatCardModule,
        EuiCoreModule,
        TranslateModule,
        ReactiveFormsModule], exports: [ReportButtonComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class StatisticReportButtonModule {
    static ɵfac = function StatisticReportButtonModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StatisticReportButtonModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: StatisticReportButtonModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, MatButtonModule, TranslateModule, EuiCoreModule, MatProgressSpinnerModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StatisticReportButtonModule, [{
        type: NgModule,
        args: [{
                declarations: [StatisticReportButtonComponent],
                imports: [CommonModule, MatButtonModule, TranslateModule, EuiCoreModule, MatProgressSpinnerModule],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(StatisticReportButtonModule, { declarations: [StatisticReportButtonComponent], imports: [CommonModule, MatButtonModule, TranslateModule, EuiCoreModule, MatProgressSpinnerModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'reports',
        component: EditReportComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.Reports,
        },
    },
];
class RpsConfigModule {
    initializer;
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 RPS loaded');
        this.initializer.onInit(routes);
        console.log('▶️ RPS initialized');
    }
    static ɵfac = function RpsConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RpsConfigModule)(i0.ɵɵinject(InitService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RpsConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [EditReportModule, SubscriptionsModule, ReportButtonModule, StatisticReportButtonModule, RouterModule.forChild(routes)] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RpsConfigModule, [{
        type: NgModule,
        args: [{
                imports: [EditReportModule, SubscriptionsModule, ReportButtonModule, StatisticReportButtonModule, RouterModule.forChild(routes)],
                declarations: [],
            }]
    }], () => [{ type: InitService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RpsConfigModule, { imports: [EditReportModule, SubscriptionsModule, ReportButtonModule, StatisticReportButtonModule, i1$2.RouterModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of rps
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ReportButtonComponent, ReportButtonModule, RpsConfigModule, SubscriptionsComponent, SubscriptionsModule };
//# sourceMappingURL=rps.mjs.map
