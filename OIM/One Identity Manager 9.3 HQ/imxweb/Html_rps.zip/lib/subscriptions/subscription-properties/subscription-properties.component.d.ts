import { OnChanges, OnInit } from '@angular/core';
import { AbstractControl, UntypedFormArray, UntypedFormGroup } from '@angular/forms';
import { IClientProperty } from '@imx-modules/imx-qbm-dbts';
import { ColumnDependentReference } from 'qbm';
import { ReportSubscription } from '../report-subscription/report-subscription';
import * as i0 from "@angular/core";
export declare class SubscriptionPropertiesComponent implements OnInit, OnChanges {
    cdrList: ColumnDependentReference[];
    parameterCdrList: ColumnDependentReference[];
    readonly subscriptionPropertiesFormArray: UntypedFormArray;
    readonly subscriptionParameterFormArray: UntypedFormArray;
    withSeparateParameterList: boolean;
    subscription: ReportSubscription;
    formGroup: UntypedFormGroup;
    withTitles: boolean;
    displayedColumns: IClientProperty[];
    ngOnInit(): void;
    ngOnChanges(): void;
    valueHasChanged(name: any): void;
    addFormControl(array: UntypedFormArray, control: AbstractControl): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionPropertiesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionPropertiesComponent, "imx-subscription-properties", never, { "subscription": { "alias": "subscription"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "withTitles": { "alias": "withTitles"; "required": false; }; "displayedColumns": { "alias": "displayedColumns"; "required": false; }; }, {}, never, never, false, never>;
}
