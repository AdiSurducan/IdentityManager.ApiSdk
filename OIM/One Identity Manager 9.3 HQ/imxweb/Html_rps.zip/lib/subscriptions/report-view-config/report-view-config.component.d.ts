import { ChangeDetectorRef, OnDestroy } from '@angular/core';
import { AbstractControl, FormArray, FormControl, FormGroup } from '@angular/forms';
import { EuiSidesheetRef, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { BusyService, ColumnDependentReference, ErrorService } from 'qbm';
import { ListReportViewerService } from '../../list-report-viewer/list-report-viewer.service';
import { ReportSubscription } from '../report-subscription/report-subscription';
import { ReportSubscriptionService } from '../report-subscription/report-subscription.service';
import * as i0 from "@angular/core";
interface reportForm {
    viewType: FormControl<'view' | 'export'>;
    reportTable: FormControl<string | undefined>;
    exportType: FormControl<string | undefined>;
    parameters: FormArray<any>;
}
export declare class ReportViewConfigComponent implements OnDestroy {
    private readonly sidesheetRef;
    private readonly sideSheet;
    private readonly reportSubscriptionService;
    private readonly cdref;
    private readonly translate;
    private readonly viewReportService;
    readonly reportFormGroup: FormGroup<reportForm>;
    newSubscription: ReportSubscription | undefined;
    parameterCdrList: ColumnDependentReference[];
    formatCdr: ColumnDependentReference;
    busyService: BusyService;
    isLoading: boolean;
    reportIsLoaded: boolean;
    isListReport: boolean;
    private uidReport;
    private subscriptions;
    private disposable;
    get formControls(): FormArray;
    get hasParameter(): boolean;
    constructor(sidesheetRef: EuiSidesheetRef, sideSheet: EuiSidesheetService, reportSubscriptionService: ReportSubscriptionService, cdref: ChangeDetectorRef, translate: TranslateService, viewReportService: ListReportViewerService, errorService: ErrorService);
    ngOnDestroy(): void;
    viewReport(): Promise<void>;
    addFormControl(control: AbstractControl): void;
    addExportControl(control: AbstractControl): void;
    private viewReportInTable;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReportViewConfigComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReportViewConfigComponent, "imx-report-view-config", never, {}, {}, never, never, false, never>;
}
export {};
