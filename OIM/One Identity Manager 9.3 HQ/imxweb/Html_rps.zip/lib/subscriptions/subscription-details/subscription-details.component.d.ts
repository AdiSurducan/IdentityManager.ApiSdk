import { OnDestroy } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { EuiLoadingService, EuiSidesheetRef } from '@elemental-ui/core';
import { Subscription } from 'rxjs';
import { ColumnDependentReference, ConfirmationService } from 'qbm';
import { ReportSubscription } from '../report-subscription/report-subscription';
import * as i0 from "@angular/core";
export declare class SubscriptionDetailsComponent implements OnDestroy {
    readonly subscription: ReportSubscription;
    readonly sidesheetRef: EuiSidesheetRef;
    private readonly busyService;
    private readonly confirmation;
    readonly formGroup: UntypedFormGroup;
    readonly cdrList: ColumnDependentReference[];
    closeClickSubscription: Subscription;
    reload: boolean;
    constructor(subscription: ReportSubscription, sidesheetRef: EuiSidesheetRef, busyService: EuiLoadingService, confirmation: ConfirmationService);
    ngOnDestroy(): void;
    submit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionDetailsComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
