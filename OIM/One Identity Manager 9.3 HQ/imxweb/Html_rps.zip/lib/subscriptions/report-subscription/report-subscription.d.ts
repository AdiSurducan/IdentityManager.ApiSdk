import { EventEmitter } from '@angular/core';
import { PortalSubscription } from '@imx-modules/imx-api-rps';
import { IClientProperty, IEntityColumn, IFkCandidateProvider, ParameterData } from '@imx-modules/imx-qbm-dbts';
import { ColumnDependentReference, ImxTranslationProviderService } from 'qbm';
import { ParameterDataService } from 'qer';
import { ReportParameterWrapper } from './report-parameter-wrapper';
export declare class ReportSubscription {
    subscription: PortalSubscription;
    private getFkProviderItem;
    readonly columnsWithParameterReload: string[];
    reportEntityWrapper: ReportParameterWrapper;
    readonly hasParameter: boolean;
    private parameterColumns;
    parameterNames: string[];
    startWriteData: EventEmitter<string>;
    endWriteData: EventEmitter<void>;
    constructor(subscription: PortalSubscription, translationService: ImxTranslationProviderService, getFkProviderItem: (cartItem: PortalSubscription, parameter: ParameterData) => IFkCandidateProvider, parameterDataService: ParameterDataService);
    getCdrs(properties: IClientProperty[]): ColumnDependentReference[];
    getParameterCdr(hiddenColumns?: string[]): ColumnDependentReference[];
    fillColumnsWithPreset(presetParameter: {
        [key: string]: string;
    }): Promise<void>;
    getParameterDictionary(): {
        [key: string]: any;
    };
    getDisplayableColums(): IEntityColumn[];
    submit(reload?: boolean): Promise<void>;
    unsubscribeEvents(): void;
}
