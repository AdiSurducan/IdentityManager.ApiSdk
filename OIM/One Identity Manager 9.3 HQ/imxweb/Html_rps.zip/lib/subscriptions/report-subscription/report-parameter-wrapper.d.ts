import { EventEmitter } from '@angular/core';
import { EntityWriteDataColumn, IEntityColumn, IFkCandidateProvider, ParameterData, ReadWriteExtTypedEntity } from '@imx-modules/imx-qbm-dbts';
import { ClassloggerService, ImxTranslationProviderService } from 'qbm';
import { ParameterContainer } from 'qer';
export declare class ReportParameterWrapper {
    private readonly translationService;
    private readonly logger;
    private parameters;
    private getFkProviderItems;
    private typedEntity;
    startWriteData: EventEmitter<string>;
    endWriteData: EventEmitter<void>;
    columns: IEntityColumn[];
    container: ParameterContainer<ParameterData[][]>;
    constructor(translationService: ImxTranslationProviderService, logger: ClassloggerService, parameters: ParameterData[], getFkProviderItems: (parameter: ParameterData) => IFkCandidateProvider, typedEntity: ReadWriteExtTypedEntity<ParameterData[][], EntityWriteDataColumn[][]>);
    unsubscribeEvents(): void;
    /** Builds a set of entity columns for a simple array of parameters. */
    private createInteractiveParameterColumns;
}
