import * as i0 from "@angular/core";
import * as i1 from "./subscription-wizard/report-selector/report-selector.component";
import * as i2 from "./report-view-config/report-view-config.component";
import * as i3 from "./subscription-details/subscription-details.component";
import * as i4 from "./subscription-properties/subscription-properties.component";
import * as i5 from "./subscription-wizard/subscription-overview/subscription-overview.component";
import * as i6 from "./subscription-wizard/subscription-wizard.component";
import * as i7 from "./subscriptions.component";
import * as i8 from "./list-report-viewer-sidesheet/list-report-viewer-sidesheet.component";
import * as i9 from "qbm";
import * as i10 from "@angular/common";
import * as i11 from "@elemental-ui/core";
import * as i12 from "@angular/forms";
import * as i13 from "@angular/cdk/overlay";
import * as i14 from "@angular/router";
import * as i15 from "@angular/cdk/scrolling";
import * as i16 from "@ngx-translate/core";
import * as i17 from "../list-report-viewer/list-report-viewer.module";
export declare class SubscriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionsModule, [typeof i1.ReportSelectorComponent, typeof i2.ReportViewConfigComponent, typeof i3.SubscriptionDetailsComponent, typeof i4.SubscriptionPropertiesComponent, typeof i5.SubscriptionOverviewComponent, typeof i6.SubscriptionWizardComponent, typeof i7.SubscriptionsComponent, typeof i8.ListReportViewerSidesheetComponent], [typeof i9.CdrModule, typeof i10.CommonModule, typeof i9.ConfirmationModule, typeof i9.DataSourceToolbarModule, typeof i9.DataTableModule, typeof i11.EuiCoreModule, typeof i11.EuiMaterialModule, typeof i12.FormsModule, typeof i9.LdsReplaceModule, typeof i9.MultiSelectFormcontrolModule, typeof i13.OverlayModule, typeof i12.ReactiveFormsModule, typeof i14.RouterModule, typeof i15.ScrollingModule, typeof i16.TranslateModule, typeof i9.UserMessageModule, typeof i9.BusyIndicatorModule, typeof i17.ListReportViewerModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionsModule>;
}
