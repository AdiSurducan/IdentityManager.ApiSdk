import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "./reports/edit-report.module";
import * as i2 from "./subscriptions/subscriptions.module";
import * as i3 from "./report-button/report-button.module";
import * as i4 from "./statistic-report-button/statistic-report-button.module";
import * as i5 from "@angular/router";
export declare class RpsConfigModule {
    private readonly initializer;
    constructor(initializer: InitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<RpsConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RpsConfigModule, never, [typeof i1.EditReportModule, typeof i2.SubscriptionsModule, typeof i3.ReportButtonModule, typeof i4.StatisticReportButtonModule, typeof i5.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RpsConfigModule>;
}
