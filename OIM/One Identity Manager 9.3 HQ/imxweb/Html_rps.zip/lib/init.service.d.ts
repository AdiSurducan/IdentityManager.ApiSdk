import { Route, Router } from '@angular/router';
import { DynamicMethodService, ExtService } from 'qbm';
import { RequestableEntitlementTypeService } from 'qer';
import { RpsApiService } from './rps-api-client.service';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly router;
    private readonly entlTypeService;
    private readonly apiService;
    private readonly dynamicMethodService;
    private readonly extService;
    constructor(router: Router, entlTypeService: RequestableEntitlementTypeService, apiService: RpsApiService, dynamicMethodService: DynamicMethodService, extService: ExtService);
    onInit(routes: Route[]): void;
    private addRoutes;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
