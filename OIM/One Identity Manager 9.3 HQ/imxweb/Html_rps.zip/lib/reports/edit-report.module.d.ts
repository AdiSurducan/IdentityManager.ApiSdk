import { MenuService } from 'qbm';
import * as i0 from "@angular/core";
import * as i1 from "./edit-report.component";
import * as i2 from "./edit-report-sidesheet/edit-report-sidesheet.component";
import * as i3 from "qbm";
import * as i4 from "@angular/common";
import * as i5 from "@angular/cdk/drag-drop";
import * as i6 from "@elemental-ui/core";
import * as i7 from "@angular/forms";
import * as i8 from "@angular/material/card";
import * as i9 from "@ngx-translate/core";
import * as i10 from "@angular/material/table";
export declare class EditReportModule {
    private readonly menuService;
    constructor(menuService: MenuService);
    private setupMenu;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditReportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EditReportModule, [typeof i1.EditReportComponent, typeof i2.EditReportSidesheetComponent], [typeof i3.CdrModule, typeof i4.CommonModule, typeof i3.DataSourceToolbarModule, typeof i3.DataTableModule, typeof i5.DragDropModule, typeof i6.EuiCoreModule, typeof i6.EuiMaterialModule, typeof i7.FormsModule, typeof i8.MatCardModule, typeof i3.OrderedListModule, typeof i7.ReactiveFormsModule, typeof i9.TranslateModule, typeof i3.SqlWizardModule, typeof i3.SelectedElementsModule, typeof i3.HelpContextualModule, typeof i10.MatTableModule, typeof i3.DataViewModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EditReportModule>;
}
