import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { ChartInfoTyped } from 'qer';
import { StatisticReportButtonService } from './statistic-report-button.service';
import * as i0 from "@angular/core";
export declare class StatisticReportButtonComponent {
    private readonly statisticService;
    private readonly sideSheet;
    private readonly translate;
    referrer: ChartInfoTyped;
    constructor(statisticService: StatisticReportButtonService, sideSheet: EuiSidesheetService, translate: TranslateService);
    /**
     * Shows the related list report data in a {@link ListReportViewerSidesheetComponent} sidesheet
     */
    viewReport(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatisticReportButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatisticReportButtonComponent, "imx-statistic-report-button", never, {}, {}, never, never, false, never>;
}
