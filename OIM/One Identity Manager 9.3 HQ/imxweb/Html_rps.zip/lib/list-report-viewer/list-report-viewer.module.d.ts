import * as i0 from "@angular/core";
import * as i1 from "./list-report-viewer.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/card";
import * as i4 from "qbm";
export declare class ListReportViewerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ListReportViewerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ListReportViewerModule, [typeof i1.ListReportViewerComponent], [typeof i2.CommonModule, typeof i3.MatCardModule, typeof i4.DataViewModule], [typeof i1.ListReportViewerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ListReportViewerModule>;
}
