import { OnInit } from '@angular/core';
import { EntitySchema } from '@imx-modules/imx-qbm-dbts';
import { BusyService, ClassloggerService, DataSourceToolbarSettings, DataTableGroupedData, DataViewSource } from 'qbm';
import { ListReportDataProvider } from './list-report-data-provider.interface';
import * as i0 from "@angular/core";
/**
 * A component, that displays the data of a list report
 *
 * Example:
 * code behind:
 *          dataService:ListReportDataProvider = {...};
 *          reportParameter:{ [key: string]: any } = {...};
 * html:
 *          <imx-list-report-viewer [dataService]="dataService" [reportParameter]="reportParameter"></imx-list-report-viewer>
 */
export declare class ListReportViewerComponent implements OnInit {
    private logger;
    dataSource: DataViewSource;
    /**
     * the data service, that is used for API communication
     */
    dataService: ListReportDataProvider;
    /**
     * Report parameter, that are necessary for the report generation
     */
    reportParameter: {
        [key: string]: any;
    };
    busyService: BusyService;
    dstSettings: DataSourceToolbarSettings;
    entitySchema: EntitySchema;
    groupedData: {
        [key: string]: DataTableGroupedData;
    };
    private dataModel;
    private reportColumns;
    private navigationState;
    constructor(logger: ClassloggerService, dataSource: DataViewSource);
    ngOnInit(): Promise<void>;
    /**
     * navigates the list report data
     */
    private navigate;
    /**
     * Initializes the data, that is used for the view
     */
    private initData;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListReportViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListReportViewerComponent, "imx-list-report-viewer", never, { "dataService": { "alias": "dataService"; "required": false; }; "reportParameter": { "alias": "reportParameter"; "required": false; }; }, {}, never, never, false, never>;
}
