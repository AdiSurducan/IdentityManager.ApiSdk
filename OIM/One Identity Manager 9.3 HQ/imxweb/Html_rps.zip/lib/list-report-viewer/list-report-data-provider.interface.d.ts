import { ListReportContentData, PortalReportData } from '@imx-modules/imx-api-rps';
import { CollectionLoadParameters, DataModel, EntitySchema, ExtendedTypedEntityCollection, GroupInfoData } from '@imx-modules/imx-qbm-dbts';
import { DataSourceToolbarExportMethod } from 'qbm';
/**
 * Provides methods for API interaction
 * Is used for navigating though the data of a list report
 *
 */
export interface ListReportDataProvider {
    /**
     * Fetches the data of a list report from the server
     * @param parameter navigation parameters
     * @returns an {@link ExtendedTypedEntityCollection} with the content of a report
     */
    get: (parameter: CollectionLoadParameters) => Promise<ExtendedTypedEntityCollection<PortalReportData, ListReportContentData>>;
    /**
     * The entity schema of the {@link ExtendedTypedEntityCollection}
     */
    entitySchema: EntitySchema;
    /**
     * Fetches the data model of a list report from the server
     * @returns The data model of the list report
     */
    getDataModel: () => Promise<DataModel>;
    /**
     * Fetches the group info data of a list report from the server
     * @param parameters the navigation state for the group
     * @returns a {@link GroupInfoData} object
     */
    getGroupInfo: (parameters: {
        by?: string;
        def?: string;
    } & CollectionLoadParameters) => Promise<GroupInfoData>;
    /**
     * Define an api method to export the list of report
     * @param parameters navigation parameters
     * @returns the correct export function
     */
    exportReports?: () => DataSourceToolbarExportMethod;
}
