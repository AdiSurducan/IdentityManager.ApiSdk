export declare function isRpsAdmin(groups: (string | undefined)[]): boolean;
