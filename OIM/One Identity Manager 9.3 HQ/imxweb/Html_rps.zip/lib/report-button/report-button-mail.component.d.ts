import { OnDestroy } from '@angular/core';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { SnackBarService } from 'qbm';
import { ReportSubscriptionService } from '../subscriptions/report-subscription/report-subscription.service';
import * as i0 from "@angular/core";
export declare class ReportButtonMailComponent implements OnDestroy {
    private readonly reportSubscriptionService;
    private readonly busy;
    private readonly sideSheet;
    private readonly translator;
    private readonly snackbarService;
    referrer: {
        uid: string;
        presetParameters: {
            [key: string]: string;
        };
    };
    private subscription;
    constructor(reportSubscriptionService: ReportSubscriptionService, busy: EuiLoadingService, sideSheet: EuiSidesheetService, translator: TranslateService, snackbarService: SnackBarService);
    ngOnDestroy(): void;
    sendReport(): Promise<void>;
    private hasParametersToCompleteByUser;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReportButtonMailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReportButtonMailComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
