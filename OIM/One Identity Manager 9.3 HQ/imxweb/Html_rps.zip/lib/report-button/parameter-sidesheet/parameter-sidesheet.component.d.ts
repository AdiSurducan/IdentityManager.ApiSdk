import { ChangeDetectorRef, OnInit } from '@angular/core';
import { AbstractControl, UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { ClassloggerService, ColumnDependentReference } from 'qbm';
import { ReportSubscription } from '../../subscriptions/report-subscription/report-subscription';
import * as i0 from "@angular/core";
export declare class ParameterSidesheetComponent implements OnInit {
    private readonly sidesheetRef;
    private readonly changeDetectorRef;
    readonly data: {
        subscription: ReportSubscription;
        presetParameter: {
            [key: string]: string;
        };
    };
    readonly reportFormGroup: UntypedFormGroup;
    cdrs: ColumnDependentReference[];
    writeOperators: number;
    constructor(sidesheetRef: EuiSidesheetRef, changeDetectorRef: ChangeDetectorRef, data: {
        subscription: ReportSubscription;
        presetParameter: {
            [key: string]: string;
        };
    }, logger: ClassloggerService);
    ngOnInit(): Promise<void>;
    addFormControl(name: string, control: AbstractControl<any, any>): void;
    viewReport(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ParameterSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ParameterSidesheetComponent, "imx-parameter-sidesheet", never, {}, {}, never, never, false, never>;
}
