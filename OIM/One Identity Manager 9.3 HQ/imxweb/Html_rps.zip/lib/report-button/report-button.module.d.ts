import * as i0 from "@angular/core";
import * as i1 from "./report-button.component";
import * as i2 from "./report-button-mail.component";
import * as i3 from "./parameter-sidesheet/parameter-sidesheet.component";
import * as i4 from "@angular/common";
import * as i5 from "qbm";
import * as i6 from "@angular/material/menu";
import * as i7 from "@angular/material/button";
import * as i8 from "@angular/material/progress-spinner";
import * as i9 from "@angular/material/card";
import * as i10 from "@elemental-ui/core";
import * as i11 from "@ngx-translate/core";
import * as i12 from "@angular/forms";
export declare class ReportButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReportButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReportButtonModule, [typeof i1.ReportButtonComponent, typeof i2.ReportButtonMailComponent, typeof i3.ParameterSidesheetComponent], [typeof i4.CommonModule, typeof i5.CdrModule, typeof i6.MatMenuModule, typeof i7.MatButtonModule, typeof i8.MatProgressSpinnerModule, typeof i9.MatCardModule, typeof i10.EuiCoreModule, typeof i11.TranslateModule, typeof i12.ReactiveFormsModule], [typeof i1.ReportButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReportButtonModule>;
}
