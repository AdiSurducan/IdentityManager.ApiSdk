import * as i0 from "@angular/core";
import * as i1 from "./pick-category.component";
import * as i2 from "./pick-category-sidesheet/pick-category-sidesheet.component";
import * as i3 from "./pick-category-select-identities/pick-category-select-identities.component";
import * as i4 from "./pick-category-create/pick-category-create.component";
import * as i5 from "@angular/common";
import * as i6 from "qbm";
import * as i7 from "@elemental-ui/core";
import * as i8 from "@angular/material/button";
import * as i9 from "@angular/material/card";
import * as i10 from "@angular/material/dialog";
import * as i11 from "@angular/material/snack-bar";
import * as i12 from "@angular/material/stepper";
import * as i13 from "@angular/forms";
import * as i14 from "@ngx-translate/core";
import * as i15 from "@angular/material/table";
export declare class PickCategoryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickCategoryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickCategoryModule, [typeof i1.PickCategoryComponent, typeof i2.PickCategorySidesheetComponent, typeof i3.PickCategorySelectIdentitiesComponent, typeof i4.PickCategoryCreateComponent], [typeof i5.CommonModule, typeof i6.CdrModule, typeof i6.DataSourceToolbarModule, typeof i6.DataTableModule, typeof i7.EuiCoreModule, typeof i8.MatButtonModule, typeof i9.MatCardModule, typeof i10.MatDialogModule, typeof i11.MatSnackBarModule, typeof i12.MatStepperModule, typeof i13.ReactiveFormsModule, typeof i14.TranslateModule, typeof i6.SelectedElementsModule, typeof i6.HelpContextualModule, typeof i15.MatTableModule, typeof i6.DataViewModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickCategoryModule>;
}
