import { ErrorHandler } from '@angular/core';
import { EuiLoadingService } from '@elemental-ui/core';
import { PortalPersonAll, PortalPickcategory, PortalPickcategoryItems } from '@imx-modules/imx-api-qer';
import { CollectionLoadParameters, EntityCollectionData, EntitySchema, ExtendedTypedEntityCollection } from '@imx-modules/imx-qbm-dbts';
import { ClassloggerService, SnackBarService } from 'qbm';
import { QerApiService } from 'qer';
import * as i0 from "@angular/core";
export declare class PickCategoryService {
    private readonly qerClient;
    private readonly busyService;
    private readonly snackbar;
    private readonly logger;
    private readonly errorHandler;
    constructor(qerClient: QerApiService, busyService: EuiLoadingService, snackbar: SnackBarService, logger: ClassloggerService, errorHandler: ErrorHandler);
    get pickcategorySchema(): EntitySchema;
    get pickcategoryItemsSchema(): EntitySchema;
    getPickCategories(navigationState: CollectionLoadParameters, signal?: AbortSignal): Promise<ExtendedTypedEntityCollection<PortalPickcategory, unknown>>;
    /**
     * Post the given {@link PortalPickcategory} to the server
     * @param pickCategory the pick category that should be posted
     * @returns the uid of the {@link PortalPickcategory}
     */
    postPickCategory(pickCategory: PortalPickcategory): Promise<string>;
    deletePickCategories(pickCategories: PortalPickcategory[]): Promise<number>;
    createPickCategory(): PortalPickcategory;
    getPickCategoryItems(uidQERPickCategory: string, navigationState: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalPickcategoryItems, unknown>>;
    deletePickCategoryItems(uidPickCategory: string, pickCategoriesItems: PortalPickcategoryItems[]): Promise<EntityCollectionData[]>;
    assignPickCategoryItems(uidPickCategory: string, pickCategoriesItems: PortalPickcategoryItems[]): Promise<number>;
    deletePickedItems(uidPickCategory: string, selectedPickedItems: PortalPickcategoryItems[]): Promise<number>;
    createPickedItems(selection: any, uidPickCategory: string, showResultInSnackbar?: boolean): Promise<number>;
    handleOpenLoader(): void;
    handleCloseLoader(): void;
    saveNewPickCategoryAndItems(pickCategory: PortalPickcategory, pickedItems: PortalPersonAll[]): Promise<void>;
    private bulkDeletePickCategories;
    private handlePromiseLoader;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickCategoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PickCategoryService>;
}
