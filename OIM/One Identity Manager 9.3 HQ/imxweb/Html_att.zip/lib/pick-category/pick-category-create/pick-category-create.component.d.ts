import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { OnDestroy, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { PortalPersonAll, PortalPickcategory, PortalPickcategoryItems } from '@imx-modules/imx-api-qer';
import { DisplayColumns, EntitySchema } from '@imx-modules/imx-qbm-dbts';
import { ColumnDependentReference, ConfirmationService, DataViewSource } from 'qbm';
import { IdentitiesService } from 'qer';
import { PickCategorySelectIdentitiesComponent } from '../pick-category-select-identities/pick-category-select-identities.component';
import { PickCategoryService } from '../pick-category.service';
import * as i0 from "@angular/core";
export declare class PickCategoryCreateComponent implements OnInit, OnDestroy {
    data: {
        pickCategory: PortalPickcategory;
    };
    private readonly sidesheetRef;
    readonly pickCategoryService: PickCategoryService;
    private readonly identityService;
    dataSource: DataViewSource<PortalPersonAll>;
    readonly displayNameForm: UntypedFormGroup;
    readonly DisplayColumns: typeof DisplayColumns;
    selectedItems: PortalPickcategoryItems[];
    displayNameCdr: ColumnDependentReference;
    displayNameReadonlyCdr: ColumnDependentReference;
    entitySchema: EntitySchema;
    private readonly subscriptions;
    selectIndentities: PickCategorySelectIdentitiesComponent;
    constructor(data: {
        pickCategory: PortalPickcategory;
    }, sidesheetRef: EuiSidesheetRef, pickCategoryService: PickCategoryService, confirmation: ConfirmationService, identityService: IdentitiesService, dataSource: DataViewSource<PortalPersonAll>);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    stepChange(change: StepperSelectionEvent): Promise<void>;
    showSummary(): Promise<void>;
    closeSidesheet(): void;
    private getData;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickCategoryCreateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickCategoryCreateComponent, "imx-pick-category-create", never, {}, {}, never, never, false, never>;
}
