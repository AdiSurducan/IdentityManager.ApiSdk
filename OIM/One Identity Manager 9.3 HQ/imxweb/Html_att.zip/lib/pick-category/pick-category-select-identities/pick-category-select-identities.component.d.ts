import { OnInit } from '@angular/core';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { PortalPersonAll, PortalPickcategoryItems } from '@imx-modules/imx-api-qer';
import { DisplayColumns, EntitySchema, IClientProperty } from '@imx-modules/imx-qbm-dbts';
import { DataViewSource, MetadataService } from 'qbm';
import { IdentitiesService } from 'qer';
import * as i0 from "@angular/core";
export declare class PickCategorySelectIdentitiesComponent implements OnInit {
    selectedItems: PortalPickcategoryItems[];
    private readonly sidesheetRef;
    private readonly identityService;
    private readonly metadataService;
    dataSource: DataViewSource<PortalPersonAll>;
    displayColumns: IClientProperty[];
    selection: PortalPersonAll[];
    entitySchema: EntitySchema;
    DisplayColumns: typeof DisplayColumns;
    embeddedMode: boolean;
    constructor(selectedItems: PortalPickcategoryItems[], sidesheetRef: EuiSidesheetRef, identityService: IdentitiesService, metadataService: MetadataService, dataSource: DataViewSource<PortalPersonAll>);
    ngOnInit(): Promise<void>;
    getData(): Promise<void>;
    onSelectionChanged(selection: PortalPersonAll[]): void;
    onAssign(): void;
    private getFilter;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickCategorySelectIdentitiesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickCategorySelectIdentitiesComponent, "imx-pick-category-select-identities", never, { "embeddedMode": { "alias": "embeddedMode"; "required": false; }; }, {}, never, never, false, never>;
}
