import { OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PortalPickcategory, PortalPickcategoryItems } from '@imx-modules/imx-api-qer';
import { DisplayColumns, EntitySchema, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { UntypedFormGroup } from '@angular/forms';
import { ClassloggerService, ConfirmationService, DataViewSource, SnackBarService } from 'qbm';
import { PickCategoryService } from '../pick-category.service';
import * as i0 from "@angular/core";
export declare class PickCategorySidesheetComponent implements OnInit {
    data: {
        pickCategory: PortalPickcategory;
    };
    private readonly sidesheet;
    private readonly snackBar;
    private readonly confirmationService;
    private readonly pickCategoryService;
    private readonly translate;
    private readonly logger;
    dataSource: DataViewSource<PortalPickcategoryItems>;
    readonly form: UntypedFormGroup;
    selectedPickedItems: PortalPickcategoryItems[];
    displayNameCdr: any;
    entitySchema: EntitySchema;
    DisplayColumns: typeof DisplayColumns;
    private uidPickCategory;
    constructor(data: {
        pickCategory: PortalPickcategory;
    }, sidesheet: EuiSidesheetService, snackBar: SnackBarService, confirmationService: ConfirmationService, pickCategoryService: PickCategoryService, translate: TranslateService, logger: ClassloggerService, dataSource: DataViewSource<PortalPickcategoryItems>);
    ngOnInit(): Promise<void>;
    getData(): Promise<void>;
    selectedItemsCanBeDeleted(): boolean;
    onSelectionChanged(items: TypedEntity[]): void;
    assignPickedItems(): Promise<void>;
    removePickedItems(): Promise<void>;
    saveChanges(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickCategorySidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickCategorySidesheetComponent, "imx-pick-category-sidesheet", never, {}, {}, never, never, false, never>;
}
