import { OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ColumnDependentReference, EntityService, FilterWizardService, FilterWizardSidesheetData } from 'qbm';
import { PersonService } from 'qer';
import * as i0 from "@angular/core";
/**
 * Shows a dropdown with identities to filter the attestation history by an attestator.
 */
export declare class AttestationHistoryFilterComponent implements OnInit, OnDestroy {
    private readonly entityService;
    private readonly filterService;
    private readonly translator;
    private readonly person;
    data?: FilterWizardSidesheetData | undefined;
    identityCdr: ColumnDependentReference;
    private selectedUid;
    private dstFilterRef;
    private filter;
    private id;
    private settings;
    private externalFilters;
    private formState;
    private readonly subscriptions;
    constructor(entityService: EntityService, filterService: FilterWizardService, translator: TranslateService, person: PersonService, data?: FilterWizardSidesheetData | undefined);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    updateSelectedEntity(): void;
    /**
     * @ignore Used internally.
     * Is called internally when the clear all filters menu option is clicked
     * Clears all selected filter values and updates and emits the new navigationState
     */
    private clearFilters;
    private applyFilters;
    /**
     * @ignore Used internally
     * Loops over the filters and adds any selected filters to the navigation state
     * as query parameters, and emits a navigationStateChanged event to let calling code know of the change
     *
     * If the datasource is local, will apply the filters here and emit a settingsChanged signal instead of a navigationStateChanged
     */
    private updateNavigateStateWithFilters;
    private createCdrPerson;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationHistoryFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationHistoryFilterComponent, "imx-attestation-history-filter", never, {}, {}, never, never, false, never>;
}
