import { AfterViewInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { AuthenticationService, DataViewSource } from 'qbm';
import { AttestationHistoryActionService } from './attestation-history-action.service';
import { AttestationHistoryCase } from './attestation-history-case';
import { AttestationHistoryComponent } from './attestation-history.component';
import * as i0 from "@angular/core";
export declare class AttestationHistoryWrapperComponent implements OnDestroy, AfterViewInit {
    readonly attestationAction: AttestationHistoryActionService;
    changeDetectionRef: ChangeDetectorRef;
    attestationHistoryComponent: AttestationHistoryComponent;
    dataSource: DataViewSource<AttestationHistoryCase>;
    get canPerformActions(): boolean;
    get canWithdrawDelegation(): boolean;
    get canRecallDecision(): boolean;
    selectedCases: AttestationHistoryCase[];
    private userUid;
    private readonly subscriptions;
    constructor(attestationAction: AttestationHistoryActionService, authentication: AuthenticationService, changeDetectionRef: ChangeDetectorRef);
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    onSelectionChanged(items: TypedEntity[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationHistoryWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationHistoryWrapperComponent, "imx-attestation-history-wrapper", never, {}, {}, never, never, false, never>;
}
