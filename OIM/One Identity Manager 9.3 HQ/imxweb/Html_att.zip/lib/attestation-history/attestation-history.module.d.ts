import * as i0 from "@angular/core";
import * as i1 from "./attestation-history.component";
import * as i2 from "./attestation-history-details/attestation-history-details.component";
import * as i3 from "./attestation-history-wrapper.component";
import * as i4 from "./attestation-history-filter/attestation-history-filter.component";
import * as i5 from "./my-attestation-cases/my-attestation-cases.component";
import * as i6 from "../attestation-snapshot/attestation-snapshot.module";
import * as i7 from "@angular/common";
import * as i8 from "qbm";
import * as i9 from "@angular/material/button";
import * as i10 from "@angular/material/card";
import * as i11 from "@angular/material/menu";
import * as i12 from "@angular/material/tabs";
import * as i13 from "@angular/material/icon";
import * as i14 from "@angular/forms";
import * as i15 from "@ngx-translate/core";
import * as i16 from "@elemental-ui/core";
import * as i17 from "../decision/attestation-decision.module";
import * as i18 from "../attestation-display/attestation-display.module";
import * as i19 from "qer";
export declare class AttestationHistoryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationHistoryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AttestationHistoryModule, [typeof i1.AttestationHistoryComponent, typeof i2.AttestationHistoryDetailsComponent, typeof i3.AttestationHistoryWrapperComponent, typeof i4.AttestationHistoryFilterComponent, typeof i5.MyAttestationCasesComponent], [typeof i6.AttestationSnapshotModule, typeof i7.CommonModule, typeof i8.CdrModule, typeof i8.DataSourceToolbarModule, typeof i8.DataTableModule, typeof i8.ExtModule, typeof i9.MatButtonModule, typeof i10.MatCardModule, typeof i11.MatMenuModule, typeof i12.MatTabsModule, typeof i13.MatIconModule, typeof i14.FormsModule, typeof i14.ReactiveFormsModule, typeof i15.TranslateModule, typeof i16.EuiCoreModule, typeof i16.EuiMaterialModule, typeof i17.AttestationDecisionModule, typeof i18.AttestationDisplayModule, typeof i6.AttestationSnapshotModule, typeof i8.SelectedElementsModule, typeof i8.HelpContextualModule, typeof i19.ObjectHyperviewModule, typeof i8.DataViewModule], [typeof i1.AttestationHistoryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AttestationHistoryModule>;
}
