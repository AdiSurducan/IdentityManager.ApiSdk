import { AttCaseDataRead, AttestationCaseData, PortalAttestationCase } from '@imx-modules/imx-api-att';
import { IEntityColumn, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { ColumnDependentReference } from 'qbm';
import { ParameterDataContainer } from 'qer';
import { AttestationCaseAction } from '../attestation-action/attestation-case-action.interface';
export declare class AttestationHistoryCase extends PortalAttestationCase implements AttestationCaseAction {
    private readonly baseObject;
    private readonly parameterDataContainer;
    get attestationParameters(): IEntityColumn[];
    get isPending(): boolean;
    readonly propertyInfo: ColumnDependentReference[];
    readonly key: string;
    readonly data: AttestationCaseData | undefined;
    readonly canRecallDecision: boolean;
    readonly typedEntity: TypedEntity;
    readonly propertiesForAction: IEntityColumn[];
    private readonly workflowWrapper;
    constructor(baseObject: PortalAttestationCase, parameterDataContainer: ParameterDataContainer, extendedCollectionData: {
        index: number;
    } & AttCaseDataRead);
    commit(): Promise<void>;
    canWithdrawDelegation(userUid: string): boolean;
}
