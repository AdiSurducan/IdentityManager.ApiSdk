import { OnDestroy } from '@angular/core';
import { AuthenticationService } from 'qbm';
import * as i0 from "@angular/core";
export declare class MyAttestationCasesComponent implements OnDestroy {
    attestationParameters: {
        objecttable: string;
        objectuid: string;
    } | undefined;
    private authSubscription;
    constructor(authentication: AuthenticationService);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAttestationCasesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAttestationCasesComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
