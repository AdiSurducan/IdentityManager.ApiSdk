import { AttCaseDataRead, PortalAttestationCase } from '@imx-modules/imx-api-att';
import { CollectionLoadParameters, DataModel, ExtendedTypedEntityCollection, FilterData, GroupInfoData, TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { DataSourceToolbarExportMethod } from 'qbm';
import { ParameterDataService } from 'qer';
import { ApiService } from '../api.service';
import { AttestationCaseLoadParameters } from './attestation-case-load-parameters.interface';
import { AttestationHistoryCase } from './attestation-history-case';
import * as i0 from "@angular/core";
export declare class AttestationHistoryService {
    private readonly attClient;
    private readonly parameterDataService;
    constructor(attClient: ApiService, parameterDataService: ParameterDataService);
    get(parameters?: AttestationCaseLoadParameters): Promise<ExtendedTypedEntityCollection<PortalAttestationCase, AttCaseDataRead>>;
    getAttestations(loadParameters?: AttestationCaseLoadParameters): Promise<TypedEntityCollectionData<AttestationHistoryCase>>;
    exportAttestation(globalState: CollectionLoadParameters): DataSourceToolbarExportMethod;
    getDataModel(objecttable?: string, objectuid?: string, groupFilter?: FilterData[]): Promise<DataModel>;
    getGroupInfo(parameters?: AttestationCaseLoadParameters): Promise<GroupInfoData>;
    private getParameterCandidates;
    private getFilterTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationHistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AttestationHistoryService>;
}
