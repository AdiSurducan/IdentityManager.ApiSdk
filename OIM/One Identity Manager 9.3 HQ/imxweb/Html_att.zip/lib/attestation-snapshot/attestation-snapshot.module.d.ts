import * as i0 from "@angular/core";
import * as i1 from "./attestation-snapshot.component";
import * as i2 from "@angular/common";
import * as i3 from "qbm";
import * as i4 from "@elemental-ui/core";
import * as i5 from "@ngx-translate/core";
import * as i6 from "@angular/material/card";
import * as i7 from "@angular/material/button";
export declare class AttestationSnapshotModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationSnapshotModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AttestationSnapshotModule, [typeof i1.AttestationSnapshotComponent], [typeof i2.CommonModule, typeof i3.CdrModule, typeof i4.EuiCoreModule, typeof i4.EuiMaterialModule, typeof i3.LdsReplaceModule, typeof i5.TranslateModule, typeof i6.MatCardModule, typeof i7.MatButtonModule], [typeof i1.AttestationSnapshotComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AttestationSnapshotModule>;
}
