import { OnDestroy } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { AppConfigService, AuthenticationService, RouteGuardService } from 'qbm';
import { PermissionsService } from '../admin/permissions.service';
import * as i0 from "@angular/core";
export declare class AttestionAdminGuardService implements OnDestroy {
    private readonly attPermissionService;
    private readonly authentication;
    private readonly appConfig;
    private readonly router;
    private readonly routeGuardService;
    private onSessionResponse;
    constructor(attPermissionService: PermissionsService, authentication: AuthenticationService, appConfig: AppConfigService, router: Router, routeGuardService: RouteGuardService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestionAdminGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AttestionAdminGuardService>;
}
