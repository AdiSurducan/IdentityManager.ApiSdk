import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { AppConfigService, RouteGuardService, SystemInfoService } from 'qbm';
import { ProjectConfigurationService } from 'qer';
import * as i0 from "@angular/core";
export declare class HardwareGuardService implements CanActivate {
    private readonly config;
    private readonly projectConfig;
    private readonly systemInfo;
    private readonly router;
    private readonly routeGuardService;
    constructor(config: AppConfigService, projectConfig: ProjectConfigurationService, systemInfo: SystemInfoService, router: Router, routeGuardService: RouteGuardService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HardwareGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HardwareGuardService>;
}
