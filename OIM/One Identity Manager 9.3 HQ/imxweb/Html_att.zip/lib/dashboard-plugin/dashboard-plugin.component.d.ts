import { OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DashboardService, PendingItemsType, UserModelService } from 'qer';
import { AttestationFeatureGuardService } from '../attestation-feature-guard.service';
import * as i0 from "@angular/core";
export declare class DashboardPluginComponent implements OnInit {
    readonly router: Router;
    private readonly dashboardSvc;
    private readonly userModelSvc;
    private readonly attFeatureGuard;
    pendingItems: PendingItemsType;
    attEnabled: boolean;
    constructor(router: Router, dashboardSvc: DashboardService, userModelSvc: UserModelService, attFeatureGuard: AttestationFeatureGuardService);
    ngOnInit(): Promise<void>;
    goToAttestationInquiries(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardPluginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardPluginComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
