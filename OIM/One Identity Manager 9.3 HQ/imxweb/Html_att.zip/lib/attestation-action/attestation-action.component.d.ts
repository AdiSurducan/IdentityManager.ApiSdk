import { UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { DisplayColumns, IEntity } from '@imx-modules/imx-qbm-dbts';
import { BaseCdr, BaseReadonlyCdr, BulkItem, ColumnDependentReference, DataSourceToolbarSettings } from 'qbm';
import { DecisionStepSevice } from 'qer';
import { AttestationCaseAction } from './attestation-case-action.interface';
import * as i0 from "@angular/core";
export declare class AttestationActionComponent {
    readonly data: {
        description?: string;
        attestationCases: AttestationCaseAction[];
        actionParameters: {
            reason: BaseCdr;
            justification: BaseCdr;
            person: ColumnDependentReference;
        };
        workflow?: {
            title: string;
            placeholder: string;
            data: {
                [key: string]: IEntity[];
            };
        };
        approve?: boolean;
        maxReasonType: number;
        additionalInfo?: BaseReadonlyCdr[];
    };
    readonly sideSheetRef: EuiSidesheetRef;
    readonly formGroup: UntypedFormGroup;
    readonly actionParameters: ColumnDependentReference[];
    readonly dstSettings: DataSourceToolbarSettings;
    readonly displayColumns: typeof DisplayColumns;
    readonly attestationCases: BulkItem[];
    readonly attestationParameter: ColumnDependentReference[];
    constructor(data: {
        description?: string;
        attestationCases: AttestationCaseAction[];
        actionParameters: {
            reason: BaseCdr;
            justification: BaseCdr;
            person: ColumnDependentReference;
        };
        workflow?: {
            title: string;
            placeholder: string;
            data: {
                [key: string]: IEntity[];
            };
        };
        approve?: boolean;
        maxReasonType: number;
        additionalInfo?: BaseReadonlyCdr[];
    }, sideSheetRef: EuiSidesheetRef, stepService: DecisionStepSevice);
    validateItem(bulkItem: BulkItem): void;
    private parseUITextHelper;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationActionComponent, "imx-attestation-action", never, {}, {}, never, never, false, never>;
}
