import { PortalAttestationWorkflow } from '@imx-modules/imx-api-att';
import { TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class AttestationWorkflowService {
    private attApi;
    constructor(attApi: ApiService);
    get(attestationCaseKey: string): Promise<{} & TypedEntityCollectionData<PortalAttestationWorkflow>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationWorkflowService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AttestationWorkflowService>;
}
