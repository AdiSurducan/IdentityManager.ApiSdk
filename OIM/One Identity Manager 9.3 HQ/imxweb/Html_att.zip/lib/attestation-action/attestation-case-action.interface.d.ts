import { AttestationCaseUiData } from '@imx-modules/imx-api-att';
import { IEntity, IEntityColumn, TypedEntity } from '@imx-modules/imx-qbm-dbts';
export interface AttestationCaseAction {
    /**
     * The entity, that is used by the bulk editor
     */
    typedEntity: TypedEntity;
    /**
     * a Property for storing the extended Data
     */
    data: any;
    uiData?: AttestationCaseUiData;
    /**
     * Properties, that are used to build special bulk item editors
     */
    propertiesForAction: IEntityColumn[];
    /**
     * the parameter columns for the attestation object (history or approve)
     */
    attestationParameters: IEntityColumn[];
    /**
     * The key, that identifies the object
     */
    key: string;
    /**
     * Method, that might update the direct decision target
     */
    updateDirectDecisionTarget?: (workflow: IEntity) => void;
}
