import { MetaTableData } from '@imx-modules/imx-qbm-dbts';
import { ApiClientService, MetadataService } from 'qbm';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class NewUserMetadataService extends MetadataService {
    private readonly apiClient;
    private readonly apiProvider;
    constructor(apiClient: ApiService, apiProvider: ApiClientService);
    protected getTable(tableName: string, options?: any): Promise<MetaTableData | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NewUserMetadataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NewUserMetadataService>;
}
