import { Router } from '@angular/router';
import { AuthenticationService, ClassloggerService } from 'qbm';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
import * as i1 from "./open-sidesheet.component";
import * as i2 from "./new-user.component";
import * as i3 from "./user-activation.component";
import * as i4 from "./confirm-dialog.component";
import * as i5 from "qbm";
import * as i6 from "@angular/common";
import * as i7 from "@angular/material/dialog";
import * as i8 from "@angular/forms";
import * as i9 from "@angular/material/progress-spinner";
import * as i10 from "@angular/material/button";
import * as i11 from "@angular/material/card";
import * as i12 from "@ngx-translate/core";
import * as i13 from "@elemental-ui/core";
export declare class NewUserModule {
    private readonly logger;
    constructor(authService: AuthenticationService, router: Router, apiService: ApiService, logger: ClassloggerService);
    private addRoutes;
    static ɵfac: i0.ɵɵFactoryDeclaration<NewUserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NewUserModule, [typeof i1.OpenSidesheetComponent, typeof i2.NewUserComponent, typeof i3.UserActivationComponent, typeof i4.ConfirmDialogComponent], [typeof i5.CaptchaModule, typeof i5.CdrModule, typeof i6.CommonModule, typeof i7.MatDialogModule, typeof i8.FormsModule, typeof i8.ReactiveFormsModule, typeof i5.MastHeadModule, typeof i9.MatProgressSpinnerModule, typeof i10.MatButtonModule, typeof i11.MatCardModule, typeof i5.ParameterizedTextModule, typeof i5.UserMessageModule, typeof i12.TranslateModule, typeof i13.EuiCoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NewUserModule>;
}
