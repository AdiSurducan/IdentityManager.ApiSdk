import { OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { IClientProperty, IEntity, IReadValue } from '@imx-modules/imx-qbm-dbts';
import { ParameterizedText } from 'qbm';
import * as i0 from "@angular/core";
export declare class AttestationDisplayComponent implements OnInit, OnChanges {
    parameterizedText: ParameterizedText;
    additionalText: string;
    attestation: {
        UiText: IReadValue<string>;
        GetEntity: () => IEntity;
    };
    additionalColumns: IClientProperty[];
    ngOnInit(): void;
    ngOnChanges(simple: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationDisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationDisplayComponent, "imx-attestation-display", never, { "attestation": { "alias": "attestation"; "required": false; }; "additionalColumns": { "alias": "additionalColumns"; "required": false; }; }, {}, never, never, false, never>;
}
