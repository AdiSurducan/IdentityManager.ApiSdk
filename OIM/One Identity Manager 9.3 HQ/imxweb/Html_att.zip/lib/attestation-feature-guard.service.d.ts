import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { AttestationConfig } from '@imx-modules/imx-api-att';
import { AppConfigService, CacheService, RouteGuardService } from 'qbm';
import { ApiService } from './api.service';
import * as i0 from "@angular/core";
export declare class AttestationFeatureGuardService {
    private attService;
    private readonly appConfig;
    private readonly router;
    private readonly routeGuardService;
    constructor(attService: ApiService, appConfig: AppConfigService, router: Router, routeGuardService: RouteGuardService, cacheService: CacheService);
    private config;
    private cachedAttestationConfig;
    getAttestationConfig(): Promise<AttestationConfig>;
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationFeatureGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AttestationFeatureGuardService>;
}
