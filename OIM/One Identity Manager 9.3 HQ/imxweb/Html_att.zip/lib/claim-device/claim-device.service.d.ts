import { BaseCdr, EntityService } from 'qbm';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class ClaimDeviceService {
    private readonly apiService;
    private readonly entityService;
    constructor(apiService: ApiService, entityService: EntityService);
    canClaimDevice(): Promise<boolean>;
    assignOwner(key: string, uidOwner: string): Promise<any>;
    createCdrForDevice(): BaseCdr;
    private createColumn;
    private getOwnerCandidates;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClaimDeviceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClaimDeviceService>;
}
