import { AfterViewInit, WritableSignal } from '@angular/core';
import { PortalAttestationRun } from '@imx-modules/imx-api-att';
import { DataViewSource } from 'qbm';
import { RunsGridComponent } from './runs-grid/runs-grid.component';
import * as i0 from "@angular/core";
export declare class RunsComponent implements AfterViewInit {
    dataSource: WritableSignal<DataViewSource<PortalAttestationRun> | undefined>;
    canSeeAttestationPolicies: boolean;
    runsGridComponent: RunsGridComponent;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RunsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RunsComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
