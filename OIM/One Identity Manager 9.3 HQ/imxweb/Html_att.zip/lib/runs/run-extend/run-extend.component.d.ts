import { OnDestroy } from '@angular/core';
import { AbstractControl, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { ColumnDependentReference } from 'qbm';
import * as i0 from "@angular/core";
export declare class RunExtendComponent implements OnDestroy {
    readonly data: {
        ProlongateUntil: Date;
        reason: ColumnDependentReference;
    };
    readonly sideSheetRef: EuiSidesheetRef;
    showHelper: boolean;
    readonly form: UntypedFormGroup;
    readonly tomorrow: Date;
    readonly date: UntypedFormControl;
    readonly reason: ColumnDependentReference;
    private readonly subscriptions;
    constructor(data: {
        ProlongateUntil: Date;
        reason: ColumnDependentReference;
    }, sideSheetRef: EuiSidesheetRef);
    ngOnDestroy(): void;
    onHelperDismissed(): void;
    addControl(name: string, control: AbstractControl): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RunExtendComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RunExtendComponent, "imx-run-extend", never, {}, {}, never, never, false, never>;
}
