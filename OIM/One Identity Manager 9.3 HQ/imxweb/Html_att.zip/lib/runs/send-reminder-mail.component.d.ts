import { OnDestroy } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import * as i0 from "@angular/core";
export declare class SendReminderMailComponent implements OnDestroy {
    readonly sideSheetRef: EuiSidesheetRef;
    showHelper: boolean;
    readonly message: UntypedFormControl;
    private readonly subscriptions;
    constructor(data: {
        message: string;
    }, sideSheetRef: EuiSidesheetRef);
    ngOnDestroy(): void;
    onHelperDismissed(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SendReminderMailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SendReminderMailComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
