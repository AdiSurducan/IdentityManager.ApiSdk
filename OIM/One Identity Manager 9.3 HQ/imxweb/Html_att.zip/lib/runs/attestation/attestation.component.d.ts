import { EventEmitter, OnDestroy } from '@angular/core';
import { FilterData, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { AuthenticationService, StorageService } from 'qbm';
import { HelperAlertContent } from 'qer';
import { AttestationHistoryActionService } from '../../attestation-history/attestation-history-action.service';
import { AttestationHistoryCase } from '../../attestation-history/attestation-history-case';
import * as i0 from "@angular/core";
export interface AttestationParameters {
    objecttable: string;
    objectuid: string;
    filter?: FilterData[];
}
export declare class AttestationComponent implements OnDestroy {
    readonly attestationAction: AttestationHistoryActionService;
    private readonly storageService;
    get canDecide(): boolean;
    get withAssignmentAnalysis(): boolean;
    get showHelperAlert(): boolean;
    parameters: AttestationParameters;
    pendingAttestations: HelperAlertContent;
    readonly itemStatus: {
        enabled: (attestationCase: any) => any;
    };
    selectedCases: AttestationHistoryCase[];
    cancel: EventEmitter<any>;
    private userUid;
    private readonly subscriptions;
    constructor(attestationAction: AttestationHistoryActionService, storageService: StorageService, authentication: AuthenticationService);
    ngOnDestroy(): void;
    onSelectionChanged(items: TypedEntity[]): void;
    onHelperDismissed(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationComponent, "imx-attestation", never, { "parameters": { "alias": "parameters"; "required": false; }; "pendingAttestations": { "alias": "pendingAttestations"; "required": false; }; }, { "cancel": "cancel"; }, never, never, false, never>;
}
