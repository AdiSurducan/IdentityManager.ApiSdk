import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { ApiService } from '../api.service';
import { PortalAttestationRunApprovers } from '@imx-modules/imx-api-att';
import { EntitySchema, TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { DataViewSource } from 'qbm';
import * as i0 from "@angular/core";
export declare class PendingApproversComponent implements OnChanges {
    private readonly attApiService;
    dataViewSource: DataViewSource<PortalAttestationRunApprovers>;
    selected: PortalAttestationRunApprovers[];
    entitySchema: EntitySchema;
    showHelper: boolean;
    dataSource: TypedEntityCollectionData<PortalAttestationRunApprovers>;
    readonly sendReminder: EventEmitter<PortalAttestationRunApprovers[]>;
    constructor(attApiService: ApiService, dataViewSource: DataViewSource<PortalAttestationRunApprovers>);
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    onSelectionChanged(items: PortalAttestationRunApprovers[]): void;
    onHelperDismissed(): void;
    LdsKeyAttestorOverview: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PendingApproversComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PendingApproversComponent, "imx-attestation-run-approvers", never, { "dataSource": { "alias": "dataSource"; "required": false; }; }, { "sendReminder": "sendReminder"; }, never, never, false, never>;
}
