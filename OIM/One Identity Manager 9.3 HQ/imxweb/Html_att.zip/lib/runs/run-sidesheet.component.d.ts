import { MatTabChangeEvent } from '@angular/material/tabs';
import { EuiDownloadOptions, EuiLoadingService, EuiSidesheetRef, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PortalAttestationRun, PortalAttestationRunApprovers, RunStatisticsConfig } from '@imx-modules/imx-api-att';
import { TypedEntityCollectionData } from '@imx-modules/imx-qbm-dbts';
import { SnackBarService } from 'qbm';
import { HelperAlertContent } from 'qer';
import { AttestationActionService } from '../attestation-action/attestation-action.service';
import { AttestationCaseLoadParameters } from '../attestation-history/attestation-case-load-parameters.interface';
import { AttestationHistoryActionService } from '../attestation-history/attestation-history-action.service';
import { AttestationParameters } from './attestation/attestation.component';
import { RunsService } from './runs.service';
import * as i0 from "@angular/core";
export declare class RunSidesheetComponent {
    readonly data: {
        run: PortalAttestationRun;
        attestationRunConfig: RunStatisticsConfig;
        canSeeAttestationPolicies: boolean;
        threshold: number;
        completed: boolean;
    };
    readonly runsService: RunsService;
    private readonly snackBarService;
    private readonly sideSheet;
    private readonly translate;
    private readonly busyService;
    private readonly sideSheetRef;
    private readonly action;
    readonly run: PortalAttestationRun;
    readonly attestationRunConfig: RunStatisticsConfig;
    readonly reportDownload: EuiDownloadOptions;
    readonly threshold: number;
    approvers: TypedEntityCollectionData<PortalAttestationRunApprovers>;
    readonly attestationParameters: AttestationCaseLoadParameters;
    readonly attestationFilterParam: AttestationParameters;
    readonly pendingAttestations: HelperAlertContent;
    private readonly subscriptions;
    get categoryExplanation(): {
        message: string;
        limit?: number;
    };
    constructor(data: {
        run: PortalAttestationRun;
        attestationRunConfig: RunStatisticsConfig;
        canSeeAttestationPolicies: boolean;
        threshold: number;
        completed: boolean;
    }, runsService: RunsService, snackBarService: SnackBarService, sideSheet: EuiSidesheetService, translate: TranslateService, busyService: EuiLoadingService, sideSheetRef: EuiSidesheetRef, action: AttestationActionService, attestationAction: AttestationHistoryActionService);
    extendAttestationRun(): Promise<void>;
    onTabChange(event: MatTabChangeEvent): Promise<void>;
    cancel(): void;
    private updatePendingAttestations;
    private showBusyIndicator;
    static ɵfac: i0.ɵɵFactoryDeclaration<RunSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RunSidesheetComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
