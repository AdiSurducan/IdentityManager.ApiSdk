import { PortalAttestationRun } from '@imx-modules/imx-api-att';
import * as i0 from "@angular/core";
export declare class ProgressComponent {
    get progress(): number;
    get totalNumberOfCases(): number;
    get percentage(): number;
    attestationRun: PortalAttestationRun;
    limit: number;
    forecast: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressComponent, "imx-progress", never, { "attestationRun": { "alias": "attestationRun"; "required": false; }; "limit": { "alias": "limit"; "required": false; }; "forecast": { "alias": "forecast"; "required": false; }; }, {}, never, never, false, never>;
}
