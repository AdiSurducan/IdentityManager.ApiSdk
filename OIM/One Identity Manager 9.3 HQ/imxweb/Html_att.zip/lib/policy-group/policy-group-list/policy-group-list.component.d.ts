import { EuiSidesheetService } from '@elemental-ui/core';
import { PortalAttestationPolicygroups } from '@imx-modules/imx-api-att';
import { CollectionLoadParameters, DisplayColumns, EntitySchema } from '@imx-modules/imx-qbm-dbts';
import { TranslateService } from '@ngx-translate/core';
import { ClassloggerService, ConfirmationService, DataTableGroupedData, DataViewSource, HelpContextualService, SettingsService, SnackBarService } from 'qbm';
import { PolicyGroupService } from '../policy-group.service';
import * as i0 from "@angular/core";
export declare class PolicyGroupListComponent {
    private readonly policyGroupService;
    private readonly logger;
    private readonly settingsService;
    private readonly confirmationService;
    private readonly snackbar;
    private readonly sideSheet;
    private readonly translator;
    private readonly helpContextualService;
    dataSource: DataViewSource<PortalAttestationPolicygroups>;
    readonly entitySchemaPolicy: EntitySchema;
    readonly DisplayColumns: typeof DisplayColumns;
    groupedData: {
        [key: string]: DataTableGroupedData;
    };
    navigationState: CollectionLoadParameters;
    isComplienceFrameworkEnabled: boolean;
    private readonly displayedColumns;
    constructor(policyGroupService: PolicyGroupService, logger: ClassloggerService, settingsService: SettingsService, confirmationService: ConfirmationService, snackbar: SnackBarService, sideSheet: EuiSidesheetService, translator: TranslateService, helpContextualService: HelpContextualService, dataSource: DataViewSource<PortalAttestationPolicygroups>);
    ngOnInit(): Promise<void>;
    private navigate;
    delete(policyGroup: PortalAttestationPolicygroups, event: any): Promise<void>;
    editPolicy(policyGroup: PortalAttestationPolicygroups): Promise<void>;
    private showPolicy;
    newPolicyGroup(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyGroupListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PolicyGroupListComponent, "imx-policy-group-list", never, {}, {}, never, never, false, never>;
}
