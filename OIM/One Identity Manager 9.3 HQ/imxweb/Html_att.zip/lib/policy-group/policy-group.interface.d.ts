import { PolicyFilterData, PortalAttestationPolicygroups } from '@imx-modules/imx-api-att';
export interface PolicyGroup {
    policyGroup: PortalAttestationPolicygroups;
    filterData: PolicyFilterData;
    isNew: boolean;
    isComplienceFrameworkEnabled: boolean;
}
