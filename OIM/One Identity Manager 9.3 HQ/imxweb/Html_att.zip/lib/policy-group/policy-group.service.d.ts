import { EuiLoadingService } from '@elemental-ui/core';
import { PolicyFilter, PortalAttestationPolicygroups } from '@imx-modules/imx-api-att';
import { CollectionLoadParameters, EntityCollectionData, EntitySchema, ExtendedTypedEntityCollection } from '@imx-modules/imx-qbm-dbts';
import { TranslateService } from '@ngx-translate/core';
import { AppConfigService, ClassloggerService } from 'qbm';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class PolicyGroupService {
    private api;
    private busyService;
    private readonly translator;
    private readonly config;
    private readonly logger;
    constructor(api: ApiService, busyService: EuiLoadingService, translator: TranslateService, config: AppConfigService, logger: ClassloggerService);
    get AttestationPolicyGroupSchema(): EntitySchema;
    get(parameters: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalAttestationPolicygroups, unknown>>;
    deleteAttestationPolicyGroup(uidAttestationpolicygroup: string): Promise<EntityCollectionData>;
    getPolicyGroupEdit(uid: string): Promise<ExtendedTypedEntityCollection<PortalAttestationPolicygroups, unknown>>;
    buildNewEntity(reference?: PortalAttestationPolicygroups, filter?: PolicyFilter): Promise<PortalAttestationPolicygroups>;
    copyPropertiesFrom(entity: PortalAttestationPolicygroups, reference: PortalAttestationPolicygroups, filter?: PolicyFilter): Promise<void>;
    getPolicyGroups(parameters: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalAttestationPolicygroups, {}>>;
    handleOpenLoader(): void;
    handleCloseLoader(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyGroupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PolicyGroupService>;
}
