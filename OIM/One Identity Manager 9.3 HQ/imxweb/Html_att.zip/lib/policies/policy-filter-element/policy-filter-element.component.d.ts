import { ChangeDetectorRef, EventEmitter } from '@angular/core';
import { FormGroup, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import { FilterChangedArgument } from '../editors/filter-changed-argument.interface';
import { FilterElementModel } from '../editors/filter-element-model';
import * as i0 from "@angular/core";
export declare class PolicyFilterElementComponent {
    private readonly cd;
    formGroup: FormGroup<{
        filterParameter: UntypedFormControl;
        type: UntypedFormControl;
    }>;
    idForTest: string;
    deleteFilter: EventEmitter<UntypedFormGroup>;
    conditionTypeChanged: EventEmitter<FilterElementModel>;
    parameterChanged: EventEmitter<FilterElementModel>;
    private panel;
    get filterElementModel(): FilterElementModel | undefined;
    constructor(cd: ChangeDetectorRef);
    open(): void;
    selectedConditionTypeChanged(arg: MatSelectChange): void;
    filterParameterChanged(arg: FilterChangedArgument): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyFilterElementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PolicyFilterElementComponent, "imx-policy-filter-element", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "idForTest": { "alias": "idForTest"; "required": false; }; }, { "deleteFilter": "deleteFilter"; "conditionTypeChanged": "conditionTypeChanged"; "parameterChanged": "parameterChanged"; }, never, never, false, never>;
}
