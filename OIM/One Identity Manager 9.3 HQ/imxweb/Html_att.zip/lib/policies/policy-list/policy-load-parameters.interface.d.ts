import { CollectionLoadParameters } from '@imx-modules/imx-qbm-dbts';
export interface PolicyLoadParameters extends CollectionLoadParameters {
    OnlyActivePolicies?: string;
    mypolicies?: string;
}
