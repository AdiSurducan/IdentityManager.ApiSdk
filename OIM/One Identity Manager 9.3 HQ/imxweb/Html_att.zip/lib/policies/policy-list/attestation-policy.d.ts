import { PortalAttestationPolicy } from '@imx-modules/imx-api-att';
export declare class AttestationPolicy extends PortalAttestationPolicy {
    hasAttestations: boolean;
}
