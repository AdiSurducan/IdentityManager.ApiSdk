import { PolicyFilterElement } from '@imx-modules/imx-api-att';
export interface FilterChangedArgument extends PolicyFilterElement {
    displays?: string[];
    setName?: boolean;
}
