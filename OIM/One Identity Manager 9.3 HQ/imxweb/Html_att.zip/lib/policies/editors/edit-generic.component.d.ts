import { EventEmitter, OnChanges } from '@angular/core';
import { ValueStruct } from '@imx-modules/imx-qbm-dbts';
import { ClassloggerService, ColumnDependentReference, MetadataService } from 'qbm';
import { FilterChangedArgument } from './filter-changed-argument.interface';
import { FilterElementModel } from './filter-element-model';
import * as i0 from "@angular/core";
export declare class EditGenericComponent implements OnChanges {
    private readonly logger;
    private readonly metaData;
    cdr: ColumnDependentReference;
    filterElementModel: FilterElementModel;
    identifier: string;
    valueChanged: EventEmitter<FilterChangedArgument>;
    constructor(logger: ClassloggerService, metaData: MetadataService);
    ngOnChanges(): Promise<void>;
    invokeValueChangedEvent(arg: ValueStruct<string>): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditGenericComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditGenericComponent, "imx-edit-generic", never, { "filterElementModel": { "alias": "filterElementModel"; "required": false; }; "identifier": { "alias": "identifier"; "required": false; }; }, { "valueChanged": "valueChanged"; }, never, never, false, never>;
}
