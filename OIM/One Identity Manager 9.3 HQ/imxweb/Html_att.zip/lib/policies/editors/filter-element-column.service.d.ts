import { TranslateService } from '@ngx-translate/core';
import { ParmData } from '@imx-modules/imx-api-att';
import { IEntityColumn } from '@imx-modules/imx-qbm-dbts';
import { EntityService } from 'qbm';
import { PolicyService } from '../policy.service';
import * as i0 from "@angular/core";
export declare class FilterElementColumnService {
    readonly policyService: PolicyService;
    private readonly translateService;
    private readonly entityService;
    constructor(policyService: PolicyService, translateService: TranslateService, entityService: EntityService);
    buildColumn(parmdata: ParmData, uidParameter: string, value: string, caption: string, displays: string[], withfk: boolean): IEntityColumn | undefined;
    private getValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterElementColumnService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FilterElementColumnService>;
}
