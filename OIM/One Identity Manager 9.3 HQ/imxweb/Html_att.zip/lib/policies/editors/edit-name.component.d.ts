import { EventEmitter, OnChanges, OnDestroy } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { ColumnDependentReference } from 'qbm';
import { FilterChangedArgument } from './filter-changed-argument.interface';
import { FilterElementModel } from './filter-element-model';
import * as i0 from "@angular/core";
export declare class EditNameComponent implements OnChanges, OnDestroy {
    filterElementModel: FilterElementModel;
    identifier: string;
    testId: string;
    cdr: ColumnDependentReference;
    valueChanged: EventEmitter<FilterChangedArgument>;
    private valueChangedSubscription;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    invokeValueChangedEvent(control: AbstractControl): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditNameComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditNameComponent, "imx-edit-name", never, { "filterElementModel": { "alias": "filterElementModel"; "required": false; }; "identifier": { "alias": "identifier"; "required": false; }; "testId": { "alias": "testId"; "required": false; }; }, { "valueChanged": "valueChanged"; }, never, never, false, never>;
}
