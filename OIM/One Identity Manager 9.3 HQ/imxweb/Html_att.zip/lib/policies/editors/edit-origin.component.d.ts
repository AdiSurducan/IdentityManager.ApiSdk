import { EventEmitter, OnChanges, OnDestroy } from '@angular/core';
import { FormArray, FormGroup, UntypedFormControl } from '@angular/forms';
import { ParmOpt } from '@imx-modules/imx-api-att';
import { ClassloggerService } from 'qbm';
import { FilterChangedArgument } from './filter-changed-argument.interface';
import { FilterElementModel } from './filter-element-model';
import * as i0 from "@angular/core";
export declare class EditOriginComponent implements OnChanges, OnDestroy {
    private readonly logger;
    candidates: ParmOpt[];
    readonly control: FormArray<UntypedFormControl>;
    form: FormGroup<{
        candidates: FormArray<UntypedFormControl>;
    }>;
    filterElementModel: FilterElementModel;
    identifier: string;
    testId: string;
    valueChanged: EventEmitter<FilterChangedArgument>;
    private selectedParameter;
    private valueChangedSubscription;
    constructor(logger: ClassloggerService);
    ngOnChanges(): void;
    ngOnDestroy(): void;
    private buildNewParameterValue;
    private buildDisplay;
    private isSelected;
    private splitStringAndRemoveQuotes;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditOriginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditOriginComponent, "imx-edit-origin", never, { "filterElementModel": { "alias": "filterElementModel"; "required": false; }; "identifier": { "alias": "identifier"; "required": false; }; "testId": { "alias": "testId"; "required": false; }; }, { "valueChanged": "valueChanged"; }, never, never, false, never>;
}
