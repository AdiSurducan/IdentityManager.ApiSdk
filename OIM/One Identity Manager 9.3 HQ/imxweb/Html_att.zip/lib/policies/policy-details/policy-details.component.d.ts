import { PortalAttestationPolicy } from '@imx-modules/imx-api-att';
import * as i0 from "@angular/core";
export declare class PolicyDetailsComponent {
    readonly data: {
        policy: PortalAttestationPolicy;
    };
    uidAttestationPolicy: string;
    status: string;
    get policy(): PortalAttestationPolicy;
    constructor(data: {
        policy: PortalAttestationPolicy;
    });
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PolicyDetailsComponent, "imx-policy-details", never, {}, {}, never, never, false, never>;
}
