import { OnDestroy, OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { BehaviorSubject } from 'rxjs';
import { PolicyFilter } from '@imx-modules/imx-api-att';
import { ClassloggerService } from 'qbm';
import { PolicyService } from '../policy.service';
import { SelectecObjectsInfo } from './selected-objects-info.interface';
import * as i0 from "@angular/core";
export declare class SelectedObjectsComponent implements OnInit, OnDestroy {
    private readonly sideSheet;
    private readonly policyService;
    private readonly logger;
    filter: PolicyFilter;
    uidAttestationObject: string;
    uidPickCategory: string;
    countMatching: number;
    popupTitle: string;
    popupSubtitle: string;
    isTotal: boolean;
    testId: string;
    filterSubject: BehaviorSubject<SelectecObjectsInfo | undefined>;
    constructor(sideSheet: EuiSidesheetService, policyService: PolicyService, logger: ClassloggerService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    showMatchingObjects(event?: Event): void;
    private getMatchCount;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectedObjectsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectedObjectsComponent, "imx-selected-objects", never, { "popupTitle": { "alias": "popupTitle"; "required": false; }; "popupSubtitle": { "alias": "popupSubtitle"; "required": false; }; "isTotal": { "alias": "isTotal"; "required": false; }; "testId": { "alias": "testId"; "required": false; }; "filterSubject": { "alias": "filterSubject"; "required": false; }; }, {}, never, never, false, never>;
}
