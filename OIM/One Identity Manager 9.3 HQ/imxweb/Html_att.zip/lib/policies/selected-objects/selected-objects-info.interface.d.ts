import { PolicyFilter } from '@imx-modules/imx-api-att';
export interface SelectecObjectsInfo {
    policyFilter: PolicyFilter;
    uidAttestationObject: string;
    uidPickCategory: string;
}
