import * as i0 from "@angular/core";
export declare class ConfirmDeactivationComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmDeactivationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmDeactivationComponent, "imx-confirm-deactivation", never, {}, {}, never, never, false, never>;
}
