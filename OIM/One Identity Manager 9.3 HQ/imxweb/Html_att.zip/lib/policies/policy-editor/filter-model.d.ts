import { BehaviorSubject } from 'rxjs';
import { ParmData, PolicyFilterData, PolicyFilterElement } from '@imx-modules/imx-api-att';
import { FilterElementColumnService } from '../editors/filter-element-column.service';
import { FilterElementModel } from '../editors/filter-element-model';
import { SelectecObjectsInfo } from '../selected-objects/selected-objects-info.interface';
export declare class FilterModel {
    readonly columnFactory: FilterElementColumnService;
    readonly attestationObjectSubject: BehaviorSubject<string>;
    totalSelectedObjectsSubject: BehaviorSubject<SelectecObjectsInfo | undefined>;
    policyFilterData: PolicyFilterData | undefined;
    parameterConfig: ParmData[];
    uidAttestationObject: string;
    constructor(columnFactory: FilterElementColumnService, attestationObjectSubject: BehaviorSubject<string>);
    dispose(): void;
    updateConfig(): Promise<void>;
    addCondition(): FilterElementModel;
    deleteCondition(index: number): void;
    filterHasChanged(filterElements: FilterElementModel[], type: string): void;
    updateConcatination(concat: string): void;
    buildPolicyModel(filterElement: PolicyFilterElement, displays?: string[]): FilterElementModel;
    private filtersAreValid;
}
