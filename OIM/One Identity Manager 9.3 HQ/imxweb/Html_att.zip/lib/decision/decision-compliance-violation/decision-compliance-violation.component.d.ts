import { ComplianceViolation } from '@imx-modules/imx-api-att';
import * as i0 from "@angular/core";
export declare class DecisionComplianceViolationComponent {
    complianceViolations: ComplianceViolation[];
    mitigatingControlsPerViolation: boolean;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<DecisionComplianceViolationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DecisionComplianceViolationComponent, "imx-decision-compliance-violation", never, { "complianceViolations": { "alias": "complianceViolations"; "required": false; }; "mitigatingControlsPerViolation": { "alias": "mitigatingControlsPerViolation"; "required": false; }; }, {}, never, ["*"], false, never>;
}
