import { EntitlementLossDto } from '@imx-modules/imx-api-att';
import { AttestationCase } from './attestation-case';
export interface LossPreview {
    Case?: AttestationCase;
    LossPreviewItems: EntitlementLossDto[];
    LossPreviewHeaders: string[];
    LossPreviewDisplayKeys: EntitlementLossDto;
}
