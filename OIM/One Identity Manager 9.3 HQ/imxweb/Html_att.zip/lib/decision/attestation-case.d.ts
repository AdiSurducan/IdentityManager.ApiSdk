import { AttCaseDataRead, AttestationCaseData, AttestationCaseUiData, PortalAttestationApprove } from '@imx-modules/imx-api-att';
import { IEntity, IEntityColumn, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { ColumnDependentReference } from 'qbm';
import { ParameterDataContainer } from 'qer';
import { AttestationCaseAction } from '../attestation-action/attestation-case-action.interface';
export declare class AttestationCase extends PortalAttestationApprove implements AttestationCaseAction {
    private readonly baseObject;
    private readonly parameterDataContainer;
    get decisionOffset(): number;
    get isOverdue(): boolean;
    get attestationParameters(): IEntityColumn[];
    get canAskAQuestion(): boolean;
    readonly propertyInfo: ColumnDependentReference[];
    readonly key: string;
    readonly data: AttestationCaseData | undefined;
    readonly typedEntity: TypedEntity;
    readonly propertiesForAction: IEntityColumn[];
    readonly uiData: AttestationCaseUiData | undefined;
    get hasPolicyViolation(): boolean;
    private directDecisionTarget;
    private readonly workflowWrapper;
    constructor(baseObject: PortalAttestationApprove, parameterDataContainer: ParameterDataContainer, extendedCollectionData: {
        index: number;
    } & AttCaseDataRead);
    updateDirectDecisionTarget(workflow: IEntity): void;
    commit(reload?: boolean): Promise<void>;
    canDenyApproval(userUid: string): boolean;
    getLevelNumbers(userUid: string): number[];
    canRerouteDecision(userUid: string): boolean;
    canAddApprover(userUid: string): boolean;
    get hasOpenQuestions(): boolean;
    canDelegateDecision(userUid: string): boolean;
    hasAskedLastQuestion(userUid: string): boolean;
    canWithdrawAddApprover(userUid: string): boolean;
    canEscalateDecision(userUid: string): boolean;
}
