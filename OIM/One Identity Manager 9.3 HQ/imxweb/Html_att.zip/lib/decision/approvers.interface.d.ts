import { EntityData } from '@imx-modules/imx-qbm-dbts';
export interface Approvers {
    current: EntityData[];
    future: EntityData[];
    canSeeSteps: boolean;
}
