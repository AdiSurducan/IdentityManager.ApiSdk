import { CollectionLoadParameters } from '@imx-modules/imx-qbm-dbts';
export interface AttestationDecisionLoadParameters extends CollectionLoadParameters {
    Escalation?: boolean;
    uid_attestationhelper?: string;
    uid_attestationcase?: string;
    uidpolicy?: string;
}
export declare enum AttestationDecisionAction {
    none = 0,
    approve = 1,
    deny = 2,
    denydecision = 3,
    showcase = 4
}
