import { EuiSidesheetRef } from '@elemental-ui/core';
import { LossPreview } from '../loss-preview.interface';
import * as i0 from "@angular/core";
export declare class LossPreviewSidesheetComponent {
    data: {
        lossPreview: LossPreview;
        decisionFunc: () => Promise<void>;
    };
    private sidesheetRef;
    constructor(data: {
        lossPreview: LossPreview;
        decisionFunc: () => Promise<void>;
    }, sidesheetRef: EuiSidesheetRef);
    /**
     * Cancel denial process, close sidesheet
     */
    onCancel(): void;
    /**
     * Continue denial process useing the passed denial function, close sidesheet after
     */
    onDeny(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LossPreviewSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LossPreviewSidesheetComponent, "imx-loss-preview-sidesheet", never, {}, {}, never, never, false, never>;
}
