import { OnDestroy, OnInit } from '@angular/core';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PwoExtendedData, ViewConfigData } from '@imx-modules/imx-api-qer';
import { EntitySchema, ExtendedTypedEntityCollection } from '@imx-modules/imx-qbm-dbts';
import { AuthenticationService, BusyService, DataViewSource, UserMessageService } from 'qbm';
import { ViewConfigService } from 'qer';
import { AttestationActionService } from '../../attestation-action/attestation-action.service';
import { AttestationFeatureGuardService } from '../../attestation-feature-guard.service';
import { AttestationCase } from '../attestation-case';
import { AttestationCasesService } from '../attestation-cases.service';
import { LossPreview } from '../loss-preview.interface';
import { AttestationInquiry } from './attestation-inquiry.model';
import * as i0 from "@angular/core";
export declare class AttestationInquiriesComponent implements OnInit, OnDestroy {
    readonly actionService: AttestationActionService;
    private readonly attestationCasesService;
    private readonly attFeatureService;
    private viewConfigService;
    private readonly sidesheet;
    private readonly messageService;
    private readonly busyServiceElemental;
    private readonly translate;
    dataSource: DataViewSource<AttestationCase>;
    readonly entitySchema: EntitySchema;
    attestationCasesCollection: ExtendedTypedEntityCollection<AttestationCase, PwoExtendedData>;
    hasData: boolean;
    isUserEscalationApprover: boolean;
    mitigatingControlsPerViolation: boolean;
    lossPreview: LossPreview;
    private displayedColumns;
    private readonly subscriptions;
    private dataModel;
    private viewConfig;
    private viewConfigPath;
    userUid: string;
    AttestationInquiry: typeof AttestationInquiry;
    busyService: BusyService;
    constructor(actionService: AttestationActionService, attestationCasesService: AttestationCasesService, attFeatureService: AttestationFeatureGuardService, viewConfigService: ViewConfigService, sidesheet: EuiSidesheetService, messageService: UserMessageService, busyServiceElemental: EuiLoadingService, translate: TranslateService, authentication: AuthenticationService, dataSource: DataViewSource<AttestationCase>);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    getData(): Promise<void>;
    updateConfig(config: ViewConfigData): Promise<void>;
    deleteConfigById(id: string): Promise<void>;
    /**
     * Occurs when user clicks the edit button for a request
     *
     * @param pwo Selected PortalItshopApproveRequests.
     */
    editCase(attestationCase: AttestationCase): Promise<void>;
    getInquiryText(pwo: AttestationCase): string;
    getInquirer(pwo: AttestationCase): string;
    getQueryDate(pwo: AttestationCase): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationInquiriesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationInquiriesComponent, "imx-attestation-inquiries", never, {}, {}, never, never, false, never>;
}
