import { OnInit } from '@angular/core';
import { EntitlementLossDto } from '@imx-modules/imx-api-att';
import { AttestationCasesService } from '../attestation-cases.service';
import { LossPreview } from '../loss-preview.interface';
import * as i0 from "@angular/core";
export declare class LossPreviewTableComponent implements OnInit {
    private caseService;
    lossPreview: LossPreview;
    showTitle: boolean;
    isLoading: boolean;
    lossPreviewItems: EntitlementLossDto[];
    lossPreviewHeaders: string[];
    lossPreviewDisplayKeys: EntitlementLossDto;
    constructor(caseService: AttestationCasesService);
    ngOnInit(): Promise<void>;
    loadData(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LossPreviewTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LossPreviewTableComponent, "imx-loss-preview-table", never, { "lossPreview": { "alias": "lossPreview"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; }, {}, never, never, false, never>;
}
