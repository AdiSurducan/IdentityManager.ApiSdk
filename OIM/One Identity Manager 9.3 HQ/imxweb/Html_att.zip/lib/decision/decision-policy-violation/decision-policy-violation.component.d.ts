import { PolicyViolation } from '@imx-modules/imx-api-att';
import * as i0 from "@angular/core";
export declare class DecisionPolicyViolationComponent {
    policyViolations: PolicyViolation[];
    mitigatingControlsPerViolation: boolean;
    constructor();
    stateDisplay(violation: PolicyViolation): "#LDS#Exception granted" | "#LDS#Exception denied" | "#LDS#Approval decision pending";
    static ɵfac: i0.ɵɵFactoryDeclaration<DecisionPolicyViolationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DecisionPolicyViolationComponent, "imx-decision-policy-violation", never, { "policyViolations": { "alias": "policyViolations"; "required": false; }; "mitigatingControlsPerViolation": { "alias": "mitigatingControlsPerViolation"; "required": false; }; }, {}, never, ["*"], false, never>;
}
