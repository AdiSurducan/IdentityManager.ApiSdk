export declare function canSeeAttestationPolicies(features: string[]): boolean;
export declare function isAttestationAdmin(features: string[]): boolean;
