import { OnChanges, SimpleChanges } from '@angular/core';
import { EntityValue } from '@imx-modules/imx-qbm-dbts';
import { ColumnDependentReference } from 'qbm';
import * as i0 from "@angular/core";
export declare class EntityPropertyEditorComponent implements OnChanges {
    cdr: ColumnDependentReference | undefined;
    property: EntityValue<any>;
    hideIfEmpty: boolean;
    caption: string;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityPropertyEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntityPropertyEditorComponent, "imx-entity-property-editor", never, { "property": { "alias": "property"; "required": false; }; "hideIfEmpty": { "alias": "hideIfEmpty"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; }, {}, never, never, false, never>;
}
