import * as i5 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, Inject, Pipe, EventEmitter, Input, Output, ViewChild, NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import * as i6 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i9 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import * as i5$1 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import * as i6$2 from '@angular/material/list';
import { MatListModule } from '@angular/material/list';
import * as i3 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i3$1 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i4 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i2$1 from 'qbm';
import { calculateSidesheetWidth, BaseCdr, BaseReadonlyCdr, DataSourceWrapper, BusyService, DataViewSource, DataSourceToolbarModule, DataTableModule, CdrModule, ExtModule, SelectedElementsModule, HelpContextualModule, DataViewModule, RouteGuardService, HELP_CONTEXTUAL, LdsReplaceModule } from 'qbm';
import * as i2 from 'qer';
import { JustificationType, JustificationModule, TilesModule, StatisticsModule, ObjectHyperviewModule } from 'qer';
import { DisplayColumns, ValType, DbObjectKey, TypedEntity, TypedEntityBuilder, MethodDefinition, CompareOperator, FilterType } from '@imx-modules/imx-qbm-dbts';
import * as i3$2 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import { V2Client, TypedClient, PortalPersonMitigatingcontrols, PortalRulesMitigatingcontrols, V2ApiClientMethodFactory, PortalRulesViolations } from '@imx-modules/imx-api-cpl';
import * as i2$2 from '@angular/forms';
import { FormControl, UntypedFormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i6$1 from '@angular/material/tooltip';
import * as i8 from '@angular/material/divider';
import { Subject } from 'rxjs';
import * as i8$2 from '@angular/material/tabs';
import { MatTabGroup, MatTabsModule } from '@angular/material/tabs';
import * as i7 from '@angular/material/progress-spinner';
import * as i8$1 from '@angular/material/stepper';
import { MatStepperModule } from '@angular/material/stepper';
import * as i4$1 from '@angular/material/core';
import * as i11 from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import * as i11$1 from '@angular/material/sort';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isExceptionAdmin(groups) {
    return groups.find((item) => item === 'vi_4_RULEADMIN_EXCEPTION') != null;
}
function isRuleStatistics(features) {
    return features.find((item) => item === 'Portal_UI_RuleStatistics') != null;
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class CplPermissionsService {
    userService;
    constructor(userService) {
        this.userService = userService;
    }
    async isExceptionAdmin() {
        return isExceptionAdmin((await this.userService.getGroups()).map((group) => group.Name || '') || []);
    }
    async isRuleStatistics() {
        return isRuleStatistics((await this.userService.getFeatures()).Features || []);
    }
    static ɵfac = function CplPermissionsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CplPermissionsService)(i0.ɵɵinject(i2.UserModelService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: CplPermissionsService, factory: CplPermissionsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CplPermissionsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2.UserModelService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function DashboardPluginComponent_imx_badge_tile_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-badge-tile", 1);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵlistener("actionClick", function DashboardPluginComponent_imx_badge_tile_0_Template_imx_badge_tile_actionClick_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.router.navigate(["compliance", "rulesviolations", "approve"])); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("caption", i0.ɵɵpipeBind1(1, 3, "#LDS#Heading Pending Rule Violations"))("value", ctx_r1.pendingItems == null ? null : ctx_r1.pendingItems.OpenNonCompliance == null ? null : ctx_r1.pendingItems.OpenNonCompliance.toString())("identifier", "cpl-rule-violation-approvals");
} }
class DashboardPluginComponent {
    router;
    dashboardService;
    permissionService;
    userModelSvc;
    pendingItems;
    isExceptionAdmin = false;
    constructor(router, dashboardService, permissionService, userModelSvc) {
        this.router = router;
        this.dashboardService = dashboardService;
        this.permissionService = permissionService;
        this.userModelSvc = userModelSvc;
    }
    async ngOnInit() {
        const busy = this.dashboardService.beginBusy();
        try {
            this.isExceptionAdmin = await this.permissionService.isExceptionAdmin();
            if (this.isExceptionAdmin) {
                this.pendingItems = await this.userModelSvc.getPendingItems();
            }
        }
        finally {
            busy.endBusy();
        }
    }
    static ɵfac = function DashboardPluginComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DashboardPluginComponent)(i0.ɵɵdirectiveInject(i3.Router), i0.ɵɵdirectiveInject(i2.DashboardService), i0.ɵɵdirectiveInject(CplPermissionsService), i0.ɵɵdirectiveInject(i2.UserModelService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DashboardPluginComponent, selectors: [["ng-component"]], decls: 1, vars: 1, consts: [["data-imx-identifier", "cpl-dashboard--plugin-badge-tile-violations-approvals", 3, "caption", "value", "identifier", "actionClick", 4, "ngIf"], ["data-imx-identifier", "cpl-dashboard--plugin-badge-tile-violations-approvals", 3, "actionClick", "caption", "value", "identifier"]], template: function DashboardPluginComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, DashboardPluginComponent_imx_badge_tile_0_Template, 2, 5, "imx-badge-tile", 0);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.isExceptionAdmin && !!(ctx.pendingItems == null ? null : ctx.pendingItems.OpenNonCompliance));
        } }, dependencies: [i5.NgIf, i2.BadgeTileComponent, i4.TranslatePipe], encapsulation: 2 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DashboardPluginComponent, [{
        type: Component,
        args: [{ template: "<imx-badge-tile\n  data-imx-identifier=\"cpl-dashboard--plugin-badge-tile-violations-approvals\"\n  [caption]=\"'#LDS#Heading Pending Rule Violations' | translate\"\n  *ngIf=\"isExceptionAdmin && !!pendingItems?.OpenNonCompliance\"\n  [value]=\"pendingItems?.OpenNonCompliance?.toString()\"\n  [identifier]=\"'cpl-rule-violation-approvals'\"\n  (actionClick)=\"router.navigate(['compliance', 'rulesviolations', 'approve'])\"\n>\n</imx-badge-tile>\n" }]
    }], () => [{ type: i3.Router }, { type: i2.DashboardService }, { type: CplPermissionsService }, { type: i2.UserModelService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DashboardPluginComponent, { className: "DashboardPluginComponent", filePath: "lib\\dashboard-plugin\\dashboard-plugin.component.ts", lineNumber: 36 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$5 = () => ["search"];
class IdentityRuleViolationsMitigationControlComponent {
    busy;
    data;
    dstSettings;
    constructor(busy, data) {
        this.busy = busy;
        this.data = data;
    }
    async ngOnInit() {
        this.getData({});
    }
    async onSearch(key) {
        return this.getData({ StartIndex: 0, search: key });
    }
    async getData(param) {
        if (this.busy.overlayRefs.length === 0) {
            this.busy.show();
        }
        try {
            const dataSource = await this.data.getData(param);
            this.dstSettings = {
                displayedColumns: this.data.displayedColumns,
                dataSource,
                entitySchema: this.data.entitySchema,
                navigationState: param,
            };
        }
        finally {
            this.busy.hide();
        }
    }
    static ɵfac = function IdentityRuleViolationsMitigationControlComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || IdentityRuleViolationsMitigationControlComponent)(i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IdentityRuleViolationsMitigationControlComponent, selectors: [["imx-identity-rule-violations-mitigation-control"]], decls: 6, vars: 5, consts: [["dst", ""], ["eui-sidesheet-content", ""], [3, "navigationStateChanged", "search", "settings", "options"], ["data-imx-identifier", "identity-rule-violations-mitigation-table", "mode", "auto", 3, "dst"], [3, "dst"]], template: function IdentityRuleViolationsMitigationControlComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 1)(1, "mat-card")(2, "imx-data-source-toolbar", 2, 0);
            i0.ɵɵlistener("navigationStateChanged", function IdentityRuleViolationsMitigationControlComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.getData($event)); })("search", function IdentityRuleViolationsMitigationControlComponent_Template_imx_data_source_toolbar_search_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSearch($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelement(4, "imx-data-table", 3)(5, "imx-data-source-paginator", 4);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            const dst_r2 = i0.ɵɵreference(3);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(4, _c0$5));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", dst_r2);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dst", dst_r2);
        } }, dependencies: [i3$1.EuiSidesheetContentDirective, i2$1.DataSourceToolbarComponent, i2$1.DataSourcePaginatorComponent, i2$1.DataTableComponent, i3$2.MatCard] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityRuleViolationsMitigationControlComponent, [{
        type: Component,
        args: [{ selector: 'imx-identity-rule-violations-mitigation-control', template: "<div eui-sidesheet-content>\n  <mat-card>\n    <imx-data-source-toolbar\n      #dst\n      [settings]=\"dstSettings\"\n      [options]=\"['search']\"\n      (navigationStateChanged)=\"getData($event)\"\n      (search)=\"onSearch($event)\"\n    ></imx-data-source-toolbar>\n    <imx-data-table [dst]=\"dst\" data-imx-identifier=\"identity-rule-violations-mitigation-table\" mode=\"auto\"> </imx-data-table>\n    <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\n  </mat-card>\n</div>\n" }]
    }], () => [{ type: i3$1.EuiLoadingService }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(IdentityRuleViolationsMitigationControlComponent, { className: "IdentityRuleViolationsMitigationControlComponent", filePath: "lib\\identity-rule-violations\\identity-rule-violations-mitigation-control\\identity-rule-violations-mitigation-control.component.ts", lineNumber: 43 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing CPL API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function ApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApiService)(i0.ɵɵinject(i2$1.AppConfigService), i0.ɵɵinject(i2$1.ClassloggerService), i0.ɵɵinject(i2$1.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApiService, factory: ApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2$1.AppConfigService }, { type: i2$1.ClassloggerService }, { type: i2$1.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class IdentityRuleViolationService {
    api;
    constructor(api) {
        this.api = api;
    }
    get nonComplianceSchema() {
        return this.api.typedClient.PortalPersonRolemembershipsNoncompliance.GetSchema();
    }
    get portalPersonMitigatingcontrols() {
        return this.api.typedClient.PortalPersonMitigatingcontrols.GetSchema();
    }
    get portalRulesMitigatingcontrols() {
        return this.api.typedClient.PortalRulesMitigatingcontrols.GetSchema();
    }
    async getNonCompliance(uidPerson, parameter) {
        return this.api.typedClient.PortalPersonRolemembershipsNoncompliance.Get(uidPerson, parameter);
    }
    async featureConfig() {
        return this.api.client.portal_compliance_config_get();
    }
    async getPersonMitigatingcontrols(uidComplianceRule, uidPerson, param) {
        return this.api.typedClient.PortalPersonMitigatingcontrols.Get(uidPerson, uidComplianceRule, param);
    }
    async getRulesMitigatingcontrols(uidComplianceRule, param) {
        return this.api.typedClient.PortalRulesMitigatingcontrols.Get(uidComplianceRule, param);
    }
    static ɵfac = function IdentityRuleViolationService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || IdentityRuleViolationService)(i0.ɵɵinject(ApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: IdentityRuleViolationService, factory: IdentityRuleViolationService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityRuleViolationService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$4 = () => ["search"];
const _c1$1 = () => ["__Display", "actions"];
function IdentityRuleViolationsComponent_ng_template_7_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", item_r2.GetEntity().GetDisplayLong(), " ");
} }
function IdentityRuleViolationsComponent_ng_template_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(2, IdentityRuleViolationsComponent_ng_template_7_div_2_Template, 2, 1, "div", 10);
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r2.GetEntity().GetDisplay());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r2.GetEntity().GetDisplay() !== item_r2.GetEntity().GetDisplayLong());
} }
function IdentityRuleViolationsComponent_imx_data_table_column_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-data-table-column", 6);
} if (rf & 2) {
    const displayColumn_r3 = ctx.$implicit;
    i0.ɵɵproperty("entityColumn", displayColumn_r3);
} }
function IdentityRuleViolationsComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 12);
    i0.ɵɵlistener("click", function IdentityRuleViolationsComponent_ng_template_11_Template_button_click_0_listener() { const dataItem_r5 = i0.ɵɵrestoreView(_r4).$implicit; const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.onShowDetails(dataItem_r5)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const dataItem_r5 = ctx.$implicit;
    i0.ɵɵproperty("disabled", !dataItem_r5.HasMitigation.value);
    i0.ɵɵattribute("data-imx-identifier", "identity-rule-violations-" + dataItem_r5.GetEntity().GetKeys().join(","));
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, "#LDS#View mitigating controls"), " ");
} }
class IdentityRuleViolationsComponent {
    busyService;
    metadataService;
    roleMembershipsService;
    settingService;
    sidesheet;
    translate;
    dstSettings;
    DisplayColumns = DisplayColumns;
    displayedColumns;
    caption;
    entitySchema;
    referrer;
    navigationState;
    constructor(busyService, metadataService, roleMembershipsService, settingService, sidesheet, translate, dataProvider) {
        this.busyService = busyService;
        this.metadataService = metadataService;
        this.roleMembershipsService = roleMembershipsService;
        this.settingService = settingService;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.referrer = dataProvider.data;
        this.entitySchema = this.roleMembershipsService.nonComplianceSchema;
        this.navigationState = { PageSize: this.settingService.DefaultPageSize };
        this.displayedColumns = [
            this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchema.Columns.XOrigin,
            this.entitySchema.Columns.XDateInserted,
            { ColumnName: 'actions', Type: ValType.String, afterAdditionals: true, untranslatedDisplay: '#LDS#Actions' },
        ];
    }
    async ngOnInit() {
        const overlay = this.busyService.show();
        try {
            await this.metadataService.updateNonExisting([this.referrer.objecttable]);
        }
        finally {
            this.busyService.hide(overlay);
        }
        this.caption = this.metadataService.tables[this.referrer.objecttable]?.Display;
        return this.getData();
    }
    async onShowDetails(entity) {
        const uidPerson = this.referrer.objectuid;
        const con = await this.roleMembershipsService.featureConfig();
        const data = {
            getData: async (param) => {
                return con.MitigatingControlsPerViolation
                    ? this.roleMembershipsService.getPersonMitigatingcontrols(entity.UID_NonCompliance.value, uidPerson, param)
                    : this.roleMembershipsService.getRulesMitigatingcontrols(entity.UID_NonCompliance.value, param);
            },
            entitySchema: con.MitigatingControlsPerViolation
                ? this.roleMembershipsService.portalPersonMitigatingcontrols
                : this.roleMembershipsService.portalRulesMitigatingcontrols,
            displayedColumns: con.MitigatingControlsPerViolation
                ? [
                    this.roleMembershipsService.portalPersonMitigatingcontrols.Columns.UID_MitigatingControl,
                    this.roleMembershipsService.portalPersonMitigatingcontrols.Columns.UID_PersonWantsOrg,
                    this.roleMembershipsService.portalPersonMitigatingcontrols.Columns.IsInActive,
                ]
                : [this.roleMembershipsService.portalRulesMitigatingcontrols.Columns.UID_MitigatingControl],
        };
        this.sidesheet.open(IdentityRuleViolationsMitigationControlComponent, {
            title: await this.translate.get('#LDS#Heading View Mitigating Controls').toPromise(),
            subTitle: entity.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(),
            disableClose: false,
            testId: 'identity-rule-violation-mitigating-sidesheet',
            data,
        });
    }
    async onNavigationStateChanged(newState) {
        if (newState) {
            this.navigationState = newState;
        }
        await this.getData();
    }
    async onSearch(keywords) {
        this.navigationState.StartIndex = 0;
        this.navigationState.search = keywords;
        await this.getData();
    }
    async getData() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            const dataSource = await this.roleMembershipsService.getNonCompliance(this.referrer.objectuid, this.navigationState);
            this.dstSettings = {
                displayedColumns: this.displayedColumns,
                dataSource,
                entitySchema: this.entitySchema,
                navigationState: this.navigationState,
            };
        }
        finally {
            this.busyService.hide();
        }
    }
    static ɵfac = function IdentityRuleViolationsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || IdentityRuleViolationsComponent)(i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2$1.MetadataService), i0.ɵɵdirectiveInject(IdentityRuleViolationService), i0.ɵɵdirectiveInject(i2$1.SettingsService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i2$1.DynamicTabDataProviderDirective)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IdentityRuleViolationsComponent, selectors: [["ng-component"]], decls: 13, vars: 12, consts: [["dst", ""], ["eui-sidesheet-content", "", 1, "imx-content"], [1, "imx-rule-violation-table-container"], [3, "navigationStateChanged", "search", "settings", "options"], [1, "imx-rule-violation-table"], ["data-imx-identifier", "identity-rule-violations-table", "mode", "manual", 3, "dst", "detailViewVisible"], [3, "entityColumn"], [3, "entityColumn", 4, "ngFor", "ngForOf"], ["columnName", "actions"], [3, "dst"], ["subtitle", "", 4, "ngIf"], ["subtitle", ""], ["mat-button", "", "color", "primary", 3, "click", "disabled"]], template: function IdentityRuleViolationsComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 1)(1, "mat-card", 2)(2, "imx-data-source-toolbar", 3, 0);
            i0.ɵɵlistener("navigationStateChanged", function IdentityRuleViolationsComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onNavigationStateChanged($event)); })("search", function IdentityRuleViolationsComponent_Template_imx_data_source_toolbar_search_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSearch($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "div", 4)(5, "imx-data-table", 5)(6, "imx-data-table-column", 6);
            i0.ɵɵtemplate(7, IdentityRuleViolationsComponent_ng_template_7_Template, 3, 2, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(8, IdentityRuleViolationsComponent_imx_data_table_column_8_Template, 1, 1, "imx-data-table-column", 7);
            i0.ɵɵpipe(9, "excludedColumns");
            i0.ɵɵelementStart(10, "imx-data-table-generic-column", 8);
            i0.ɵɵtemplate(11, IdentityRuleViolationsComponent_ng_template_11_Template, 3, 5, "ng-template");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(12, "imx-data-source-paginator", 9);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            const dst_r7 = i0.ɵɵreference(3);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(10, _c0$4));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", dst_r7)("detailViewVisible", false);
            i0.ɵɵadvance();
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", i0.ɵɵpipeBind2(9, 7, ctx.displayedColumns, i0.ɵɵpureFunction0(11, _c1$1)));
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dst", dst_r7);
        } }, dependencies: [i5.NgForOf, i5.NgIf, i3$1.EuiSidesheetContentDirective, i2$1.DataSourceToolbarComponent, i2$1.DataSourcePaginatorComponent, i2$1.DataTableComponent, i2$1.DataTableColumnComponent, i2$1.DataTableGenericColumnComponent, i6.MatButton, i3$2.MatCard, i2$1.ExcludedColumnsPipe, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-rule-violation-table[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}.imx-content[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;padding:20px}.imx-content[_ngcontent-%COMP%]   .imx-rule-violation-table-container[_ngcontent-%COMP%]{overflow:hidden;display:flex;flex-direction:column;flex:1 1 auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityRuleViolationsComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content class=\"imx-content\">\n  <mat-card class=\"imx-rule-violation-table-container\">\n    <imx-data-source-toolbar\n      #dst\n      [settings]=\"dstSettings\"\n      [options]=\"['search']\"\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\"\n      (search)=\"onSearch($event)\"\n    ></imx-data-source-toolbar>\n    <div class=\"imx-rule-violation-table\">\n      <imx-data-table [dst]=\"dst\" [detailViewVisible]=\"false\" data-imx-identifier=\"identity-rule-violations-table\" mode=\"manual\">\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\n          <ng-template let-item>\n            <div>{{ item.GetEntity().GetDisplay() }}</div>\n            <div *ngIf=\"item.GetEntity().GetDisplay() !== item.GetEntity().GetDisplayLong()\" subtitle>\n              {{ item.GetEntity().GetDisplayLong() }}\n            </div>\n          </ng-template>\n        </imx-data-table-column>\n        <imx-data-table-column\n          *ngFor=\"let displayColumn of displayedColumns | excludedColumns: ['__Display', 'actions']\"\n          [entityColumn]=\"displayColumn\"\n        >\n        </imx-data-table-column>\n\n        <imx-data-table-generic-column columnName=\"actions\">\n          <ng-template let-dataItem>\n            <button\n              mat-button\n              color=\"primary\"\n              [disabled]=\"!dataItem.HasMitigation.value\"\n              [attr.data-imx-identifier]=\"'identity-rule-violations-' + dataItem.GetEntity().GetKeys().join(',')\"\n              (click)=\"onShowDetails(dataItem)\"\n            >\n              {{ '#LDS#View mitigating controls' | translate }}\n            </button>\n          </ng-template>\n        </imx-data-table-generic-column>\n      </imx-data-table>\n      <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\n    </div>\n  </mat-card>\n</div>\n", styles: [":host{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-rule-violation-table{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}.imx-content{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;padding:20px}.imx-content .imx-rule-violation-table-container{overflow:hidden;display:flex;flex-direction:column;flex:1 1 auto}\n"] }]
    }], () => [{ type: i3$1.EuiLoadingService }, { type: i2$1.MetadataService }, { type: IdentityRuleViolationService }, { type: i2$1.SettingsService }, { type: i3$1.EuiSidesheetService }, { type: i4.TranslateService }, { type: i2$1.DynamicTabDataProviderDirective }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(IdentityRuleViolationsComponent, { className: "IdentityRuleViolationsComponent", filePath: "lib\\identity-rule-violations\\identity-rule-violations.component.ts", lineNumber: 48 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ItemValidatorService {
    api;
    constructor(api) {
        this.api = api;
    }
    async getRules() {
        return await this.api.typedClient.PortalRules.Get({ PageSize: 1000 });
    }
    getRulesSchema() {
        return this.api.typedClient.PortalRules.GetSchema();
    }
    static ɵfac = function ItemValidatorService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ItemValidatorService)(i0.ɵɵinject(ApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ItemValidatorService, factory: ItemValidatorService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ItemValidatorService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ComplianceViolationService {
    api;
    constructor(api) {
        this.api = api;
    }
    async getRequestViolations(pwoId) {
        return await this.api.client.portal_itshop_requests_compliance_get(pwoId);
    }
    async getMitigatingControlsPerViolation() {
        return (await this.api.client.portal_compliance_config_get()).MitigatingControlsPerViolation;
    }
    static ɵfac = function ComplianceViolationService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ComplianceViolationService)(i0.ɵɵinject(ApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ComplianceViolationService, factory: ComplianceViolationService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ComplianceViolationService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Class thats extends the {@link PortalPersonMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
class PersonMitigatingControls extends PortalPersonMitigatingcontrols {
    editable;
    baseObject;
    /**
     * The property list depending on the value of the state of a {@link PortalPersonMitigatingcontrols}.
     */
    cdrs;
    formControl = new FormControl('', { nonNullable: true });
    isDeferredData = false;
    constructor(editable, baseObject) {
        super(baseObject.GetEntity());
        this.editable = editable;
        this.baseObject = baseObject;
        this.cdrs = this.initPropertyInfo();
    }
    get uidMitigatingControl() {
        return this.baseObject.UID_MitigatingControl.value;
    }
    set uidMitigatingControl(value) {
        this.baseObject.UID_MitigatingControl.value = value;
    }
    initPropertyInfo() {
        const properties = [this.UID_MitigatingControl, this.IsInActive];
        return properties.map((property) => new BaseCdr(property.Column));
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ExtendedDeferredOperationsData {
    deferred;
    formControl = new FormControl('', { nonNullable: true });
    cdrs;
    isDeferredData = true;
    editable = false;
    get uidMitigatingControl() {
        return this.deferred.Uid || '';
    }
    set uidMitigatingControl(value) {
        this.deferred.Uid = value;
    }
    get displayMitigatingControls() {
        return this.deferred.Display || '';
    }
    isInActive = true;
    data = undefined;
    constructor(deferred, entiyService) {
        this.deferred = deferred;
        const schema = PortalPersonMitigatingcontrols.GetEntitySchema();
        this.cdrs = [
            new BaseReadonlyCdr(entiyService.createLocalEntityColumn({
                ColumnName: 'UID_MitigatingControl',
                Type: ValType.String,
            }, undefined, {
                Value: deferred.Uid,
                DisplayValue: deferred.Display,
            }), '#LDS#Mitigating control'),
            new BaseReadonlyCdr(entiyService.createLocalEntityColumn({
                ColumnName: 'IsInActive',
                Type: ValType.Bool,
            }, undefined, {
                Value: true,
                DisplayValue: '#LDS#Yes',
            }), '#LDS#Inactive'),
        ];
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Class thats extends the {@link PortalPersonMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
class RequestMitigatingControls extends PortalPersonMitigatingcontrols {
    editable;
    baseObject;
    /**
     * The property list depending on the value of the state of a {@link PortalPersonMitigatingcontrols}.
     */
    cdrs;
    formControl = new FormControl('', { nonNullable: true });
    constructor(editable, baseObject) {
        super(baseObject.GetEntity());
        this.editable = editable;
        this.baseObject = baseObject;
        this.cdrs = this.initPropertyInfo();
    }
    isDeferredData = false;
    get uidMitigatingControl() {
        return this.baseObject.UID_MitigatingControl.value;
    }
    set uidMitigatingControl(value) {
        this.baseObject.UID_MitigatingControl.value = value;
    }
    get displayMitigatingControls() {
        return this.baseObject.UID_MitigatingControl.Column.GetDisplayValue();
    }
    get isInActive() {
        return this.baseObject.IsInActive.value;
    }
    get data() {
        return this.baseObject;
    }
    initPropertyInfo() {
        const properties = [this.UID_MitigatingControl, this.IsInActive];
        return properties.map((property) => new BaseCdr(property.Column));
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class MitigatingControlsRequestService {
    apiService;
    constructor(apiService) {
        this.apiService = apiService;
    }
    get mitigationSchema() {
        return this.apiService.typedClient.PortalPersonMitigatingcontrols.GetSchema();
    }
    async getControls(uidPerson, uidNonCompliance) {
        return this.apiService.typedClient.PortalPersonMitigatingcontrols.Get(uidPerson, uidNonCompliance);
    }
    createControl(uidPerson, uidNonCompliance) {
        const newMControl = this.apiService.typedClient.PortalPersonMitigatingcontrols.createEntity({
            Columns: {
                UID_NonCompliance: { Value: uidNonCompliance },
                UID_Person: { Value: uidPerson },
                IsInActive: { Value: false },
            },
        });
        return new RequestMitigatingControls(true, newMControl);
    }
    async postControl(uidPerson, uidNonCompliance, mControl) {
        await this.apiService.typedClient.PortalPersonMitigatingcontrols.Post(uidPerson, uidNonCompliance, mControl);
    }
    async postControlRequest(uidPerson, uidNonCompliance, uidPersonWantsOrg, uidMitigatinControl) {
        const inter = (await this.apiService.typedClient.PortalPersonMitigatingcontrolsInteractive.Get(uidPerson, uidNonCompliance)).Data[0];
        await inter.UID_PersonWantsOrg.Column.PutValue(uidPersonWantsOrg);
        await inter.UID_MitigatingControl.Column.PutValue(uidMitigatinControl);
        await this.apiService.client.portal_person_mitigatingcontrols_interactive_forrequest_get(uidPerson, uidNonCompliance, inter.InteractiveEntityStateData.EntityId || '', { keys: inter.InteractiveEntityStateData.Keys, state: inter.InteractiveEntityStateData.State });
    }
    async deleteControl(mControl) {
        await mControl.data?.GetEntity().MarkForDeletion();
        await mControl.data?.GetEntity().Commit();
    }
    async getCandidates(uid, uidNonCompliance, data, parameter) {
        return this.apiService.client.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(uid, uidNonCompliance, data, parameter);
    }
    static ɵfac = function MitigatingControlsRequestService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlsRequestService)(i0.ɵɵinject(ApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: MitigatingControlsRequestService, factory: MitigatingControlsRequestService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsRequestService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestMitigatingControlFilterPipe {
    transform(items, filter) {
        if (!items || !filter) {
            return items;
        }
        // filter items array, items which match and return true will be
        // kept, false will be filtered out
        return RequestMitigatingControlFilterPipe.getItems(items, filter);
    }
    static getItems(items, filter) {
        switch (filter) {
            case 'active':
                return items.filter((elem) => !elem.isDeferredData && !elem.isInActive);
            case 'inactive':
                return items.filter((elem) => !elem.isDeferredData && elem.isInActive);
            case 'deferred':
                return items.filter((elem) => elem.isDeferredData);
        }
    }
    static ɵfac = function RequestMitigatingControlFilterPipe_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RequestMitigatingControlFilterPipe)(); };
    static ɵpipe = /*@__PURE__*/ i0.ɵɵdefinePipe({ name: "filtered", type: RequestMitigatingControlFilterPipe, pure: false });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RequestMitigatingControlFilterPipe, [{
        type: Pipe,
        args: [{
                name: 'filtered',
                pure: false,
            }]
    }], null, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_mat_error_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#This field is mandatory."), " ");
} }
function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_mat_error_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once."), " ");
} }
function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-select", 9);
    i0.ɵɵlistener("selectionChange", function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_Template_eui_select_selectionChange_0_listener($event) { i0.ɵɵrestoreView(_r1); const mControl_r2 = i0.ɵɵnextContext(2).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onSelectionChange(mControl_r2, $event)); })("openChange", function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_Template_eui_select_openChange_0_listener($event) { i0.ɵɵrestoreView(_r1); const mControl_r2 = i0.ɵɵnextContext(2).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onOpenChange($event, mControl_r2)); });
    i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_div_1_eui_select_1_mat_error_1_Template, 3, 3, "mat-error", 10)(2, MitigatingControlContainerComponent_div_1_div_1_eui_select_1_mat_error_2_Template, 3, 3, "mat-error", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext(2);
    const mControl_r2 = ctx_r3.$implicit;
    const i_r5 = ctx_r3.index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("label", ctx_r2.mitigatingCaption)("filterFunction", ctx_r2.filter)("enableFormFieldMargin", true)("options", ctx_r2.options)("inputControl", mControl_r2.formControl)("hideClearButton", true);
    i0.ɵɵattribute("data-imx-identifier", "mitigating-control-container-" + i_r5 + "-select");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", mControl_r2.formControl.errors == null ? null : mControl_r2.formControl.errors["required"]);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", mControl_r2.formControl.errors == null ? null : mControl_r2.formControl.errors["duplicated"]);
} }
function MitigatingControlContainerComponent_div_1_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 6);
    i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_div_1_eui_select_1_Template, 3, 9, "eui-select", 7);
    i0.ɵɵelement(2, "imx-cdr-editor", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const mControl_r2 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", mControl_r2.editable);
    i0.ɵɵadvance();
    i0.ɵɵproperty("cdr", mControl_r2.cdrs[1]);
} }
function MitigatingControlContainerComponent_div_1_div_2_imx_cdr_editor_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 8);
} if (rf & 2) {
    const cdr_r6 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r6);
} }
function MitigatingControlContainerComponent_div_1_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 6);
    i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_div_2_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const mControl_r2 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", mControl_r2.cdrs);
} }
function MitigatingControlContainerComponent_div_1_button_3_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 12);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵlistener("click", function MitigatingControlContainerComponent_div_1_button_3_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r7); const ctx_r3 = i0.ɵɵnextContext(); const mControl_r2 = ctx_r3.$implicit; const i_r5 = ctx_r3.index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onDelete(mControl_r2, i_r5)); });
    i0.ɵɵelement(3, "eui-icon", 13);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 3, "#LDS#Removes the mitigating control"));
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(2, 5, "#LDS#Remove mitigating control"))("data-imx-identifier", "mitigating-control-container-button-delete- + index");
} }
function MitigatingControlContainerComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 3);
    i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_div_1_Template, 3, 2, "div", 4)(2, MitigatingControlContainerComponent_div_1_div_2_Template, 2, 1, "div", 4)(3, MitigatingControlContainerComponent_div_1_button_3_Template, 4, 7, "button", 5);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const mControl_r2 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", mControl_r2 == null ? null : mControl_r2.editable);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !mControl_r2.editable);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !mControl_r2.isDeferredData);
} }
function MitigatingControlContainerComponent_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 14);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵlistener("click", function MitigatingControlContainerComponent_button_2_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r8); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onCreateControl()); });
    i0.ɵɵelement(3, "eui-icon", 15);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, "#LDS#Assigns a mitigating control"));
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(2, 4, "#LDS#Assign mitigating control"));
} }
class MitigatingControlContainerComponent {
    cd;
    confirmationService;
    mControls = [];
    mitigatingCaption;
    formArray;
    options = [];
    controlDeleted = new EventEmitter();
    controlsRequested = new EventEmitter();
    constructor(cd, confirmationService) {
        this.cd = cd;
        this.confirmationService = confirmationService;
    }
    filter = (option, searchInputValue) => option.value.toString().toUpperCase() === searchInputValue.toUpperCase();
    async onSelectionChange(mcontrol, option) {
        // Multiple is set to false so there is no array of options
        mcontrol.uidMitigatingControl = option.value;
        this.formArray.updateValueAndValidity();
        this.cd.detectChanges();
        return;
    }
    onOpenChange(isopen, mControl) {
        if (!isopen) {
            mControl?.formControl.updateValueAndValidity({ onlySelf: true });
        }
    }
    async onDelete(mControl, index) {
        if (mControl?.uidMitigatingControl !== '' && !(await this.confirmationService.confirmDelete())) {
            return;
        }
        if (!(mControl instanceof ExtendedDeferredOperationsData) && mControl?.GetEntity().GetKeys() != null) {
            this.controlDeleted.emit(mControl);
        }
        this.mControls.splice(index, 1);
        this.formArray.controls.splice(index, 1);
        this.formArray.controls.forEach((elem) => elem.updateValueAndValidity());
        this.cd.detectChanges();
    }
    async onCreateControl() {
        this.controlsRequested.emit();
    }
    static ɵfac = function MitigatingControlContainerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlContainerComponent)(i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i2$1.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlContainerComponent, selectors: [["imx-mitigating-control-container"]], inputs: { mControls: "mControls", mitigatingCaption: "mitigatingCaption", formArray: "formArray", options: "options" }, outputs: { controlDeleted: "controlDeleted", controlsRequested: "controlsRequested" }, decls: 3, vars: 2, consts: [[1, "content"], ["class", "imx-mitigating-control bordered", 4, "ngFor", "ngForOf"], ["data-imx-identifier", "mitigating-control-container-button-add", "mat-icon-button", "", 3, "matTooltip", "click", 4, "ngIf"], [1, "imx-mitigating-control", "bordered"], ["class", "imx-mitigating-control-properties", 4, "ngIf"], ["mat-button", "", "class", "mat-icon-button imx-delete-button", 3, "matTooltip", "click", 4, "ngIf"], [1, "imx-mitigating-control-properties"], [3, "label", "filterFunction", "enableFormFieldMargin", "options", "inputControl", "hideClearButton", "selectionChange", "openChange", 4, "ngIf"], [3, "cdr"], [3, "selectionChange", "openChange", "label", "filterFunction", "enableFormFieldMargin", "options", "inputControl", "hideClearButton"], [4, "ngIf"], [3, "cdr", 4, "ngFor", "ngForOf"], ["mat-button", "", 1, "mat-icon-button", "imx-delete-button", 3, "click", "matTooltip"], ["icon", "delete"], ["data-imx-identifier", "mitigating-control-container-button-add", "mat-icon-button", "", 3, "click", "matTooltip"], ["icon", "add"]], template: function MitigatingControlContainerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_Template, 4, 3, "div", 1)(2, MitigatingControlContainerComponent_button_2_Template, 4, 6, "button", 2);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.mControls);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.options.length > 0);
        } }, dependencies: [i5.NgForOf, i5.NgIf, i3$1.EuiIconComponent, i3$1.EuiSelectComponent, i6.MatButton, i6.MatIconButton, i5$1.MatError, i6$1.MatTooltip, i2$1.CdrEditorComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;padding:16px 20px}[_nghost-%COMP%]   .control-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}[_nghost-%COMP%]   .imx-mitigating-control.bordered[_ngcontent-%COMP%]{border-bottom:1px solid #797e80}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   eui-select[_ngcontent-%COMP%]{flex:1 1 auto}[_nghost-%COMP%]   .imx-mitigating-control-properties[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;margin-right:15px;gap:15px}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]   .content[_ngcontent-%COMP%]{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .imx-delete-button[_ngcontent-%COMP%]{margin-top:15px;align-self:flex-start}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0;justify-self:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#797e80}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .bordered[_ngcontent-%COMP%]{border-bottom:1px solid #dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .bordered[_ngcontent-%COMP%]{border-bottom:1px solid #ffffff}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlContainerComponent, [{
        type: Component,
        args: [{ selector: 'imx-mitigating-control-container', template: "<div class=\"content\">\n  <div class=\"imx-mitigating-control bordered\" *ngFor=\"let mControl of mControls; index as i\">\n    <!-- editable control-->\n    <div class=\"imx-mitigating-control-properties\" *ngIf=\"mControl?.editable\">\n      <eui-select\n        *ngIf=\"mControl.editable\"\n        (selectionChange)=\"onSelectionChange(mControl, $event)\"\n        [label]=\"mitigatingCaption\"\n        [filterFunction]=\"filter\"\n        [enableFormFieldMargin]=\"true\"\n        [options]=\"options\"\n        [inputControl]=\"mControl.formControl\"\n        (openChange)=\"onOpenChange($event, mControl)\"\n        [hideClearButton]=\"true\"\n        [attr.data-imx-identifier]=\"'mitigating-control-container-' + i + '-select'\"\n      >\n        <mat-error *ngIf=\"mControl.formControl.errors?.['required']\">\n          {{ '#LDS#This field is mandatory.' | translate }}\n        </mat-error>\n        <mat-error *ngIf=\"mControl.formControl.errors?.['duplicated']\">\n          {{ '#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once.' | translate }}\n        </mat-error>\n      </eui-select>\n      <imx-cdr-editor [cdr]=\"mControl.cdrs[1]\"></imx-cdr-editor>\n    </div>\n    <!-- read only control-->\n    <div class=\"imx-mitigating-control-properties\" *ngIf=\"!mControl.editable\">\n      <imx-cdr-editor *ngFor=\"let cdr of mControl.cdrs\" [cdr]=\"cdr\"></imx-cdr-editor>\n    </div>\n\n    <button\n      [matTooltip]=\"'#LDS#Removes the mitigating control' | translate\"\n      [attr.aria-label]=\"'#LDS#Remove mitigating control' | translate\"\n      [attr.data-imx-identifier]=\"'mitigating-control-container-button-delete- + index'\"\n      mat-button\n      *ngIf=\"!mControl.isDeferredData\"\n      class=\"mat-icon-button imx-delete-button\"\n      (click)=\"onDelete(mControl, i)\"\n    >\n      <eui-icon icon=\"delete\"></eui-icon>\n    </button>\n  </div>\n  <button\n    *ngIf=\"options.length > 0\"\n    [matTooltip]=\"'#LDS#Assigns a mitigating control' | translate\"\n    data-imx-identifier=\"mitigating-control-container-button-add\"\n    [attr.aria-label]=\"'#LDS#Assign mitigating control' | translate\"\n    mat-icon-button\n    (click)=\"onCreateControl()\"\n  >\n    <eui-icon icon=\"add\"></eui-icon>\n  </button>\n</div>\n", styles: [":host{height:100%;display:flex;flex-direction:column;justify-content:space-between}:host .eui-sidesheet-actions{display:flex;justify-content:flex-end;padding:16px 20px}:host .control-container{display:flex;flex-direction:column;overflow:auto}:host .imx-mitigating-control{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}:host .imx-mitigating-control.bordered{border-bottom:1px solid #797e80}:host .imx-mitigating-control eui-select{flex:1 1 auto}:host .imx-mitigating-control-properties{display:flex;flex-direction:column;width:100%;margin-right:15px;gap:15px}:host .imx-mitigating-control-content{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:auto}:host .imx-mitigating-control-content .content{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}:host .imx-mitigating-control .imx-delete-button{margin-top:15px;align-self:flex-start}:host .imx-no-mitigating-controls{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}:host .imx-no-results{text-align:center;margin:20px 0;justify-self:center}:host .imx-no-results p{margin:0;font-size:18px}:host .imx-no-results button{margin-top:10px}:host .imx-no-results p{color:#797e80}:host .imx-no-mitigating-controls{color:#797e80}.eui-dark-theme :host .imx-no-results p{color:#dfe4e6}.eui-dark-theme :host .imx-no-mitigating-controls{color:#dfe4e6}.eui-dark-theme :host .imx-mitigating-control .bordered{border-bottom:1px solid #dfe4e6}.eui-contrast-theme :host .imx-data-no-results p{color:#fff}.eui-contrast-theme :host .imx-no-mitigating-controls{color:#fff}.eui-contrast-theme :host .imx-mitigating-control .bordered{border-bottom:1px solid #ffffff}\n"] }]
    }], () => [{ type: i0.ChangeDetectorRef }, { type: i2$1.ConfirmationService }], { mControls: [{
            type: Input
        }], mitigatingCaption: [{
            type: Input
        }], formArray: [{
            type: Input
        }], options: [{
            type: Input
        }], controlDeleted: [{
            type: Output
        }], controlsRequested: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MitigatingControlContainerComponent, { className: "MitigatingControlContainerComponent", filePath: "lib\\mitigating-control-container\\mitigating-control-container.component.ts", lineNumber: 40 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MitigatingControlsRequestComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Here you can assign mitigating controls to the rule violation. NOTE: If no mitigating controls have been assigned to the violated compliance rule, you cannot assign any mitigating controls to the rule violation either."), " ");
} }
function MitigatingControlsRequestComponent_ng_container_10_mat_card_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 7)(1, "imx-mitigating-control-container", 8);
    i0.ɵɵlistener("controlsRequested", function MitigatingControlsRequestComponent_ng_container_10_mat_card_1_Template_imx_mitigating_control_container_controlsRequested_1_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onCreateControl()); })("controlDeleted", function MitigatingControlsRequestComponent_ng_container_10_mat_card_1_Template_imx_mitigating_control_container_controlDeleted_1_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onControlDeleted($event)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("mControls", ctx_r1.mControls)("formArray", ctx_r1.formArray)("options", ctx_r1.options);
} }
function MitigatingControlsRequestComponent_ng_container_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, MitigatingControlsRequestComponent_ng_container_10_mat_card_1_Template, 2, 3, "mat-card", 6);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    const readOnlyView_r3 = i0.ɵɵreference(14);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r1.readOnly)("ngIfElse", readOnlyView_r3);
} }
function MitigatingControlsRequestComponent_mat_card_11_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 13);
    i0.ɵɵlistener("click", function MitigatingControlsRequestComponent_mat_card_11_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onCreateControl()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Assign mitigating controls"), " ");
} }
function MitigatingControlsRequestComponent_mat_card_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card", 9)(1, "div", 10);
    i0.ɵɵelement(2, "eui-icon", 11);
    i0.ɵɵelementStart(3, "p");
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(6, MitigatingControlsRequestComponent_mat_card_11_button_6_Template, 3, 3, "button", 12);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(5, 2, ctx_r1.options.length > 0 ? "#LDS#There are currently no mitigating controls assigned to this rule violation." : "#LDS#There are currently no mitigating controls that can be assigned to this rule violation."), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.options.length > 0);
} }
function MitigatingControlsRequestComponent_mat_card_12_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 14)(1, "button", 15);
    i0.ɵɵlistener("click", function MitigatingControlsRequestComponent_mat_card_12_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onSave()); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", ctx_r1.notSaveable);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Save"), " ");
} }
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_1_imx_cdr_editor_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 21);
} if (rf & 2) {
    const mControl_r6 = ctx.$implicit;
    i0.ɵɵproperty("cdr", mControl_r6.cdrs[0]);
} }
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-expansion-panel", 19)(1, "mat-expansion-panel-header")(2, "mat-panel-title");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(5, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_1_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 20);
    i0.ɵɵpipe(6, "filtered");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵproperty("expanded", true);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 3, "#LDS#Active mitigating controls"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", i0.ɵɵpipeBind2(6, 5, ctx_r1.mControls, "active"));
} }
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_2_imx_cdr_editor_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 21);
} if (rf & 2) {
    const mControl_r7 = ctx.$implicit;
    i0.ɵɵproperty("cdr", mControl_r7.cdrs[0]);
} }
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-expansion-panel", 19)(1, "mat-expansion-panel-header")(2, "mat-panel-title");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(5, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_2_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 20);
    i0.ɵɵpipe(6, "filtered");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵproperty("expanded", true);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 3, "#LDS#Inactive mitigating controls"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", i0.ɵɵpipeBind2(6, 5, ctx_r1.mControls, "inactive"));
} }
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-accordion", 17);
    i0.ɵɵtemplate(1, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_1_Template, 7, 8, "mat-expansion-panel", 18)(2, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_2_Template, 7, 8, "mat-expansion-panel", 18);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.hasItems("active"));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.hasItems("inactive"));
} }
function MitigatingControlsRequestComponent_ng_template_13_mat_card_1_imx_cdr_editor_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 21);
} if (rf & 2) {
    const mControl_r8 = ctx.$implicit;
    i0.ɵɵproperty("cdr", mControl_r8.cdrs[0]);
} }
function MitigatingControlsRequestComponent_ng_template_13_mat_card_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card");
    i0.ɵɵtemplate(1, MitigatingControlsRequestComponent_ng_template_13_mat_card_1_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 20);
    i0.ɵɵpipe(2, "filtered");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", i0.ɵɵpipeBind2(2, 1, ctx_r1.mControls, "deferred"));
} }
function MitigatingControlsRequestComponent_ng_template_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_Template, 3, 2, "mat-accordion", 16)(1, MitigatingControlsRequestComponent_ng_template_13_mat_card_1_Template, 3, 4, "mat-card", 3);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngIf", ctx_r1.mControls.length > 0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.hasItems("deferred"));
} }
class MitigatingControlsRequestComponent {
    mControlService;
    formBuilder;
    cd;
    busyService;
    snackbarService;
    settingService;
    confirmationService;
    entityService;
    uidPerson;
    uidNonCompliance;
    uidPersonWantsOrg;
    status;
    sidesheetRef;
    readOnly;
    closeOnSave;
    isMControlPerViolation;
    subscriptions$ = [];
    formGroup;
    options = [];
    mControls = [];
    mControlsToDelete = [];
    mitigatingCaption;
    headertext;
    constructor(mControlService, formBuilder, cd, busyService, snackbarService, settingService, confirmationService, entityService) {
        this.mControlService = mControlService;
        this.formBuilder = formBuilder;
        this.cd = cd;
        this.busyService = busyService;
        this.snackbarService = snackbarService;
        this.settingService = settingService;
        this.confirmationService = confirmationService;
        this.entityService = entityService;
        this.mitigatingCaption = mControlService.mitigationSchema.Columns.UID_MitigatingControl.Display || '';
        this.formGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    get formArray() {
        return this.formGroup.get('formArray');
    }
    hasItems(filter) {
        return RequestMitigatingControlFilterPipe.getItems(this.mControls, filter)?.length > 0;
    }
    get itemText() {
        return this.mControls.every((elem) => elem.isDeferredData)
            ? '#LDS#The following mitigating controls will be automatically assigned to the rule violation if this request is approved.'
            : '#LDS#The following mitigating controls are assigned to this request.';
    }
    get notSaveable() {
        if (this.mControlsToDelete.length !== 0) {
            this.formGroup.markAsDirty();
        }
        if (!this.formGroup.dirty || !this.formGroup.valid) {
            return true;
        }
        return (this.mControls.length > 0 &&
            this.mControls.every((ctrl) => {
                return !ctrl.editable || ctrl.uidMitigatingControl === null || ctrl.uidMitigatingControl === '';
            }) &&
            this.mControlsToDelete.length === 0);
    }
    get isDirty() {
        return this.formGroup.dirty || this.mControlsToDelete.length > 0;
    }
    async ngOnInit() {
        this.subscriptions$.push(this.sidesheetRef.closeClicked().subscribe(async () => {
            if (!this.isDirty || (await this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close();
            }
        }));
        this.headertext = !this.readOnly ? '#LDS#Heading Mitigating Controls Can Be Assigned Individually' : '#LDS#Heading Mitigating Controls';
        await this.loadMitigatingControls();
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
    async onSelectionChange(mcontrol, value) {
        mcontrol.UID_MitigatingControl.value = value;
        this.formArray.updateValueAndValidity();
        this.cd.detectChanges();
        return;
    }
    onOpenChange(isopen, mControl) {
        if (!isopen) {
            mControl.formControl.updateValueAndValidity({ onlySelf: true });
        }
    }
    onControlDeleted(mControl) {
        if (!(mControl instanceof PersonMitigatingControls)) {
            this.mControlsToDelete.push(mControl);
        }
    }
    getMControlId(mControl) {
        return mControl.GetEntity().GetColumn('UID_MitigatingControl').GetValue();
    }
    async onCreateControl() {
        const mControl = this.mControlService.createControl(this.uidPerson, this.uidNonCompliance);
        this.mControls.push(mControl);
        this.formArray.push(mControl.formControl);
        this.cd.detectChanges();
        mControl.formControl.setValidators([
            Validators.required,
            (control) => (this.isDuplicate(control) ? { duplicated: true } : null),
        ]);
        this.formGroup.markAsDirty();
    }
    async onSave() {
        const overlay = this.busyService.show();
        try {
            await this.handleSave();
        }
        finally {
            this.busyService.hide(overlay);
            this.snackbarService.open({
                key: '#LDS#The mitigating controls have been successfully saved.',
            });
            if (this.closeOnSave) {
                this.sidesheetRef.close();
            }
        }
    }
    async handleSave() {
        for (const ctrl of this.mControlsToDelete) {
            await this.mControlService.deleteControl(ctrl);
        }
        for (const ctrl of this.mControls.filter((elem) => elem.editable)) {
            if (this.uidPersonWantsOrg != null && this.uidPersonWantsOrg !== '') {
                await this.mControlService.postControlRequest(this.uidPerson, this.uidNonCompliance, this.uidPersonWantsOrg, ctrl.uidMitigatingControl);
            }
            else if (ctrl.data) {
                await this.mControlService.postControl(this.uidPerson, this.uidNonCompliance, ctrl.data);
            }
        }
        if (!this.closeOnSave) {
            this.resetForm();
        }
    }
    async resetForm() {
        // Since we must handle change detection manually, overwrite formgroup and get read-only mcontrols
        this.formGroup = new UntypedFormGroup({ formArray: this.formBuilder.array([]) });
        this.mControlsToDelete = [];
        await this.loadMitigatingControls();
        this.cd.detectChanges();
    }
    async loadMitigatingControls() {
        if (!this.isMControlPerViolation) {
            this.mControls = [];
            return;
        }
        const overlay = this.busyService.show();
        try {
            //reload
            const data = await this.mControlService.getControls(this.uidPerson, this.uidNonCompliance);
            this.mControls = data.Data.map((elem) => new RequestMitigatingControls(false, elem));
            this.mControls.push(...(data.extendedData?.MitigatingControls?.map((elem) => new ExtendedDeferredOperationsData(elem, this.entityService)) || []));
            if (!this.readOnly) {
                this.mControls.forEach((elem) => this.formArray.push(elem.formControl));
                await this.initOptions();
            }
        }
        finally {
            this.busyService.hide(overlay);
        }
    }
    isDuplicate(actrl) {
        const test = this.mControls.findIndex((ctrl) => ctrl.formControl != actrl && ctrl?.uidMitigatingControl === actrl.value) !== -1;
        return test;
    }
    async initOptions() {
        const optionCandidates = await this.mControlService.getCandidates(this.uidPerson, this.uidNonCompliance, {}, {
            PageSize: this.settingService.PageSizeForAllElements,
        });
        this.options =
            optionCandidates.Entities?.map((elem) => ({ display: elem.Display || '', value: elem.Keys?.[0] })) || [];
    }
    static ɵfac = function MitigatingControlsRequestComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlsRequestComponent)(i0.ɵɵdirectiveInject(MitigatingControlsRequestService), i0.ɵɵdirectiveInject(i2$2.UntypedFormBuilder), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2$1.SnackBarService), i0.ɵɵdirectiveInject(i2$1.SettingsService), i0.ɵɵdirectiveInject(i2$1.ConfirmationService), i0.ɵɵdirectiveInject(i2$1.EntityService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsRequestComponent, selectors: [["imx-mitigating-controls-request"]], inputs: { uidPerson: "uidPerson", uidNonCompliance: "uidNonCompliance", uidPersonWantsOrg: "uidPersonWantsOrg", status: "status", sidesheetRef: "sidesheetRef", readOnly: "readOnly", closeOnSave: "closeOnSave", isMControlPerViolation: "isMControlPerViolation" }, decls: 15, vars: 11, consts: [["readOnlyView", ""], ["eui-sidesheet-content", "", 1, "control-container"], ["type", "info", 3, "colored"], [4, "ngIf"], ["class", "imx-no-mitigating-controls", 4, "ngIf"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["class", "imx-mitigating-control-content", 4, "ngIf", "ngIfElse"], [1, "imx-mitigating-control-content"], [3, "controlsRequested", "controlDeleted", "mControls", "formArray", "options"], [1, "imx-no-mitigating-controls"], [1, "imx-data-no-results"], ["icon", "table"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-request-button-add", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-request-button-add", 3, "click"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-request-button-save", 3, "click", "disabled"], ["multi", "", 4, "ngIf"], ["multi", ""], [3, "expanded", 4, "ngIf"], [3, "expanded"], [3, "cdr", 4, "ngFor", "ngForOf"], [3, "cdr"]], template: function MitigatingControlsRequestComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 1)(1, "eui-alert", 2)(2, "eui-alert-header");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "eui-alert-content");
            i0.ɵɵtemplate(6, MitigatingControlsRequestComponent_div_6_Template, 3, 3, "div", 3);
            i0.ɵɵelementStart(7, "div");
            i0.ɵɵtext(8);
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵelementEnd()()();
            i0.ɵɵtemplate(10, MitigatingControlsRequestComponent_ng_container_10_Template, 2, 2, "ng-container", 3)(11, MitigatingControlsRequestComponent_mat_card_11_Template, 7, 4, "mat-card", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(12, MitigatingControlsRequestComponent_mat_card_12_Template, 4, 4, "mat-card", 5)(13, MitigatingControlsRequestComponent_ng_template_13_Template, 2, 2, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("colored", true);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 7, ctx.headertext));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", !ctx.readOnly);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 9, ctx.itemText), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.mControls != null && ctx.mControls.length > 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.readOnly && ctx.isMControlPerViolation && ctx.options.length > 0);
        } }, dependencies: [i2$1.CdrEditorComponent, i5.NgForOf, i5.NgIf, i3$1.EuiAlertComponent, i3$1.EuiAlertContentDirective, i3$1.EuiAlertHeaderDirective, i3$1.EuiIconComponent, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i6.MatButton, i3$2.MatCard, i9.MatAccordion, i9.MatExpansionPanel, i9.MatExpansionPanelHeader, i9.MatExpansionPanelTitle, MitigatingControlContainerComponent, i4.TranslatePipe, RequestMitigatingControlFilterPipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;padding:16px 20px}[_nghost-%COMP%]   .control-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}[_nghost-%COMP%]   .imx-mitigating-control.bordered[_ngcontent-%COMP%]{border-bottom:1px solid #797e80}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   eui-select[_ngcontent-%COMP%]{flex:1 1 auto}[_nghost-%COMP%]   .imx-mitigating-control-properties[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;margin-right:15px;gap:15px}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]   .content[_ngcontent-%COMP%]{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .imx-delete-button[_ngcontent-%COMP%]{margin-top:15px;align-self:flex-start}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0;justify-self:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#797e80}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .bordered[_ngcontent-%COMP%]{border-bottom:1px solid #dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .bordered[_ngcontent-%COMP%]{border-bottom:1px solid #ffffff}", "[_nghost-%COMP%]   .mitigating-control-readonly[_ngcontent-%COMP%]{margin-bottom:15px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsRequestComponent, [{
        type: Component,
        args: [{ selector: 'imx-mitigating-controls-request', template: "<div class=\"control-container\" eui-sidesheet-content>\n  <eui-alert type=\"info\" [colored]=\"true\">\n    <eui-alert-header>{{ headertext | translate }}</eui-alert-header>\n    <eui-alert-content>\n      <div *ngIf=\"!readOnly\">\n        {{\n          '#LDS#Here you can assign mitigating controls to the rule violation. NOTE: If no mitigating controls have been assigned to the violated compliance rule, you cannot assign any mitigating controls to the rule violation either.'\n            | translate\n        }}\n      </div>\n      <div>\n        {{ itemText | translate }}\n      </div>\n    </eui-alert-content>\n  </eui-alert>\n  <ng-container *ngIf=\"mControls != null && mControls.length > 0\">\n    <mat-card class=\"imx-mitigating-control-content\" *ngIf=\"!readOnly; else readOnlyView\">\n      <imx-mitigating-control-container\n        [mControls]=\"mControls\"\n        [formArray]=\"formArray\"\n        [options]=\"options\"\n        (controlsRequested)=\"onCreateControl()\"\n        (controlDeleted)=\"onControlDeleted($event)\"\n      ></imx-mitigating-control-container>\n    </mat-card>\n  </ng-container>\n\n  <mat-card class=\"imx-no-mitigating-controls\" *ngIf=\"!mControls || mControls.length == 0\">\n    <div class=\"imx-data-no-results\">\n      <eui-icon icon=\"table\"></eui-icon>\n      <p>\n        {{\n          (options.length > 0\n            ? '#LDS#There are currently no mitigating controls assigned to this rule violation.'\n            : '#LDS#There are currently no mitigating controls that can be assigned to this rule violation.'\n          ) | translate\n        }}\n      </p>\n      <button\n        *ngIf=\"options.length > 0\"\n        mat-stroked-button\n        color=\"primary\"\n        data-imx-identifier=\"mitigating-controls-request-button-add\"\n        (click)=\"onCreateControl()\"\n      >\n        {{ '#LDS#Assign mitigating controls' | translate }}\n      </button>\n    </div>\n  </mat-card>\n</div>\n\n<mat-card eui-sidesheet-actions *ngIf=\"!readOnly && isMControlPerViolation && options.length > 0\">\n  <button\n    mat-flat-button\n    color=\"primary\"\n    (click)=\"onSave()\"\n    [disabled]=\"notSaveable\"\n    data-imx-identifier=\"mitigating-controls-request-button-save\"\n  >\n    {{ '#LDS#Save' | translate }}\n  </button>\n</mat-card>\n\n<ng-template #readOnlyView>\n  <mat-accordion multi *ngIf=\"mControls.length > 0\">\n    <mat-expansion-panel [expanded]=\"true\" *ngIf=\"hasItems('active')\">\n      <mat-expansion-panel-header>\n        <mat-panel-title>\n          {{ '#LDS#Active mitigating controls' | translate }}\n        </mat-panel-title>\n      </mat-expansion-panel-header>\n      <imx-cdr-editor *ngFor=\"let mControl of mControls | filtered: 'active'\" [cdr]=\"mControl.cdrs[0]\"></imx-cdr-editor>\n    </mat-expansion-panel>\n    <mat-expansion-panel [expanded]=\"true\" *ngIf=\"hasItems('inactive')\">\n      <mat-expansion-panel-header>\n        <mat-panel-title>\n          {{ '#LDS#Inactive mitigating controls' | translate }}\n        </mat-panel-title>\n      </mat-expansion-panel-header>\n      <imx-cdr-editor *ngFor=\"let mControl of mControls | filtered: 'inactive'\" [cdr]=\"mControl.cdrs[0]\"></imx-cdr-editor>\n    </mat-expansion-panel>\n  </mat-accordion>\n  <mat-card *ngIf=\"hasItems('deferred')\">\n    <imx-cdr-editor *ngFor=\"let mControl of mControls | filtered: 'deferred'\" [cdr]=\"mControl.cdrs[0]\"></imx-cdr-editor>\n  </mat-card>\n</ng-template>\n", styles: [":host{height:100%;display:flex;flex-direction:column;justify-content:space-between}:host .eui-sidesheet-actions{display:flex;justify-content:flex-end;padding:16px 20px}:host .control-container{display:flex;flex-direction:column;overflow:auto}:host .imx-mitigating-control{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}:host .imx-mitigating-control.bordered{border-bottom:1px solid #797e80}:host .imx-mitigating-control eui-select{flex:1 1 auto}:host .imx-mitigating-control-properties{display:flex;flex-direction:column;width:100%;margin-right:15px;gap:15px}:host .imx-mitigating-control-content{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:auto}:host .imx-mitigating-control-content .content{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}:host .imx-mitigating-control .imx-delete-button{margin-top:15px;align-self:flex-start}:host .imx-no-mitigating-controls{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}:host .imx-no-results{text-align:center;margin:20px 0;justify-self:center}:host .imx-no-results p{margin:0;font-size:18px}:host .imx-no-results button{margin-top:10px}:host .imx-no-results p{color:#797e80}:host .imx-no-mitigating-controls{color:#797e80}.eui-dark-theme :host .imx-no-results p{color:#dfe4e6}.eui-dark-theme :host .imx-no-mitigating-controls{color:#dfe4e6}.eui-dark-theme :host .imx-mitigating-control .bordered{border-bottom:1px solid #dfe4e6}.eui-contrast-theme :host .imx-data-no-results p{color:#fff}.eui-contrast-theme :host .imx-no-mitigating-controls{color:#fff}.eui-contrast-theme :host .imx-mitigating-control .bordered{border-bottom:1px solid #ffffff}\n", ":host .mitigating-control-readonly{margin-bottom:15px}\n"] }]
    }], () => [{ type: MitigatingControlsRequestService }, { type: i2$2.UntypedFormBuilder }, { type: i0.ChangeDetectorRef }, { type: i3$1.EuiLoadingService }, { type: i2$1.SnackBarService }, { type: i2$1.SettingsService }, { type: i2$1.ConfirmationService }, { type: i2$1.EntityService }], { uidPerson: [{
            type: Input
        }], uidNonCompliance: [{
            type: Input
        }], uidPersonWantsOrg: [{
            type: Input
        }], status: [{
            type: Input
        }], sidesheetRef: [{
            type: Input
        }], readOnly: [{
            type: Input
        }], closeOnSave: [{
            type: Input
        }], isMControlPerViolation: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MitigatingControlsRequestComponent, { className: "MitigatingControlsRequestComponent", filePath: "lib\\request\\compliance-violation-details\\edit-mitigating-controls\\mitigating-controls-request\\mitigating-controls-request.component.ts", lineNumber: 44 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EditMitigatingControlsComponent {
    sidesheetRef;
    data;
    constructor(sidesheetRef, data) {
        this.sidesheetRef = sidesheetRef;
        this.data = data;
    }
    static ɵfac = function EditMitigatingControlsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EditMitigatingControlsComponent)(i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditMitigatingControlsComponent, selectors: [["ng-component"]], decls: 2, vars: 7, consts: [["eui-sidesheet-content", ""], [3, "isMControlPerViolation", "closeOnSave", "uidPerson", "uidNonCompliance", "uidPersonWantsOrg", "sidesheetRef", "readOnly"]], template: function EditMitigatingControlsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "imx-mitigating-controls-request", 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("isMControlPerViolation", ctx.data.isMControlPerViolation)("closeOnSave", true)("uidPerson", ctx.data.uidPerson)("uidNonCompliance", ctx.data.uidNonCompliance)("uidPersonWantsOrg", ctx.data.uidPersonWantsOrg)("sidesheetRef", ctx.sidesheetRef)("readOnly", ctx.data.readOnly);
        } }, dependencies: [i3$1.EuiSidesheetContentDirective, MitigatingControlsRequestComponent], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{padding:0}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditMitigatingControlsComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\n  <imx-mitigating-controls-request\n    [isMControlPerViolation]=\"data.isMControlPerViolation\"\n    [closeOnSave]=\"true\"\n    [uidPerson]=\"data.uidPerson\"\n    [uidNonCompliance]=\"data.uidNonCompliance\"\n    [uidPersonWantsOrg]=\"data.uidPersonWantsOrg\"\n    [sidesheetRef]=\"sidesheetRef\"\n    [readOnly]=\"data.readOnly\"\n  ></imx-mitigating-controls-request>\n</div>\n", styles: [".eui-sidesheet-content{padding:0}\n"] }]
    }], () => [{ type: i3$1.EuiSidesheetRef }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EditMitigatingControlsComponent, { className: "EditMitigatingControlsComponent", filePath: "lib\\request\\compliance-violation-details\\edit-mitigating-controls\\edit-mitigating-controls.component.ts", lineNumber: 34 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function WorkflowViolationDetailsComponent_mat_expansion_panel_5_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 5);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 6);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const item_r1 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Affected identity"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", item_r1 == null ? null : item_r1.Columns == null ? null : item_r1.Columns["UID_PersonRelated"] == null ? null : item_r1.Columns["UID_PersonRelated"].DisplayValue, " ");
} }
function WorkflowViolationDetailsComponent_mat_expansion_panel_5_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 5);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 6);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const item_r1 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Approval procedure"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", item_r1 == null ? null : item_r1.Columns == null ? null : item_r1.Columns["UID_PWODecisionRule"] == null ? null : item_r1.Columns["UID_PWODecisionRule"].DisplayValue, " ");
} }
function WorkflowViolationDetailsComponent_mat_expansion_panel_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-expansion-panel")(1, "mat-expansion-panel-header")(2, "mat-panel-title");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-panel-description");
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(6, WorkflowViolationDetailsComponent_mat_expansion_panel_5_ng_container_6_Template, 6, 4, "ng-container", 4)(7, WorkflowViolationDetailsComponent_mat_expansion_panel_5_ng_container_7_Template, 6, 4, "ng-container", 4);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", item_r1 == null ? null : item_r1.Columns == null ? null : item_r1.Columns["UID_ComplianceRule"] == null ? null : item_r1.Columns["UID_ComplianceRule"].DisplayValue, " ");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r1 == null ? null : item_r1.Columns == null ? null : item_r1.Columns["DateHead"] == null ? null : item_r1.Columns["DateHead"].DisplayValue, " ");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r1 == null ? null : item_r1.Columns == null ? null : item_r1.Columns["UID_PersonRelated"] == null ? null : item_r1.Columns["UID_PersonRelated"].Value);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r1 == null ? null : item_r1.Columns == null ? null : item_r1.Columns["UID_PWODecisionRule"] == null ? null : item_r1.Columns["UID_PWODecisionRule"].Value);
} }
class WorkflowViolationDetailsComponent {
    violations = [];
    pwoData;
    constructor() { }
    ngOnInit() {
        this.violations = this.pwoData.WorkflowHistory?.Entities?.filter((item) => item.Columns?.['UID_ComplianceRule'].Value) || [];
    }
    static ɵfac = function WorkflowViolationDetailsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || WorkflowViolationDetailsComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: WorkflowViolationDetailsComponent, selectors: [["imx-workflow-violation-details"]], inputs: { pwoData: "pwoData" }, decls: 6, vars: 7, consts: [["type", "info", 3, "condensed", "colored", "dismissable"], [1, "imx-content-container"], ["multi", "", 1, "imx-accordion"], [4, "ngFor", "ngForOf"], [4, "ngIf"], [1, "imx-label"], [1, "imx-description", "imx-value"]], template: function WorkflowViolationDetailsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "eui-alert", 0);
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "div", 1)(4, "mat-accordion", 2);
            i0.ɵɵtemplate(5, WorkflowViolationDetailsComponent_mat_expansion_panel_5_Template, 8, 4, "mat-expansion-panel", 3);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", false);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 5, "#LDS#Here you can get an overview of the rule violations that occurred in the workflow of the request."), "\n");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngForOf", ctx.violations);
        } }, dependencies: [i5.NgForOf, i5.NgIf, i3$1.EuiAlertComponent, i9.MatAccordion, i9.MatExpansionPanel, i9.MatExpansionPanelHeader, i9.MatExpansionPanelTitle, i9.MatExpansionPanelDescription, i4.TranslatePipe], styles: [".imx-content-container[_ngcontent-%COMP%]{margin-top:20px}.imx-label[_ngcontent-%COMP%]{color:#797e80;margin-bottom:-10px}.imx-value[_ngcontent-%COMP%]{margin-bottom:20px}.imx-list-value[_ngcontent-%COMP%]{margin-left:20px}.imx-first-section-item[_ngcontent-%COMP%]{margin-top:20px;margin-bottom:10px}.imx-last-section-item[_ngcontent-%COMP%]{margin-bottom:20px}.imx-horizontal-container[_ngcontent-%COMP%]{display:flex;width:100%}.imx-horizontal-container[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{margin-right:20px}.imx-list-container[_ngcontent-%COMP%]{max-height:200px;overflow:auto}.imx-description[_ngcontent-%COMP%]{overflow-wrap:break-word;word-wrap:break-word;hyphens:auto}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-title[_ngcontent-%COMP%], .imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-description[_ngcontent-%COMP%]{flex-basis:0}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-description[_ngcontent-%COMP%]{justify-content:space-between;align-items:center}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(WorkflowViolationDetailsComponent, [{
        type: Component,
        args: [{ selector: 'imx-workflow-violation-details', template: "<eui-alert type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"false\">\n  {{ '#LDS#Here you can get an overview of the rule violations that occurred in the workflow of the request.' | translate }}\n</eui-alert>\n\n<div class=\"imx-content-container\">\n  <mat-accordion class=\"imx-accordion\" multi>\n    <mat-expansion-panel *ngFor=\"let item of violations\">\n      <mat-expansion-panel-header>\n        <mat-panel-title>\n          {{ item?.Columns?.['UID_ComplianceRule']?.DisplayValue }}\n        </mat-panel-title>\n        <mat-panel-description>\n          {{ item?.Columns?.['DateHead']?.DisplayValue }}\n        </mat-panel-description>\n      </mat-expansion-panel-header>\n\n      <ng-container *ngIf=\"item?.Columns?.['UID_PersonRelated']?.Value\">\n        <div class=\"imx-label\">{{ '#LDS#Affected identity' | translate }}</div>\n        <p class=\"imx-description imx-value\">\n          {{ item?.Columns?.['UID_PersonRelated']?.DisplayValue }}\n        </p>\n      </ng-container>\n\n      <ng-container *ngIf=\"item?.Columns?.['UID_PWODecisionRule']?.Value\">\n        <div class=\"imx-label\">{{ '#LDS#Approval procedure' | translate }}</div>\n        <p class=\"imx-description imx-value\">\n          {{ item?.Columns?.['UID_PWODecisionRule']?.DisplayValue }}\n        </p>\n      </ng-container>\n    </mat-expansion-panel>\n  </mat-accordion>\n</div>\n", styles: [".imx-content-container{margin-top:20px}.imx-label{color:#797e80;margin-bottom:-10px}.imx-value{margin-bottom:20px}.imx-list-value{margin-left:20px}.imx-first-section-item{margin-top:20px;margin-bottom:10px}.imx-last-section-item{margin-bottom:20px}.imx-horizontal-container{display:flex;width:100%}.imx-horizontal-container div{margin-right:20px}.imx-list-container{max-height:200px;overflow:auto}.imx-description{overflow-wrap:break-word;word-wrap:break-word;hyphens:auto}.imx-accordion .mat-expansion-panel-header-title,.imx-accordion .mat-expansion-panel-header-description{flex-basis:0}.imx-accordion .mat-expansion-panel-header-description{justify-content:space-between;align-items:center}\n"] }]
    }], () => [], { pwoData: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(WorkflowViolationDetailsComponent, { className: "WorkflowViolationDetailsComponent", filePath: "lib\\request\\workflow-violation-details\\workflow-violation-details.component.ts", lineNumber: 36 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$3 = a0 => ({ $implicit: a0 });
function ComplianceViolationDetailsComponent_ng_container_1_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 7);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", false);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, ctx_r0.rules.length > 1 ? "#LDS#Here you can get an overview of the rule violations this request may cause." : "#LDS#Here you can see the rule violation this request may cause."), " ");
} }
function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_7_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-action-row")(1, "button", 13);
    i0.ɵɵlistener("click", function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_7_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r2); const item_r3 = i0.ɵɵnextContext().$implicit; const ctx_r0 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r0.addMitigationControls(item_r3)); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Assign mitigating controls"), " ");
} }
function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_8_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-action-row")(1, "button", 14);
    i0.ɵɵlistener("click", function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_8_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r4); const item_r3 = i0.ɵɵnextContext().$implicit; const ctx_r0 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r0.addMitigationControls(item_r3)); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#View mitigating controls"), " ");
} }
function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-expansion-panel", 11)(1, "mat-expansion-panel-header")(2, "mat-panel-title");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-panel-description");
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(6, ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_ng_container_6_Template, 1, 0, "ng-container", 12)(7, ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_7_Template, 4, 3, "mat-action-row", 2)(8, ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_8_Template, 4, 3, "mat-action-row", 2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    const isFirst_r5 = ctx.first;
    const ctx_r0 = i0.ɵɵnextContext(3);
    const ruleViolationTemplate_r6 = i0.ɵɵreference(6);
    i0.ɵɵproperty("expanded", isFirst_r5);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", item_r3 == null ? null : item_r3.violationDetail == null ? null : item_r3.violationDetail.DisplayRule, " ");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r3 == null ? null : item_r3.violationDetail == null ? null : item_r3.violationDetail.DisplayPerson, " ");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", ruleViolationTemplate_r6)("ngTemplateOutletContext", i0.ɵɵpureFunction1(7, _c0$3, item_r3));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", (item_r3.violationDetail == null ? null : item_r3.violationDetail.IsExceptionApprover) && ctx_r0.isApproval && ctx_r0.mitigatingControlsPerViolation && ctx_r0.canEditMitigationControls(item_r3));
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !ctx_r0.isApproval && ctx_r0.mitigatingControlsPerViolation && ctx_r0.canEditMitigationControls(item_r3));
} }
function ComplianceViolationDetailsComponent_ng_container_1_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8)(1, "mat-accordion", 9);
    i0.ɵɵtemplate(2, ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_Template, 9, 9, "mat-expansion-panel", 10);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r0.rules);
} }
function ComplianceViolationDetailsComponent_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, ComplianceViolationDetailsComponent_ng_container_1_eui_alert_1_Template, 3, 6, "eui-alert", 4)(2, ComplianceViolationDetailsComponent_ng_container_1_div_2_Template, 3, 1, "div", 6);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.request != null);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.rules.length > 0);
} }
function ComplianceViolationDetailsComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 15);
    i0.ɵɵelement(1, "eui-icon", 16);
    i0.ɵɵelementStart(2, "p");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 1, "#LDS#No data"));
} }
function ComplianceViolationDetailsComponent_eui_alert_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 7);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", false);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, "#LDS#The ad hoc compliance check cannot be run for this request."), " ");
} }
function ComplianceViolationDetailsComponent_imx_workflow_violation_details_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-workflow-violation-details", 17);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("pwoData", ctx_r0.request == null ? null : ctx_r0.request.pwoData);
} }
function ComplianceViolationDetailsComponent_ng_template_5_eui_alert_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 21);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, "#LDS#Assigning this entitlement will cause a rule violation."), " ");
} }
function ComplianceViolationDetailsComponent_ng_template_5_imx_cdr_editor_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 22);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("cdr", ctx_r0.cdrRuleDisplay);
} }
function ComplianceViolationDetailsComponent_ng_template_5_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 22);
} if (rf & 2) {
    const cdr_r7 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r7);
} }
function ComplianceViolationDetailsComponent_ng_template_5_ng_container_3_imx_cdr_editor_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 22);
} if (rf & 2) {
    const cdr_r8 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r8);
} }
function ComplianceViolationDetailsComponent_ng_template_5_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, ComplianceViolationDetailsComponent_ng_template_5_ng_container_3_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 20);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const item_r9 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", item_r9 == null ? null : item_r9.cdrLists.sources);
} }
function ComplianceViolationDetailsComponent_ng_template_5_ng_container_4_li_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 26);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ceItem_r10 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ceItem_r10.Display);
} }
function ComplianceViolationDetailsComponent_ng_template_5_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelement(1, "mat-divider");
    i0.ɵɵelementStart(2, "div", 23);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "ul", 24);
    i0.ɵɵtemplate(6, ComplianceViolationDetailsComponent_ng_template_5_ng_container_4_li_6_Template, 2, 1, "li", 25);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const item_r9 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#Contributing entitlements"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngForOf", item_r9.violationDetail.ContributingEntitlements);
} }
function ComplianceViolationDetailsComponent_ng_template_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, ComplianceViolationDetailsComponent_ng_template_5_eui_alert_0_Template, 3, 5, "eui-alert", 18)(1, ComplianceViolationDetailsComponent_ng_template_5_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 19)(2, ComplianceViolationDetailsComponent_ng_template_5_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 20)(3, ComplianceViolationDetailsComponent_ng_template_5_ng_container_3_Template, 2, 1, "ng-container", 2)(4, ComplianceViolationDetailsComponent_ng_template_5_ng_container_4_Template, 7, 4, "ng-container", 2);
} if (rf & 2) {
    const item_r9 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngIf", (item_r9.violationDetail == null ? null : item_r9.violationDetail.ViolationType) === "Org");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.cdrRuleDisplay);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", item_r9 == null ? null : item_r9.cdrLists.common);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", (item_r9 == null ? null : item_r9.cdrLists == null ? null : item_r9.cdrLists.sources == null ? null : item_r9.cdrLists.sources.length) > 0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", (item_r9 == null ? null : item_r9.violationDetail == null ? null : item_r9.violationDetail.ContributingEntitlements) && (item_r9 == null ? null : item_r9.violationDetail == null ? null : item_r9.violationDetail.ContributingEntitlements.length) > 0);
} }
class ComplianceViolationDetailsComponent {
    validator;
    complianceApi;
    loadingService;
    metaData;
    entityService;
    sidesheets;
    translate;
    systemInfoService;
    data;
    pwoId;
    request;
    isApproval = false;
    mitigatingControlsPerViolation;
    cdrRuleDisplay;
    rules = [];
    schema;
    hasRiskIndex;
    constructor(validator, complianceApi, loadingService, metaData, entityService, sidesheets, translate, systemInfoService, data) {
        this.validator = validator;
        this.complianceApi = complianceApi;
        this.loadingService = loadingService;
        this.metaData = metaData;
        this.entityService = entityService;
        this.sidesheets = sidesheets;
        this.translate = translate;
        this.systemInfoService = systemInfoService;
        this.data = data;
    }
    async ngOnInit() {
        const ref = this.loadingService.show();
        try {
            this.schema = this.validator.getRulesSchema();
            this.isICartItemCheck(this.data) ? await this.loadCartItemViolations(this.data) : await this.loadRequestViolations(this.pwoId);
            this.hasRiskIndex = !!(await this.systemInfoService.get()).PreProps?.includes('RISKINDEX');
            this.checkHistoryForViolations();
            this.mitigatingControlsPerViolation = await this.complianceApi.getMitigatingControlsPerViolation();
        }
        finally {
            this.loadingService.hide(ref);
        }
    }
    /**
     * Check for org type violations, we disable the mitigation control settings for them
     * @param item
     * @returns if we can access the EditMitigatingControlsComponent
     */
    canEditMitigationControls(item) {
        return item.violationDetail.ViolationType ? !['Org'].includes(item.violationDetail.ViolationType) : !!item.violationDetail.UidPerson;
    }
    async addMitigationControls(item) {
        this.sidesheets
            .open(EditMitigatingControlsComponent, {
            title: await this.translate.get('#LDS#Heading Mitigating Controls').toPromise(),
            subTitle: item.violationDetail.DisplayRule,
            padding: '0px',
            disableClose: true,
            width: calculateSidesheetWidth(1000),
            testId: 'compliance-violation-details-mitigating-sidesheet',
            data: {
                uidPerson: item.violationDetail.UidPerson,
                uidNonCompliance: item.violationDetail.UidNonCompliance,
                uidPersonWantsOrg: item.violationDetail.UidPersonWantsOrg,
                readOnly: !this.isApproval,
                isMControlPerViolation: this.mitigatingControlsPerViolation,
            },
        })
            .afterClosed()
            .toPromise();
    }
    getDisplayForSource(item) {
        return this.metaData.tables[DbObjectKey.FromXml(item.ObjectKeyEntitlement || '').TableName]?.DisplaySingular ?? '';
    }
    async loadTableNamesForSources(violations) {
        const sourecedRules = violations.filter((elem) => !!elem.Sources?.length);
        if (sourecedRules.length > 0) {
            for (const source of sourecedRules) {
                await this.metaData.updateNonExisting(source.Sources?.map((item) => DbObjectKey.FromXml(item.ObjectKeyEntitlement || '').TableName) || []);
            }
        }
    }
    async loadCartItemViolations(cartItemCheck) {
        let rules = (await this.validator.getRules()).Data;
        await this.loadTableNamesForSources(cartItemCheck.Detail.Violations);
        this.rules = [];
        if (cartItemCheck.Detail.Violations.length === 1) {
            this.cdrRuleDisplay = this.getDisplayRuleCdr(undefined, cartItemCheck.Detail.Violations[0]);
        }
        cartItemCheck.Detail.Violations.forEach(async (item) => {
            const rule = rules.find((x) => x.GetEntity().GetKeys()[0] === item.UidComplianceRule);
            this.rules.push({
                rule,
                violationDetail: item,
                cdrLists: await this.buildCdrForViolations(rule, item),
            });
        });
    }
    async loadRequestViolations(id) {
        const violations = await this.complianceApi.getRequestViolations(id);
        await this.loadTableNamesForSources(violations);
        this.rules = [];
        if (violations.length === 1) {
            this.cdrRuleDisplay = this.getDisplayRuleCdr(undefined, violations[0]);
        }
        violations.forEach(async (violation) => {
            this.rules.push({
                violationDetail: violation,
                cdrLists: await this.buildCdrForViolations(undefined, violation),
            });
        });
    }
    getDisplayRuleCdr(rule, detail) {
        const column = rule
            ? rule.GetEntity().GetColumn('DisplayRule')
            : this.buildColumn('DisplayRule', this.translate.instant('#LDS#Violated compliance rule'), detail.DisplayRule);
        return new BaseReadonlyCdr(column);
    }
    async buildCdrForViolations(rule, detail) {
        const tableName = DbObjectKey.FromXml(detail.ObjectKeyElement || '').TableName;
        await this.metaData.updateNonExisting([tableName]);
        const displayTitle = this.metaData.tables[tableName]?.DisplaySingular || '';
        //Build common elments
        const cdrColumns = [
            this.buildColumn('DisplayElement', displayTitle, detail.DisplayElement),
            rule
                ? rule.GetEntity().GetColumn('Description')
                : this.buildColumn('Description', this.schema.Columns['Description'].Display || '', detail.Description),
            this.buildColumn('DisplayPerson', await this.translate.get('#LDS#Identity').toPromise(), detail.DisplayPerson),
            rule
                ? rule.GetEntity().GetColumn('RuleNumber')
                : this.buildColumn('RuleNumber', this.schema.Columns['RuleNumber'].Display || '', detail.RuleNumber),
        ];
        if (this.hasRiskIndex) {
            cdrColumns.push(rule
                ? rule.GetEntity().GetColumn('RiskIndex')
                : this.buildColumn('RiskIndex', this.schema.Columns['RiskIndex'].Display || '', detail.RiskIndex, ValType.Double));
            if (rule != null &&
                rule.GetEntity().GetColumn('RiskIndex').GetValue() !== rule.GetEntity().GetColumn('RiskIndexReduced').GetValue()) {
                cdrColumns.push(rule.GetEntity().GetColumn('RiskIndexReduced'));
            }
            else {
                if (detail.RiskIndex !== detail.RiskIndexReduced) {
                    cdrColumns.push(this.buildColumn('RiskIndexReduced', this.schema.Columns['RiskIndexReduced'].Display || '', detail.RiskIndexReduced, ValType.Double));
                }
            }
        }
        let sources;
        if (!!detail.Sources?.length) {
            sources = detail.Sources?.map((source, index) => new BaseReadonlyCdr(this.buildColumn(`source ${index}`, this.getDisplayForSource(source), source.Display)));
        }
        return { common: cdrColumns.map((column) => new BaseReadonlyCdr(column)), sources };
    }
    buildColumn(columnName, display, value, type = ValType.String) {
        return this.entityService.createLocalEntityColumn({
            ColumnName: columnName,
            Type: type,
            Display: display,
        }, undefined, { Value: value });
    }
    checkHistoryForViolations() {
        if (this.request?.pwoData && this.request.pwoData.WorkflowHistory && this.request.pwoData.WorkflowHistory.Entities) {
            this.request.pwoData.WorkflowHistory.Entities.forEach((wh) => {
                const uid = wh.Columns && wh.Columns['UID_ComplianceRule'] ? wh.Columns['UID_ComplianceRule'].Value : '';
                if (uid.length > 0) {
                    this.request.complianceRuleViolation = true;
                }
            });
        }
    }
    // ICartItemCheck type guard
    isICartItemCheck(obj) {
        return 'Id' in obj && 'Status' in obj && 'Title' in obj && 'ResultText' in obj && 'Detail' in obj;
    }
    static ɵfac = function ComplianceViolationDetailsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ComplianceViolationDetailsComponent)(i0.ɵɵdirectiveInject(ItemValidatorService), i0.ɵɵdirectiveInject(ComplianceViolationService), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2$1.MetadataService), i0.ɵɵdirectiveInject(i2$1.EntityService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i2$1.SystemInfoService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ComplianceViolationDetailsComponent, selectors: [["imx-compliance-violation-details"]], inputs: { pwoId: "pwoId", request: "request", isApproval: "isApproval" }, decls: 7, vars: 4, consts: [["ruleViolationTemplate", ""], [1, "imx-main-container"], [4, "ngIf"], ["class", "imx-no-results", 4, "ngIf"], ["type", "info", 3, "condensed", "colored", "dismissable", 4, "ngIf"], [3, "pwoData", 4, "ngIf"], ["class", "imx-content-container", 4, "ngIf"], ["type", "info", 3, "condensed", "colored", "dismissable"], [1, "imx-content-container"], ["multi", "", 1, "imx-accordion"], [3, "expanded", 4, "ngFor", "ngForOf"], [3, "expanded"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["mat-button", "", "color", "primary", "data-imx-identifier", "compliance-violation-datails-edit-mitigating-controls", 3, "click"], ["mat-button", "", "color", "primary", "data-imx-identifier", "compliance-violation-datails-view-mitigating-controls", 3, "click"], [1, "imx-no-results"], ["icon", "table"], [3, "pwoData"], ["type", "warning", 3, "condensed", "colored", 4, "ngIf"], [3, "cdr", 4, "ngIf"], [3, "cdr", 4, "ngFor", "ngForOf"], ["type", "warning", 3, "condensed", "colored"], [3, "cdr"], [1, "imx-label", "imx-first-section-item"], [1, "imx-list-container"], ["class", "imx-list-value", 4, "ngFor", "ngForOf"], [1, "imx-list-value"]], template: function ComplianceViolationDetailsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵtemplate(1, ComplianceViolationDetailsComponent_ng_container_1_Template, 3, 2, "ng-container", 2)(2, ComplianceViolationDetailsComponent_div_2_Template, 5, 3, "div", 3)(3, ComplianceViolationDetailsComponent_eui_alert_3_Template, 3, 6, "eui-alert", 4)(4, ComplianceViolationDetailsComponent_imx_workflow_violation_details_4_Template, 1, 1, "imx-workflow-violation-details", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, ComplianceViolationDetailsComponent_ng_template_5_Template, 5, 5, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.request == null || (ctx.request == null ? null : ctx.request.UiOrderState == null ? null : ctx.request.UiOrderState.value) === "OrderProduct");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", (ctx.rules == null || ctx.rules.length === 0) && (ctx.request == null ? null : ctx.request.UiOrderState == null ? null : ctx.request.UiOrderState.value) === "OrderProduct");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.request != null && (ctx.request == null ? null : ctx.request.UiOrderState == null ? null : ctx.request.UiOrderState.value) != "OrderProduct" && !(ctx.request == null ? null : ctx.request.complianceRuleViolation));
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.request != null && (ctx.request == null ? null : ctx.request.UiOrderState == null ? null : ctx.request.UiOrderState.value) != "OrderProduct" && (ctx.request == null ? null : ctx.request.complianceRuleViolation));
        } }, dependencies: [i2$1.CdrEditorComponent, i5.NgForOf, i5.NgIf, i5.NgTemplateOutlet, i3$1.EuiAlertComponent, i3$1.EuiIconComponent, i6.MatButton, i8.MatDivider, i9.MatAccordion, i9.MatExpansionPanel, i9.MatExpansionPanelActionRow, i9.MatExpansionPanelHeader, i9.MatExpansionPanelTitle, i9.MatExpansionPanelDescription, WorkflowViolationDetailsComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]     .mat-expansion-panel-body{display:flex;flex-direction:column}.imx-content-container[_ngcontent-%COMP%]{margin-top:20px}.imx-main-container[_ngcontent-%COMP%]{margin:20px}.imx-label[_ngcontent-%COMP%]{color:#797e80;margin-bottom:-10px}.imx-value[_ngcontent-%COMP%]{margin-bottom:20px}.imx-list-value[_ngcontent-%COMP%]{margin-left:20px;list-style-type:disc}.imx-first-section-item[_ngcontent-%COMP%]{margin-top:20px;margin-bottom:10px}.imx-last-section-item[_ngcontent-%COMP%]{margin-bottom:20px}.imx-horizontal-container[_ngcontent-%COMP%]{display:flex;width:100%}.imx-horizontal-container[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{margin-right:20px}.imx-list-container[_ngcontent-%COMP%]{max-height:200px;overflow:auto}.imx-description[_ngcontent-%COMP%]{overflow-wrap:break-word;word-wrap:break-word;hyphens:auto}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-title[_ngcontent-%COMP%]{flex-basis:70%}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-description[_ngcontent-%COMP%]{flex-basis:30%}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-title[_ngcontent-%COMP%]{font-weight:700}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-description[_ngcontent-%COMP%]{justify-content:end;align-items:center;color:#919799}.imx-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0}.imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px;color:#919799}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ComplianceViolationDetailsComponent, [{
        type: Component,
        args: [{ selector: 'imx-compliance-violation-details', template: "<div class=\"imx-main-container\">\n  <ng-container *ngIf=\"request == null || request?.UiOrderState?.value === 'OrderProduct'\">\n    <eui-alert *ngIf=\"request != null\" type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"false\">\n      {{\n        (rules.length > 1\n          ? '#LDS#Here you can get an overview of the rule violations this request may cause.'\n          : '#LDS#Here you can see the rule violation this request may cause.'\n        ) | translate\n      }}\n    </eui-alert>\n\n    <div *ngIf=\"rules.length > 0\" class=\"imx-content-container\">\n      <mat-accordion class=\"imx-accordion\" multi>\n        <mat-expansion-panel *ngFor=\"let item of rules; let isFirst = first\" [expanded]=\"isFirst\">\n          <mat-expansion-panel-header>\n            <mat-panel-title>\n              {{ item?.violationDetail?.DisplayRule }}\n            </mat-panel-title>\n            <mat-panel-description>\n              {{ item?.violationDetail?.DisplayPerson }}\n            </mat-panel-description>\n          </mat-expansion-panel-header>\n          <ng-container *ngTemplateOutlet=\"ruleViolationTemplate; context: { $implicit: item }\"></ng-container>\n          <mat-action-row\n            *ngIf=\"\n              item.violationDetail?.IsExceptionApprover && isApproval && mitigatingControlsPerViolation && canEditMitigationControls(item)\n            \"\n          >\n            <button\n              mat-button\n              color=\"primary\"\n              (click)=\"addMitigationControls(item)\"\n              data-imx-identifier=\"compliance-violation-datails-edit-mitigating-controls\"\n            >\n              {{ '#LDS#Assign mitigating controls' | translate }}\n            </button>\n          </mat-action-row>\n          <mat-action-row *ngIf=\"!isApproval && mitigatingControlsPerViolation && canEditMitigationControls(item)\">\n            <button\n              mat-button\n              color=\"primary\"\n              (click)=\"addMitigationControls(item)\"\n              data-imx-identifier=\"compliance-violation-datails-view-mitigating-controls\"\n            >\n              {{ '#LDS#View mitigating controls' | translate }}\n            </button>\n          </mat-action-row>\n        </mat-expansion-panel>\n      </mat-accordion>\n    </div>\n  </ng-container>\n\n  <div *ngIf=\"(rules == null || rules.length === 0) && request?.UiOrderState?.value === 'OrderProduct'\" class=\"imx-no-results\">\n    <eui-icon icon=\"table\"></eui-icon>\n    <p>{{ '#LDS#No data' | translate }}</p>\n  </div>\n\n  <eui-alert\n    *ngIf=\"request != null && request?.UiOrderState?.value != 'OrderProduct' && !request?.complianceRuleViolation\"\n    type=\"info\"\n    [condensed]=\"true\"\n    [colored]=\"true\"\n    [dismissable]=\"false\"\n  >\n    {{ '#LDS#The ad hoc compliance check cannot be run for this request.' | translate }}\n  </eui-alert>\n\n  <imx-workflow-violation-details\n    *ngIf=\"request != null && request?.UiOrderState?.value != 'OrderProduct' && request?.complianceRuleViolation\"\n    [pwoData]=\"request?.pwoData\"\n  ></imx-workflow-violation-details>\n</div>\n\n<ng-template #ruleViolationTemplate let-item>\n  <eui-alert type=\"warning\" *ngIf=\"item.violationDetail?.ViolationType === 'Org'\" [condensed]=\"true\" [colored]=\"true\">\n    {{ '#LDS#Assigning this entitlement will cause a rule violation.' | translate }}\n  </eui-alert>\n  <imx-cdr-editor *ngIf=\"cdrRuleDisplay\" [cdr]=\"cdrRuleDisplay\"></imx-cdr-editor>\n  <imx-cdr-editor *ngFor=\"let cdr of item?.cdrLists.common\" [cdr]=\"cdr\"> </imx-cdr-editor>\n\n  <ng-container *ngIf=\"item?.cdrLists?.sources?.length > 0\">\n    <imx-cdr-editor *ngFor=\"let cdr of item?.cdrLists.sources\" [cdr]=\"cdr\"> </imx-cdr-editor>\n  </ng-container>\n\n  <ng-container *ngIf=\"item?.violationDetail?.ContributingEntitlements && item?.violationDetail?.ContributingEntitlements.length > 0\">\n    <mat-divider></mat-divider>\n    <div class=\"imx-label imx-first-section-item\">{{ '#LDS#Contributing entitlements' | translate }}</div>\n    <ul class=\"imx-list-container\">\n      <li *ngFor=\"let ceItem of item.violationDetail.ContributingEntitlements\" class=\"imx-list-value\">{{ ceItem.Display }}</li>\n    </ul>\n  </ng-container>\n</ng-template>\n", styles: [":host ::ng-deep .mat-expansion-panel-body{display:flex;flex-direction:column}.imx-content-container{margin-top:20px}.imx-main-container{margin:20px}.imx-label{color:#797e80;margin-bottom:-10px}.imx-value{margin-bottom:20px}.imx-list-value{margin-left:20px;list-style-type:disc}.imx-first-section-item{margin-top:20px;margin-bottom:10px}.imx-last-section-item{margin-bottom:20px}.imx-horizontal-container{display:flex;width:100%}.imx-horizontal-container div{margin-right:20px}.imx-list-container{max-height:200px;overflow:auto}.imx-description{overflow-wrap:break-word;word-wrap:break-word;hyphens:auto}.imx-accordion .mat-expansion-panel-header-title{flex-basis:70%}.imx-accordion .mat-expansion-panel-header-description{flex-basis:30%}.imx-accordion .mat-expansion-panel-header-title{font-weight:700}.imx-accordion .mat-expansion-panel-header-description{justify-content:end;align-items:center;color:#919799}.imx-no-results{text-align:center;margin:20px 0}.imx-no-results p{margin:0;font-size:18px;color:#919799}\n"] }]
    }], () => [{ type: ItemValidatorService }, { type: ComplianceViolationService }, { type: i3$1.EuiLoadingService }, { type: i2$1.MetadataService }, { type: i2$1.EntityService }, { type: i3$1.EuiSidesheetService }, { type: i4.TranslateService }, { type: i2$1.SystemInfoService }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }], { pwoId: [{
            type: Input
        }], request: [{
            type: Input
        }], isApproval: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ComplianceViolationDetailsComponent, { className: "ComplianceViolationDetailsComponent", filePath: "lib\\request\\compliance-violation-details\\compliance-violation-details.component.ts", lineNumber: 46 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class CartItemComplianceCheckComponent {
    sidesheetService;
    translateService;
    check;
    constructor(sidesheetService, translateService) {
        this.sidesheetService = sidesheetService;
        this.translateService = translateService;
    }
    async onOpenDetails() {
        this.sidesheetService.open(ComplianceViolationDetailsComponent, {
            title: await this.translateService.get('#LDS#Heading View Rule Violation Details').toPromise(),
            width: calculateSidesheetWidth(800, 0.5),
            padding: '0px',
            data: this.check,
            testId: 'cart-item-compliance-violation-details',
        });
    }
    static ɵfac = function CartItemComplianceCheckComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CartItemComplianceCheckComponent)(i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CartItemComplianceCheckComponent, selectors: [["imx-cart-item-compliance-check"]], decls: 3, vars: 3, consts: [["data-imx-identifier", "compliance-check-button", "mat-stroked-button", "", 3, "click"]], template: function CartItemComplianceCheckComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵlistener("click", function CartItemComplianceCheckComponent_Template_button_click_0_listener() { return ctx.onOpenDetails(); });
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#View violation details"), "\n");
        } }, dependencies: [i6.MatButton, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;justify-content:flex-end;margin-top:10px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CartItemComplianceCheckComponent, [{
        type: Component,
        args: [{ selector: 'imx-cart-item-compliance-check', template: "<button data-imx-identifier=\"compliance-check-button\" mat-stroked-button (click)=\"onOpenDetails()\">\n  {{ '#LDS#View violation details' | translate }}\n</button>\n", styles: [":host{display:flex;justify-content:flex-end;margin-top:10px}\n"] }]
    }], () => [{ type: i3$1.EuiSidesheetService }, { type: i4.TranslateService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CartItemComplianceCheckComponent, { className: "CartItemComplianceCheckComponent", filePath: "lib\\item-validator\\cart-item-compliance-check\\cart-item-compliance-check.component.ts", lineNumber: 40 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestRuleViolation {
    static id = 'cpl.UID_ComplianceRule';
    subject = new Subject();
    get inputData() {
        return this.dstSettings;
    }
    set inputData(dstSettings) {
        this.dstSettings = dstSettings;
        if (this.dstSettings?.extendedData) {
            for (let i = 0; i < (this.dstSettings.dataSource?.Data.length || 0); i++) {
                const item = this.dstSettings.dataSource?.Data[i];
                item.complianceRuleViolation = !!item.pwoData.WorkflowHistory?.Entities?.filter((wh) => wh.Columns?.['UID_ComplianceRule']?.Value?.length > 0).length;
            }
        }
        this.subject.next(this.dstSettings);
    }
    dstSettings;
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestRuleViolationDetail {
    static id = 'cpl.ruleViolationDetail';
    instance = ComplianceViolationDetailsComponent;
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RoleComplianceViolationTypedEntity extends TypedEntity {
    static GetEntitySchema() {
        const columns = {
            UID_ComplianceRule: { Type: ValType.String, ColumnName: 'UID_ComplianceRule' },
            RuleName: { Type: ValType.String, ColumnName: 'RuleName' },
            DbObjectKey: { Type: ValType.String, ColumnName: 'DbObjectKey' },
            ObjectDisplay: { Type: ValType.String, ColumnName: 'ObjectDisplay' },
            ObjectKeyElement: { Type: ValType.String, ColumnName: 'ObjectKeyElement' },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        return { Columns: columns };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RoleComplianceViolationsWrapperService {
    roleComplianceEntitySchema = RoleComplianceViolationTypedEntity.GetEntitySchema();
    builder = new TypedEntityBuilder(RoleComplianceViolationTypedEntity);
    build(data) {
        const violations = {
            TotalCount: data.length,
            Entities: data.map((elem) => this.buildEntityData(elem)),
        };
        return this.builder.buildReadWriteEntities(violations, this.roleComplianceEntitySchema);
    }
    buildEntityData(data) {
        const ret = {};
        ret.UID_ComplianceRule = { Value: data.UID_ComplianceRule, IsReadOnly: true };
        ret.RuleName = { Value: data.RuleName, IsReadOnly: true };
        ret.DbObjectKey = { Value: data.DbObjectKey, IsReadOnly: true };
        ret.ObjectDisplay = { Value: data.ObjectDisplay, IsReadOnly: true };
        ret.ObjectKeyElement = { Value: data.ObjectKeyElement, IsReadOnly: true };
        return { Columns: ret };
    }
    static ɵfac = function RoleComplianceViolationsWrapperService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RoleComplianceViolationsWrapperService)(); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RoleComplianceViolationsWrapperService, factory: RoleComplianceViolationsWrapperService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RoleComplianceViolationsWrapperService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], null, null); })();

class RoleComplianceViolationsService {
    apiservice;
    busyService;
    busyIndicator;
    constructor(apiservice, busyService) {
        this.apiservice = apiservice;
        this.busyService = busyService;
    }
    async getRoleComplianceViolations(table, uidRole) {
        return this.apiservice.client.portal_roles_config_compliance_get(table, uidRole);
    }
    handleOpenLoader() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
    }
    handleCloseLoader() {
        this.busyService.hide();
    }
    static ɵfac = function RoleComplianceViolationsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RoleComplianceViolationsService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i3$1.EuiLoadingService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RoleComplianceViolationsService, factory: RoleComplianceViolationsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RoleComplianceViolationsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }, { type: i3$1.EuiLoadingService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$2 = () => [];
function RoleComplianceViolationsComponent_eui_alert_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-alert", 8);
    i0.ɵɵlistener("dismissed", function RoleComplianceViolationsComponent_eui_alert_2_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onHelperDismissed()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, ctx_r1.keyDescription), " ");
} }
class RoleComplianceViolationsComponent {
    entityService;
    roleComplianceViolationService;
    metaDataService;
    tablename;
    uidRole;
    dstSettings;
    DisplayColumns = DisplayColumns;
    entitySchema;
    showHelperAlert = true;
    keyDescription;
    displayedColumns = [];
    constructor(dataProvider, entityService, roleComplianceViolationService, metaDataService) {
        this.entityService = entityService;
        this.roleComplianceViolationService = roleComplianceViolationService;
        this.metaDataService = metaDataService;
        this.tablename = dataProvider.data.tablename;
        this.uidRole = dataProvider.data.entity.GetKeys()[0];
        this.entitySchema = this.entityService.roleComplianceEntitySchema;
        this.displayedColumns = [this.entitySchema.Columns.RuleName, this.entitySchema.Columns.ObjectDisplay];
        /* eslint-disable max-len */
        switch ((this.tablename ?? '').toLowerCase()) {
            case 'aerole':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this application role that may violate a compliance rule.';
                break;
            case 'department':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this department that may violate a compliance rule.';
                break;
            case 'locality':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this location that may violate a compliance rule.';
                break;
            case 'profitcenter':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this cost center that may violate a compliance rule.';
                break;
            case 'eset':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this system role that may violate a compliance rule.';
                break;
            case 'org':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this business role that may violate a compliance rule.';
                break;
            default:
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this object that may violate a compliance rule.';
                break;
        }
        /* eslint-enable max-len */
    }
    async ngOnInit() {
        await this.metaDataService.updateNonExisting([this.tablename]);
        await this.getData();
    }
    async getData() {
        this.roleComplianceViolationService.handleOpenLoader();
        try {
            const data = await this.roleComplianceViolationService.getRoleComplianceViolations(this.tablename, this.uidRole);
            this.dstSettings = {
                displayedColumns: this.displayedColumns,
                dataSource: this.entityService.build(data.Violations || []),
                entitySchema: this.entityService.roleComplianceEntitySchema,
                navigationState: {},
            };
        }
        finally {
            this.roleComplianceViolationService.handleCloseLoader();
        }
    }
    onHelperDismissed() {
        this.showHelperAlert = false;
    }
    static ɵfac = function RoleComplianceViolationsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RoleComplianceViolationsComponent)(i0.ɵɵdirectiveInject(i2$1.DynamicTabDataProviderDirective), i0.ɵɵdirectiveInject(RoleComplianceViolationsWrapperService), i0.ɵɵdirectiveInject(RoleComplianceViolationsService), i0.ɵɵdirectiveInject(i2$1.MetadataService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RoleComplianceViolationsComponent, selectors: [["ng-component"]], decls: 11, vars: 14, consts: [["dst", ""], [1, "imx-tab-content"], [1, "imx-tab-body"], ["type", "info", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [3, "settings", "options"], ["mode", "manual", "data-imx-identifier", "rules-table", 3, "dst", "detailViewVisible"], ["data-imx-identifier", "violations-table-column-RuleName", 3, "columnLabel", "entityColumn"], ["data-imx-identifier", "violations-table-column-ObjectDisplay", 3, "columnLabel", "entityColumn"], ["type", "info", 3, "dismissed", "condensed", "colored", "dismissable"]], template: function RoleComplianceViolationsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 1)(1, "div", 2);
            i0.ɵɵtemplate(2, RoleComplianceViolationsComponent_eui_alert_2_Template, 3, 6, "eui-alert", 3);
            i0.ɵɵelementStart(3, "div");
            i0.ɵɵelement(4, "imx-data-source-toolbar", 4, 0);
            i0.ɵɵelementStart(6, "imx-data-table", 5);
            i0.ɵɵelement(7, "imx-data-table-column", 6);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelement(9, "imx-data-table-column", 7);
            i0.ɵɵpipe(10, "translate");
            i0.ɵɵelementEnd()()()();
        } if (rf & 2) {
            const dst_r3 = i0.ɵɵreference(5);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.showHelperAlert);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(13, _c0$2));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", dst_r3)("detailViewVisible", false);
            i0.ɵɵadvance();
            i0.ɵɵproperty("columnLabel", i0.ɵɵpipeBind1(8, 9, "#LDS#Compliance rule"))("entityColumn", ctx.entitySchema.Columns.RuleName);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("columnLabel", i0.ɵɵpipeBind1(10, 11, "#LDS#Entitlement"))("entityColumn", ctx.entitySchema.Columns.ObjectDisplay);
        } }, dependencies: [i5.NgIf, i3$1.EuiAlertComponent, i2$1.DataSourceToolbarComponent, i2$1.DataTableComponent, i2$1.DataTableColumnComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-tab-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%;overflow:hidden}.imx-tab-body[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RoleComplianceViolationsComponent, [{
        type: Component,
        args: [{ template: "<div class=\"imx-tab-content\">\n  <div class=\"imx-tab-body\">\n    <eui-alert\n      *ngIf=\"showHelperAlert\"\n      type=\"info\"\n      [condensed]=\"true\"\n      [colored]=\"true\"\n      [dismissable]=\"true\"\n      (dismissed)=\"onHelperDismissed()\"\n    >\n      {{ keyDescription | translate }}\n    </eui-alert>\n    <div>\n      <imx-data-source-toolbar #dst [settings]=\"dstSettings\" [options]=\"[]\"> </imx-data-source-toolbar>\n      <imx-data-table [dst]=\"dst\" [detailViewVisible]=\"false\" mode=\"manual\" data-imx-identifier=\"rules-table\">\n        <imx-data-table-column\n          [columnLabel]=\"'#LDS#Compliance rule' | translate\"\n          [entityColumn]=\"entitySchema.Columns.RuleName\"\n          data-imx-identifier=\"violations-table-column-RuleName\"\n        >\n        </imx-data-table-column>\n        <imx-data-table-column\n          [columnLabel]=\"'#LDS#Entitlement' | translate\"\n          [entityColumn]=\"entitySchema.Columns.ObjectDisplay\"\n          data-imx-identifier=\"violations-table-column-ObjectDisplay\"\n        >\n        </imx-data-table-column>\n      </imx-data-table>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-tab-content{display:flex;flex-direction:column;height:100%;overflow:hidden}.imx-tab-body{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}\n"] }]
    }], () => [{ type: i2$1.DynamicTabDataProviderDirective }, { type: RoleComplianceViolationsWrapperService }, { type: RoleComplianceViolationsService }, { type: i2$1.MetadataService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RoleComplianceViolationsComponent, { className: "RoleComplianceViolationsComponent", filePath: "lib\\role-compliance-violations\\role-compliance-violations.component.ts", lineNumber: 38 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    extService;
    router;
    menuService;
    cplService;
    notificationService;
    validationDetailService;
    constructor(extService, router, menuService, cplService, notificationService, validationDetailService) {
        this.extService = extService;
        this.router = router;
        this.menuService = menuService;
        this.cplService = cplService;
        this.notificationService = notificationService;
        this.validationDetailService = validationDetailService;
        this.setupMenu();
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register('Dashboard-SmallTiles', { instance: DashboardPluginComponent });
        this.extService.register(RequestRuleViolation.id, new RequestRuleViolation());
        this.extService.register(RequestRuleViolationDetail.id, new RequestRuleViolationDetail());
        this.extService.register('roleOverview', {
            instance: RoleComplianceViolationsComponent,
            inputData: {
                id: 'roleCompliance',
                label: '#LDS#Heading Rule Violations',
                checkVisibility: async (ref) => this.checkCompliances(ref),
            },
            sortOrder: 0,
        });
        this.extService.register('identitySidesheet', {
            instance: IdentityRuleViolationsComponent,
            inputData: {
                id: 'NonCompliance',
                label: '#LDS#Heading Rule Violations',
                checkVisibility: async (_) => true,
            },
            sortOrder: 20,
        });
        this.validationDetailService.register(CartItemComplianceCheckComponent, 'CartItemComplianceCheck');
        // Register handler for compliance notifications
        this.notificationService.registerRedirectNotificationHandler({
            id: 'OpenNonCompliance',
            message: '#LDS#There are new rule violations for which you can grant or deny exceptions.',
            route: 'compliance/rulesviolations/approve',
        });
    }
    async checkCompliances(referrer) {
        this.cplService.handleOpenLoader();
        let violationCount = 0;
        try {
            violationCount =
                (await this.cplService.getRoleComplianceViolations(referrer.tablename, referrer.entity.GetKeys()[0])).Violations?.length || 0;
        }
        finally {
            this.cplService.handleCloseLoader();
        }
        return violationCount > 0;
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features) => {
            if (!preProps.includes('COMPLIANCE') || !isRuleStatistics(features)) {
                return undefined;
            }
            const items = [];
            if (isRuleStatistics(features)) {
                items.push({
                    id: 'CPL_Compliance_Rules',
                    route: 'compliance/rules',
                    title: '#LDS#Menu Entry Compliance rules',
                    description: '#LDS#Shows an overview of compliance rules.',
                    sorting: '25-10',
                });
            }
            const menu = {
                id: 'ROOT_Compliance',
                title: '#LDS#Compliance',
                sorting: '25',
                items,
            };
            return menu;
        });
    }
    static ɵfac = function InitService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InitService)(i0.ɵɵinject(i2$1.ExtService), i0.ɵɵinject(i3.Router), i0.ɵɵinject(i2$1.MenuService), i0.ɵɵinject(RoleComplianceViolationsService), i0.ɵɵinject(i2.NotificationRegistryService), i0.ɵɵinject(i2.ShoppingCartValidationDetailService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i2$1.ExtService }, { type: i3.Router }, { type: i2$1.MenuService }, { type: RoleComplianceViolationsService }, { type: i2.NotificationRegistryService }, { type: i2.ShoppingCartValidationDetailService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Class thats extends the {@link PortalRulesMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
class RulesMitigatingControls extends PortalRulesMitigatingcontrols {
    baseObject;
    /**
     * The property list depending on the value of the state of a {@link PortalRulesMitigatingcontrols}.
     */
    propertyInfo;
    constructor(baseObject) {
        super(baseObject.GetEntity());
        this.baseObject = baseObject;
        this.propertyInfo = this.initPropertyInfo();
    }
    initPropertyInfo() {
        const properties = [this.UID_MitigatingControl];
        return properties.map((property) => new BaseCdr(property.Column));
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class MitigatingControlsRulesService {
    apiService;
    constructor(apiService) {
        this.apiService = apiService;
    }
    async getControls(uidNonCompliance) {
        const collection = await this.apiService.typedClient.PortalRulesMitigatingcontrols.Get(uidNonCompliance);
        return {
            tableName: collection.tableName,
            totalCount: collection.totalCount,
            Data: collection.Data.map((item) => new RulesMitigatingControls(item)),
        };
    }
    createControl(uidCompliance) {
        // TODO: When API can handle permission issues uncomment. PBI: 305793
        const newMControl = this.apiService.typedClient.PortalRulesWorkingcopiesMitigatingcontrols.createEntity({
            Columns: {
                UID_ComplianceRule: { Value: uidCompliance },
            },
        });
        return new RulesMitigatingControls(newMControl);
        // const newMControl = this.apiService.typedClient.PortalRulesMitigatingcontrols.createEntity({
        //   Columns: {
        //     "UID_ComplianceRule": { Value: uidCompliance }
        //   }
        // });
        // return new RulesMitigatingControls(newMControl);
    }
    async postControl(uidNonCompliance, mControl) {
        // TODO: When API can handle permission issues uncomment. PBI: 305793
        await this.apiService.typedClient.PortalRulesWorkingcopiesMitigatingcontrols.Post(uidNonCompliance, mControl);
        // await this.apiService.typedClient.PortalRulesMitigatingcontrols.Post(uidNonCompliance, mControl);
    }
    async deleteControl(mControl) {
        await mControl.GetEntity().MarkForDeletion();
        await mControl.GetEntity().Commit();
    }
    static ɵfac = function MitigatingControlsRulesService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlsRulesService)(i0.ɵɵinject(ApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: MitigatingControlsRulesService, factory: MitigatingControlsRulesService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsRulesService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RulesService {
    apiservice;
    busyService;
    appConfig;
    constructor(apiservice, busyService, appConfig) {
        this.apiservice = apiservice;
        this.busyService = busyService;
        this.appConfig = appConfig;
    }
    get ruleSchema() {
        return this.apiservice.typedClient.PortalRules.GetSchema();
    }
    async featureConfig() {
        return this.apiservice.client.portal_compliance_config_get();
    }
    async getRules(parameter, signal) {
        return this.apiservice.typedClient.PortalRules.Get(parameter, { signal });
    }
    exportRules() {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, navigationState, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_rules_get({ ...navigationState, withProperties, PageSize, StartIndex: 0 });
                }
                else {
                    method = factory.portal_rules_get({ ...navigationState, withProperties });
                }
                return new MethodDefinition(method);
            },
        };
    }
    async getDataModel() {
        return this.apiservice.client.portal_rules_datamodel_get();
    }
    ruleReport(uidrule) {
        const path = `rules/${uidrule}/report`;
        return `${this.appConfig.BaseUrl}/portal/${path}`;
    }
    async recalculate(uidrule) {
        return this.apiservice.client.portal_rules_recalculate_post(uidrule);
    }
    handleOpenLoader() {
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
    }
    handleCloseLoader() {
        this.busyService.hide();
    }
    static ɵfac = function RulesService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i3$1.EuiLoadingService), i0.ɵɵinject(i2$1.AppConfigService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RulesService, factory: RulesService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }, { type: i3$1.EuiLoadingService }, { type: i2$1.AppConfigService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MitigatingControlsRulesComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 5)(1, "eui-alert-header");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "eui-alert-content");
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 4, "#LDS#Heading Mitigating Controls Can Be Assigned Individually"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 6, "#LDS#Here you can get an overview of the mitigating controls that can be assigned to a violation of this compliance rule."));
} }
function MitigatingControlsRulesComponent_eui_alert_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 5)(1, "eui-alert-header");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "eui-alert-content");
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 4, "#LDS#Heading Mitigating Controls Applied Globally"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 6, "#LDS#Here you can get an overview of the mitigating controls that are automatically applied to every violation of this compliance rule."));
} }
function MitigatingControlsRulesComponent_mat_card_3_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 10);
    i0.ɵɵlistener("controlCreated", function MitigatingControlsRulesComponent_mat_card_3_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.formArray.push($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r3);
} }
function MitigatingControlsRulesComponent_mat_card_3_eui_icon_3_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-icon", 11);
    i0.ɵɵlistener("click", function MitigatingControlsRulesComponent_mat_card_3_eui_icon_3_Template_eui_icon_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r4 = i0.ɵɵnextContext(); const mControl_r6 = ctx_r4.$implicit; const i_r7 = ctx_r4.index; const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onDelete(mControl_r6, i_r7)); });
    i0.ɵɵelementEnd();
} }
function MitigatingControlsRulesComponent_mat_card_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card", 6)(1, "div", 7);
    i0.ɵɵtemplate(2, MitigatingControlsRulesComponent_mat_card_3_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 8);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, MitigatingControlsRulesComponent_mat_card_3_eui_icon_3_Template, 1, 0, "eui-icon", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const mControl_r6 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", mControl_r6.propertyInfo);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.canEdit);
} }
function MitigatingControlsRulesComponent_mat_card_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card", 12)(1, "div", 13);
    i0.ɵɵelement(2, "eui-icon", 14);
    i0.ɵɵelementStart(3, "p");
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "translate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 1, "#LDS#Currently, no mitigating controls are assigned to this compliance rule."));
} }
function MitigatingControlsRulesComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 15)(1, "button", 16);
    i0.ɵɵlistener("click", function MitigatingControlsRulesComponent_div_5_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r8); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onCreateControl()); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 17);
    i0.ɵɵlistener("click", function MitigatingControlsRulesComponent_div_5_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r8); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onSave()); });
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 3, "#LDS#Assign mitigating controls"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r1.formGroup.pristine || ctx_r1.formGroup.invalid || ctx_r1.formArray.length === 0);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 5, "#LDS#Save"), " ");
} }
class MitigatingControlsRulesComponent {
    mControlService;
    formBuilder;
    cd;
    busyService;
    snackbarService;
    confirmationService;
    isMControlPerViolation;
    uidNonCompliance;
    uidCompliance;
    mControls;
    sidesheetRef;
    canEdit = true;
    subscriptions$ = [];
    formGroup;
    constructor(mControlService, formBuilder, cd, busyService, snackbarService, confirmationService) {
        this.mControlService = mControlService;
        this.formBuilder = formBuilder;
        this.cd = cd;
        this.busyService = busyService;
        this.snackbarService = snackbarService;
        this.confirmationService = confirmationService;
        this.formGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    get formArray() {
        return this.formGroup.get('formArray');
    }
    ngOnInit() {
        this.subscriptions$.push(this.sidesheetRef.closeClicked().subscribe(async () => {
            if (!this.formGroup.dirty || (await this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close();
            }
        }));
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
    getMControlId(mControl) {
        return mControl.GetEntity().GetColumn('UID_MitigatingControl').GetValue();
    }
    onCreateControl() {
        const mControl = this.mControlService.createControl(this.uidCompliance);
        this.mControls.push(mControl);
        this.formGroup.markAsDirty();
        this.cd.detectChanges();
    }
    async onDelete(mControl, index) {
        if (mControl.GetEntity().GetKeys()) {
            // Only call delete if the control exists on the server
            this.busyService.show();
            try {
                await this.mControlService.deleteControl(mControl);
            }
            finally {
                this.busyService.hide();
            }
        }
        this.formArray.removeAt(index);
        this.mControls.splice(index, 1);
        this.cd.detectChanges();
    }
    hasDuplicates() {
        const values = this.mControls.map((mControl) => this.getMControlId(mControl));
        const uniqueValues = [...new Set(values)];
        return values.length !== uniqueValues.length;
    }
    async onSave() {
        if (this.hasDuplicates()) {
            await this.confirmationService.confirmGeneral({
                ShowOk: true,
                Title: '#LDS#Heading Mitigating Control Assigned More Than Once',
                Message: '#LDS#Saving is not possible. At least one mitigating control is assigned more than once. Remove the multiple assigned mitigating control and try again.',
            });
            return;
        }
        this.busyService.show();
        try {
            await this.handleSave();
        }
        finally {
            this.busyService.hide();
            this.snackbarService.open({
                key: '#LDS#The mitigating controls have been successfully saved.',
            });
        }
    }
    async handleSave() {
        for await (const [index, mControl] of this.mControls.entries()) {
            if (this.formArray.controls[index].dirty) {
                // Only save if the form array is dirty
                const _ = await this.mControlService.postControl(this.uidNonCompliance, mControl.baseObject);
            }
        }
        this.resetForm();
    }
    async resetForm() {
        // Since we must handle change detection manually, overwrite formgroup and get read-only mcontrols
        this.formGroup = new UntypedFormGroup({ formArray: this.formBuilder.array([]) });
        this.mControls = (await this.mControlService.getControls(this.uidNonCompliance)).Data;
        this.cd.detectChanges();
    }
    static ɵfac = function MitigatingControlsRulesComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlsRulesComponent)(i0.ɵɵdirectiveInject(MitigatingControlsRulesService), i0.ɵɵdirectiveInject(i2$2.UntypedFormBuilder), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2$1.SnackBarService), i0.ɵɵdirectiveInject(i2$1.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsRulesComponent, selectors: [["imx-mitigating-controls-rules"]], inputs: { isMControlPerViolation: "isMControlPerViolation", uidNonCompliance: "uidNonCompliance", uidCompliance: "uidCompliance", mControls: "mControls", sidesheetRef: "sidesheetRef", canEdit: "canEdit" }, decls: 6, vars: 5, consts: [[1, "control-container"], ["type", "info", 3, "condensed", "colored", 4, "ngIf"], ["class", "imx-mitigating-control", 4, "ngFor", "ngForOf"], ["class", "imx-centered-filled-card", 4, "ngIf"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["type", "info", 3, "condensed", "colored"], [1, "imx-mitigating-control"], [1, "imx-mitigating-control-properties"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["icon", "delete", 3, "click", 4, "ngIf"], [3, "controlCreated", "cdr"], ["icon", "delete", 3, "click"], [1, "imx-centered-filled-card"], [1, "imx-no-results"], ["icon", "table"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "mitigating-controls-button-add", 1, "justify-start", 3, "click"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-rules-button-save", 3, "click", "disabled"]], template: function MitigatingControlsRulesComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, MitigatingControlsRulesComponent_eui_alert_1_Template, 7, 8, "eui-alert", 1)(2, MitigatingControlsRulesComponent_eui_alert_2_Template, 7, 8, "eui-alert", 1)(3, MitigatingControlsRulesComponent_mat_card_3_Template, 4, 2, "mat-card", 2)(4, MitigatingControlsRulesComponent_mat_card_4_Template, 6, 3, "mat-card", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, MitigatingControlsRulesComponent_div_5_Template, 7, 7, "div", 4);
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isMControlPerViolation);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.isMControlPerViolation);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.mControls);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.canEdit);
        } }, dependencies: [i5.NgForOf, i5.NgIf, i3$1.EuiAlertComponent, i3$1.EuiAlertContentDirective, i3$1.EuiAlertHeaderDirective, i3$1.EuiIconComponent, i3$1.EuiSidesheetActionsDirective, i2$1.CdrEditorComponent, i6.MatButton, i3$2.MatCard, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .control-container[_ngcontent-%COMP%]{padding:20px;display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{margin-bottom:15px;display:flex;justify-content:space-between}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]   .mitigating-control-properties[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;margin-right:15px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]{text-align:center;margin:auto}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px;color:#919799}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsRulesComponent, [{
        type: Component,
        args: [{ selector: 'imx-mitigating-controls-rules', template: "<div class=\"control-container\">\n  <eui-alert type=\"info\" [condensed]=\"true\" [colored]=\"true\" *ngIf=\"isMControlPerViolation\">\n    <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Can Be Assigned Individually' | translate }}</eui-alert-header>\n    <eui-alert-content>{{\n      '#LDS#Here you can get an overview of the mitigating controls that can be assigned to a violation of this compliance rule.'\n        | translate\n    }}</eui-alert-content>\n  </eui-alert>\n  <eui-alert type=\"info\" [condensed]=\"true\" [colored]=\"true\" *ngIf=\"!isMControlPerViolation\">\n    <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Applied Globally' | translate }}</eui-alert-header>\n    <eui-alert-content>{{\n      '#LDS#Here you can get an overview of the mitigating controls that are automatically applied to every violation of this compliance rule.'\n        | translate\n    }}</eui-alert-content>\n  </eui-alert>\n  <mat-card class=\"imx-mitigating-control\" *ngFor=\"let mControl of mControls; let i = index\">\n    <div class=\"imx-mitigating-control-properties\">\n      <imx-cdr-editor *ngFor=\"let cdr of mControl.propertyInfo\" [cdr]=\"cdr\" (controlCreated)=\"formArray.push($event)\"></imx-cdr-editor>\n    </div>\n\n    <eui-icon *ngIf=\"canEdit\" icon=\"delete\" (click)=\"onDelete(mControl, i)\"></eui-icon>\n  </mat-card>\n\n  <mat-card class=\"imx-centered-filled-card\" *ngIf=\"!mControls || mControls.length == 0\">\n    <div class=\"imx-no-results\">\n      <eui-icon icon=\"table\"></eui-icon>\n      <p>{{ '#LDS#Currently, no mitigating controls are assigned to this compliance rule.' | translate }}</p>\n    </div>\n  </mat-card>\n</div>\n\n<div eui-sidesheet-actions *ngIf=\"canEdit\">\n  <button mat-stroked-button class=\"justify-start\" data-imx-identifier=\"mitigating-controls-button-add\" (click)=\"onCreateControl()\">\n    {{ '#LDS#Assign mitigating controls' | translate }}\n  </button>\n  <button\n    mat-flat-button\n    color=\"primary\"\n    (click)=\"onSave()\"\n    [disabled]=\"formGroup.pristine || formGroup.invalid || formArray.length === 0\"\n    data-imx-identifier=\"mitigating-controls-rules-button-save\"\n  >\n    {{ '#LDS#Save' | translate }}\n  </button>\n</div>\n", styles: [":host{height:100%;display:flex;flex-direction:column;justify-content:space-between}:host .control-container{padding:20px;display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}:host .mitigating-control{margin-bottom:15px;display:flex;justify-content:space-between}:host .mitigating-control .mitigating-control-properties{display:flex;flex-direction:column;width:100%;margin-right:15px}:host .imx-no-results{text-align:center;margin:auto}:host .imx-no-results p{margin:0;font-size:18px;color:#919799}\n"] }]
    }], () => [{ type: MitigatingControlsRulesService }, { type: i2$2.UntypedFormBuilder }, { type: i0.ChangeDetectorRef }, { type: i3$1.EuiLoadingService }, { type: i2$1.SnackBarService }, { type: i2$1.ConfirmationService }], { isMControlPerViolation: [{
            type: Input
        }], uidNonCompliance: [{
            type: Input
        }], uidCompliance: [{
            type: Input
        }], mControls: [{
            type: Input
        }], sidesheetRef: [{
            type: Input
        }], canEdit: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MitigatingControlsRulesComponent, { className: "MitigatingControlsRulesComponent", filePath: "lib\\rules\\mitigating-controls-rules\\mitigating-controls-rules.component.ts", lineNumber: 40 }); })();

function ResolveComponent_mat_spinner_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner");
} }
function ResolveComponent_ng_container_4_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 7);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, ctx_r0.LdsContributingPermissions), " ");
} }
function ResolveComponent_ng_container_4_eui_alert_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 7);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, ctx_r0.LdsNoPermissions), "");
} }
function ResolveComponent_ng_container_4_mat_selection_list_3_mat_list_option_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-list-option", 10)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 11);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const entl_r3 = ctx.$implicit;
    i0.ɵɵproperty("value", entl_r3.ObjectKeyEntitlement);
    i0.ɵɵattribute("data-imx-identifier", "multi-select-entitlement-" + entl_r3.ObjectKeyEntitlement);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(entl_r3.Display);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(entl_r3.TypeDisplay);
} }
function ResolveComponent_ng_container_4_mat_selection_list_3_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-selection-list", 8);
    i0.ɵɵtwoWayListener("ngModelChange", function ResolveComponent_ng_container_4_mat_selection_list_3_Template_mat_selection_list_ngModelChange_0_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(2); i0.ɵɵtwoWayBindingSet(ctx_r0.selectedEntitlements, $event) || (ctx_r0.selectedEntitlements = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵtemplate(1, ResolveComponent_ng_container_4_mat_selection_list_3_mat_list_option_1_Template, 5, 4, "mat-list-option", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵtwoWayProperty("ngModel", ctx_r0.selectedEntitlements);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r0.entitlements);
} }
function ResolveComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, ResolveComponent_ng_container_4_eui_alert_1_Template, 3, 5, "eui-alert", 3)(2, ResolveComponent_ng_container_4_eui_alert_2_Template, 3, 5, "eui-alert", 3)(3, ResolveComponent_ng_container_4_mat_selection_list_3_Template, 2, 2, "mat-selection-list", 4);
    i0.ɵɵelementStart(4, "div", 5)(5, "button", 6);
    i0.ɵɵtext(6);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.entitlements.length > 0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.entitlements.length == 0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.entitlements.length > 0);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r0.selectedEntitlements.length < 1);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 5, "#LDS#Next"), " ");
} }
function ResolveComponent_mat_spinner_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner");
} }
function ResolveComponent_ng_container_8_mat_list_option_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-list-option", 17)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 11);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const action_r5 = ctx.$implicit;
    i0.ɵɵproperty("value", action_r5.Id)("disabled", !action_r5.CanExecute);
    i0.ɵɵattribute("data-imx-identifier", "multi-select-action-" + action_r5.Id);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(action_r5.Display);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(action_r5.ObjectDisplay);
} }
function ResolveComponent_ng_container_8_imx_cdr_editor_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 18);
} if (rf & 2) {
    const cdr_r6 = ctx.$implicit;
    const i_r7 = ctx.index;
    i0.ɵɵproperty("cdr", cdr_r6);
    i0.ɵɵattribute("data-imx-identifier", "resolve-cdr-" + cdr_r6.column.ColumnName + "-" + i_r7);
} }
function ResolveComponent_ng_container_8_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "eui-alert", 7);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-selection-list", 12);
    i0.ɵɵtwoWayListener("ngModelChange", function ResolveComponent_ng_container_8_Template_mat_selection_list_ngModelChange_4_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r0.uidActions, $event) || (ctx_r0.uidActions = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵtemplate(5, ResolveComponent_ng_container_8_mat_list_option_5_Template, 5, 5, "mat-list-option", 13);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(6, ResolveComponent_ng_container_8_imx_cdr_editor_6_Template, 1, 2, "imx-cdr-editor", 14);
    i0.ɵɵelementStart(7, "div", 5)(8, "button", 15);
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "button", 16);
    i0.ɵɵtext(12);
    i0.ɵɵpipe(13, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 9, ctx_r0.LdsActionList), "");
    i0.ɵɵadvance(2);
    i0.ɵɵtwoWayProperty("ngModel", ctx_r0.uidActions);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r0.actions);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r0.cdrs);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 11, "#LDS#Back"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r0.uidActions.length < 1);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 13, "#LDS#Next"), " ");
} }
function ResolveComponent_mat_spinner_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner");
} }
function ResolveComponent_ng_container_12_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 7);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, ctx_r0.LdsNoLoseAdditional), "");
} }
function ResolveComponent_ng_container_12_ng_container_2_li_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 23)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 11);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const entl_r9 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(entl_r9.Display);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(entl_r9.TypeDisplay);
} }
function ResolveComponent_ng_container_12_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "eui-alert", 21);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "ul");
    i0.ɵɵtemplate(5, ResolveComponent_ng_container_12_ng_container_2_li_5_Template, 5, 2, "li", 22);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 4, ctx_r0.LdsLoseEntitlements), "");
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngForOf", ctx_r0.entitlementsLoseAlso);
} }
function ResolveComponent_ng_container_12_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, ResolveComponent_ng_container_12_eui_alert_1_Template, 3, 5, "eui-alert", 3)(2, ResolveComponent_ng_container_12_ng_container_2_Template, 6, 6, "ng-container", 2);
    i0.ɵɵelementStart(3, "div", 5)(4, "button", 19);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "button", 20);
    i0.ɵɵlistener("click", function ResolveComponent_ng_container_12_Template_button_click_7_listener() { i0.ɵɵrestoreView(_r8); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.Execute()); });
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", 0 === ctx_r0.entitlementsLoseAlso.length);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", 0 < ctx_r0.entitlementsLoseAlso.length);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Back"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 6, "#LDS#Next"), " ");
} }
class ResolveComponent {
    sidesheetRef;
    snackbar;
    cplApi;
    busySvc;
    metadata;
    entityService;
    data;
    constructor(sidesheetRef, snackbar, cplApi, busySvc, metadata, entityService, data) {
        this.sidesheetRef = sidesheetRef;
        this.snackbar = snackbar;
        this.cplApi = cplApi;
        this.busySvc = busySvc;
        this.metadata = metadata;
        this.entityService = entityService;
        this.data = data;
    }
    busy = false;
    completed = false;
    actions = [];
    entitlements = [];
    entitlementsLoseAlso = [];
    selectedEntitlements = [];
    uidActions = [];
    reasonCdr;
    cdrs;
    async ngOnInit() {
        this.reasonCdr = new BaseCdr(this.entityService.createLocalEntityColumn({
            ColumnName: 'ReasonHead',
            Type: ValType.Text,
            IsMultiLine: true,
        }), '#LDS#Reason for unsubscribing');
        this.busy = true;
        // load entitlements contributing to the rule violation
        this.selectedEntitlements = [];
        try {
            this.entitlements = await this.cplApi.client.portal_rules_violations_entitlements_get(this.data.uidPerson, this.data.uidNonCompliance);
            await this.enhanceWithTypeDisplay(this.entitlements);
        }
        finally {
            this.busy = false;
        }
    }
    async enhanceWithTypeDisplay(obj) {
        obj.forEach((element) => {
            element.Key = DbObjectKey.FromXml(element.ObjectKeyEntitlement || '');
        });
        await this.metadata.updateNonExisting(obj.map((i) => i.Key?.TableName || ''));
        obj.forEach((element) => {
            if (element.Key?.TableName) {
                element.TypeDisplay = this.metadata.tables[element.Key.TableName]?.DisplaySingular;
            }
        });
    }
    async selectedStepChanged(event) {
        if (this.completed)
            return;
        if (event.selectedIndex === 1 && event.previouslySelectedIndex === 0) {
            await this.LoadActions();
        }
        else if (event.selectedIndex === 2 && event.previouslySelectedIndex === 1) {
            await this.LoadEntitlementsLoseAlso();
        }
    }
    async LoadActions() {
        // load actions
        this.actions = [];
        this.uidActions = [];
        this.busy = true;
        try {
            this.actions = await this.cplApi.client.portal_rules_violations_actions_post(this.data.uidPerson, this.data.uidNonCompliance, {
                ObjectKeys: this.selectedEntitlements,
            });
            this.uidActions = this.actions.filter((a) => a.IsActive).map((a) => a.Id || '');
            // do we have any unsubscribe actions?
            if (this.actions.filter((a) => a.Id?.endsWith('.Unsubscribe')).length > 0) {
                // allow the user to enter a reason
                this.cdrs = [this.reasonCdr];
            }
            else {
                this.cdrs = [];
            }
        }
        finally {
            this.busy = false;
        }
    }
    async LoadEntitlementsLoseAlso() {
        // load the entitlements that will also be lost if the selected actions are run
        this.entitlementsLoseAlso = [];
        this.busy = true;
        try {
            this.entitlementsLoseAlso = await this.cplApi.client.portal_rules_violations_analyzeloss_post(this.data.uidPerson, this.data.uidNonCompliance, {
                ObjectKeys: this.selectedEntitlements,
                ActionIds: this.uidActions,
            });
            await this.enhanceWithTypeDisplay(this.entitlementsLoseAlso);
        }
        finally {
            this.busy = false;
        }
    }
    async Execute() {
        const b = this.busySvc.show();
        try {
            await this.cplApi.client.portal_rules_violations_result_post(this.data.uidPerson, this.data.uidNonCompliance, {
                ReasonText: this.reasonCdr.column.GetValue(),
                ObjectKeys: this.selectedEntitlements,
                ActionIds: this.uidActions,
            });
            this.completed = true;
            this.sidesheetRef.close(true);
            this.snackbar.open({ key: this.LdsChangesQueued });
        }
        finally {
            this.busySvc.hide(b);
        }
    }
    LdsChangesQueued = '#LDS#Your changes have been successfully saved. It may take some time for the changes to take effect.';
    LdsLoseEntitlements = '#LDS#The identity will lose the following entitlements when the selected actions take effect. Check the list to avoid unintentional loss of access. To change the selection, go back to the previous page.';
    LdsNoPermissions = '#LDS#No entitlements were found. The cause for the violation may has already been resolved. You may close this wizard.';
    LdsContributingPermissions = '#LDS#The following entitlements contribute to this rule violation. Select the entitlements to be removed from the identity.';
    LdsNoLoseAdditional = '#LDS#The identity will not lose any additional entitlements.';
    LdsActionList = '#LDS#The following actions will be performed to remove the selected entitlements from the identity.';
    static ɵfac = function ResolveComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ResolveComponent)(i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2$1.SnackBarService), i0.ɵɵdirectiveInject(ApiService), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2$1.MetadataService), i0.ɵɵdirectiveInject(i2$1.EntityService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ResolveComponent, selectors: [["ng-component"]], decls: 13, vars: 16, consts: [["orientation", "vertical", 3, "selectionChange", "linear"], [3, "label"], [4, "ngIf"], ["type", "info", 3, "condensed", "colored", 4, "ngIf"], ["class", "imx-margin-bottom-20", 3, "ngModel", "ngModelChange", 4, "ngIf"], [1, "imx-button-stepper"], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-1-next", "color", "primary", "matStepperNext", "", 3, "disabled"], ["type", "info", 3, "condensed", "colored"], [1, "imx-margin-bottom-20", 3, "ngModelChange", "ngModel"], ["checkboxPosition", "before", 3, "value", 4, "ngFor", "ngForOf"], ["checkboxPosition", "before", 3, "value"], [1, "subtext"], [3, "ngModelChange", "ngModel"], ["checkboxPosition", "before", 3, "value", "disabled", 4, "ngFor", "ngForOf"], [3, "cdr", 4, "ngFor", "ngForOf"], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-2-back", "matStepperPrevious", ""], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-2-next", "color", "primary", "matStepperNext", "", 3, "disabled"], ["checkboxPosition", "before", 3, "value", "disabled"], [3, "cdr"], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-3-back", "matStepperPrevious", ""], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-3-next", "color", "primary", "matStepperNext", "", 3, "click"], ["type", "warning", 3, "condensed", "colored"], ["class", "entllose", 4, "ngFor", "ngForOf"], [1, "entllose"]], template: function ResolveComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-stepper", 0);
            i0.ɵɵlistener("selectionChange", function ResolveComponent_Template_mat_stepper_selectionChange_0_listener($event) { return ctx.selectedStepChanged($event); });
            i0.ɵɵelementStart(1, "mat-step", 1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵtemplate(3, ResolveComponent_mat_spinner_3_Template, 1, 0, "mat-spinner", 2)(4, ResolveComponent_ng_container_4_Template, 8, 7, "ng-container", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-step", 1);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵtemplate(7, ResolveComponent_mat_spinner_7_Template, 1, 0, "mat-spinner", 2)(8, ResolveComponent_ng_container_8_Template, 14, 15, "ng-container", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(9, "mat-step", 1);
            i0.ɵɵpipe(10, "translate");
            i0.ɵɵtemplate(11, ResolveComponent_mat_spinner_11_Template, 1, 0, "mat-spinner", 2)(12, ResolveComponent_ng_container_12_Template, 10, 8, "ng-container", 2);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵproperty("linear", true);
            i0.ɵɵadvance();
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(2, 10, "#LDS#Select permissions for removal"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.busy);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.busy);
            i0.ɵɵadvance();
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(6, 12, "#LDS#Verify actions"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.busy);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.busy);
            i0.ɵɵadvance();
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(10, 14, "#LDS#Check loss of entitlements"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.busy);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.busy);
        } }, dependencies: [i2$1.CdrEditorComponent, i5.NgForOf, i5.NgIf, i3$1.EuiAlertComponent, i6.MatButton, i6$2.MatSelectionList, i6$2.MatListOption, i7.MatProgressSpinner, i8$1.MatStep, i8$1.MatStepper, i8$1.MatStepperNext, i8$1.MatStepperPrevious, i2$2.NgControlStatus, i2$2.NgModel, i4.TranslatePipe], styles: [".item[_ngcontent-%COMP%]{flex-grow:1;padding-top:1em}.subtext[_ngcontent-%COMP%]{font-size:small;font-style:italic;color:#919799;margin-bottom:10px}li.entllose[_ngcontent-%COMP%]{list-style-type:initial}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ResolveComponent, [{
        type: Component,
        args: [{ template: "<mat-stepper orientation=\"vertical\" [linear]=\"true\" (selectionChange)=\"selectedStepChanged($event)\">\n  <mat-step label=\"{{ '#LDS#Select permissions for removal' | translate }}\">\n    <mat-spinner *ngIf=\"busy\"></mat-spinner>\n\n    <ng-container *ngIf=\"!busy\">\n      <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"info\" *ngIf=\"entitlements.length > 0\">\n        {{ LdsContributingPermissions | translate }}\n      </eui-alert>\n\n      <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"info\" *ngIf=\"entitlements.length == 0\">\n        {{ LdsNoPermissions | translate }}</eui-alert\n      >\n\n      <mat-selection-list class=\"imx-margin-bottom-20\" [(ngModel)]=\"selectedEntitlements\" *ngIf=\"entitlements.length > 0\">\n        <mat-list-option\n          checkboxPosition=\"before\"\n          *ngFor=\"let entl of entitlements\"\n          [value]=\"entl.ObjectKeyEntitlement\"\n          [attr.data-imx-identifier]=\"'multi-select-entitlement-' + entl.ObjectKeyEntitlement\"\n        >\n          <div>{{ entl.Display }}</div>\n          <div class=\"subtext\">{{ entl.TypeDisplay }}</div>\n        </mat-list-option>\n      </mat-selection-list>\n\n      <div class=\"imx-button-stepper\">\n        <button\n          mat-stroked-button\n          data-imx-identifier=\"resolve-step-1-next\"\n          color=\"primary\"\n          matStepperNext\n          [disabled]=\"selectedEntitlements.length < 1\"\n        >\n          {{ '#LDS#Next' | translate }}\n        </button>\n      </div>\n    </ng-container>\n  </mat-step>\n\n  <mat-step label=\"{{ '#LDS#Verify actions' | translate }}\">\n    <mat-spinner *ngIf=\"busy\"></mat-spinner>\n\n    <ng-container *ngIf=\"!busy\">\n      <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"info\"> {{ LdsActionList | translate }}</eui-alert>\n\n      <mat-selection-list [(ngModel)]=\"uidActions\">\n        <mat-list-option\n          checkboxPosition=\"before\"\n          *ngFor=\"let action of actions\"\n          [value]=\"action.Id\"\n          [disabled]=\"!action.CanExecute\"\n          [attr.data-imx-identifier]=\"'multi-select-action-' + action.Id\"\n        >\n          <div>{{ action.Display }}</div>\n          <div class=\"subtext\">{{ action.ObjectDisplay }}</div>\n        </mat-list-option>\n      </mat-selection-list>\n\n      <imx-cdr-editor\n        *ngFor=\"let cdr of cdrs; let i = index\"\n        [cdr]=\"cdr\"\n        [attr.data-imx-identifier]=\"'resolve-cdr-' + cdr.column.ColumnName + '-' + i\"\n      >\n      </imx-cdr-editor>\n\n      <div class=\"imx-button-stepper\">\n        <button mat-stroked-button data-imx-identifier=\"resolve-step-2-back\" matStepperPrevious>{{ '#LDS#Back' | translate }}</button>\n        <button\n          mat-stroked-button\n          data-imx-identifier=\"resolve-step-2-next\"\n          color=\"primary\"\n          matStepperNext\n          [disabled]=\"uidActions.length < 1\"\n        >\n          {{ '#LDS#Next' | translate }}\n        </button>\n      </div>\n    </ng-container>\n  </mat-step>\n  <mat-step label=\"{{ '#LDS#Check loss of entitlements' | translate }}\">\n    <mat-spinner *ngIf=\"busy\"></mat-spinner>\n\n    <ng-container *ngIf=\"!busy\">\n      <eui-alert [condensed]=\"true\" [colored]=\"true\" *ngIf=\"0 === entitlementsLoseAlso.length\" type=\"info\">\n        {{ LdsNoLoseAdditional | translate }}</eui-alert\n      >\n\n      <ng-container *ngIf=\"0 < entitlementsLoseAlso.length\">\n        <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"warning\"> {{ LdsLoseEntitlements | translate }}</eui-alert>\n\n        <ul>\n          <li class=\"entllose\" *ngFor=\"let entl of entitlementsLoseAlso\">\n            <div>{{ entl.Display }}</div>\n            <div class=\"subtext\">{{ entl.TypeDisplay }}</div>\n          </li>\n        </ul>\n      </ng-container>\n\n      <div class=\"imx-button-stepper\">\n        <button mat-stroked-button data-imx-identifier=\"resolve-step-3-back\" matStepperPrevious>{{ '#LDS#Back' | translate }}</button>\n        <button mat-stroked-button data-imx-identifier=\"resolve-step-3-next\" (click)=\"Execute()\" color=\"primary\" matStepperNext>\n          {{ '#LDS#Next' | translate }}\n        </button>\n      </div>\n    </ng-container>\n  </mat-step>\n</mat-stepper>\n", styles: [".item{flex-grow:1;padding-top:1em}.subtext{font-size:small;font-style:italic;color:#919799;margin-bottom:10px}li.entllose{list-style-type:initial}\n"] }]
    }], () => [{ type: i3$1.EuiSidesheetRef }, { type: i2$1.SnackBarService }, { type: ApiService }, { type: i3$1.EuiLoadingService }, { type: i2$1.MetadataService }, { type: i2$1.EntityService }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ResolveComponent, { className: "ResolveComponent", filePath: "lib\\rules-violations\\resolve\\resolve.component.ts", lineNumber: 41 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesViolationsMultiActionComponent_imx_cdr_editor_9_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 7);
    i0.ɵɵlistener("controlCreated", function RulesViolationsMultiActionComponent_imx_cdr_editor_9_Template_imx_cdr_editor_controlCreated_0_listener($event) { const ctx_r1 = i0.ɵɵrestoreView(_r1); const cdr_r3 = ctx_r1.$implicit; const i_r4 = ctx_r1.index; const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.onFormControlCreated(cdr_r3.column.ColumnName + "_" + i_r4, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    const i_r4 = ctx.index;
    i0.ɵɵproperty("cdr", cdr_r3);
    i0.ɵɵattribute("data-imx-identifier", "rules-violations-multi-action-" + cdr_r3.column.ColumnName + "-" + i_r4);
} }
function RulesViolationsMultiActionComponent_mat_list_item_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-list-item")(1, "div", 8);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 9);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    let tmp_3_0;
    const ruleViolationApproval_r6 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ruleViolationApproval_r6 == null ? null : (tmp_3_0 = ruleViolationApproval_r6.GetEntity()) == null ? null : tmp_3_0.GetDisplay(), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ruleViolationApproval_r6 == null ? null : ruleViolationApproval_r6.stateBadge == null ? null : ruleViolationApproval_r6.stateBadge.caption, " ");
} }
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a multiple rules violations.
 * There is an alternative component for the case of a decision for a single rules
 * violation as well: {@link RulesViolationsSingleActionComponent}.
 */
class RulesViolationsMultiActionComponent {
    /**
     * @ignore since this is only an internal component.
     *
     * Data coming from the service about the rules violations.
     */
    data;
    /**
     * @ignore since this is only an internal component.
     *
     * The form group to which the necessary form fields will be added.
     */
    formGroup;
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * The references depending on the columns of the rules violations that are displayed/edited during the decision.
     *
     */
    columns = [];
    /**
     * @ignore since this is only an internal component
     *
     * Sets up the {@link columns} to be displayed/edited during OnInit lifecycle hook.
     */
    ngOnInit() {
        if (this.data.actionParameters.validUntil) {
            this.columns.push(this.data.actionParameters.validUntil);
        }
        if (this.data.actionParameters.justification) {
            this.columns.push(this.data.actionParameters.justification);
        }
        this.columns.push(this.data.actionParameters.reason);
    }
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * Handles the event emitted when a cdr editor created a new form control.
     *
     * @param name The name of the form control
     * @param control The form control
     */
    onFormControlCreated(name, control) {
        // use setTimeout to make addControl asynchronous in order to avoid "NG0100: Expression has changed after it was checked"
        setTimeout(() => this.formGroup.addControl(name, control));
    }
    static ɵfac = function RulesViolationsMultiActionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesViolationsMultiActionComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsMultiActionComponent, selectors: [["imx-rules-violations-multi-action"]], inputs: { data: "data", formGroup: "formGroup" }, decls: 17, vars: 11, consts: [["list", ""], [1, "imx-card-title-m"], [1, "imx-rules-violations-parameters"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [1, "imx-list-container"], [1, "imx-list-multi-action"], [4, "ngFor", "ngForOf"], [3, "controlCreated", "cdr"], [1, "mat-mdc-line"], ["mat-line", "", 1, "mat-mdc-line", "imx-list-item-subtitle", "imx-margin-bottom-5"]], template: function RulesViolationsMultiActionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title", 1);
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-card-subtitle");
            i0.ɵɵtext(5);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-card-content")(8, "div", 2);
            i0.ɵɵtemplate(9, RulesViolationsMultiActionComponent_imx_cdr_editor_9_Template, 1, 2, "imx-cdr-editor", 3);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(10, "mat-card", 4)(11, "mat-card-title", 1);
            i0.ɵɵtext(12);
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(14, "mat-list", 5, 0);
            i0.ɵɵtemplate(16, RulesViolationsMultiActionComponent_mat_list_item_16_Template, 5, 2, "mat-list-item", 6);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 5, "#LDS#Heading General Settings"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 7, "#LDS#Here you can make settings that are applied to each selected rule violation."), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngForOf", ctx.columns);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 9, "#LDS#Heading Selected Rule Violations"), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngForOf", ctx.data == null ? null : ctx.data.rulesViolationsApprovals);
        } }, dependencies: [i2$1.CdrEditorComponent, i5.NgForOf, i3$2.MatCard, i3$2.MatCardContent, i3$2.MatCardSubtitle, i3$2.MatCardTitle, i4$1.MatLine, i6$2.MatList, i6$2.MatListItem, i4.TranslatePipe], styles: ["mat-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;margin-bottom:20px}.imx-items-title[_ngcontent-%COMP%]{font-size:16px}.imx-list-container[_ngcontent-%COMP%]{overflow:hidden;margin-bottom:10px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsMultiActionComponent, [{
        type: Component,
        args: [{ selector: 'imx-rules-violations-multi-action', template: "<mat-card>\n  <mat-card-title class=\"imx-card-title-m\">\n    {{ '#LDS#Heading General Settings' | translate }}\n  </mat-card-title>\n  <mat-card-subtitle>\n    {{ '#LDS#Here you can make settings that are applied to each selected rule violation.' | translate }}\n  </mat-card-subtitle>\n  <mat-card-content>\n    <div class=\"imx-rules-violations-parameters\">\n      <imx-cdr-editor\n        *ngFor=\"let cdr of columns; let i = index\"\n        [cdr]=\"cdr\"\n        (controlCreated)=\"onFormControlCreated(cdr.column.ColumnName + '_' + i, $event)\"\n        [attr.data-imx-identifier]=\"'rules-violations-multi-action-' + cdr.column.ColumnName + '-' + i\"\n      >\n      </imx-cdr-editor>\n    </div>\n  </mat-card-content>\n</mat-card>\n<mat-card class=\"imx-list-container\">\n  <mat-card-title class=\"imx-card-title-m\">\n    {{ '#LDS#Heading Selected Rule Violations' | translate }}\n  </mat-card-title>\n  <mat-list #list class=\"imx-list-multi-action\">\n    <mat-list-item *ngFor=\"let ruleViolationApproval of data?.rulesViolationsApprovals\">\n      <div class=\"mat-mdc-line\">\n        {{ ruleViolationApproval?.GetEntity()?.GetDisplay() }}\n      </div>\n      <div mat-line class=\"mat-mdc-line imx-list-item-subtitle imx-margin-bottom-5\">\n        {{ ruleViolationApproval?.stateBadge?.caption }}\n      </div>\n    </mat-list-item>\n  </mat-list>\n</mat-card>\n", styles: ["mat-card{display:flex;flex-direction:column;margin-bottom:20px}.imx-items-title{font-size:16px}.imx-list-container{overflow:hidden;margin-bottom:10px}\n"] }]
    }], null, { data: [{
            type: Input
        }], formGroup: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RulesViolationsMultiActionComponent, { className: "RulesViolationsMultiActionComponent", filePath: "lib\\rules-violations\\rules-violations-action\\rules-violations-multi-action\\rules-violations-multi-action.component.ts", lineNumber: 45 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesViolationsSingleActionComponent_imx_cdr_editor_6_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 2);
    i0.ɵɵlistener("controlCreated", function RulesViolationsSingleActionComponent_imx_cdr_editor_6_Template_imx_cdr_editor_controlCreated_0_listener($event) { const ctx_r1 = i0.ɵɵrestoreView(_r1); const cdr_r3 = ctx_r1.$implicit; const i_r4 = ctx_r1.index; const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.onFormControlCreated(cdr_r3.column.ColumnName + "_" + i_r4, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    const i_r4 = ctx.index;
    i0.ɵɵproperty("cdr", cdr_r3);
    i0.ɵɵattribute("data-imx-identifier", "rules-violations-single-action-" + cdr_r3.column.ColumnName + "-" + i_r4);
} }
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a single rules violation.
 * There is an alternative component for the case of a decision for multiple rules
 * violations as well: {@link RulesViolationsMultiActionComponent}.
 */
class RulesViolationsSingleActionComponent {
    /**
     * @ignore since this is only an internal component.
     *
     * Data coming from the service about the rules violation.
     */
    data;
    /**
     * @ignore since this is only an internal component.
     *
     * The form group to which the necessary form fields will be added.
     */
    formGroup;
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * The references depending on the columns of the rules violation that are displayed/edited during the decision.
     *
     */
    columns = [];
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * The single ruoes violation taken from {@link data}
     */
    rulesViolation;
    /**
     * @ignore since this is only an internal component
     *
     * Sets up the {@link columns} to be displayed/edited during OnInit lifecycle hook.
     */
    ngOnInit() {
        this.rulesViolation = this.data.rulesViolationsApprovals[0];
        if (this.data.actionParameters.validUntil) {
            this.columns.push(this.data.actionParameters.validUntil);
        }
        if (this.data.actionParameters.justification) {
            this.columns.push(this.data.actionParameters.justification);
        }
        this.columns.push(this.data.actionParameters.reason);
    }
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * Handles the event emitted when a cdr editor created a new form control.
     *
     * @param name The name of the form control
     * @param control The form control
     */
    onFormControlCreated(name, control) {
        // use setTimeout to make addControl asynchronous in order to avoid "NG0100: Expression has changed after it was checked"
        setTimeout(() => this.formGroup.addControl(name, control));
    }
    static ɵfac = function RulesViolationsSingleActionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesViolationsSingleActionComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsSingleActionComponent, selectors: [["imx-rules-violations-single-action"]], inputs: { data: "data", formGroup: "formGroup" }, decls: 7, vars: 3, consts: [[1, "imx-card-title-s"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [3, "controlCreated", "cdr"]], template: function RulesViolationsSingleActionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title", 0);
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card-subtitle");
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-card-content");
            i0.ɵɵtemplate(6, RulesViolationsSingleActionComponent_imx_cdr_editor_6_Template, 1, 2, "imx-cdr-editor", 1);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            let tmp_0_0;
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate((tmp_0_0 = ctx.rulesViolation.GetEntity()) == null ? null : tmp_0_0.GetDisplay());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.rulesViolation == null ? null : ctx.rulesViolation.stateBadge == null ? null : ctx.rulesViolation.stateBadge.caption);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", ctx.columns);
        } }, dependencies: [i2$1.CdrEditorComponent, i5.NgForOf, i3$2.MatCard, i3$2.MatCardContent, i3$2.MatCardSubtitle, i3$2.MatCardTitle], styles: ["mat-card-content[_ngcontent-%COMP%]{overflow:hidden}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsSingleActionComponent, [{
        type: Component,
        args: [{ selector: 'imx-rules-violations-single-action', template: "<mat-card>\n  <mat-card-title class=\"imx-card-title-s\">{{ rulesViolation.GetEntity()?.GetDisplay() }}</mat-card-title>\n  <mat-card-subtitle>{{ rulesViolation?.stateBadge?.caption }}</mat-card-subtitle>\n  <mat-card-content>\n    <imx-cdr-editor\n      *ngFor=\"let cdr of columns; let i = index\"\n      [cdr]=\"cdr\"\n      (controlCreated)=\"onFormControlCreated(cdr.column.ColumnName + '_' + i, $event)\"\n      [attr.data-imx-identifier]=\"'rules-violations-single-action-' + cdr.column.ColumnName + '-' + i\"\n    >\n    </imx-cdr-editor>\n  </mat-card-content>\n</mat-card>\n", styles: ["mat-card-content{overflow:hidden}\n"] }]
    }], null, { data: [{
            type: Input
        }], formGroup: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RulesViolationsSingleActionComponent, { className: "RulesViolationsSingleActionComponent", filePath: "lib\\rules-violations\\rules-violations-action\\rules-violations-single-action\\rules-violations-single-action.component.ts", lineNumber: 46 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesViolationsActionComponent_p_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, ctx_r0.data.description));
} }
function RulesViolationsActionComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelement(1, "imx-rules-violations-multi-action", 5);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("formGroup", ctx_r0.formGroup)("data", ctx_r0.data);
} }
function RulesViolationsActionComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelement(1, "imx-rules-violations-single-action", 5);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("formGroup", ctx_r0.formGroup)("data", ctx_r0.data);
} }
function RulesViolationsActionComponent_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 6);
    i0.ɵɵlistener("click", function RulesViolationsActionComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.sideSheetRef.close(true)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r0.formGroup.invalid);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Save"), " ");
} }
/**
 * Component displayed in a sidesheet to make a decision for one or more rules violations.
 *
 * Uses two alternate views
 * <ul>
 * <li>a) a simple view for a single rules violation</li>
 * <li>b) a complex view using bulk items for multiple rules violations.</li>
 * </ul>
 */
class RulesViolationsActionComponent {
    data;
    sideSheetRef;
    /**
     * The form group to which the created form controls will be added.
     */
    formGroup = new UntypedFormGroup({});
    /**
     * Creates a new RulesViolationsActionComponent
     * @param data The pre-calculated data object.
     * @param sideSheetRef A reference to the sidesheet containing this component.
     */
    constructor(data, sideSheetRef) {
        this.data = data;
        this.sideSheetRef = sideSheetRef;
    }
    static ɵfac = function RulesViolationsActionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesViolationsActionComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsActionComponent, selectors: [["imx-rules-violations-action"]], decls: 7, vars: 5, consts: [["eui-sidesheet-content", ""], [4, "ngIf"], [1, "imx-rules-violations-action-form", 3, "formGroup"], ["eui-sidesheet-actions", ""], ["data-imx-identifier", "rules-violations-action-button-save", "mat-flat-button", "", "color", "primary", 3, "disabled", "click", 4, "ngIf"], [3, "formGroup", "data"], ["data-imx-identifier", "rules-violations-action-button-save", "mat-flat-button", "", "color", "primary", 3, "click", "disabled"]], template: function RulesViolationsActionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, RulesViolationsActionComponent_p_1_Template, 3, 3, "p", 1);
            i0.ɵɵelementStart(2, "form", 2);
            i0.ɵɵtemplate(3, RulesViolationsActionComponent_ng_container_3_Template, 2, 2, "ng-container", 1)(4, RulesViolationsActionComponent_ng_container_4_Template, 2, 2, "ng-container", 1);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "div", 3);
            i0.ɵɵtemplate(6, RulesViolationsActionComponent_button_6_Template, 3, 4, "button", 4);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.description);
            i0.ɵɵadvance();
            i0.ɵɵproperty("formGroup", ctx.formGroup);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.rulesViolationsApprovals.length > 1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.rulesViolationsApprovals.length === 1);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.formGroup);
        } }, dependencies: [i5.NgIf, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i6.MatButton, i2$2.ɵNgNoValidate, i2$2.NgControlStatusGroup, i2$2.FormGroupDirective, RulesViolationsMultiActionComponent, RulesViolationsSingleActionComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]   .imx-rules-violations-action-form[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]   .imx-rules-violations-action-form[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsActionComponent, [{
        type: Component,
        args: [{ selector: 'imx-rules-violations-action', template: "<div eui-sidesheet-content>\n  <p *ngIf=\"data.description\">{{ data.description | translate }}</p>\n  <form [formGroup]=\"formGroup\" class=\"imx-rules-violations-action-form\">\n    <ng-container *ngIf=\"data.rulesViolationsApprovals.length > 1\">\n      <imx-rules-violations-multi-action [formGroup]=\"formGroup\" [data]=\"data\"> </imx-rules-violations-multi-action>\n    </ng-container>\n    <ng-container *ngIf=\"data.rulesViolationsApprovals.length === 1\">\n      <imx-rules-violations-single-action [formGroup]=\"formGroup\" [data]=\"data\"> </imx-rules-violations-single-action>\n    </ng-container>\n  </form>\n</div>\n<div eui-sidesheet-actions>\n  <button\n    data-imx-identifier=\"rules-violations-action-button-save\"\n    mat-flat-button\n    color=\"primary\"\n    (click)=\"sideSheetRef.close(true)\"\n    *ngIf=\"formGroup\"\n    [disabled]=\"formGroup.invalid\"\n  >\n    {{ '#LDS#Save' | translate }}\n  </button>\n</div>\n", styles: [":host .eui-sidesheet-content{display:flex;flex-direction:column}:host .eui-sidesheet-content .imx-rules-violations-action-form{display:flex;flex-direction:column;overflow:auto}:host .eui-sidesheet-content .imx-rules-violations-action-form>*{display:flex;flex-direction:column;overflow:auto}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i3$1.EuiSidesheetRef }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RulesViolationsActionComponent, { className: "RulesViolationsActionComponent", filePath: "lib\\rules-violations\\rules-violations-action\\rules-violations-action.component.ts", lineNumber: 47 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Service that handles the approve and deny of one or more rules violations.
 */
class RulesViolationsActionService {
    justification;
    cplClient;
    sidesheet;
    busyService;
    translate;
    snackBar;
    entityService;
    userService;
    applied = new Subject();
    constructor(justification, cplClient, sidesheet, busyService, translate, snackBar, entityService, userService) {
        this.justification = justification;
        this.cplClient = cplClient;
        this.sidesheet = sidesheet;
        this.busyService = busyService;
        this.translate = translate;
        this.snackBar = snackBar;
        this.entityService = entityService;
        this.userService = userService;
    }
    /**
     * Approve the rules violation
     * @param ruleViolationToApprove The rules violation
     * @param input reason and/or standard reason
     */
    async approve(rulesViolations) {
        return this.makeDecisions(rulesViolations, true);
    }
    /**
     * Deny the rules violation
     * @param ruleViolationToApprove The rules violation
     * @param input reason and/or standard reason
     */
    async deny(rulesViolations) {
        return this.makeDecisions(rulesViolations, false);
    }
    async resolve(ruleViolation) {
        const sidesheetRef = this.sidesheet.open(ResolveComponent, {
            title: await this.translate.get('#LDS#Heading Resolve Rule Violation').toPromise(),
            subTitle: ruleViolation.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(),
            testId: 'rulesviolations-resolve-sidesheet',
            data: {
                uidPerson: ruleViolation.UID_Person.value,
                uidNonCompliance: ruleViolation.UID_NonCompliance.value,
            },
        });
        return sidesheetRef.afterClosed().toPromise();
    }
    async makeDecisions(rulesViolationsApprovals, approve) {
        let justification;
        if (this.busyService.overlayRefs.length === 0) {
            this.busyService.show();
        }
        try {
            justification = await this.justification.createCdr(approve ? JustificationType.approveRuleViolation : JustificationType.denyRuleViolation);
        }
        finally {
            this.busyService.hide();
        }
        const actionParameters = {
            justification,
            reason: this.createCdrReason({ display: justification ? '#LDS#Additional comments about your decision' : undefined }),
        };
        if (approve) {
            actionParameters.validUntil = this.createCdrValidUntil();
        }
        const sidesheetTitle = approve
            ? rulesViolationsApprovals.length > 1
                ? '#LDS#Heading Grant Exceptions'
                : '#LDS#Heading Grant Exception'
            : rulesViolationsApprovals.length > 1
                ? '#LDS#Heading Deny Exceptions'
                : '#LDS#Heading Deny Exception';
        return this.editAction({
            title: sidesheetTitle,
            data: { rulesViolationsApprovals, actionParameters, approve },
            message: approve
                ? '#LDS#Exceptions have been successfully granted for {0} rule violations.'
                : '#LDS#Exceptions have been successfully denied for {0} rule violations.',
            apply: async (rulesViolationsAction) => {
                return this.postDecision(rulesViolationsAction, {
                    Reason: actionParameters.reason.column.GetValue(),
                    UidJustification: actionParameters.justification?.column?.GetValue(),
                    ExceptionValidUntil: actionParameters.validUntil?.column?.GetValue(),
                    Decision: approve,
                });
            },
        });
    }
    /**
     * Opens the RulesViolationsActionComponent there the user can set the reason and/or standard reason
     * and the ExceptionValidUntil in the approve contest.
     * @param config the configuration for the sidesheet (title) and the corresponding rules violations data
     */
    async editAction(config) {
        const result = await this.sidesheet
            .open(RulesViolationsActionComponent, {
            title: await this.translate.get(config.title).toPromise(),
            subTitle: config.data.rulesViolationsApprovals.length == 1 ? config.data.rulesViolationsApprovals[0].GetEntity().GetDisplay() : '',
            panelClass: 'imx-sidesheet',
            padding: '0',
            width: calculateSidesheetWidth(600, 0.4),
            testId: `rulesvioalations-action-sidesheet-${config.data.approve ? 'approve' : 'deny'}`,
            data: config.data,
        })
            .afterClosed()
            .toPromise();
        if (result) {
            if (this.busyService.overlayRefs.length === 0) {
                this.busyService.show();
            }
            let success;
            try {
                for (const rulesViolation of config.data.rulesViolationsApprovals) {
                    await config.apply(rulesViolation);
                }
                success = true;
                await this.userService.reloadPendingItems();
            }
            finally {
                this.busyService.hide();
            }
            if (success) {
                this.snackBar.open(config.getMessage ? config.getMessage() : { key: config.message, parameters: [config.data.rulesViolationsApprovals.length] });
                this.applied.next();
            }
        }
        else {
            this.snackBar.open({ key: '#LDS#You have canceled the action.' });
        }
    }
    /**
     * Approve or deny the rules violation
     * @param ruleViolationToApprove The rules violation
     * @param input reason and/or standard reason
     */
    async postDecision(ruleViolationToApprove, input) {
        return this.cplClient.client.portal_rules_violations_post(ruleViolationToApprove.UID_Person.value, ruleViolationToApprove.UID_NonCompliance.value, input);
    }
    /**
     * Creates a Cdr-Editor for the reason.
     */
    createCdrReason(metadata = {}) {
        return new BaseCdr(this.entityService.createLocalEntityColumn({
            ColumnName: 'ReasonHead',
            Type: ValType.Text,
            IsMultiLine: true,
            MinLen: metadata.mandatory ? 1 : 0,
        }), metadata.display || '#LDS#Reason for your decision');
    }
    /**
     * Creates a Cdr-Editor for the ExceptionValidUntil value.
     */
    createCdrValidUntil() {
        const schema = this.cplClient.typedClient.PortalRulesViolations.GetSchema();
        const minDateUntil = new Date();
        minDateUntil.setDate(minDateUntil.getDate() + 1);
        const validUntilColumn = this.entityService.createLocalEntityColumn({
            ColumnName: schema.Columns.ExceptionValidUntil.ColumnName,
            Type: schema.Columns.ExceptionValidUntil.Type,
            IsMultiLine: schema.Columns.ExceptionValidUntil.IsMultiLine,
            MinLen: schema.Columns.ExceptionValidUntil.MinLen,
            Display: schema.Columns.ExceptionValidUntil.Display,
        }, undefined, { ValueConstraint: { MinValue: minDateUntil } });
        return new BaseCdr(validUntilColumn);
    }
    static ɵfac = function RulesViolationsActionService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesViolationsActionService)(i0.ɵɵinject(i2.JustificationService), i0.ɵɵinject(ApiService), i0.ɵɵinject(i3$1.EuiSidesheetService), i0.ɵɵinject(i3$1.EuiLoadingService), i0.ɵɵinject(i4.TranslateService), i0.ɵɵinject(i2$1.SnackBarService), i0.ɵɵinject(i2$1.EntityService), i0.ɵɵinject(i2.UserModelService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RulesViolationsActionService, factory: RulesViolationsActionService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsActionService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i2.JustificationService }, { type: ApiService }, { type: i3$1.EuiSidesheetService }, { type: i3$1.EuiLoadingService }, { type: i4.TranslateService }, { type: i2$1.SnackBarService }, { type: i2$1.EntityService }, { type: i2.UserModelService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class MitigatingControlsPersonService {
    apiService;
    constructor(apiService) {
        this.apiService = apiService;
    }
    get mitigationSchema() {
        return this.apiService.typedClient.PortalPersonMitigatingcontrols.GetSchema();
    }
    async getControls(uidPerson, uidNonCompliance) {
        return this.apiService.typedClient.PortalPersonMitigatingcontrols.Get(uidPerson, uidNonCompliance);
    }
    createControl(uidPerson, uidNonCompliance) {
        const newMControl = this.apiService.typedClient.PortalPersonMitigatingcontrols.createEntity({
            Columns: {
                UID_NonCompliance: { Value: uidNonCompliance },
                UID_Person: { Value: uidPerson },
                IsInActive: { Value: false },
            },
        });
        return new PersonMitigatingControls(true, newMControl);
    }
    async postControl(uidPerson, uidNonCompliance, mControl) {
        await this.apiService.typedClient.PortalPersonMitigatingcontrols.Post(uidPerson, uidNonCompliance, mControl);
    }
    async postControlRequest(uidPerson, uidNonCompliance, uidPersonWantsOrg, uidMitigatinControl) {
        const inter = (await this.apiService.typedClient.PortalPersonMitigatingcontrolsInteractive.Get(uidPerson, uidNonCompliance)).Data[0];
        await inter.UID_PersonWantsOrg.Column.PutValue(uidPersonWantsOrg);
        await inter.UID_MitigatingControl.Column.PutValue(uidMitigatinControl);
        await this.apiService.client.portal_person_mitigatingcontrols_interactive_forrequest_get(uidPerson, uidNonCompliance, inter.InteractiveEntityStateData.EntityId || '', { keys: inter.InteractiveEntityStateData.Keys, state: inter.InteractiveEntityStateData.State || '' });
    }
    async deleteControl(mControl) {
        await mControl.GetEntity().MarkForDeletion();
        await mControl.GetEntity().Commit();
    }
    async getCandidates(uid, uidNonCompliance, data, parameter) {
        return this.apiService.client.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(uid, uidNonCompliance, data, parameter);
    }
    static ɵfac = function MitigatingControlsPersonService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlsPersonService)(i0.ɵɵinject(ApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: MitigatingControlsPersonService, factory: MitigatingControlsPersonService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsPersonService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MitigatingControlsPersonComponent_ng_container_9_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "mat-card", 5)(2, "imx-mitigating-control-container", 6);
    i0.ɵɵlistener("controlsRequested", function MitigatingControlsPersonComponent_ng_container_9_Template_imx_mitigating_control_container_controlsRequested_2_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onCreateControl()); })("controlDeleted", function MitigatingControlsPersonComponent_ng_container_9_Template_imx_mitigating_control_container_controlDeleted_2_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onDelete($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("mControls", ctx_r1.mControls)("mitigatingCaption", ctx_r1.mitigatingCaption)("formArray", ctx_r1.formArray)("options", ctx_r1.options);
} }
function MitigatingControlsPersonComponent_mat_card_10_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 11);
    i0.ɵɵlistener("click", function MitigatingControlsPersonComponent_mat_card_10_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onCreateControl()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Assign mitigating controls"), " ");
} }
function MitigatingControlsPersonComponent_mat_card_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card", 7)(1, "div", 8);
    i0.ɵɵelement(2, "eui-icon", 9);
    i0.ɵɵelementStart(3, "p");
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(6, MitigatingControlsPersonComponent_mat_card_10_button_6_Template, 3, 3, "button", 10);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(5, 2, ctx_r1.options.length > 0 ? "#LDS#There are currently no mitigating controls assigned to this rule violation." : "#LDS#There are currently no mitigating controls that can be assigned to this rule violation."), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.options.length > 0);
} }
function MitigatingControlsPersonComponent_mat_card_11_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 12)(1, "button", 13);
    i0.ɵɵlistener("click", function MitigatingControlsPersonComponent_mat_card_11_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onSave()); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", ctx_r1.notSaveable);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Save"), " ");
} }
class MitigatingControlsPersonComponent {
    mControlService;
    formBuilder;
    cd;
    busyService;
    snackbarService;
    settingService;
    confirmationService;
    uidPerson;
    uidNonCompliance;
    sidesheetRef;
    closeOnSave;
    isMControlPerViolation;
    subscriptions$ = [];
    formGroup;
    options = [];
    mControls = [];
    mControlsToDelete = [];
    mitigatingCaption;
    constructor(mControlService, formBuilder, cd, busyService, snackbarService, settingService, confirmationService) {
        this.mControlService = mControlService;
        this.formBuilder = formBuilder;
        this.cd = cd;
        this.busyService = busyService;
        this.snackbarService = snackbarService;
        this.settingService = settingService;
        this.confirmationService = confirmationService;
        this.mitigatingCaption = mControlService.mitigationSchema.Columns.UID_MitigatingControl.Display || '';
        this.formGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    get formArray() {
        return this.formGroup.get('formArray');
    }
    get notSaveable() {
        if (this.mControlsToDelete.length !== 0) {
            this.formGroup.markAsDirty();
        }
        if (!this.formGroup.dirty || !this.formGroup.valid) {
            return true;
        }
        return (this.mControls.length > 0 &&
            this.mControls.every((ctrl) => {
                return !ctrl.editable || ctrl.UID_MitigatingControl.value === null || ctrl.UID_MitigatingControl.value === '';
            }) &&
            this.mControlsToDelete.length === 0);
    }
    get isDirty() {
        return this.formGroup.dirty || this.mControlsToDelete.length > 0;
    }
    async ngOnInit() {
        this.subscriptions$.push(this.sidesheetRef.closeClicked().subscribe(async () => {
            if (!this.isDirty || (await this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close();
            }
        }));
        await this.loadMitigatingControls();
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
    async onSelectionChange(mcontrol, value) {
        mcontrol.UID_MitigatingControl.value = value;
        this.formArray.updateValueAndValidity();
        this.cd.detectChanges();
        return;
    }
    onOpenChange(isopen, mControl) {
        if (!isopen) {
            mControl.formControl.updateValueAndValidity({ onlySelf: true });
        }
    }
    getMControlId(mControl) {
        return mControl.GetEntity().GetColumn('UID_MitigatingControl').GetValue();
    }
    async onCreateControl() {
        const mControl = this.mControlService.createControl(this.uidPerson, this.uidNonCompliance);
        this.mControls.push(mControl);
        this.formArray.push(mControl.formControl);
        mControl.formControl.setValidators([
            Validators.required,
            (control) => (this.isDuplicate(control) ? { duplicated: true } : null),
        ]);
        this.formGroup.markAsDirty();
        this.cd.detectChanges();
    }
    onDelete(mControl) {
        if (mControl instanceof PersonMitigatingControls) {
            this.mControlsToDelete.push(mControl);
        }
    }
    async onSave() {
        const overlay = this.busyService.show();
        try {
            await this.handleSave();
        }
        finally {
            this.busyService.hide(overlay);
            this.snackbarService.open({
                key: '#LDS#The mitigating controls have been successfully saved.',
            });
            if (this.closeOnSave) {
                this.sidesheetRef.close();
            }
        }
    }
    async handleSave() {
        for (const ctrl of this.mControlsToDelete) {
            await this.mControlService.deleteControl(ctrl);
        }
        for (const ctrl of this.mControls.filter((elem) => elem.editable)) {
            await this.mControlService.postControl(this.uidPerson, this.uidNonCompliance, ctrl);
        }
        if (!this.closeOnSave) {
            this.resetForm();
        }
    }
    async resetForm() {
        // Since we must handle change detection manually, overwrite formgroup and get read-only mcontrols
        this.formGroup = new UntypedFormGroup({ formArray: this.formBuilder.array([]) });
        this.mControlsToDelete = [];
        await this.loadMitigatingControls();
        this.cd.detectChanges();
    }
    async loadMitigatingControls() {
        if (!this.isMControlPerViolation) {
            this.mControls = [];
            return;
        }
        const overlay = this.busyService.show();
        try {
            //reload
            const data = await this.mControlService.getControls(this.uidPerson, this.uidNonCompliance);
            this.mControls = data.Data.map((elem) => new PersonMitigatingControls(false, elem));
            this.mControls.forEach((elem) => this.formArray.push(elem.formControl));
            await this.initOptions();
        }
        finally {
            this.busyService.hide(overlay);
        }
    }
    isDuplicate(actrl) {
        const test = this.mControls.findIndex((ctrl) => ctrl.formControl != actrl && ctrl?.UID_MitigatingControl.value === actrl.value) !== -1;
        return test;
    }
    async initOptions() {
        const optionCandidates = await this.mControlService.getCandidates(this.uidPerson, this.uidNonCompliance, {}, {
            PageSize: this.settingService.PageSizeForAllElements,
        });
        this.options =
            optionCandidates.Entities?.map((elem) => ({ display: elem.Display || '', value: elem?.Keys?.[0] || '' })) || [];
    }
    static ɵfac = function MitigatingControlsPersonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlsPersonComponent)(i0.ɵɵdirectiveInject(MitigatingControlsPersonService), i0.ɵɵdirectiveInject(i2$2.UntypedFormBuilder), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2$1.SnackBarService), i0.ɵɵdirectiveInject(i2$1.SettingsService), i0.ɵɵdirectiveInject(i2$1.ConfirmationService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsPersonComponent, selectors: [["imx-mitigating-controls-person"]], inputs: { uidPerson: "uidPerson", uidNonCompliance: "uidNonCompliance", sidesheetRef: "sidesheetRef", closeOnSave: "closeOnSave", isMControlPerViolation: "isMControlPerViolation" }, decls: 12, vars: 10, consts: [["eui-sidesheet-content", "", 1, "control-container"], ["type", "info", 3, "colored"], [4, "ngIf"], ["class", "imx-no-mitigating-controls", 4, "ngIf"], ["eui-sidesheet-actions", "", "class", "imx-sidesheet-actions", 4, "ngIf"], [1, "imx-mitigating-control-content"], [3, "controlsRequested", "controlDeleted", "mControls", "mitigatingCaption", "formArray", "options"], [1, "imx-no-mitigating-controls"], [1, "imx-no-results"], ["icon", "table"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-person-button-add", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-person-button-add", 3, "click"], ["eui-sidesheet-actions", "", 1, "imx-sidesheet-actions"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-person-button-save", 1, "imx-margin-left-auto", 3, "click", "disabled"]], template: function MitigatingControlsPersonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "eui-alert", 1)(2, "eui-alert-header");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "eui-alert-content")(6, "p");
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd()()();
            i0.ɵɵtemplate(9, MitigatingControlsPersonComponent_ng_container_9_Template, 3, 4, "ng-container", 2)(10, MitigatingControlsPersonComponent_mat_card_10_Template, 7, 4, "mat-card", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(11, MitigatingControlsPersonComponent_mat_card_11_Template, 4, 4, "mat-card", 4);
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("colored", true);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 6, "#LDS#Heading Mitigating Controls Can Be Assigned Individually"));
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 8, "#LDS#Here you can assign mitigating controls to the rule violation. NOTE: If no mitigating controls have been assigned to the violated compliance rule, you cannot assign any mitigating controls to the rule violation either."), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.mControls != null && ctx.mControls.length > 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isMControlPerViolation && ctx.options.length > 0);
        } }, dependencies: [i5.NgIf, i3$1.EuiAlertComponent, i3$1.EuiAlertContentDirective, i3$1.EuiAlertHeaderDirective, i3$1.EuiIconComponent, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i6.MatButton, i3$2.MatCard, MitigatingControlContainerComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;padding:16px 20px}[_nghost-%COMP%]   .control-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}[_nghost-%COMP%]   .imx-mitigating-control.bordered[_ngcontent-%COMP%]{border-bottom:1px solid #797e80}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   eui-select[_ngcontent-%COMP%]{flex:1 1 auto}[_nghost-%COMP%]   .imx-mitigating-control-properties[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;margin-right:15px;gap:15px}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]   .content[_ngcontent-%COMP%]{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .imx-delete-button[_ngcontent-%COMP%]{margin-top:15px;align-self:flex-start}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0;justify-self:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#797e80}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .bordered[_ngcontent-%COMP%]{border-bottom:1px solid #dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   .bordered[_ngcontent-%COMP%]{border-bottom:1px solid #ffffff}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsPersonComponent, [{
        type: Component,
        args: [{ selector: 'imx-mitigating-controls-person', template: "<div class=\"control-container\" eui-sidesheet-content>\n  <eui-alert type=\"info\" [colored]=\"true\">\n    <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Can Be Assigned Individually' | translate }}</eui-alert-header>\n    <eui-alert-content>\n      <p>\n        {{\n          '#LDS#Here you can assign mitigating controls to the rule violation. NOTE: If no mitigating controls have been assigned to the violated compliance rule, you cannot assign any mitigating controls to the rule violation either.'\n            | translate\n        }}\n      </p>\n    </eui-alert-content>\n  </eui-alert>\n  <ng-container *ngIf=\"mControls != null && mControls.length > 0\">\n    <mat-card class=\"imx-mitigating-control-content\">\n      <imx-mitigating-control-container\n        [mControls]=\"mControls\"\n        [mitigatingCaption]=\"mitigatingCaption\"\n        [formArray]=\"formArray\"\n        [options]=\"options\"\n        (controlsRequested)=\"onCreateControl()\"\n        (controlDeleted)=\"onDelete($event)\"\n      ></imx-mitigating-control-container>\n    </mat-card>\n  </ng-container>\n\n  <mat-card class=\"imx-no-mitigating-controls\" *ngIf=\"!mControls || mControls.length == 0\">\n    <div class=\"imx-no-results\">\n      <eui-icon icon=\"table\"></eui-icon>\n      <p>\n        {{\n          (options.length > 0\n            ? '#LDS#There are currently no mitigating controls assigned to this rule violation.'\n            : '#LDS#There are currently no mitigating controls that can be assigned to this rule violation.'\n          ) | translate\n        }}\n      </p>\n      <button\n        *ngIf=\"options.length > 0\"\n        mat-stroked-button\n        color=\"primary\"\n        data-imx-identifier=\"mitigating-controls-person-button-add\"\n        (click)=\"onCreateControl()\"\n      >\n        {{ '#LDS#Assign mitigating controls' | translate }}\n      </button>\n    </div>\n  </mat-card>\n</div>\n\n<mat-card eui-sidesheet-actions *ngIf=\"isMControlPerViolation && options.length > 0\" class=\"imx-sidesheet-actions\">\n  <button\n    mat-flat-button\n    color=\"primary\"\n    (click)=\"onSave()\"\n    [disabled]=\"notSaveable\"\n    data-imx-identifier=\"mitigating-controls-person-button-save\"\n    class=\"imx-margin-left-auto\"\n  >\n    {{ '#LDS#Save' | translate }}\n  </button>\n</mat-card>\n", styles: [":host{height:100%;display:flex;flex-direction:column;justify-content:space-between}:host .eui-sidesheet-actions{display:flex;justify-content:flex-end;padding:16px 20px}:host .control-container{display:flex;flex-direction:column;overflow:auto}:host .imx-mitigating-control{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}:host .imx-mitigating-control.bordered{border-bottom:1px solid #797e80}:host .imx-mitigating-control eui-select{flex:1 1 auto}:host .imx-mitigating-control-properties{display:flex;flex-direction:column;width:100%;margin-right:15px;gap:15px}:host .imx-mitigating-control-content{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:auto}:host .imx-mitigating-control-content .content{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}:host .imx-mitigating-control .imx-delete-button{margin-top:15px;align-self:flex-start}:host .imx-no-mitigating-controls{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}:host .imx-no-results{text-align:center;margin:20px 0;justify-self:center}:host .imx-no-results p{margin:0;font-size:18px}:host .imx-no-results button{margin-top:10px}:host .imx-no-results p{color:#797e80}:host .imx-no-mitigating-controls{color:#797e80}.eui-dark-theme :host .imx-no-results p{color:#dfe4e6}.eui-dark-theme :host .imx-no-mitigating-controls{color:#dfe4e6}.eui-dark-theme :host .imx-mitigating-control .bordered{border-bottom:1px solid #dfe4e6}.eui-contrast-theme :host .imx-data-no-results p{color:#fff}.eui-contrast-theme :host .imx-no-mitigating-controls{color:#fff}.eui-contrast-theme :host .imx-mitigating-control .bordered{border-bottom:1px solid #ffffff}\n"] }]
    }], () => [{ type: MitigatingControlsPersonService }, { type: i2$2.UntypedFormBuilder }, { type: i0.ChangeDetectorRef }, { type: i3$1.EuiLoadingService }, { type: i2$1.SnackBarService }, { type: i2$1.SettingsService }, { type: i2$1.ConfirmationService }], { uidPerson: [{
            type: Input
        }], uidNonCompliance: [{
            type: Input
        }], sidesheetRef: [{
            type: Input
        }], closeOnSave: [{
            type: Input
        }], isMControlPerViolation: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MitigatingControlsPersonComponent, { className: "MitigatingControlsPersonComponent", filePath: "lib\\rules-violations\\mitigating-controls-person\\mitigating-controls-person.component.ts", lineNumber: 42 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$1 = a0 => ({ data: a0 });
function RulesViolationsDetailsComponent_eui_badge_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 10);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("color", ctx_r0.data.selectedRulesViolation == null ? null : ctx_r0.data.selectedRulesViolation.stateBadge == null ? null : ctx_r0.data.selectedRulesViolation.stateBadge.color);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.data.selectedRulesViolation == null ? null : ctx_r0.data.selectedRulesViolation.stateBadge == null ? null : ctx_r0.data.selectedRulesViolation.stateBadge.caption, " ");
} }
function RulesViolationsDetailsComponent_imx_cdr_editor_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 11);
} if (rf & 2) {
    const cdr_r2 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r2);
} }
function RulesViolationsDetailsComponent_imx_cdr_editor_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 11);
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r3);
} }
function RulesViolationsDetailsComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 12)(1, "button", 13);
    i0.ɵɵlistener("click", function RulesViolationsDetailsComponent_div_10_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.resolve()); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 14);
    i0.ɵɵlistener("click", function RulesViolationsDetailsComponent_div_10_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.deny()); });
    i0.ɵɵelement(5, "eui-icon", 15);
    i0.ɵɵtext(6);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "button", 16);
    i0.ɵɵlistener("click", function RulesViolationsDetailsComponent_div_10_Template_button_click_8_listener() { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.approve()); });
    i0.ɵɵelement(9, "eui-icon", 17);
    i0.ɵɵtext(10);
    i0.ɵɵpipe(11, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 3, "#LDS#Resolve rule violation"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 5, "#LDS#Deny exception"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(11, 7, "#LDS#Grant exception"), " ");
} }
function RulesViolationsDetailsComponent_mat_tab_11_ng_template_1_eui_icon_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 22);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
} }
function RulesViolationsDetailsComponent_mat_tab_11_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 20);
    i0.ɵɵtext(1, "#LDS#Heading Mitigating Controls");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(2, RulesViolationsDetailsComponent_mat_tab_11_ng_template_1_eui_icon_2_Template, 2, 3, "eui-icon", 21);
} if (rf & 2) {
    i0.ɵɵnextContext();
    const mitig_r5 = i0.ɵɵreference(3);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", mitig_r5 == null ? null : mitig_r5.isDirty);
} }
function RulesViolationsDetailsComponent_mat_tab_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab");
    i0.ɵɵtemplate(1, RulesViolationsDetailsComponent_mat_tab_11_ng_template_1_Template, 3, 1, "ng-template", 18);
    i0.ɵɵelement(2, "imx-mitigating-controls-person", 19, 0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("isMControlPerViolation", ctx_r0.data.isMControlPerViolation)("uidPerson", ctx_r0.uidPerson)("closeOnSave", false)("uidNonCompliance", ctx_r0.uidNonCompliance)("sidesheetRef", ctx_r0.sidesheetRef);
} }
function RulesViolationsDetailsComponent_mat_tab_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab", 2);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵelement(2, "imx-ext", 23);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 2, "#LDS#Heading SAP Functions"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("properties", i0.ɵɵpureFunction1(4, _c0$1, ctx_r0.data));
} }
class baseComplienceClass {
    data;
}
/**
 * A sidesheet component to show some information about the selected rules violation.
 */
class RulesViolationsDetailsComponent {
    data;
    sidesheetRef;
    actionService;
    extService;
    translateService;
    matTabGroup;
    cdrList = [];
    uidPerson;
    uidNonCompliance;
    uidCompliance;
    ruleInfoCdrList = [];
    subscriptions$ = [];
    constructor(data, sidesheetRef, actionService, extService, translateService) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.actionService = actionService;
        this.extService = extService;
        this.translateService = translateService;
        this.uidPerson = data.selectedRulesViolation.GetEntity().GetColumn('UID_Person').GetValue();
        this.uidNonCompliance = data.selectedRulesViolation.GetEntity().GetColumn('UID_NonCompliance').GetValue();
        this.cdrList = data.selectedRulesViolation.propertyInfo;
        if (this.data.complianceRule)
            this.ruleInfoCdrList.push(new BaseCdr(this.data.complianceRule.Description.Column, this.translateService.instant('#LDS#Rule description')), new BaseCdr(this.data.complianceRule.RuleNumber.Column));
    }
    ngOnInit() {
        this.subscriptions$.push(this.sidesheetRef.componentInstance?.onOpen().subscribe(() => {
            // Recalculates header
            this.matTabGroup.updatePagination();
        }));
    }
    /**
     * Opens the Approve-Sidesheet for the current selected rule violations and closes the sidesheet afterwards.
     */
    async approve() {
        await this.actionService.approve([this.data.selectedRulesViolation]);
        return this.sidesheetRef.close(true);
    }
    /**
     * Opens the Deny-Sidesheet for the current selected rule violations and closes the sidesheet afterwards.
     */
    async deny() {
        await this.actionService.deny([this.data.selectedRulesViolation]);
        return this.sidesheetRef.close(true);
    }
    async resolve() {
        await this.actionService.resolve(this.data.selectedRulesViolation);
        return this.sidesheetRef.close(true);
    }
    get showDynamicTab() {
        return this.extService.Registry['RuleViolationsTab'] && this.extService.Registry['RuleViolationsTab'].length > 0;
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub?.unsubscribe());
    }
    static ɵfac = function RulesViolationsDetailsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesViolationsDetailsComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(RulesViolationsActionService), i0.ɵɵdirectiveInject(i2$1.ExtService), i0.ɵɵdirectiveInject(i4.TranslateService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsDetailsComponent, selectors: [["imx-rules-violations-details"]], viewQuery: function RulesViolationsDetailsComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(MatTabGroup, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.matTabGroup = _t.first);
        } }, decls: 13, vars: 10, consts: [["mitig", ""], ["mat-stretch-tabs", "false"], [3, "label"], ["eui-sidesheet-content", "", 1, "imx-tab-container"], [1, "imx-state-caption"], ["class", "imx-margin-bottom-20", 3, "color", 4, "ngIf"], [3, "cdr", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", "", 4, "ngIf"], [4, "ngIf"], [3, "label", 4, "ngIf"], [1, "imx-margin-bottom-20", 3, "color"], [3, "cdr"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "rules-violations-table-row-button-resolve", 3, "click"], ["mat-flat-button", "", "color", "warn", "data-imx-identifier", "rules-violations-table-row-button-deny", 3, "click"], ["icon", "ignore"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "rules-violations-table-row-button-approve", 3, "click"], ["icon", "check"], ["mat-tab-label", ""], [3, "isMControlPerViolation", "uidPerson", "closeOnSave", "uidNonCompliance", "sidesheetRef"], ["translate", ""], ["icon", "save", "class", "imx-dirty-indicator", "size", "s", 4, "ngIf"], ["icon", "save", "size", "s", 1, "imx-dirty-indicator"], ["id", "RuleViolationsTab", 3, "properties"]], template: function RulesViolationsDetailsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group", 1)(1, "mat-tab", 2);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementStart(3, "div", 3)(4, "mat-card")(5, "div", 4);
            i0.ɵɵtext(6);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, RulesViolationsDetailsComponent_eui_badge_7_Template, 2, 2, "eui-badge", 5)(8, RulesViolationsDetailsComponent_imx_cdr_editor_8_Template, 1, 1, "imx-cdr-editor", 6)(9, RulesViolationsDetailsComponent_imx_cdr_editor_9_Template, 1, 1, "imx-cdr-editor", 6);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(10, RulesViolationsDetailsComponent_div_10_Template, 12, 9, "div", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(11, RulesViolationsDetailsComponent_mat_tab_11_Template, 4, 5, "mat-tab", 8)(12, RulesViolationsDetailsComponent_mat_tab_12_Template, 3, 6, "mat-tab", 9);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            let tmp_1_0;
            i0.ɵɵadvance();
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 8, "#LDS#Heading Information"));
            i0.ɵɵadvance(5);
            i0.ɵɵtextInterpolate1(" ", ctx.data.selectedRulesViolation == null ? null : ctx.data.selectedRulesViolation.State == null ? null : (tmp_1_0 = ctx.data.selectedRulesViolation.State.GetMetadata()) == null ? null : tmp_1_0.GetDisplay(), " ");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.selectedRulesViolation == null ? null : ctx.data.selectedRulesViolation.State == null ? null : ctx.data.selectedRulesViolation.State.value);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.ruleInfoCdrList);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !!(ctx.data.selectedRulesViolation == null ? null : ctx.data.selectedRulesViolation.CanUserDecide == null ? null : ctx.data.selectedRulesViolation.CanUserDecide.value));
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data.isMControlPerViolation);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showDynamicTab);
        } }, dependencies: [i2$1.CdrEditorComponent, i5.NgForOf, i5.NgIf, i3$1.EuiBadgeComponent, i3$1.EuiIconComponent, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i6.MatButton, i3$2.MatCard, i8$2.MatTabLabel, i8$2.MatTab, i8$2.MatTabGroup, i2$1.ExtComponent, i4.TranslateDirective, MitigatingControlsPersonComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{font-size:12px;padding-bottom:5px}[_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{margin-left:5px}[_nghost-%COMP%]   imx-ext[_ngcontent-%COMP%]{height:100%}[_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{color:#e36a00}[_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{color:#919799}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsDetailsComponent, [{
        type: Component,
        args: [{ selector: 'imx-rules-violations-details', template: "<mat-tab-group mat-stretch-tabs=\"false\">\n  <mat-tab [label]=\"'#LDS#Heading Information' | translate\">\n    <div class=\"imx-tab-container\" eui-sidesheet-content>\n      <mat-card>\n        <div class=\"imx-state-caption\">\n          {{ data.selectedRulesViolation?.State?.GetMetadata()?.GetDisplay() }}\n        </div>\n        <eui-badge\n          class=\"imx-margin-bottom-20\"\n          [color]=\"data.selectedRulesViolation?.stateBadge?.color\"\n          *ngIf=\"data.selectedRulesViolation?.State?.value\"\n        >\n          {{ data.selectedRulesViolation?.stateBadge?.caption }}\n        </eui-badge>\n        <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\n        <imx-cdr-editor *ngFor=\"let cdr of ruleInfoCdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\n      </mat-card>\n    </div>\n    <div eui-sidesheet-actions *ngIf=\"!!data.selectedRulesViolation?.CanUserDecide?.value\">\n      <button mat-stroked-button (click)=\"resolve()\" data-imx-identifier=\"rules-violations-table-row-button-resolve\">\n        {{ '#LDS#Resolve rule violation' | translate }}\n      </button>\n      <button mat-flat-button color=\"warn\" (click)=\"deny()\" data-imx-identifier=\"rules-violations-table-row-button-deny\">\n        <eui-icon icon=\"ignore\"></eui-icon>\n        {{ '#LDS#Deny exception' | translate }}\n      </button>\n      <button mat-flat-button color=\"primary\" (click)=\"approve()\" data-imx-identifier=\"rules-violations-table-row-button-approve\">\n        <eui-icon icon=\"check\"></eui-icon>\n        {{ '#LDS#Grant exception' | translate }}\n      </button>\n    </div>\n  </mat-tab>\n  <mat-tab *ngIf=\"data.isMControlPerViolation\">\n    <ng-template mat-tab-label>\n      <span translate>#LDS#Heading Mitigating Controls</span>\n      <eui-icon\n        *ngIf=\"mitig?.isDirty\"\n        icon=\"save\"\n        class=\"imx-dirty-indicator\"\n        size=\"s\"\n        [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"\n      ></eui-icon>\n    </ng-template>\n    <imx-mitigating-controls-person\n      #mitig\n      [isMControlPerViolation]=\"data.isMControlPerViolation\"\n      [uidPerson]=\"uidPerson\"\n      [closeOnSave]=\"false\"\n      [uidNonCompliance]=\"uidNonCompliance\"\n      [sidesheetRef]=\"sidesheetRef\"\n    ></imx-mitigating-controls-person>\n  </mat-tab>\n  <mat-tab *ngIf=\"showDynamicTab\" [label]=\"'#LDS#Heading SAP Functions' | translate\">\n    <imx-ext id=\"RuleViolationsTab\" [properties]=\"{ data: data }\"></imx-ext>\n  </mat-tab>\n</mat-tab-group>\n", styles: [":host .imx-state-caption{font-size:12px;padding-bottom:5px}:host .imx-dirty-indicator{margin-left:5px}:host imx-ext{height:100%}:host .imx-dirty-indicator{color:#e36a00}:host .imx-state-caption{color:#919799}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i3$1.EuiSidesheetRef }, { type: RulesViolationsActionService }, { type: i2$1.ExtService }, { type: i4.TranslateService }], { matTabGroup: [{
            type: ViewChild,
            args: [MatTabGroup]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RulesViolationsDetailsComponent, { className: "RulesViolationsDetailsComponent", filePath: "lib\\rules-violations\\rules-violations-details\\rules-violations-details.component.ts", lineNumber: 54 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Class thats extends the {@link PortalRulesViolations} with some additional properties that are needed for
 * the components in the approval context.
 */
class RulesViolationsApproval extends PortalRulesViolations {
    baseObject;
    hasRiskIndex;
    translate;
    /**
     * The color and the caption depending on the value of the state of a {@link PortalRulesViolations}.
     */
    get stateBadge() {
        return {
            color: this.stateBadgeColor,
            caption: this.stateCaption,
        };
    }
    /**
     * The property list depending on the value of the state of a {@link PortalRulesViolations}.
     */
    propertyInfo;
    stateBadgeColor;
    stateCaption;
    constructor(baseObject, hasRiskIndex, translate) {
        super(baseObject.GetEntity());
        this.baseObject = baseObject;
        this.hasRiskIndex = hasRiskIndex;
        this.translate = translate;
        this.propertyInfo = this.initPropertyInfo();
        this.initStateBadge();
    }
    initPropertyInfo() {
        const properties = [this.UID_Person, this.UID_NonCompliance];
        if (this.hasRiskIndex) {
            properties.push([this.RiskIndexCalculated, this.RiskIndexReduced]);
        }
        if (this.State.value !== 'pending') {
            properties.push(this.DecisionDate, this.UID_PersonDecisionMade, this.DecisionReason, this.UID_QERJustification);
        }
        if (this.State.value === 'approved') {
            properties.push(this.ExceptionValidUntil);
        }
        return properties.filter((property) => property.value != null && property.value !== '').map((property) => new BaseCdr(property.Column));
    }
    async initStateBadge() {
        switch (this.State.value) {
            case 'approved':
                this.stateBadgeColor = 'green';
                this.stateCaption = await this.translate.get('#LDS#Exception granted').toPromise();
                break;
            case 'denied':
                this.stateBadgeColor = 'orange';
                this.stateCaption = await this.translate.get('#LDS#Exception denied').toPromise();
                break;
            default:
                this.stateBadgeColor = 'blue';
                this.stateCaption = await this.translate.get('#LDS#Approval decision pending').toPromise();
        }
    }
}

/**
 * Service that provides all rules violations, including schema, DataModel and GroupingInfo.
 */
class RulesViolationsService {
    cplClient;
    logger;
    busyService;
    translate;
    systemInfoService;
    busyIndicator;
    busyIndicatorCounter = 0;
    constructor(cplClient, logger, busyService, translate, systemInfoService) {
        this.cplClient = cplClient;
        this.logger = logger;
        this.busyService = busyService;
        this.translate = translate;
        this.systemInfoService = systemInfoService;
    }
    async featureConfig() {
        return this.cplClient.client.portal_compliance_config_get();
    }
    /**
     * Provides the schema of {@link PortalRulesViolations}.
     */
    get rulesViolationsApproveSchema() {
        return this.cplClient.typedClient.PortalRulesViolations.GetSchema();
    }
    /**
     * Provides the data model of {@link PortalRulesViolations}.
     */
    async getDataModel(filter) {
        const options = { filter };
        return this.cplClient.client.portal_rules_violations_datamodel_get(options);
    }
    /**
     * Provides the GroupInfo of {@link PortalRulesViolations}.
     */
    getGroupInfo(parameters = {}) {
        const { withProperties, OrderBy, search, ...params } = parameters;
        return this.cplClient.client.portal_rules_violations_group_get({
            ...params,
            withcount: true,
            approvable: true,
        });
    }
    /**
     * Retrieves all rule violations, that the current user can approve or deny.
     *
     * @returns a list of {@link PortalRulesViolations|PortalRulesViolationss}
     */
    async getRulesViolationsApprove(parameters, signal) {
        this.logger.debug(this, `Retrieving all rule violations to approve`);
        this.logger.trace('Navigation state', parameters);
        const collection = await this.cplClient.typedClient.PortalRulesViolations.Get({
            approvable: true,
            ...parameters,
        }, { signal });
        const hasRiskIndex = !!(await this.systemInfoService.get()).PreProps?.includes('RISKINDEX');
        return {
            tableName: collection.tableName,
            totalCount: collection.totalCount,
            Data: collection.Data.map((item) => new RulesViolationsApproval(item, hasRiskIndex, this.translate)),
        };
    }
    exportRulesViolations(signal) {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, navigationState, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_rules_violations_get({ ...navigationState, approvable: true, withProperties, PageSize, StartIndex: 0 }, { signal });
                }
                else {
                    method = factory.portal_rules_violations_get({ ...navigationState, approvable: true, withProperties }, { signal });
                }
                return new MethodDefinition(method);
            },
        };
    }
    /**
     * Shows the busy indicator.
     */
    handleOpenLoader() {
        if (this.busyIndicatorCounter === 0) {
            this.busyService.show();
        }
        this.busyIndicatorCounter++;
    }
    /**
     * Closes the busy indicator.
     */
    handleCloseLoader() {
        if (this.busyIndicatorCounter === 1) {
            this.busyService.hide();
        }
        this.busyIndicatorCounter--;
    }
    async getComplianceRuleByUId(rulesViolationsApproval) {
        const uidNonCompliance = rulesViolationsApproval.GetEntity().GetColumn('UID_NonCompliance').GetValue();
        const call = await this.cplClient.typedClient.PortalRules.Get({
            filter: [
                { ColumnName: 'UID_NonCompliance', CompareOp: CompareOperator.Equal, Type: FilterType.Compare, Value1: uidNonCompliance },
                { ColumnName: 'isWorkingcopy', CompareOp: CompareOperator.Equal, Type: FilterType.Compare, Value1: false },
            ],
        });
        return call.Data[0];
    }
    static ɵfac = function RulesViolationsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesViolationsService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i2$1.ClassloggerService), i0.ɵɵinject(i3$1.EuiLoadingService), i0.ɵɵinject(i4.TranslateService), i0.ɵɵinject(i2$1.SystemInfoService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RulesViolationsService, factory: RulesViolationsService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: ApiService }, { type: i2$1.ClassloggerService }, { type: i3$1.EuiLoadingService }, { type: i4.TranslateService }, { type: i2$1.SystemInfoService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0 = () => ["search", "filter", "groups"];
const _c1 = () => ["uid_compliancerule"];
class ViolationsPerRuleComponent {
    rulesViolationsService;
    translate;
    sidesheet;
    dataModelWrapper;
    dstWrapper;
    dstSettings;
    groupedData = {};
    entitySchema;
    uidRule;
    constructor(rulesViolationsService, translate, sidesheet) {
        this.rulesViolationsService = rulesViolationsService;
        this.translate = translate;
        this.sidesheet = sidesheet;
    }
    async ngOnInit() {
        this.entitySchema = this.rulesViolationsService.rulesViolationsApproveSchema;
        this.dataModelWrapper = {
            dataModel: await this.rulesViolationsService.getDataModel(),
            getGroupInfo: (parameters) => this.rulesViolationsService.getGroupInfo(parameters),
            groupingFilterOptions: ['state'],
        };
        this.dstWrapper = new DataSourceWrapper((state) => this.rulesViolationsService.getRulesViolationsApprove({ ...state, ...{ uid_compliancerule: this.uidRule, approvable: undefined } }), [
            this.entitySchema.Columns.UID_Person,
            this.entitySchema.Columns.State,
            this.entitySchema.Columns.RiskIndexCalculated,
            this.entitySchema.Columns.RiskIndexReduced,
        ], this.entitySchema, this.dataModelWrapper);
        await this.getData();
    }
    /**
     * Handles grouping changes with reload
     * @param groupKey The key of the group
     */
    async onGroupingChange(groupKey) {
        this.rulesViolationsService.handleOpenLoader();
        try {
            const groupedData = this.groupedData[groupKey];
            groupedData.data = await this.rulesViolationsService.getRulesViolationsApprove(groupedData.navigationState);
            groupedData.settings = {
                displayedColumns: this.dstSettings?.displayedColumns,
                dataModel: this.dstSettings?.dataModel,
                dataSource: groupedData.data,
                entitySchema: this.entitySchema,
                navigationState: groupedData.navigationState || {},
            };
        }
        finally {
            this.rulesViolationsService.handleCloseLoader();
        }
    }
    /**
     * Opens rules-violations-details sidesheet, where you can manage the selected rule.
     * @param rule The selected rule from the Rule Violations list
     */
    async showRulesViolationsDetail(entity) {
        this.rulesViolationsService.handleOpenLoader();
        const rule = entity;
        let complianceRule;
        let config;
        try {
            complianceRule = await this.rulesViolationsService.getComplianceRuleByUId(rule);
            config = await this.rulesViolationsService.featureConfig();
        }
        finally {
            this.rulesViolationsService.handleCloseLoader();
        }
        await this.sidesheet
            .open(RulesViolationsDetailsComponent, {
            title: await this.translate.get('#LDS#Heading View Rule Violation Details').toPromise(),
            subTitle: rule.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(1000),
            testId: 'rules-violations-informations-sidesheet',
            data: {
                selectedRulesViolation: rule,
                isMControlPerViolation: config.MitigatingControlsPerViolation,
                complianceRule,
            },
        })
            .afterClosed()
            .toPromise();
    }
    /**
     * Loads the dstSettings with load parameters
     * @param parameter Load parameter
     */
    async getData(parameter) {
        this.rulesViolationsService.handleOpenLoader();
        try {
            this.dstSettings = await this.dstWrapper.getDstSettings(parameter);
        }
        finally {
            this.rulesViolationsService.handleCloseLoader();
        }
    }
    static ɵfac = function ViolationsPerRuleComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ViolationsPerRuleComponent)(i0.ɵɵdirectiveInject(RulesViolationsService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ViolationsPerRuleComponent, selectors: [["imx-violations-per-rule"]], inputs: { uidRule: "uidRule" }, decls: 15, vars: 18, consts: [["dst", ""], ["dataTable", ""], [1, "mat-tab-content"], ["type", "info", 3, "condensed", "colored"], [1, "imx-card-fill"], ["data-imx-identifier", "violations-per-rule-dst", 3, "search", "navigationStateChanged", "options", "settings", "hiddenFilters"], [1, "imx-table-container"], ["mode", "manual", "data-imx-identifier", "violations-per-rule-datatable", 3, "highlightedEntityChanged", "groupDataChanged", "dst", "detailViewVisible", "groupData"], ["data-imx-identifier", "violations-per-rule-table-column-UidPerson", 3, "entityColumn"], ["data-imx-identifier", "violations-per-rule-table-column-state", 3, "entityColumn"], ["data-imx-identifier", "violations-per-rule-table-column-RiskIndexCalculated", 3, "entityColumn"], ["data-imx-identifier", "violations-per-rule-table-column-RiskIndexReduced", 3, "entityColumn"], ["data-imx-identifier", "violations-per-rule-paginator", 3, "dst"]], template: function ViolationsPerRuleComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 2)(1, "eui-alert", 3);
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-card", 4)(5, "imx-data-source-toolbar", 5, 0);
            i0.ɵɵlistener("search", function ViolationsPerRuleComponent_Template_imx_data_source_toolbar_search_5_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.getData({ search: $event })); })("navigationStateChanged", function ViolationsPerRuleComponent_Template_imx_data_source_toolbar_navigationStateChanged_5_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.getData($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div", 6)(8, "imx-data-table", 7, 1);
            i0.ɵɵlistener("highlightedEntityChanged", function ViolationsPerRuleComponent_Template_imx_data_table_highlightedEntityChanged_8_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.showRulesViolationsDetail($event)); })("groupDataChanged", function ViolationsPerRuleComponent_Template_imx_data_table_groupDataChanged_8_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onGroupingChange($event)); });
            i0.ɵɵelement(10, "imx-data-table-column", 8)(11, "imx-data-table-column", 9)(12, "imx-data-table-column", 10)(13, "imx-data-table-column", 11);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(14, "imx-data-source-paginator", 12);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            const dst_r2 = i0.ɵɵreference(6);
            i0.ɵɵadvance();
            i0.ɵɵproperty("condensed", true)("colored", true);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 14, "#LDS#Here you can get an overview of the violations of the compliance rule."), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("options", i0.ɵɵpureFunction0(16, _c0))("settings", ctx.dstSettings)("hiddenFilters", i0.ɵɵpureFunction0(17, _c1));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", dst_r2)("detailViewVisible", false)("groupData", ctx.groupedData);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_Person);
            i0.ɵɵadvance();
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.State);
            i0.ɵɵadvance();
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.RiskIndexCalculated);
            i0.ɵɵadvance();
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.RiskIndexReduced);
            i0.ɵɵadvance();
            i0.ɵɵproperty("dst", dst_r2);
        } }, dependencies: [i3$1.EuiAlertComponent, i2$1.DataTableComponent, i2$1.DataTableColumnComponent, i2$1.DataSourceToolbarComponent, i2$1.DataSourcePaginatorComponent, i3$2.MatCard, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ViolationsPerRuleComponent, [{
        type: Component,
        args: [{ selector: 'imx-violations-per-rule', template: "<div class=\"mat-tab-content\">\n  <eui-alert type=\"info\" [condensed]=\"true\" [colored]=\"true\">\n    {{ '#LDS#Here you can get an overview of the violations of the compliance rule.' | translate }}\n  </eui-alert>\n  <mat-card class=\"imx-card-fill\">\n    <imx-data-source-toolbar\n      #dst\n      [options]=\"['search', 'filter', 'groups']\"\n      [settings]=\"dstSettings\"\n      (search)=\"getData({ search: $event })\"\n      (navigationStateChanged)=\"getData($event)\"\n      [hiddenFilters]=\"['uid_compliancerule']\"\n      data-imx-identifier=\"violations-per-rule-dst\"\n    >\n    </imx-data-source-toolbar>\n    <div class=\"imx-table-container\">\n      <imx-data-table\n        #dataTable\n        [dst]=\"dst\"\n        [detailViewVisible]=\"false\"\n        mode=\"manual\"\n        [groupData]=\"groupedData\"\n        (highlightedEntityChanged)=\"showRulesViolationsDetail($event)\"\n        (groupDataChanged)=\"onGroupingChange($event)\"\n        data-imx-identifier=\"violations-per-rule-datatable\"\n      >\n        <imx-data-table-column\n          data-imx-identifier=\"violations-per-rule-table-column-UidPerson\"\n          [entityColumn]=\"entitySchema.Columns.UID_Person\"\n        >\n        </imx-data-table-column>\n        <imx-data-table-column\n          data-imx-identifier=\"violations-per-rule-table-column-state\"\n          [entityColumn]=\"entitySchema.Columns.State\"\n        ></imx-data-table-column>\n        <imx-data-table-column\n          [entityColumn]=\"entitySchema.Columns.RiskIndexCalculated\"\n          data-imx-identifier=\"violations-per-rule-table-column-RiskIndexCalculated\"\n        >\n        </imx-data-table-column>\n        <imx-data-table-column\n          [entityColumn]=\"entitySchema.Columns.RiskIndexReduced\"\n          data-imx-identifier=\"violations-per-rule-table-column-RiskIndexReduced\"\n        >\n        </imx-data-table-column>\n      </imx-data-table>\n      <imx-data-source-paginator data-imx-identifier=\"violations-per-rule-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\n    </div>\n  </mat-card>\n</div>\n", styles: [":host{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}\n"] }]
    }], () => [{ type: RulesViolationsService }, { type: i4.TranslateService }, { type: i3$1.EuiSidesheetService }], { uidRule: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ViolationsPerRuleComponent, { className: "ViolationsPerRuleComponent", filePath: "lib\\rules\\rules-sidesheet\\violations-per-rule\\violations-per-rule.component.ts", lineNumber: 43 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesSidesheetComponent_ng_template_3_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-cdr-editor", 8);
} if (rf & 2) {
    const cdr_r1 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r1);
} }
function RulesSidesheetComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 4)(1, "mat-card");
    i0.ɵɵtemplate(2, RulesSidesheetComponent_ng_template_3_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 5);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(3, "div", 6)(4, "button", 7);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r1.cdrList);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("euiDownload", ctx_r1.reportDownload);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 3, "#LDS#Download report"), " ");
} }
function RulesSidesheetComponent_mat_tab_4_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9);
    i0.ɵɵelement(1, "imx-violations-per-rule", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("uidRule", ctx_r1.data.selectedRule.GetEntity().GetKeys()[0]);
} }
function RulesSidesheetComponent_mat_tab_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab", 1);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵtemplate(2, RulesSidesheetComponent_mat_tab_4_ng_template_2_Template, 2, 1, "ng-template", 2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Rule Violations"));
} }
function RulesSidesheetComponent_mat_tab_5_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-mitigating-controls-rules", 11);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("isMControlPerViolation", ctx_r1.data.isMControlPerViolation)("mControls", ctx_r1.data.mControls)("uidNonCompliance", ctx_r1.uidNonCompliance)("uidCompliance", ctx_r1.uidCompliance)("sidesheetRef", ctx_r1.sidesheetRef)("canEdit", ctx_r1.data.canEdit);
} }
function RulesSidesheetComponent_mat_tab_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-tab", 1);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵtemplate(2, RulesSidesheetComponent_mat_tab_5_ng_template_2_Template, 1, 6, "ng-template", 2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Mitigating Controls"));
} }
function RulesSidesheetComponent_ng_template_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 4);
    i0.ɵɵelement(1, "imx-object-hyperview", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("objectType", ctx_r1.data == null ? null : ctx_r1.data.selectedRule == null ? null : (tmp_1_0 = ctx_r1.data.selectedRule.GetEntity()) == null ? null : tmp_1_0.TypeName)("objectUid", (ctx_r1.data == null ? null : ctx_r1.data.selectedRule == null ? null : (tmp_2_0 = ctx_r1.data.selectedRule.GetEntity()) == null ? null : (tmp_2_0 = tmp_2_0.GetKeys()) == null ? null : tmp_2_0[0]) || "");
} }
class RulesSidesheetComponent {
    data;
    sidesheetRef;
    rulesProvider;
    reportDownload;
    cdrList;
    uidNonCompliance;
    uidCompliance;
    subscriptions$ = [];
    constructor(data, sidesheetRef, rulesProvider, elementalUiConfigService) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.rulesProvider = rulesProvider;
        this.uidNonCompliance = data.selectedRule.GetEntity().GetColumn('UID_NonCompliance').GetValue();
        this.uidCompliance = data.selectedRule.GetEntity().GetKeys().join(',');
        this.cdrList = [
            new BaseReadonlyCdr(this.data.selectedRule.GetEntity().GetColumn(DisplayColumns.DISPLAY_PROPERTYNAME)),
            new BaseReadonlyCdr(this.data.selectedRule.Description.Column),
            new BaseReadonlyCdr(this.data.selectedRule.RuleNumber.Column),
            ...(data.hasRiskIndex ? [new BaseReadonlyCdr(this.data.selectedRule.RiskIndex.Column)] : []),
            ...(data.hasRiskIndex && this.data.selectedRule.RiskIndex.value !== this.data.selectedRule.RiskIndexReduced.value
                ? [new BaseReadonlyCdr(this.data.selectedRule.RiskIndexReduced.Column)]
                : []),
            new BaseReadonlyCdr(this.data.selectedRule.IsInActive.Column),
            new BaseReadonlyCdr(this.data.selectedRule.CountOpen.Column),
            new BaseReadonlyCdr(this.data.selectedRule.CountClosed.Column),
        ];
        this.reportDownload = {
            ...elementalUiConfigService.Config.downloadOptions,
            url: this.rulesProvider.ruleReport(this.uidCompliance),
        };
    }
    get objectType() {
        return this.data.selectedRule.GetEntity().TypeName;
    }
    get objectUid() {
        return this.data.selectedRule.GetEntity().GetKeys().join(',');
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
    static ɵfac = function RulesSidesheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(RulesService), i0.ɵɵdirectiveInject(i2$1.ElementalUiConfigService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesSidesheetComponent, selectors: [["imx-rules-sidesheet"]], decls: 9, vars: 8, consts: [["mat-stretch-tabs", "false"], [3, "label"], ["matTabContent", ""], [3, "label", 4, "ngIf"], ["eui-sidesheet-content", ""], [3, "cdr", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "rules-sidesheet-button-download-report", 1, "justify-start", 3, "euiDownload"], [3, "cdr"], [1, "imx-tab-container"], [3, "uidRule"], [3, "isMControlPerViolation", "mControls", "uidNonCompliance", "uidCompliance", "sidesheetRef", "canEdit"], [3, "objectType", "objectUid"]], template: function RulesSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group", 0)(1, "mat-tab", 1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵtemplate(3, RulesSidesheetComponent_ng_template_3_Template, 7, 5, "ng-template", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(4, RulesSidesheetComponent_mat_tab_4_Template, 3, 3, "mat-tab", 3)(5, RulesSidesheetComponent_mat_tab_5_Template, 3, 3, "mat-tab", 3);
            i0.ɵɵelementStart(6, "mat-tab", 1);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵtemplate(8, RulesSidesheetComponent_ng_template_8_Template, 2, 2, "ng-template", 2);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 4, "#LDS#Heading Information"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.data);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.data == null ? null : ctx.data.hasRiskIndex);
            i0.ɵɵadvance();
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(7, 6, "#LDS#Heading Hyperview"));
        } }, dependencies: [i5.NgForOf, i5.NgIf, i3$1.EuiDownloadDirective, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i2$1.CdrEditorComponent, i6.MatButton, i3$2.MatCard, i8$2.MatTabContent, i8$2.MatTab, i8$2.MatTabGroup, i2.ObjectHyperviewComponent, MitigatingControlsRulesComponent, ViolationsPerRuleComponent, i4.TranslatePipe], styles: [".eui-sidesheet-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;padding:16px 20px}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesSidesheetComponent, [{
        type: Component,
        args: [{ selector: 'imx-rules-sidesheet', template: "<mat-tab-group mat-stretch-tabs=\"false\">\n  <mat-tab [label]=\"'#LDS#Heading Information' | translate\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <mat-card>\n          <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\n        </mat-card>\n      </div>\n\n      <div eui-sidesheet-actions>\n        <button\n          mat-stroked-button\n          [euiDownload]=\"reportDownload\"\n          class=\"justify-start\"\n          data-imx-identifier=\"rules-sidesheet-button-download-report\"\n        >\n          {{ '#LDS#Download report' | translate }}\n        </button>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab *ngIf=\"data\" [label]=\"'#LDS#Heading Rule Violations' | translate\">\n    <ng-template matTabContent>\n      <div class=\"imx-tab-container\">\n        <imx-violations-per-rule [uidRule]=\"data.selectedRule.GetEntity().GetKeys()[0]\"> </imx-violations-per-rule>\n      </div>\n    </ng-template>\n  </mat-tab>\n\n  <mat-tab *ngIf=\"data?.hasRiskIndex\" [label]=\"'#LDS#Heading Mitigating Controls' | translate\">\n    <ng-template matTabContent>\n      <imx-mitigating-controls-rules\n        [isMControlPerViolation]=\"data.isMControlPerViolation\"\n        [mControls]=\"data.mControls\"\n        [uidNonCompliance]=\"uidNonCompliance\"\n        [uidCompliance]=\"uidCompliance\"\n        [sidesheetRef]=\"sidesheetRef\"\n        [canEdit]=\"data.canEdit\"\n      ></imx-mitigating-controls-rules\n    ></ng-template>\n  </mat-tab>\n\n  <mat-tab label=\"{{ '#LDS#Heading Hyperview' | translate }}\">\n    <ng-template matTabContent>\n      <div eui-sidesheet-content>\n        <imx-object-hyperview\n          [objectType]=\"data?.selectedRule?.GetEntity()?.TypeName\"\n          [objectUid]=\"data?.selectedRule?.GetEntity()?.GetKeys()?.[0] || ''\"\n        >\n        </imx-object-hyperview>\n      </div>\n    </ng-template>\n  </mat-tab>\n</mat-tab-group>\n", styles: [".eui-sidesheet-actions{display:flex;justify-content:flex-end;padding:16px 20px}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i3$1.EuiSidesheetRef }, { type: RulesService }, { type: i2$1.ElementalUiConfigService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RulesSidesheetComponent, { className: "RulesSidesheetComponent", filePath: "lib\\rules\\rules-sidesheet\\rules-sidesheet.component.ts", lineNumber: 42 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesComponent_th_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 10);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.ruleSchema == null ? null : ctx_r0.ruleSchema.Columns == null ? null : ctx_r0.ruleSchema.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME] == null ? null : ctx_r0.ruleSchema.Columns[ctx_r0.DisplayColumns.DISPLAY_PROPERTYNAME].Display, " ");
} }
function RulesComponent_td_11_eui_badge_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 17);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Deactivated"));
} }
function RulesComponent_td_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 11)(1, "div", 12)(2, "div", 13)(3, "div", 14);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "div", 15);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(7, RulesComponent_td_11_eui_badge_7_Template, 3, 3, "eui-badge", 16);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(item_r2.GetEntity().GetDisplay());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r2.Description.Column.GetDisplayValue());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r2.IsInActive.value);
} }
function RulesComponent_th_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 10);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Rule violations"), " ");
} }
function RulesComponent_td_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 18)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const rule_r3 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", rule_r3.CountOpen.value + rule_r3.CountClosed.value, " ");
} }
function RulesComponent_th_18_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 10);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.ruleSchema == null ? null : ctx_r0.ruleSchema.Columns == null ? null : ctx_r0.ruleSchema.Columns.CountOpen == null ? null : ctx_r0.ruleSchema.Columns.CountOpen.Display, " ");
} }
function RulesComponent_td_19_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 18)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const rule_r4 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", rule_r4.CountOpen.Column.GetDisplayValue(), " ");
} }
function RulesComponent_th_22_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "th", 10);
} }
function RulesComponent_td_23_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "td", 18)(1, "div", 19)(2, "button", 20);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵlistener("click", function RulesComponent_td_23_Template_button_click_2_listener($event) { const rule_r6 = i0.ɵɵrestoreView(_r5).$implicit; const ctx_r0 = i0.ɵɵnextContext(); ctx_r0.recalculateRule(rule_r6); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "translate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(3, 2, "#LDS#Recalculates the violations of this compliance rule"));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(5, 4, "#LDS#Recalculate"), " ");
} }
class RulesComponent {
    rulesProvider;
    viewConfigService;
    mControlsProvider;
    sideSheetService;
    systemInfoService;
    translate;
    permissionService;
    dataSource;
    DisplayColumns = DisplayColumns;
    ruleSchema;
    isMControlPerViolation;
    busyService = new BusyService();
    canRecalculate = false;
    displayedColumns = [];
    dataModel;
    viewConfig;
    viewConfigPath = 'rules';
    constructor(rulesProvider, viewConfigService, mControlsProvider, sideSheetService, systemInfoService, translate, permissionService, dataSource) {
        this.rulesProvider = rulesProvider;
        this.viewConfigService = viewConfigService;
        this.mControlsProvider = mControlsProvider;
        this.sideSheetService = sideSheetService;
        this.systemInfoService = systemInfoService;
        this.translate = translate;
        this.permissionService = permissionService;
        this.dataSource = dataSource;
        this.ruleSchema = rulesProvider.ruleSchema;
        this.displayedColumns = [
            this.ruleSchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            {
                ColumnName: 'cases',
                Type: ValType.Int,
                untranslatedDisplay: '#LDS#Rule violations',
            },
            this.ruleSchema.Columns.CountOpen,
            {
                ColumnName: 'recalculate',
                Type: ValType.String,
                afterAdditionals: true,
                untranslatedDisplay: '#LDS#Recalculate',
            },
        ];
    }
    async ngOnInit() {
        const isBusy = this.busyService.beginBusy();
        try {
            this.dataModel = await this.rulesProvider.getDataModel();
            this.viewConfig = await this.viewConfigService.getInitialDSTExtension(this.dataModel, this.viewConfigPath);
            this.isMControlPerViolation = (await this.rulesProvider.featureConfig()).MitigatingControlsPerViolation;
            this.canRecalculate = await this.permissionService.isRuleStatistics();
            if (!this.canRecalculate) {
                this.displayedColumns.pop();
            }
            await this.getData();
        }
        finally {
            isBusy.endBusy();
        }
    }
    async updateConfig(config) {
        await this.viewConfigService.putViewConfig(config);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    async deleteConfigById(id) {
        await this.viewConfigService.deleteViewConfig(id);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    async showDetails(entity) {
        const selectedRule = entity;
        this.rulesProvider.handleOpenLoader();
        const hasRiskIndex = (await this.systemInfoService.get()).PreProps?.includes('RISKINDEX');
        let mControls = [];
        try {
            if (hasRiskIndex) {
                mControls = (await this.mControlsProvider.getControls(selectedRule.GetEntity().GetColumn('UID_NonCompliance').GetValue())).Data;
            }
        }
        finally {
            this.rulesProvider.handleCloseLoader();
        }
        await this.sideSheetService
            .open(RulesSidesheetComponent, {
            title: await this.translate.get('#LDS#Heading View Compliance Rule Details').toPromise(),
            subTitle: selectedRule.GetEntity().GetDisplay(),
            padding: '0px',
            width: calculateSidesheetWidth(1200, 0.7),
            testId: 'rule-details-sidesheet',
            data: {
                selectedRule,
                isMControlPerViolation: this.isMControlPerViolation,
                hasRiskIndex,
                mControls,
                canEdit: this.canRecalculate && false, // TODO: When API can handle permission Update canEdit or remove "&& false" PBI: 305793
            },
        })
            .afterClosed()
            .toPromise();
    }
    async recalculateRule(selectedRule) {
        this.rulesProvider.handleOpenLoader();
        try {
            await this.rulesProvider.recalculate(selectedRule.GetEntity().GetKeys().join(','));
            await this.dataSource.updateState();
        }
        finally {
            this.rulesProvider.handleCloseLoader();
        }
    }
    async getData() {
        const dataViewInitParameters = {
            execute: (params, signal) => this.rulesProvider.getRules(params, signal),
            schema: this.ruleSchema,
            columnsToDisplay: this.displayedColumns,
            dataModel: this.dataModel,
            exportFunction: this.rulesProvider.exportRules(),
            viewConfig: this.viewConfig,
            highlightEntity: (identity) => {
                this.showDetails(identity);
            },
        };
        this.dataSource.init(dataViewInitParameters);
    }
    static ɵfac = function RulesComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesComponent)(i0.ɵɵdirectiveInject(RulesService), i0.ɵɵdirectiveInject(i2.ViewConfigService), i0.ɵɵdirectiveInject(MitigatingControlsRulesService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2$1.SystemInfoService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(CplPermissionsService), i0.ɵɵdirectiveInject(i2$1.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesComponent, selectors: [["imx-rules"]], features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 25, vars: 10, consts: [[1, "imx-header-toolbar"], [1, "mat-headline-5"], [3, "updateConfig", "deleteConfigById", "dataSource"], [1, "imx-card-fill"], ["mode", "manual", 3, "dataSource"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", "class", "imx-table-cell", 4, "matCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], [3, "dataSource"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell", 1, "imx-table-cell"], ["data-imx-identifier", "runs-button-show-details", 1, "imx-displayColumn"], [1, "imx-display-column-main"], ["data-imx-identifier", "rules-table-display"], ["subtitle", "", "data-imx-identifier", "rules-table-description"], ["class", "imx-badge", "color", "gray", 4, "ngIf"], ["color", "gray", 1, "imx-badge"], ["mat-cell", "", "role", "gridcell"], [1, "imx-button-column"], ["mat-stroked-button", "", "data-imx-identifier", "runs-button-show-recalculate", 3, "click", "title"]], template: function RulesComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1)(2, "span");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(5, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(6, "imx-data-view-toolbar", 2);
            i0.ɵɵlistener("updateConfig", function RulesComponent_Template_imx_data_view_toolbar_updateConfig_6_listener($event) { return ctx.updateConfig($event); })("deleteConfigById", function RulesComponent_Template_imx_data_view_toolbar_deleteConfigById_6_listener($event) { return ctx.deleteConfigById($event); });
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(7, "mat-card", 3)(8, "imx-data-view-auto-table", 4);
            i0.ɵɵelementContainerStart(9, 5);
            i0.ɵɵtemplate(10, RulesComponent_th_10_Template, 2, 1, "th", 6)(11, RulesComponent_td_11_Template, 8, 3, "td", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(12, 5)(13);
            i0.ɵɵtemplate(14, RulesComponent_th_14_Template, 3, 3, "th", 6);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(15, RulesComponent_td_15_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(16, 5)(17);
            i0.ɵɵtemplate(18, RulesComponent_th_18_Template, 2, 1, "th", 6);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(19, RulesComponent_td_19_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(20, 5)(21);
            i0.ɵɵtemplate(22, RulesComponent_th_22_Template, 1, 0, "th", 6);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(23, RulesComponent_td_23_Template, 6, 6, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd();
            i0.ɵɵelement(24, "imx-data-view-paginator", 9);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 8, "#LDS#Heading Compliance Rules"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.DisplayColumns.DISPLAY_PROPERTYNAME);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("matColumnDef", "cases");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("matColumnDef", ctx.ruleSchema == null ? null : ctx.ruleSchema.Columns == null ? null : ctx.ruleSchema.Columns.CountOpen == null ? null : ctx.ruleSchema.Columns.CountOpen.ColumnName);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("matColumnDef", "recalculate");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
        } }, dependencies: [i5.NgIf, i3$1.EuiBadgeComponent, i6.MatButton, i3$2.MatCard, i2$1.HelpContextualComponent, i2$1.DataViewAutoTableComponent, i2$1.DataViewPaginatorComponent, i2$1.DataViewToolbarComponent, i11.MatHeaderCellDef, i11.MatColumnDef, i11.MatCellDef, i11.MatHeaderCell, i11.MatCell, i4.TranslatePipe], styles: ["div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit}.imx-display-column[_ngcontent-%COMP%]{width:100%!important;cursor:inherit!important}.imx-display-column-main[_ngcontent-%COMP%]{flex:1 1 auto;display:block!important;cursor:inherit!important}.imx-display-column[_ngcontent-%COMP%]   .imx-badge[_ngcontent-%COMP%]{align-self:flex-end}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesComponent, [{
        type: Component,
        args: [{ selector: 'imx-rules', providers: [DataViewSource], template: "<div class=\"imx-header-toolbar\">\n  <h2 class=\"mat-headline-5\">\n    <span>{{ '#LDS#Heading Compliance Rules' | translate }}</span>\n    <imx-help-contextual></imx-help-contextual>\n  </h2>\n  <imx-data-view-toolbar\n    [dataSource]=\"dataSource\"\n    (updateConfig)=\"updateConfig($event)\"\n    (deleteConfigById)=\"deleteConfigById($event)\"\n  ></imx-data-view-toolbar>\n</div>\n<mat-card class=\"imx-card-fill\">\n  <imx-data-view-auto-table [dataSource]=\"dataSource\" mode=\"manual\">\n    <ng-container [matColumnDef]=\"DisplayColumns.DISPLAY_PROPERTYNAME\">\n      <th mat-header-cell *matHeaderCellDef>\n        {{ ruleSchema?.Columns?.[DisplayColumns.DISPLAY_PROPERTYNAME]?.Display }}\n      </th>\n      <td mat-cell *matCellDef=\"let item\" role=\"gridcell\" class=\"imx-table-cell\">\n        <div class=\"imx-displayColumn\" data-imx-identifier=\"runs-button-show-details\">\n          <div class=\"imx-display-column-main\">\n            <div data-imx-identifier=\"rules-table-display\">{{ item.GetEntity().GetDisplay() }}</div>\n            <div subtitle data-imx-identifier=\"rules-table-description\">{{ item.Description.Column.GetDisplayValue() }}</div>\n          </div>\n          <eui-badge class=\"imx-badge\" *ngIf=\"item.IsInActive.value\" color=\"gray\">{{ '#LDS#Deactivated' | translate }}</eui-badge>\n        </div>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"'cases'\">\n      <ng-container>\n        <th mat-header-cell *matHeaderCellDef>\n          {{ '#LDS#Rule violations' | translate }}\n        </th>\n      </ng-container>\n      <td mat-cell *matCellDef=\"let rule\" role=\"gridcell\">\n        <span>\n          {{ rule.CountOpen.value + rule.CountClosed.value }}\n        </span>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"ruleSchema?.Columns?.CountOpen?.ColumnName\">\n      <ng-container>\n        <th mat-header-cell *matHeaderCellDef>\n          {{ ruleSchema?.Columns?.CountOpen?.Display }}\n        </th>\n      </ng-container>\n      <td mat-cell *matCellDef=\"let rule\" role=\"gridcell\">\n        <span>\n          {{ rule.CountOpen.Column.GetDisplayValue() }}\n        </span>\n      </td>\n    </ng-container>\n    <ng-container [matColumnDef]=\"'recalculate'\">\n      <ng-container>\n        <th mat-header-cell *matHeaderCellDef></th>\n      </ng-container>\n      <td mat-cell *matCellDef=\"let rule\" role=\"gridcell\">\n        <div class=\"imx-button-column\">\n          <button\n            mat-stroked-button\n            data-imx-identifier=\"runs-button-show-recalculate\"\n            (click)=\"recalculateRule(rule); $event.stopPropagation()\"\n            title=\"{{ '#LDS#Recalculates the violations of this compliance rule' | translate }}\"\n          >\n            {{ '#LDS#Recalculate' | translate }}\n          </button>\n        </div>\n      </td>\n    </ng-container>\n  </imx-data-view-auto-table>\n  <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n</mat-card>\n", styles: ["div[subtitle]{font-size:smaller;color:#919799}:host{display:flex;flex-direction:column;overflow:hidden;height:inherit}.imx-display-column{width:100%!important;cursor:inherit!important}.imx-display-column-main{flex:1 1 auto;display:block!important;cursor:inherit!important}.imx-display-column .imx-badge{align-self:flex-end}\n"] }]
    }], () => [{ type: RulesService }, { type: i2.ViewConfigService }, { type: MitigatingControlsRulesService }, { type: i3$1.EuiSidesheetService }, { type: i2$1.SystemInfoService }, { type: i4.TranslateService }, { type: CplPermissionsService }, { type: i2$1.DataViewSource }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RulesComponent, { className: "RulesComponent", filePath: "lib\\rules\\rules.component.ts", lineNumber: 63 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ComplianceRulesGuardService {
    permissionService;
    appConfig;
    router;
    routeGuardService;
    constructor(permissionService, appConfig, router, routeGuardService) {
        this.permissionService = permissionService;
        this.appConfig = appConfig;
        this.router = router;
        this.routeGuardService = routeGuardService;
    }
    async canActivate(route, state) {
        if (await this.routeGuardService.canActivate(route, state)) {
            const userRuleStatistics = await this.permissionService.isRuleStatistics();
            if (!userRuleStatistics) {
                this.router.navigate([this.appConfig.Config.routeConfig?.start]);
            }
            return userRuleStatistics;
        }
        this.router.navigate([this.appConfig.Config.routeConfig?.login]);
        return false;
    }
    static ɵfac = function ComplianceRulesGuardService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ComplianceRulesGuardService)(i0.ɵɵinject(CplPermissionsService), i0.ɵɵinject(i2$1.AppConfigService), i0.ɵɵinject(i3.Router), i0.ɵɵinject(i2$1.RouteGuardService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ComplianceRulesGuardService, factory: ComplianceRulesGuardService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ComplianceRulesGuardService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: CplPermissionsService }, { type: i2$1.AppConfigService }, { type: i3.Router }, { type: i2$1.RouteGuardService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RuleViolationsGuardService {
    permissionService;
    appConfig;
    router;
    routeGuardService;
    constructor(permissionService, appConfig, router, routeGuardService) {
        this.permissionService = permissionService;
        this.appConfig = appConfig;
        this.router = router;
        this.routeGuardService = routeGuardService;
    }
    async canActivate(route, state) {
        if (await this.routeGuardService.canActivate(route, state)) {
            const isExceptionAdmin = await this.permissionService.isExceptionAdmin();
            if (!isExceptionAdmin) {
                this.router.navigate([this.appConfig.Config.routeConfig?.start]);
            }
            return isExceptionAdmin;
        }
        this.router.navigate([this.appConfig.Config.routeConfig?.login]);
        return false;
    }
    static ɵfac = function RuleViolationsGuardService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RuleViolationsGuardService)(i0.ɵɵinject(CplPermissionsService), i0.ɵɵinject(i2$1.AppConfigService), i0.ɵɵinject(i3.Router), i0.ɵɵinject(i2$1.RouteGuardService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RuleViolationsGuardService, factory: RuleViolationsGuardService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RuleViolationsGuardService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: CplPermissionsService }, { type: i2$1.AppConfigService }, { type: i3.Router }, { type: i2$1.RouteGuardService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class IdentityRuleViolationsModule {
    static ɵfac = function IdentityRuleViolationsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || IdentityRuleViolationsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: IdentityRuleViolationsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, EuiCoreModule, DataSourceToolbarModule, DataTableModule, TranslateModule, MatButtonModule, MatCardModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityRuleViolationsModule, [{
        type: NgModule,
        args: [{
                declarations: [IdentityRuleViolationsComponent, IdentityRuleViolationsMitigationControlComponent],
                imports: [CommonModule, EuiCoreModule, DataSourceToolbarModule, DataTableModule, TranslateModule, MatButtonModule, MatCardModule],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(IdentityRuleViolationsModule, { declarations: [IdentityRuleViolationsComponent, IdentityRuleViolationsMitigationControlComponent], imports: [CommonModule, EuiCoreModule, DataSourceToolbarModule, DataTableModule, TranslateModule, MatButtonModule, MatCardModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class MitigatingControlContainerModule {
    static ɵfac = function MitigatingControlContainerModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MitigatingControlContainerModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: MitigatingControlContainerModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, EuiCoreModule, EuiMaterialModule, CdrModule, TranslateModule.forChild()] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlContainerModule, [{
        type: NgModule,
        args: [{
                declarations: [MitigatingControlContainerComponent],
                imports: [CommonModule, EuiCoreModule, EuiMaterialModule, CdrModule, TranslateModule.forChild()],
                exports: [MitigatingControlContainerComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(MitigatingControlContainerModule, { declarations: [MitigatingControlContainerComponent], imports: [CommonModule, EuiCoreModule, EuiMaterialModule, CdrModule, i4.TranslateModule], exports: [MitigatingControlContainerComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestModule {
    constructor(logger) {
        logger.info(this, '▶️ RequestModule loaded');
    }
    static ɵfac = function RequestModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RequestModule)(i0.ɵɵinject(i2$1.ClassloggerService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RequestModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CdrModule,
            CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            EuiCoreModule,
            EuiMaterialModule,
            FormsModule,
            JustificationModule,
            MatCardModule,
            MatExpansionModule,
            ReactiveFormsModule,
            TranslateModule,
            MitigatingControlContainerModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RequestModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    MitigatingControlsRequestComponent,
                    EditMitigatingControlsComponent,
                    WorkflowViolationDetailsComponent,
                    ComplianceViolationDetailsComponent,
                    RequestMitigatingControlFilterPipe,
                ],
                imports: [
                    CdrModule,
                    CommonModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    FormsModule,
                    JustificationModule,
                    MatCardModule,
                    MatExpansionModule,
                    ReactiveFormsModule,
                    TranslateModule,
                    MitigatingControlContainerModule,
                ],
                exports: [MitigatingControlsRequestComponent],
            }]
    }], () => [{ type: i2$1.ClassloggerService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RequestModule, { declarations: [MitigatingControlsRequestComponent,
        EditMitigatingControlsComponent,
        WorkflowViolationDetailsComponent,
        ComplianceViolationDetailsComponent,
        RequestMitigatingControlFilterPipe], imports: [CdrModule,
        CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        EuiMaterialModule,
        FormsModule,
        JustificationModule,
        MatCardModule,
        MatExpansionModule,
        ReactiveFormsModule,
        TranslateModule,
        MitigatingControlContainerModule], exports: [MitigatingControlsRequestComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesViolationsComponent_th_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_Person == null ? null : ctx_r0.entitySchema.Columns.UID_Person.Display, " ");
} }
function RulesViolationsComponent_td_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 18)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r2.UID_Person.Column.GetDisplayValue(), " ");
} }
function RulesViolationsComponent_th_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.UID_NonCompliance == null ? null : ctx_r0.entitySchema.Columns.UID_NonCompliance.Display, " ");
} }
function RulesViolationsComponent_td_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 18)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r3.UID_NonCompliance.Column.GetDisplayValue(), " ");
} }
function RulesViolationsComponent_th_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.State == null ? null : ctx_r0.entitySchema.Columns.State.Display, " ");
} }
function RulesViolationsComponent_td_21_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 18)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r4 == null ? null : item_r4.stateBadge == null ? null : item_r4.stateBadge.caption, " ");
} }
function RulesViolationsComponent_th_24_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 19);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.RiskIndexCalculated == null ? null : ctx_r0.entitySchema.Columns.RiskIndexCalculated.Display, " ");
} }
function RulesViolationsComponent_td_25_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 18)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r5.RiskIndexCalculated.Column.GetDisplayValue(), " ");
} }
function RulesViolationsComponent_th_28_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 19);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.RiskIndexReduced == null ? null : ctx_r0.entitySchema.Columns.RiskIndexReduced.Display, " ");
} }
function RulesViolationsComponent_td_29_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 18)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", item_r6.RiskIndexReduced.Column.GetDisplayValue(), " ");
} }
function RulesViolationsComponent_th_32_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns == null ? null : ctx_r0.entitySchema.Columns.CountOpen == null ? null : ctx_r0.entitySchema.Columns.CountOpen.Display, " ");
} }
function RulesViolationsComponent_td_33_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "td", 18)(1, "div", 20)(2, "button", 21);
    i0.ɵɵlistener("click", function RulesViolationsComponent_td_33_Template_button_click_2_listener($event) { const item_r8 = i0.ɵɵrestoreView(_r7).$implicit; const ctx_r0 = i0.ɵɵnextContext(); $event.stopPropagation(); return i0.ɵɵresetView(ctx_r0.actionService.deny([item_r8])); });
    i0.ɵɵelement(3, "eui-icon", 14);
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "button", 22);
    i0.ɵɵlistener("click", function RulesViolationsComponent_td_33_Template_button_click_6_listener($event) { const item_r8 = i0.ɵɵrestoreView(_r7).$implicit; const ctx_r0 = i0.ɵɵnextContext(); $event.stopPropagation(); return i0.ɵɵresetView(ctx_r0.actionService.approve([item_r8])); });
    i0.ɵɵelement(7, "eui-icon", 16);
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "translate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(5, 2, "#LDS#Deny exception"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 4, "#LDS#Grant exception"), " ");
} }
/**
 * Component that shows all rules violations that the user can approve or deny.
 * Therefore, the user can also view some information about the rules violations.
 *
 * Initially only the pending rules violations are shown.
 *
 */
class RulesViolationsComponent {
    rulesViolationsService;
    actionService;
    viewConfigService;
    mControlsProvider;
    sidesheet;
    translate;
    logger;
    activatedRoute;
    elementalBusyService;
    dataSource;
    isMControlPerViolation;
    dataModel;
    selectedRulesViolations = [];
    groupedData = {};
    entitySchema;
    busyService = new BusyService();
    displayedColumns;
    viewConfig;
    viewConfigPath = 'rules/violations';
    subscriptions = [];
    constructor(rulesViolationsService, actionService, viewConfigService, mControlsProvider, sidesheet, translate, logger, activatedRoute, elementalBusyService, dataSource) {
        this.rulesViolationsService = rulesViolationsService;
        this.actionService = actionService;
        this.viewConfigService = viewConfigService;
        this.mControlsProvider = mControlsProvider;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.logger = logger;
        this.activatedRoute = activatedRoute;
        this.elementalBusyService = elementalBusyService;
        this.dataSource = dataSource;
        this.subscriptions.push(this.actionService.applied.subscribe(async () => {
            this.dataSource.selection.clear();
            this.dataSource.updateState();
        }));
    }
    async ngOnInit() {
        const isBusy = this.busyService.beginBusy();
        try {
            this.entitySchema = this.rulesViolationsService.rulesViolationsApproveSchema;
            // If this wasn't already set, then we need to get it from the config
            this.isMControlPerViolation ??= (await this.rulesViolationsService.featureConfig()).MitigatingControlsPerViolation;
            this.dataModel = await this.rulesViolationsService.getDataModel();
            this.viewConfig = await this.viewConfigService.getInitialDSTExtension(this.dataModel, this.viewConfigPath);
            this.displayedColumns = [
                this.entitySchema.Columns.UID_Person,
                this.entitySchema.Columns.UID_NonCompliance,
                this.entitySchema.Columns.State,
                this.entitySchema.Columns.RiskIndexCalculated,
                this.entitySchema.Columns.RiskIndexReduced,
                {
                    ColumnName: 'decision',
                    Type: ValType.String,
                },
            ];
            this.subscriptions.push(this.activatedRoute.queryParams.subscribe((params) => this.updateFiltersFromRouteParams(params)));
        }
        finally {
            isBusy.endBusy();
        }
        await this.getData();
    }
    ngOnDestroy() {
        this.subscriptions.forEach((s) => s.unsubscribe());
    }
    async updateConfig(config) {
        await this.viewConfigService.putViewConfig(config);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    async deleteConfigById(id) {
        await this.viewConfigService.deleteViewConfig(id);
        this.viewConfig = await this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
        this.dataSource.viewConfig.set(this.viewConfig);
    }
    async getData() {
        const dataViewInitParameters = {
            execute: (params, signal) => this.rulesViolationsService.getRulesViolationsApprove(params, signal),
            schema: this.entitySchema,
            columnsToDisplay: this.displayedColumns,
            dataModel: this.dataModel,
            groupExecute: (column, params, signal) => this.rulesViolationsService.getGroupInfo({ ...params, by: column }),
            exportFunction: this.rulesViolationsService.exportRulesViolations(),
            viewConfig: this.viewConfig,
            highlightEntity: (entity) => {
                this.viewDetails(entity);
            },
            selectionChange: (selection) => this.onSelectionChanged(selection),
        };
        this.dataSource.init(dataViewInitParameters);
    }
    onSelectionChanged(items) {
        this.logger.trace(this, 'selection changed', items);
        this.selectedRulesViolations = items;
    }
    /**
     * Opens the {@link RulesViolationsDetailsComponent} sidesheet thats shows some informations of the selected rules violation.
     * @param selectedRulesViolation the selected {@link RulesViolationsApproval}
     */
    async viewDetails(entity) {
        const selectedRulesViolation = entity;
        let complianceRule;
        this.elementalBusyService.show();
        try {
            complianceRule = await this.rulesViolationsService.getComplianceRuleByUId(selectedRulesViolation);
        }
        finally {
            this.elementalBusyService.hide();
        }
        if (!complianceRule) {
            return;
        }
        // TODO: Make API for mit conts
        const result = await this.sidesheet
            .open(RulesViolationsDetailsComponent, {
            title: await this.translate.get('#LDS#Heading View Rule Violation Details').toPromise(),
            subTitle: selectedRulesViolation.GetEntity().GetDisplay(),
            padding: '0px',
            panelClass: 'imx-sidesheet',
            disableClose: this.isMControlPerViolation,
            width: calculateSidesheetWidth(1200, 0.7),
            testId: 'rules-violations-details-sidesheet',
            data: {
                selectedRulesViolation,
                isMControlPerViolation: this.isMControlPerViolation,
                complianceRule,
            },
        })
            .afterClosed()
            .toPromise();
        if (result) {
            this.dataSource.updateState();
        }
    }
    updateFiltersFromRouteParams(params) {
        for (const [key, value] of Object.entries(params)) {
            this.tryApplyFilter(key, value);
        }
    }
    tryApplyFilter(name, value) {
        let filterOptions = this.dataModel?.Filters || [];
        const index = filterOptions.findIndex((elem) => elem.Name?.toLowerCase() === name.toLowerCase());
        if (index > -1) {
            const filter = filterOptions[index];
            if (filter) {
                filter.InitialValue = value;
                filter.CurrentValue = value;
                this.dataSource.state.update((state) => ({ ...state, [name.toLowerCase()]: value }));
            }
        }
    }
    static ɵfac = function RulesViolationsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesViolationsComponent)(i0.ɵɵdirectiveInject(RulesViolationsService), i0.ɵɵdirectiveInject(RulesViolationsActionService), i0.ɵɵdirectiveInject(i2.ViewConfigService), i0.ɵɵdirectiveInject(MitigatingControlsPersonService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i2$1.ClassloggerService), i0.ɵɵdirectiveInject(i3.ActivatedRoute), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2$1.DataViewSource)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsComponent, selectors: [["imx-rules-violations"]], inputs: { isMControlPerViolation: "isMControlPerViolation" }, features: [i0.ɵɵProvidersFeature([DataViewSource])], decls: 45, vars: 24, consts: [[1, "imx-rules-violations-page"], [1, "imx-header-toolbar"], [1, "mat-headline-5"], [3, "updateConfig", "deleteConfigById", "dataSource"], [1, "imx-card-fill"], ["mode", "manual", "matSort", "", 3, "matSortChange", "dataSource", "selectable", "matSortActive", "matSortDirection"], [3, "matColumnDef"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "role", "gridcell", 4, "matCellDef"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], [3, "dataSource"], [1, "imx-button-bar-transparent"], [1, "justify-start", 3, "dataSource"], ["color", "warn", "mat-flat-button", "", "data-imx-identifier", "rules-violations-button-deny", 3, "click", "disabled"], ["icon", "ignore"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "rules-violations-button-approve", 3, "click", "disabled"], ["icon", "check"], ["mat-header-cell", ""], ["mat-cell", "", "role", "gridcell"], ["mat-header-cell", "", "mat-sort-header", ""], [1, "imx-button-column"], ["color", "warn", "mat-stroked-button", "", "data-imx-identifier", "rules-violations-table-row-button-deny", 3, "click"], ["color", "primary", "mat-stroked-button", "", "data-imx-identifier", "rules-violations-table-row-button-approve", 3, "click"]], template: function RulesViolationsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
            i0.ɵɵtext(4);
            i0.ɵɵpipe(5, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(6, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "imx-data-view-toolbar", 3);
            i0.ɵɵlistener("updateConfig", function RulesViolationsComponent_Template_imx_data_view_toolbar_updateConfig_7_listener($event) { return ctx.updateConfig($event); })("deleteConfigById", function RulesViolationsComponent_Template_imx_data_view_toolbar_deleteConfigById_7_listener($event) { return ctx.deleteConfigById($event); });
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(8, "mat-card", 4)(9, "imx-data-view-auto-table", 5);
            i0.ɵɵlistener("matSortChange", function RulesViolationsComponent_Template_imx_data_view_auto_table_matSortChange_9_listener($event) { return ctx.dataSource == null ? null : ctx.dataSource.sortChange($event); });
            i0.ɵɵelementContainerStart(10, 6)(11);
            i0.ɵɵtemplate(12, RulesViolationsComponent_th_12_Template, 2, 1, "th", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(13, RulesViolationsComponent_td_13_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(14, 6)(15);
            i0.ɵɵtemplate(16, RulesViolationsComponent_th_16_Template, 2, 1, "th", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(17, RulesViolationsComponent_td_17_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(18, 6)(19);
            i0.ɵɵtemplate(20, RulesViolationsComponent_th_20_Template, 2, 1, "th", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(21, RulesViolationsComponent_td_21_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(22, 6)(23);
            i0.ɵɵtemplate(24, RulesViolationsComponent_th_24_Template, 2, 1, "th", 9);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(25, RulesViolationsComponent_td_25_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(26, 6)(27);
            i0.ɵɵtemplate(28, RulesViolationsComponent_th_28_Template, 2, 1, "th", 9);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(29, RulesViolationsComponent_td_29_Template, 3, 1, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(30, 6)(31);
            i0.ɵɵtemplate(32, RulesViolationsComponent_th_32_Template, 2, 1, "th", 7);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(33, RulesViolationsComponent_td_33_Template, 10, 6, "td", 8);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementEnd();
            i0.ɵɵelement(34, "imx-data-view-paginator", 10);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(35, "div", 11);
            i0.ɵɵelement(36, "imx-data-view-selection", 12);
            i0.ɵɵelementStart(37, "button", 13);
            i0.ɵɵlistener("click", function RulesViolationsComponent_Template_button_click_37_listener() { return ctx.actionService.deny(ctx.selectedRulesViolations); });
            i0.ɵɵelement(38, "eui-icon", 14);
            i0.ɵɵtext(39);
            i0.ɵɵpipe(40, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(41, "button", 15);
            i0.ɵɵlistener("click", function RulesViolationsComponent_Template_button_click_41_listener() { return ctx.actionService.approve(ctx.selectedRulesViolations); });
            i0.ɵɵelement(42, "eui-icon", 16);
            i0.ɵɵtext(43);
            i0.ɵɵpipe(44, "translate");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 18, "#LDS#Heading Rule Violations"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource)("selectable", true)("matSortActive", ctx.dataSource.sortId())("matSortDirection", ctx.dataSource.sortDirection());
            i0.ɵɵadvance();
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns.UID_Person == null ? null : ctx.entitySchema.Columns.UID_Person.ColumnName);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns.UID_NonCompliance == null ? null : ctx.entitySchema.Columns.UID_NonCompliance.ColumnName);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns.State == null ? null : ctx.entitySchema.Columns.State.ColumnName);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns.RiskIndexCalculated == null ? null : ctx.entitySchema.Columns.RiskIndexCalculated.ColumnName);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("matColumnDef", ctx.entitySchema == null ? null : ctx.entitySchema.Columns == null ? null : ctx.entitySchema.Columns.RiskIndexReduced == null ? null : ctx.entitySchema.Columns.RiskIndexReduced.ColumnName);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("matColumnDef", "decision");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance();
            i0.ɵɵproperty("disabled", !ctx.selectedRulesViolations.length);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(40, 20, "#LDS#Deny exception"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.selectedRulesViolations.length);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(44, 22, "#LDS#Grant exception"), " ");
        } }, dependencies: [i3$1.EuiIconComponent, i6.MatButton, i3$2.MatCard, i11$1.MatSort, i11$1.MatSortHeader, i11.MatHeaderCellDef, i11.MatColumnDef, i11.MatCellDef, i11.MatHeaderCell, i11.MatCell, i2$1.HelpContextualComponent, i2$1.DataViewAutoTableComponent, i2$1.DataViewPaginatorComponent, i2$1.DataViewToolbarComponent, i2$1.DataViewSelectionComponent, i4.TranslatePipe], styles: [".heading-wrapper[_ngcontent-%COMP%]{display:flex;flex-direction:row;flex:0 0 auto}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;max-width:100%}.imx-rules-violations-page[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;background-color:inherit;flex:1 1 auto}@media screen and (max-width: 768px){.imx-rules-violations-page[_ngcontent-%COMP%]   .heading-wrapper[_ngcontent-%COMP%]{display:block}}@media only screen and (max-width: 1024px){  .mat-column-decision{display:none}}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsComponent, [{
        type: Component,
        args: [{ selector: 'imx-rules-violations', providers: [DataViewSource], template: "<div class=\"imx-rules-violations-page\">\n  <div class=\"imx-header-toolbar\">\n    <h2 class=\"mat-headline-5\">\n      <span>{{ '#LDS#Heading Rule Violations' | translate }}</span>\n      <imx-help-contextual></imx-help-contextual>\n    </h2>\n    <imx-data-view-toolbar\n      [dataSource]=\"dataSource\"\n      (updateConfig)=\"updateConfig($event)\"\n      (deleteConfigById)=\"deleteConfigById($event)\"\n    ></imx-data-view-toolbar>\n  </div>\n  <mat-card class=\"imx-card-fill\">\n    <imx-data-view-auto-table\n      [dataSource]=\"dataSource\"\n      mode=\"manual\"\n      [selectable]=\"true\"\n      matSort\n      (matSortChange)=\"dataSource?.sortChange($event)\"\n      [matSortActive]=\"dataSource.sortId()\"\n      [matSortDirection]=\"dataSource.sortDirection()\"\n    >\n      <ng-container [matColumnDef]=\"entitySchema?.Columns?.UID_Person?.ColumnName\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef>\n            {{ entitySchema?.Columns?.UID_Person?.Display }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <span>\n            {{ item.UID_Person.Column.GetDisplayValue() }}\n          </span>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"entitySchema?.Columns?.UID_NonCompliance?.ColumnName\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef>\n            {{ entitySchema?.Columns?.UID_NonCompliance?.Display }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <span>\n            {{ item.UID_NonCompliance.Column.GetDisplayValue() }}\n          </span>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"entitySchema?.Columns?.State?.ColumnName\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef>\n            {{ entitySchema?.Columns?.State?.Display }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <span>\n            {{ item?.stateBadge?.caption }}\n          </span>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"entitySchema?.Columns?.RiskIndexCalculated?.ColumnName\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>\n            {{ entitySchema?.Columns?.RiskIndexCalculated?.Display }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <span>\n            {{ item.RiskIndexCalculated.Column.GetDisplayValue() }}\n          </span>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"entitySchema?.Columns?.RiskIndexReduced?.ColumnName\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>\n            {{ entitySchema?.Columns?.RiskIndexReduced?.Display }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <span>\n            {{ item.RiskIndexReduced.Column.GetDisplayValue() }}\n          </span>\n        </td>\n      </ng-container>\n      <ng-container [matColumnDef]=\"'decision'\">\n        <ng-container>\n          <th mat-header-cell *matHeaderCellDef>\n            {{ entitySchema?.Columns?.CountOpen?.Display }}\n          </th>\n        </ng-container>\n        <td mat-cell *matCellDef=\"let item\" role=\"gridcell\">\n          <div class=\"imx-button-column\">\n            <button\n              color=\"warn\"\n              mat-stroked-button\n              (click)=\"$event.stopPropagation(); actionService.deny([item])\"\n              data-imx-identifier=\"rules-violations-table-row-button-deny\"\n            >\n              <eui-icon icon=\"ignore\"></eui-icon>\n              {{ '#LDS#Deny exception' | translate }}\n            </button>\n            <button\n              color=\"primary\"\n              mat-stroked-button\n              (click)=\"$event.stopPropagation(); actionService.approve([item])\"\n              data-imx-identifier=\"rules-violations-table-row-button-approve\"\n            >\n              <eui-icon icon=\"check\"></eui-icon>\n              {{ '#LDS#Grant exception' | translate }}\n            </button>\n          </div>\n        </td>\n      </ng-container>\n    </imx-data-view-auto-table>\n    <imx-data-view-paginator [dataSource]=\"dataSource\"></imx-data-view-paginator>\n  </mat-card>\n  <div class=\"imx-button-bar-transparent\">\n    <imx-data-view-selection class=\"justify-start\" [dataSource]=\"dataSource\"></imx-data-view-selection>\n    <button\n      color=\"warn\"\n      mat-flat-button\n      (click)=\"actionService.deny(selectedRulesViolations)\"\n      data-imx-identifier=\"rules-violations-button-deny\"\n      [disabled]=\"!selectedRulesViolations.length\"\n    >\n      <eui-icon icon=\"ignore\"></eui-icon>\n      {{ '#LDS#Deny exception' | translate }}\n    </button>\n    <button\n      mat-flat-button\n      color=\"primary\"\n      (click)=\"actionService.approve(selectedRulesViolations)\"\n      data-imx-identifier=\"rules-violations-button-approve\"\n      [disabled]=\"!selectedRulesViolations.length\"\n    >\n      <eui-icon icon=\"check\"></eui-icon>\n      {{ '#LDS#Grant exception' | translate }}\n    </button>\n  </div>\n</div>\n", styles: [".heading-wrapper{display:flex;flex-direction:row;flex:0 0 auto}:host{display:flex;flex-direction:column;overflow:hidden;height:inherit;max-width:100%}.imx-rules-violations-page{display:flex;flex-direction:column;overflow:hidden;background-color:inherit;flex:1 1 auto}@media screen and (max-width: 768px){.imx-rules-violations-page .heading-wrapper{display:block}}@media only screen and (max-width: 1024px){::ng-deep .mat-column-decision{display:none}}\n"] }]
    }], () => [{ type: RulesViolationsService }, { type: RulesViolationsActionService }, { type: i2.ViewConfigService }, { type: MitigatingControlsPersonService }, { type: i3$1.EuiSidesheetService }, { type: i4.TranslateService }, { type: i2$1.ClassloggerService }, { type: i3.ActivatedRoute }, { type: i3$1.EuiLoadingService }, { type: i2$1.DataViewSource }], { isMControlPerViolation: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RulesViolationsComponent, { className: "RulesViolationsComponent", filePath: "lib\\rules-violations\\rules-violations.component.ts", lineNumber: 74 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RulesViolationsModule {
    menuService;
    constructor(menuService, logger) {
        this.menuService = menuService;
        logger.info(this, '▶︝ RulesViolationsnModule loaded');
        this.setupMenu();
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features, projectConfig, groups) => {
            const items = [];
            if (preProps.includes('ITSHOP') && isExceptionAdmin(groups)) {
                items.push({
                    id: 'CPL_Compliance_RulesViolations',
                    navigationCommands: {
                        commands: ['compliance', 'rulesviolations', 'approve'],
                    },
                    title: '#LDS#Menu Entry Rule violations',
                    description: '#LDS#Shows the rule violations for which you can grant or deny exceptions.',
                    sorting: '25-20',
                });
            }
            if (items.length === 0) {
                return undefined;
            }
            return {
                id: 'ROOT_Compliance',
                title: '#LDS#Compliance',
                sorting: '25',
                items,
            };
        });
    }
    static ɵfac = function RulesViolationsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesViolationsModule)(i0.ɵɵinject(i2$1.MenuService), i0.ɵɵinject(i2$1.ClassloggerService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RulesViolationsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CdrModule,
            CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            EuiCoreModule,
            EuiMaterialModule,
            ExtModule,
            FormsModule,
            JustificationModule,
            MatCardModule,
            MatStepperModule,
            MatExpansionModule,
            ReactiveFormsModule,
            TranslateModule,
            SelectedElementsModule,
            MitigatingControlContainerModule,
            HelpContextualModule,
            MatTableModule,
            DataViewModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    ResolveComponent,
                    RulesViolationsComponent,
                    RulesViolationsDetailsComponent,
                    RulesViolationsActionComponent,
                    RulesViolationsMultiActionComponent,
                    RulesViolationsSingleActionComponent,
                    MitigatingControlsPersonComponent,
                ],
                imports: [
                    CdrModule,
                    CommonModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    ExtModule,
                    FormsModule,
                    JustificationModule,
                    MatCardModule,
                    MatStepperModule,
                    MatExpansionModule,
                    ReactiveFormsModule,
                    TranslateModule,
                    SelectedElementsModule,
                    MitigatingControlContainerModule,
                    HelpContextualModule,
                    MatTableModule,
                    DataViewModule,
                ],
                exports: [MitigatingControlsPersonComponent],
                schemas: [CUSTOM_ELEMENTS_SCHEMA],
            }]
    }], () => [{ type: i2$1.MenuService }, { type: i2$1.ClassloggerService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RulesViolationsModule, { declarations: [ResolveComponent,
        RulesViolationsComponent,
        RulesViolationsDetailsComponent,
        RulesViolationsActionComponent,
        RulesViolationsMultiActionComponent,
        RulesViolationsSingleActionComponent,
        MitigatingControlsPersonComponent], imports: [CdrModule,
        CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        EuiMaterialModule,
        ExtModule,
        FormsModule,
        JustificationModule,
        MatCardModule,
        MatStepperModule,
        MatExpansionModule,
        ReactiveFormsModule,
        TranslateModule,
        SelectedElementsModule,
        MitigatingControlContainerModule,
        HelpContextualModule,
        MatTableModule,
        DataViewModule], exports: [MitigatingControlsPersonComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'compliance/rules',
        component: RulesComponent,
        canActivate: [ComplianceRulesGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.ComplianceRules,
        },
    },
    {
        path: 'compliance/rulesviolations/approve',
        component: RulesViolationsComponent,
        canActivate: [RuleViolationsGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.ComplianceRulesViolationsApprove,
        },
    },
];
class CplConfigModule {
    initializer;
    logger;
    constructor(initializer, logger) {
        this.initializer = initializer;
        this.logger = logger;
        this.logger.info(this, '🔥 CPL loaded');
        this.initializer.onInit(routes);
        this.logger.info(this, '▶︝ CPL initialized');
    }
    static ɵfac = function CplConfigModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CplConfigModule)(i0.ɵɵinject(InitService), i0.ɵɵinject(i2$1.ClassloggerService)); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: CplConfigModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            CdrModule,
            EuiCoreModule,
            FormsModule,
            MatButtonModule,
            MatCardModule,
            MatExpansionModule,
            MatFormFieldModule,
            MatIconModule,
            MatInputModule,
            MatListModule,
            ReactiveFormsModule,
            RouterModule.forChild(routes),
            RulesViolationsModule,
            RequestModule,
            TilesModule,
            TranslateModule,
            EuiCoreModule,
            IdentityRuleViolationsModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CplConfigModule, [{
        type: NgModule,
        args: [{
                declarations: [DashboardPluginComponent, CartItemComplianceCheckComponent],
                imports: [
                    CommonModule,
                    CdrModule,
                    EuiCoreModule,
                    FormsModule,
                    MatButtonModule,
                    MatCardModule,
                    MatExpansionModule,
                    MatFormFieldModule,
                    MatIconModule,
                    MatInputModule,
                    MatListModule,
                    ReactiveFormsModule,
                    RouterModule.forChild(routes),
                    RulesViolationsModule,
                    RequestModule,
                    TilesModule,
                    TranslateModule,
                    EuiCoreModule,
                    IdentityRuleViolationsModule,
                ],
            }]
    }], () => [{ type: InitService }, { type: i2$1.ClassloggerService }], null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(CplConfigModule, { declarations: [DashboardPluginComponent, CartItemComplianceCheckComponent], imports: [CommonModule,
        CdrModule,
        EuiCoreModule,
        FormsModule,
        MatButtonModule,
        MatCardModule,
        MatExpansionModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatListModule,
        ReactiveFormsModule, i3.RouterModule, RulesViolationsModule,
        RequestModule,
        TilesModule,
        TranslateModule,
        EuiCoreModule,
        IdentityRuleViolationsModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RulesModule {
    static ɵfac = function RulesModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RulesModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RulesModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
            EuiCoreModule,
            TranslateModule,
            CdrModule,
            DataTableModule,
            DataSourceToolbarModule,
            MatButtonModule,
            MatCardModule,
            MatTabsModule,
            StatisticsModule,
            ObjectHyperviewModule,
            HelpContextualModule,
            ExtModule,
            RulesViolationsModule,
            DataViewModule,
            MatTableModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesModule, [{
        type: NgModule,
        args: [{
                declarations: [RulesComponent, RulesSidesheetComponent, MitigatingControlsRulesComponent, ViolationsPerRuleComponent],
                imports: [
                    CommonModule,
                    EuiCoreModule,
                    TranslateModule,
                    CdrModule,
                    DataTableModule,
                    DataSourceToolbarModule,
                    MatButtonModule,
                    MatCardModule,
                    MatTabsModule,
                    StatisticsModule,
                    ObjectHyperviewModule,
                    HelpContextualModule,
                    ExtModule,
                    RulesViolationsModule,
                    DataViewModule,
                    MatTableModule,
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RulesModule, { declarations: [RulesComponent, RulesSidesheetComponent, MitigatingControlsRulesComponent, ViolationsPerRuleComponent], imports: [CommonModule,
        EuiCoreModule,
        TranslateModule,
        CdrModule,
        DataTableModule,
        DataSourceToolbarModule,
        MatButtonModule,
        MatCardModule,
        MatTabsModule,
        StatisticsModule,
        ObjectHyperviewModule,
        HelpContextualModule,
        ExtModule,
        RulesViolationsModule,
        DataViewModule,
        MatTableModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RoleComplianceViolationsModule {
    static ɵfac = function RoleComplianceViolationsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RoleComplianceViolationsModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RoleComplianceViolationsModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, EuiCoreModule, DataSourceToolbarModule, DataTableModule, MatCardModule, TranslateModule, LdsReplaceModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RoleComplianceViolationsModule, [{
        type: NgModule,
        args: [{
                declarations: [RoleComplianceViolationsComponent],
                imports: [CommonModule, EuiCoreModule, DataSourceToolbarModule, DataTableModule, MatCardModule, TranslateModule, LdsReplaceModule],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RoleComplianceViolationsModule, { declarations: [RoleComplianceViolationsComponent], imports: [CommonModule, EuiCoreModule, DataSourceToolbarModule, DataTableModule, MatCardModule, TranslateModule, LdsReplaceModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of cpl
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApiService, CplConfigModule, MitigatingControlsRulesService, RequestRuleViolation, RequestRuleViolationDetail, RoleComplianceViolationsModule, RulesModule };
//# sourceMappingURL=cpl.mjs.map
