import { ClassloggerService } from 'qbm';
import * as i0 from "@angular/core";
import * as i1 from "./compliance-violation-details/edit-mitigating-controls/mitigating-controls-request/mitigating-controls-request.component";
import * as i2 from "./compliance-violation-details/edit-mitigating-controls/edit-mitigating-controls.component";
import * as i3 from "./workflow-violation-details/workflow-violation-details.component";
import * as i4 from "./compliance-violation-details/compliance-violation-details.component";
import * as i5 from "./compliance-violation-details/edit-mitigating-controls/mitigating-controls-request/request-mitigating-control-filter.pipe";
import * as i6 from "qbm";
import * as i7 from "@angular/common";
import * as i8 from "@elemental-ui/core";
import * as i9 from "@angular/forms";
import * as i10 from "qer";
import * as i11 from "@angular/material/card";
import * as i12 from "@angular/material/expansion";
import * as i13 from "@ngx-translate/core";
import * as i14 from "../mitigating-control-container/mitigating-control-container.module";
export declare class RequestModule {
    constructor(logger: ClassloggerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RequestModule, [typeof i1.MitigatingControlsRequestComponent, typeof i2.EditMitigatingControlsComponent, typeof i3.WorkflowViolationDetailsComponent, typeof i4.ComplianceViolationDetailsComponent, typeof i5.RequestMitigatingControlFilterPipe], [typeof i6.CdrModule, typeof i7.CommonModule, typeof i6.DataSourceToolbarModule, typeof i6.DataTableModule, typeof i8.EuiCoreModule, typeof i8.EuiMaterialModule, typeof i9.FormsModule, typeof i10.JustificationModule, typeof i11.MatCardModule, typeof i12.MatExpansionModule, typeof i9.ReactiveFormsModule, typeof i13.TranslateModule, typeof i14.MitigatingControlContainerModule], [typeof i1.MitigatingControlsRequestComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RequestModule>;
}
