import { OnInit } from '@angular/core';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { ICartItemCheck } from '@imx-modules/imx-api-qer';
import { EntitySchema } from '@imx-modules/imx-qbm-dbts';
import { ColumnDependentReference, EntityService, MetadataService, SystemInfoService } from 'qbm';
import { RequestParameterDataEntity } from 'qer';
import { ItemValidatorService } from '../../item-validator/item-validator.service';
import { ApplicableRule } from '../compliance-violation-model';
import { ComplianceViolationService } from './compliance-violation.service';
import * as i0 from "@angular/core";
export declare class ComplianceViolationDetailsComponent implements OnInit {
    private readonly validator;
    private complianceApi;
    private readonly loadingService;
    private readonly metaData;
    private readonly entityService;
    private readonly sidesheets;
    private readonly translate;
    private readonly systemInfoService;
    data?: ICartItemCheck | any;
    pwoId: string;
    request: RequestParameterDataEntity;
    isApproval: boolean;
    mitigatingControlsPerViolation: boolean;
    cdrRuleDisplay: ColumnDependentReference | undefined;
    rules: ApplicableRule[];
    schema: EntitySchema;
    private hasRiskIndex;
    constructor(validator: ItemValidatorService, complianceApi: ComplianceViolationService, loadingService: EuiLoadingService, metaData: MetadataService, entityService: EntityService, sidesheets: EuiSidesheetService, translate: TranslateService, systemInfoService: SystemInfoService, data?: ICartItemCheck | any);
    ngOnInit(): Promise<void>;
    /**
     * Check for org type violations, we disable the mitigation control settings for them
     * @param item
     * @returns if we can access the EditMitigatingControlsComponent
     */
    canEditMitigationControls(item: ApplicableRule): boolean;
    addMitigationControls(item: ApplicableRule): Promise<void>;
    private getDisplayForSource;
    private loadTableNamesForSources;
    private loadCartItemViolations;
    private loadRequestViolations;
    private getDisplayRuleCdr;
    private buildCdrForViolations;
    private buildColumn;
    private checkHistoryForViolations;
    private isICartItemCheck;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComplianceViolationDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ComplianceViolationDetailsComponent, "imx-compliance-violation-details", never, { "pwoId": { "alias": "pwoId"; "required": false; }; "request": { "alias": "request"; "required": false; }; "isApproval": { "alias": "isApproval"; "required": false; }; }, {}, never, never, false, never>;
}
