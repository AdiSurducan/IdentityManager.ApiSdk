import { ComplianceViolation } from '@imx-modules/imx-api-cpl';
import { ApiService } from '../../api.service';
import * as i0 from "@angular/core";
export declare class ComplianceViolationService {
    private api;
    constructor(api: ApiService);
    getRequestViolations(pwoId: string): Promise<ComplianceViolation[]>;
    getMitigatingControlsPerViolation(): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComplianceViolationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ComplianceViolationService>;
}
