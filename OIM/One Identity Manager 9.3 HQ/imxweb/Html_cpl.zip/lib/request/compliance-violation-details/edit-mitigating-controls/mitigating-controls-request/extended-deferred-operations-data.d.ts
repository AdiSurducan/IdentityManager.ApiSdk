import { FormControl } from '@angular/forms';
import { DeferredOperationMControlData } from '@imx-modules/imx-api-cpl';
import { ColumnDependentReference, EntityService } from 'qbm';
import { MitigatingControlData } from './mitigating-control-data.interface';
export declare class ExtendedDeferredOperationsData implements MitigatingControlData {
    private readonly deferred;
    formControl: FormControl<string>;
    cdrs: ColumnDependentReference[];
    isDeferredData: boolean;
    editable: boolean;
    get uidMitigatingControl(): string;
    set uidMitigatingControl(value: string);
    get displayMitigatingControls(): string;
    isInActive: boolean;
    data: undefined;
    constructor(deferred: DeferredOperationMControlData, entiyService: EntityService);
}
