import { ComplianceViolation, PortalRules } from '@imx-modules/imx-api-cpl';
import { ColumnDependentReference } from 'qbm';
export interface ApplicableRule {
    rule?: PortalRules;
    violationDetail: ComplianceViolation;
    cdrLists: RuleCdrs;
}
export interface RuleCdrs {
    common: ColumnDependentReference[];
    sources?: ColumnDependentReference[];
}
