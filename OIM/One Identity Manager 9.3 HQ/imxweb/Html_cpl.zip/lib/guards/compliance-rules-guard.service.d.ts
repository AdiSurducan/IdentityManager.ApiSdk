import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { AppConfigService, RouteGuardService } from 'qbm';
import { CplPermissionsService } from '../rules/admin/cpl-permissions.service';
import * as i0 from "@angular/core";
export declare class ComplianceRulesGuardService {
    private readonly permissionService;
    private readonly appConfig;
    private readonly router;
    private readonly routeGuardService;
    constructor(permissionService: CplPermissionsService, appConfig: AppConfigService, router: Router, routeGuardService: RouteGuardService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComplianceRulesGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ComplianceRulesGuardService>;
}
