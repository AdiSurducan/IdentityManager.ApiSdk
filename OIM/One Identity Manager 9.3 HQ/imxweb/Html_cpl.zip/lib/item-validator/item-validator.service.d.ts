import { PortalRules } from '@imx-modules/imx-api-cpl';
import { EntitySchema, ExtendedTypedEntityCollection } from '@imx-modules/imx-qbm-dbts';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class ItemValidatorService {
    private readonly api;
    constructor(api: ApiService);
    getRules(): Promise<ExtendedTypedEntityCollection<PortalRules, unknown>>;
    getRulesSchema(): EntitySchema;
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemValidatorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ItemValidatorService>;
}
