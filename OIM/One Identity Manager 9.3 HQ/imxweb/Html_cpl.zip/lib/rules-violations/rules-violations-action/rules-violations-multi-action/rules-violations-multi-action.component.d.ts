import { OnInit } from '@angular/core';
import { AbstractControl, UntypedFormGroup } from '@angular/forms';
import { RulesViolationsAction } from '../rules-violations-action.interface';
import { ColumnDependentReference } from 'qbm';
import * as i0 from "@angular/core";
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a multiple rules violations.
 * There is an alternative component for the case of a decision for a single rules
 * violation as well: {@link RulesViolationsSingleActionComponent}.
 */
export declare class RulesViolationsMultiActionComponent implements OnInit {
    /**
     * @ignore since this is only an internal component.
     *
     * Data coming from the service about the rules violations.
     */
    data: RulesViolationsAction;
    /**
     * @ignore since this is only an internal component.
     *
     * The form group to which the necessary form fields will be added.
     */
    formGroup: UntypedFormGroup;
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * The references depending on the columns of the rules violations that are displayed/edited during the decision.
     *
     */
    readonly columns: ColumnDependentReference[];
    /**
     * @ignore since this is only an internal component
     *
     * Sets up the {@link columns} to be displayed/edited during OnInit lifecycle hook.
     */
    ngOnInit(): void;
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * Handles the event emitted when a cdr editor created a new form control.
     *
     * @param name The name of the form control
     * @param control The form control
     */
    onFormControlCreated(name: string, control: AbstractControl): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesViolationsMultiActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RulesViolationsMultiActionComponent, "imx-rules-violations-multi-action", never, { "data": { "alias": "data"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; }, {}, never, never, false, never>;
}
