import { UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { RulesViolationsAction } from './rules-violations-action.interface';
import * as i0 from "@angular/core";
/**
 * Component displayed in a sidesheet to make a decision for one or more rules violations.
 *
 * Uses two alternate views
 * <ul>
 * <li>a) a simple view for a single rules violation</li>
 * <li>b) a complex view using bulk items for multiple rules violations.</li>
 * </ul>
 */
export declare class RulesViolationsActionComponent {
    readonly data: RulesViolationsAction;
    readonly sideSheetRef: EuiSidesheetRef;
    /**
     * The form group to which the created form controls will be added.
     */
    readonly formGroup: UntypedFormGroup;
    /**
     * Creates a new RulesViolationsActionComponent
     * @param data The pre-calculated data object.
     * @param sideSheetRef A reference to the sidesheet containing this component.
     */
    constructor(data: RulesViolationsAction, sideSheetRef: EuiSidesheetRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesViolationsActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RulesViolationsActionComponent, "imx-rules-violations-action", never, {}, {}, never, never, false, never>;
}
