import { DeferredOperationData, PortalPersonMitigatingcontrols } from '@imx-modules/imx-api-cpl';
import { CollectionLoadParameters, EntityKeysData, EntitySchema, ExtendedTypedEntityCollection } from '@imx-modules/imx-qbm-dbts';
import { ApiService } from '../../api.service';
import { PersonMitigatingControls } from './person-mitigating-controls';
import * as i0 from "@angular/core";
export declare class MitigatingControlsPersonService {
    private apiService;
    constructor(apiService: ApiService);
    get mitigationSchema(): EntitySchema;
    getControls(uidPerson: string, uidNonCompliance: string): Promise<ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, DeferredOperationData>>;
    createControl(uidPerson: string, uidNonCompliance: string): PersonMitigatingControls;
    postControl(uidPerson: string, uidNonCompliance: string, mControl: PortalPersonMitigatingcontrols): Promise<void>;
    postControlRequest(uidPerson: string, uidNonCompliance: string, uidPersonWantsOrg: string, uidMitigatinControl: string): Promise<void>;
    deleteControl(mControl: PersonMitigatingControls): Promise<void>;
    getCandidates(uid: string, uidNonCompliance: string, data: EntityKeysData, parameter?: CollectionLoadParameters): Promise<import("@imx-modules/imx-qbm-dbts").ExtendedEntityCollectionData<import("@imx-modules/imx-api-cpl").FkCandidateInformation>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MitigatingControlsPersonService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MitigatingControlsPersonService>;
}
