import { FormControl } from '@angular/forms';
import { PortalPersonMitigatingcontrols } from '@imx-modules/imx-api-cpl';
import { ColumnDependentReference } from 'qbm';
/**
 * Class thats extends the {@link PortalPersonMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
export declare class PersonMitigatingControls extends PortalPersonMitigatingcontrols {
    editable: boolean;
    readonly baseObject: PortalPersonMitigatingcontrols;
    /**
     * The property list depending on the value of the state of a {@link PortalPersonMitigatingcontrols}.
     */
    cdrs: ColumnDependentReference[];
    formControl: FormControl<string>;
    readonly isDeferredData = false;
    constructor(editable: boolean, baseObject: PortalPersonMitigatingcontrols);
    get uidMitigatingControl(): string;
    set uidMitigatingControl(value: string);
    private initPropertyInfo;
}
