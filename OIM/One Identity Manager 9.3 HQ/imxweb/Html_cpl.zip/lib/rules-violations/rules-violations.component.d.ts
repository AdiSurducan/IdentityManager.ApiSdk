import { OnDestroy, OnInit } from '@angular/core';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute } from '@angular/router';
import { DataModel, EntitySchema, IClientProperty } from '@imx-modules/imx-qbm-dbts';
import { ViewConfigData } from '@imx-modules/imx-api-qer';
import { BusyService, ClassloggerService, DataTableGroupedData, DataViewSource } from 'qbm';
import { ViewConfigService } from 'qer';
import { MitigatingControlsPersonService } from './mitigating-controls-person/mitigating-controls-person.service';
import { RulesViolationsActionService } from './rules-violations-action/rules-violations-action.service';
import { RulesViolationsApproval } from './rules-violations-approval';
import { RulesViolationsService } from './rules-violations.service';
import * as i0 from "@angular/core";
/**
 * Component that shows all rules violations that the user can approve or deny.
 * Therefore, the user can also view some information about the rules violations.
 *
 * Initially only the pending rules violations are shown.
 *
 */
export declare class RulesViolationsComponent implements OnInit, OnDestroy {
    readonly rulesViolationsService: RulesViolationsService;
    readonly actionService: RulesViolationsActionService;
    readonly viewConfigService: ViewConfigService;
    readonly mControlsProvider: MitigatingControlsPersonService;
    private readonly sidesheet;
    private readonly translate;
    private readonly logger;
    private readonly activatedRoute;
    private readonly elementalBusyService;
    dataSource: DataViewSource<RulesViolationsApproval>;
    isMControlPerViolation: boolean;
    dataModel: DataModel;
    selectedRulesViolations: RulesViolationsApproval[];
    groupedData: {
        [key: string]: DataTableGroupedData;
    };
    entitySchema: EntitySchema;
    busyService: BusyService;
    displayedColumns: IClientProperty[];
    private viewConfig;
    private viewConfigPath;
    private readonly subscriptions;
    constructor(rulesViolationsService: RulesViolationsService, actionService: RulesViolationsActionService, viewConfigService: ViewConfigService, mControlsProvider: MitigatingControlsPersonService, sidesheet: EuiSidesheetService, translate: TranslateService, logger: ClassloggerService, activatedRoute: ActivatedRoute, elementalBusyService: EuiLoadingService, dataSource: DataViewSource<RulesViolationsApproval>);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    updateConfig(config: ViewConfigData): Promise<void>;
    deleteConfigById(id: string): Promise<void>;
    getData(): Promise<void>;
    onSelectionChanged(items: RulesViolationsApproval[]): void;
    /**
     * Opens the {@link RulesViolationsDetailsComponent} sidesheet thats shows some informations of the selected rules violation.
     * @param selectedRulesViolation the selected {@link RulesViolationsApproval}
     */
    viewDetails(entity: RulesViolationsApproval): Promise<void>;
    private updateFiltersFromRouteParams;
    private tryApplyFilter;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesViolationsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RulesViolationsComponent, "imx-rules-violations", never, { "isMControlPerViolation": { "alias": "isMControlPerViolation"; "required": false; }; }, {}, never, never, false, never>;
}
