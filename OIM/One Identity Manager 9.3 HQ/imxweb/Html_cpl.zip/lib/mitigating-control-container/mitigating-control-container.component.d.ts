import { ChangeDetectorRef, EventEmitter } from '@angular/core';
import { FormArray } from '@angular/forms';
import { EuiSelectOption } from '@elemental-ui/core';
import { ConfirmationService } from 'qbm';
import { ExtendedDeferredOperationsData } from '../request/compliance-violation-details/edit-mitigating-controls/mitigating-controls-request/extended-deferred-operations-data';
import { RequestMitigatingControls } from '../request/compliance-violation-details/edit-mitigating-controls/mitigating-controls-request/request-mitigating-controls';
import { PersonMitigatingControls } from '../rules-violations/mitigating-controls-person/person-mitigating-controls';
import * as i0 from "@angular/core";
export declare class MitigatingControlContainerComponent {
    private readonly cd;
    private readonly confirmationService;
    mControls: Array<RequestMitigatingControls | ExtendedDeferredOperationsData | PersonMitigatingControls>;
    mitigatingCaption: string;
    formArray: FormArray;
    options: EuiSelectOption[];
    controlDeleted: EventEmitter<PersonMitigatingControls | RequestMitigatingControls>;
    controlsRequested: EventEmitter<void>;
    constructor(cd: ChangeDetectorRef, confirmationService: ConfirmationService);
    filter: (option: EuiSelectOption, searchInputValue: string) => boolean;
    onSelectionChange(mcontrol: RequestMitigatingControls | ExtendedDeferredOperationsData | PersonMitigatingControls, option: EuiSelectOption | EuiSelectOption[]): Promise<void>;
    onOpenChange(isopen: boolean, mControl: RequestMitigatingControls | ExtendedDeferredOperationsData | PersonMitigatingControls): void;
    onDelete(mControl: RequestMitigatingControls | ExtendedDeferredOperationsData | PersonMitigatingControls | undefined, index: number): Promise<void>;
    onCreateControl(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MitigatingControlContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MitigatingControlContainerComponent, "imx-mitigating-control-container", never, { "mControls": { "alias": "mControls"; "required": false; }; "mitigatingCaption": { "alias": "mitigatingCaption"; "required": false; }; "formArray": { "alias": "formArray"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, { "controlDeleted": "controlDeleted"; "controlsRequested": "controlsRequested"; }, never, never, false, never>;
}
