import * as i0 from "@angular/core";
import * as i1 from "./mitigating-control-container.component";
import * as i2 from "@angular/common";
import * as i3 from "@elemental-ui/core";
import * as i4 from "qbm";
import * as i5 from "@ngx-translate/core";
export declare class MitigatingControlContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MitigatingControlContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MitigatingControlContainerModule, [typeof i1.MitigatingControlContainerComponent], [typeof i2.CommonModule, typeof i3.EuiCoreModule, typeof i3.EuiMaterialModule, typeof i4.CdrModule, typeof i5.TranslateModule], [typeof i1.MitigatingControlContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MitigatingControlContainerModule>;
}
