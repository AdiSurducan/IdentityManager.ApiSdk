import { EuiLoadingService } from '@elemental-ui/core';
import { RoleComplianceViolations } from '@imx-modules/imx-api-cpl';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class RoleComplianceViolationsService {
    private apiservice;
    private busyService;
    private busyIndicator;
    constructor(apiservice: ApiService, busyService: EuiLoadingService);
    getRoleComplianceViolations(table: string, uidRole: string): Promise<RoleComplianceViolations>;
    handleOpenLoader(): void;
    handleCloseLoader(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoleComplianceViolationsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoleComplianceViolationsService>;
}
