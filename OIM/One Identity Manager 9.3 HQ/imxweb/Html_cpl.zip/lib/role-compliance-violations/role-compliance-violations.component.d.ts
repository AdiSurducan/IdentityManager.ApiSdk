import { OnInit } from '@angular/core';
import { DisplayColumns, EntitySchema } from '@imx-modules/imx-qbm-dbts';
import { DataSourceToolbarSettings, DynamicTabDataProviderDirective, MetadataService } from 'qbm';
import { RoleComplianceViolationsWrapperService } from './role-compliance-violations-wrapper';
import { RoleComplianceViolationsService } from './role-compliance-violations.service';
import * as i0 from "@angular/core";
export declare class RoleComplianceViolationsComponent implements OnInit {
    private readonly entityService;
    private readonly roleComplianceViolationService;
    private readonly metaDataService;
    tablename: string;
    uidRole: string;
    dstSettings: DataSourceToolbarSettings;
    readonly DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    showHelperAlert: boolean;
    keyDescription: string;
    private displayedColumns;
    constructor(dataProvider: DynamicTabDataProviderDirective, entityService: RoleComplianceViolationsWrapperService, roleComplianceViolationService: RoleComplianceViolationsService, metaDataService: MetadataService);
    ngOnInit(): Promise<void>;
    getData(): Promise<void>;
    onHelperDismissed(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoleComplianceViolationsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RoleComplianceViolationsComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
