import { TypedEntity, EntitySchema } from '@imx-modules/imx-qbm-dbts';
export declare class RoleComplianceViolationTypedEntity extends TypedEntity {
    static GetEntitySchema(): EntitySchema;
}
