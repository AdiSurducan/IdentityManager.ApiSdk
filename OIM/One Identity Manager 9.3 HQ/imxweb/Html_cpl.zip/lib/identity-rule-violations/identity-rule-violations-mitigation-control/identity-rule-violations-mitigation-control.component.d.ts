import { OnInit } from '@angular/core';
import { EuiLoadingService } from '@elemental-ui/core';
import { CollectionLoadParameters, EntitySchema, ExtendedTypedEntityCollection, IClientProperty, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { DataSourceToolbarSettings } from 'qbm';
import * as i0 from "@angular/core";
export declare class IdentityRuleViolationsMitigationControlComponent implements OnInit {
    private readonly busy;
    data: {
        getData: (param: CollectionLoadParameters) => Promise<ExtendedTypedEntityCollection<TypedEntity, unknown>>;
        entitySchema: EntitySchema;
        displayedColumns: IClientProperty[];
    };
    dstSettings: DataSourceToolbarSettings;
    constructor(busy: EuiLoadingService, data: {
        getData: (param: CollectionLoadParameters) => Promise<ExtendedTypedEntityCollection<TypedEntity, unknown>>;
        entitySchema: EntitySchema;
        displayedColumns: IClientProperty[];
    });
    ngOnInit(): Promise<void>;
    onSearch(key: string): Promise<void>;
    getData(param: CollectionLoadParameters): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdentityRuleViolationsMitigationControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IdentityRuleViolationsMitigationControlComponent, "imx-identity-rule-violations-mitigation-control", never, {}, {}, never, never, false, never>;
}
