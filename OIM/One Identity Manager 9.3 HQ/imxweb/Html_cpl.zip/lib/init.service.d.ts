import { Route, Router } from '@angular/router';
import { NotificationRegistryService, ShoppingCartValidationDetailService } from 'qer';
import { ExtService, MenuService } from 'qbm';
import { RoleComplianceViolationsService } from './role-compliance-violations/role-compliance-violations.service';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly extService;
    private readonly router;
    private readonly menuService;
    private readonly cplService;
    private readonly notificationService;
    private readonly validationDetailService;
    constructor(extService: ExtService, router: Router, menuService: MenuService, cplService: RoleComplianceViolationsService, notificationService: NotificationRegistryService, validationDetailService: ShoppingCartValidationDetailService);
    onInit(routes: Route[]): void;
    private checkCompliances;
    private addRoutes;
    private setupMenu;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
