import { OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { CollectionLoadParameters, EntitySchema, TypedEntity } from '@imx-modules/imx-qbm-dbts';
import { DataModelWrapper, DataSourceToolbarSettings, DataSourceWrapper, DataTableGroupedData } from 'qbm';
import { RulesViolationsApproval } from '../../../rules-violations/rules-violations-approval';
import { RulesViolationsService } from '../../../rules-violations/rules-violations.service';
import * as i0 from "@angular/core";
export declare class ViolationsPerRuleComponent implements OnInit {
    private readonly rulesViolationsService;
    private readonly translate;
    private readonly sidesheet;
    dataModelWrapper: DataModelWrapper;
    dstWrapper: DataSourceWrapper<RulesViolationsApproval>;
    dstSettings: DataSourceToolbarSettings | undefined;
    groupedData: {
        [key: string]: DataTableGroupedData;
    };
    entitySchema: EntitySchema;
    uidRule: string;
    constructor(rulesViolationsService: RulesViolationsService, translate: TranslateService, sidesheet: EuiSidesheetService);
    ngOnInit(): Promise<void>;
    /**
     * Handles grouping changes with reload
     * @param groupKey The key of the group
     */
    onGroupingChange(groupKey: string): Promise<void>;
    /**
     * Opens rules-violations-details sidesheet, where you can manage the selected rule.
     * @param rule The selected rule from the Rule Violations list
     */
    showRulesViolationsDetail(entity: TypedEntity): Promise<void>;
    /**
     * Loads the dstSettings with load parameters
     * @param parameter Load parameter
     */
    getData(parameter?: CollectionLoadParameters): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViolationsPerRuleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViolationsPerRuleComponent, "imx-violations-per-rule", never, { "uidRule": { "alias": "uidRule"; "required": false; }; }, {}, never, never, false, never>;
}
