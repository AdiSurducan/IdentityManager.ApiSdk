export declare function isExceptionAdmin(groups: string[]): boolean;
export declare function isRuleStatistics(features: string[]): boolean;
