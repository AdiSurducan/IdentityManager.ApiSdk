import { PortalRulesMitigatingcontrols } from '@imx-modules/imx-api-cpl';
import { ExtendedTypedEntityCollection } from '@imx-modules/imx-qbm-dbts';
import { ApiService } from '../../api.service';
import { RulesMitigatingControls } from './rules-mitigating-controls';
import * as i0 from "@angular/core";
export declare class MitigatingControlsRulesService {
    private apiService;
    constructor(apiService: ApiService);
    getControls(uidNonCompliance: string): Promise<ExtendedTypedEntityCollection<RulesMitigatingControls, unknown>>;
    createControl(uidCompliance: string): RulesMitigatingControls;
    postControl(uidNonCompliance: string, mControl: PortalRulesMitigatingcontrols): Promise<void>;
    deleteControl(mControl: PortalRulesMitigatingcontrols): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MitigatingControlsRulesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MitigatingControlsRulesService>;
}
