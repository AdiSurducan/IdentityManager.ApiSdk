import { ColumnDependentReference } from 'qbm';
import { PortalRulesMitigatingcontrols } from '@imx-modules/imx-api-cpl';
/**
 * Class thats extends the {@link PortalRulesMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
export declare class RulesMitigatingControls extends PortalRulesMitigatingcontrols {
    readonly baseObject: PortalRulesMitigatingcontrols;
    /**
     * The property list depending on the value of the state of a {@link PortalRulesMitigatingcontrols}.
     */
    readonly propertyInfo: ColumnDependentReference[];
    constructor(baseObject: PortalRulesMitigatingcontrols);
    private initPropertyInfo;
}
