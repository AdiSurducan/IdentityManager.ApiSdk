import { OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DashboardService, PendingItemsType, UserModelService } from 'qer';
import { CplPermissionsService } from '../rules/admin/cpl-permissions.service';
import * as i0 from "@angular/core";
export declare class DashboardPluginComponent implements OnInit {
    readonly router: Router;
    private readonly dashboardService;
    private readonly permissionService;
    private readonly userModelSvc;
    pendingItems: PendingItemsType;
    isExceptionAdmin: boolean;
    constructor(router: Router, dashboardService: DashboardService, permissionService: CplPermissionsService, userModelSvc: UserModelService);
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardPluginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardPluginComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
