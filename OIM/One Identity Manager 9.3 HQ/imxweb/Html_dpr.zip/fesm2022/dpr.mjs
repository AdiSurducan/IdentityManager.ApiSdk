import * as i5 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Component, Inject, Injectable, NgModule } from '@angular/core';
import * as i6 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i12 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i14 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i3 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i2 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i1 from 'qbm';
import { BusyService, calculateSidesheetWidth, DataSourceToolbarModule, DataTableModule, SelectedElementsModule, LdsReplaceModule, BusyIndicatorModule } from 'qbm';
import { OutstandingAction, V2Client, TypedClient } from '@imx-modules/imx-api-dpr';
import * as i3$1 from '@angular/material/button';
import * as i4 from '@angular/material/list';
import { TypedEntity, ReadOnlyEntity, ValType, DisplayColumns } from '@imx-modules/imx-qbm-dbts';
import * as i2$1 from '@angular/material/card';
import * as i7 from '@angular/material/core';
import * as i10 from '@angular/material/checkbox';
import * as i11 from '@angular/material/form-field';
import * as i13 from '@angular/material/select';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function DependenciesComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 8)(1, "span", 7);
    i0.ɵɵtext(2, "#LDS#The following objects must also be added to the target system, as they depend on the objects to be added.");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
} }
function DependenciesComponent_eui_alert_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 9)(1, "span", 7);
    i0.ɵɵtext(2, "#LDS#The following objects must also be deleted, as they depend on the objects to be deleted.");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("condensed", true)("colored", true);
} }
function DependenciesComponent_mat_list_item_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-list-item", 10);
    i0.ɵɵtext(1);
    i0.ɵɵelementStart(2, "span", 11);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const u_r1 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("", u_r1.Display, " -\u00A0");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(u_r1.ObjectType);
} }
class DependenciesComponent {
    data;
    sidesheetRef;
    constructor(data, sidesheetRef) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
    }
    async save() {
        this.sidesheetRef.close(true);
    }
    isPublish() {
        return this.data.action === OutstandingAction.Publish;
    }
    isDelete() {
        return this.data.action === OutstandingAction.Delete;
    }
    static ɵfac = function DependenciesComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DependenciesComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i3.EuiSidesheetRef)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DependenciesComponent, selectors: [["ng-component"]], decls: 9, vars: 3, consts: [["eui-sidesheet-content", "", 1, "sidesheet-margin"], ["type", "info", 3, "condensed", "colored", 4, "ngIf"], ["type", "warning", 3, "condensed", "colored", 4, "ngIf"], ["role", "list"], ["role", "listitem", 4, "ngFor", "ngForOf"], ["eui-sidesheet-action", ""], ["data-imx-identifier", "dependencies-proceed", "mat-flat-button", "", "color", "primary", "type", "button", "form", "form", 3, "click"], ["translate", ""], ["type", "info", 3, "condensed", "colored"], ["type", "warning", 3, "condensed", "colored"], ["role", "listitem"], [1, "object-type"]], template: function DependenciesComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, DependenciesComponent_eui_alert_1_Template, 3, 2, "eui-alert", 1)(2, DependenciesComponent_eui_alert_2_Template, 3, 2, "eui-alert", 2);
            i0.ɵɵelementStart(3, "mat-list", 3);
            i0.ɵɵtemplate(4, DependenciesComponent_mat_list_item_4_Template, 4, 2, "mat-list-item", 4);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "div", 5)(6, "button", 6);
            i0.ɵɵlistener("click", function DependenciesComponent_Template_button_click_6_listener() { return ctx.save(); });
            i0.ɵɵelementStart(7, "span", 7);
            i0.ɵɵtext(8, "#LDS#Proceed");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isPublish());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.isDelete());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", ctx.data.dependencies);
        } }, dependencies: [i5.NgForOf, i5.NgIf, i3.EuiAlertComponent, i3.EuiSidesheetContentDirective, i3$1.MatButton, i4.MatList, i4.MatListItem, i2.TranslateDirective], styles: [".sidesheet-margin[_ngcontent-%COMP%]{margin:1em}.object-type[_ngcontent-%COMP%]{font-style:italic}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DependenciesComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content class=\"sidesheet-margin\">\n  <eui-alert type=\"info\" [condensed]=\"true\" [colored]=\"true\" *ngIf=\"isPublish()\">\n    <span translate>#LDS#The following objects must also be added to the target system, as they depend on the objects to be added.</span>\n  </eui-alert>\n\n  <eui-alert type=\"warning\" [condensed]=\"true\" [colored]=\"true\" *ngIf=\"isDelete()\">\n    <span translate>#LDS#The following objects must also be deleted, as they depend on the objects to be deleted.</span>\n  </eui-alert>\n\n  <mat-list role=\"list\">\n    <mat-list-item role=\"listitem\" *ngFor=\"let u of data.dependencies\"\n      >{{ u.Display }} -&nbsp;<span class=\"object-type\">{{ u.ObjectType }}</span>\n    </mat-list-item>\n  </mat-list>\n</div>\n\n<div eui-sidesheet-action>\n  <button data-imx-identifier=\"dependencies-proceed\" mat-flat-button color=\"primary\" type=\"button\" (click)=\"save()\" form=\"form\">\n    <span translate>#LDS#Proceed</span>\n  </button>\n</div>\n", styles: [".sidesheet-margin{margin:1em}.object-type{font-style:italic}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i3.EuiSidesheetRef }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DependenciesComponent, { className: "DependenciesComponent", filePath: "lib\\outstanding\\dependencies.component.ts", lineNumber: 35 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class OutstandingObjectEntity extends TypedEntity {
    ObjectType = this.GetEntityValue('ObjectType');
    ObjectKey = this.GetEntityValue('ObjectKey');
    Display = this.GetEntityValue('Display');
    CanPublish = this.GetEntityValue('CanPublish');
    CanDelete = this.GetEntityValue('CanDelete');
    CanDeleteRestrictionReason = this.GetEntityValue('CanDeleteRestrictionReason');
    CanPublishRestrictionReason = this.GetEntityValue('CanPublishRestrictionReason');
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApiService {
    config;
    logger;
    translationProvider;
    tc;
    get typedClient() {
        return this.tc;
    }
    c;
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing DPR API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    static ɵfac = function ApiService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApiService, factory: ApiService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], () => [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i1.ImxTranslationProviderService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class OutstandingService {
    apiService;
    constructor(apiService) {
        this.apiService = apiService;
    }
    async getNamespaces() {
        return this.apiService.typedClient.OpsupportNamespaces.Get({ PageSize: 1024 });
    }
    async getTableData(newNamespace) {
        return this.apiService.typedClient.OpsupportOutstandingTables.Get({ PageSize: 1024, namespace: newNamespace.Ident_DPRNameSpace.value });
    }
    async getDependencies(action, values) {
        return this.apiService.client.opsupport_outstanding_dependencies_post(action, values);
    }
    async getOutstandingTable(tableName, namespace, actionfilter) {
        return this.apiService.client.opsupport_outstanding_table_get(tableName, {
            namespace: namespace,
            actionfilter: actionfilter,
        });
    }
    getOutstandingNamespace(namespace, actionfilter) {
        return this.apiService.client.opsupport_outstanding_namespace_get(namespace, { actionfilter: actionfilter });
    }
    processObjects(action, bulk, objects) {
        return this.apiService.client.opsupport_outstanding_process_post(action, objects, { bulk: bulk });
    }
    static ɵfac = function OutstandingService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OutstandingService)(i0.ɵɵinject(ApiService)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: OutstandingService, factory: OutstandingService.ɵfac });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OutstandingService, [{
        type: Injectable
    }], () => [{ type: ApiService }], null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$1 = () => ["search", "filter"];
function SelectedItemsComponent_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
    i0.ɵɵelementStart(1, "div", 9);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r2 = ctx.$implicit;
    i0.ɵɵtextInterpolate1(" ", data_r2.Display.value, " ");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(data_r2.ObjectType.value);
} }
class SelectedItemsComponent {
    data;
    sortedEntities;
    displayedColumns;
    dstSettings;
    searchedEntities;
    navigationState = {};
    constructor(data) {
        this.data = data;
        this.displayedColumns = [data.schema.Columns.Display];
        this.sortedEntities = data.objects.sort((a, b) => a.Display.value.localeCompare(b.Display.value));
        this.searchedEntities = [...this.sortedEntities];
    }
    ngOnInit() {
        this.getData({ StartIndex: 0, PageSize: 20 });
    }
    search(key) {
        if (key === '') {
            this.searchedEntities = [...this.sortedEntities];
        }
        else {
            this.searchedEntities = this.sortedEntities.filter((elem) => elem.Display.value.toLocaleLowerCase().includes(key.toLocaleLowerCase()));
        }
        this.getData({ StartIndex: 0, search: key });
    }
    getData(state) {
        this.navigationState = { ...this.navigationState, ...state };
        const data = this.searchedEntities.slice(this.navigationState.StartIndex, this.navigationState?.StartIndex && this.navigationState?.PageSize
            ? this.navigationState.StartIndex + this.navigationState?.PageSize
            : 0);
        this.dstSettings = {
            navigationState: this.navigationState,
            dataSource: {
                Data: data,
                totalCount: this.searchedEntities.length,
            },
            entitySchema: this.data.schema,
            displayedColumns: this.displayedColumns,
        };
    }
    static ɵfac = function SelectedItemsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SelectedItemsComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SelectedItemsComponent, selectors: [["imx-selected-items"]], decls: 11, vars: 10, consts: [["dst", ""], ["dataTable", ""], [1, "imx-sidesheet-content__overflow"], [1, "imx-sidesheet-content"], [3, "navigationStateChanged", "search", "settings", "options"], [1, "imx-table-container"], ["mode", "manual", "data-imx-identifier", "outstanding-objects-table", 3, "dst", "detailViewVisible", "selectable"], ["columnName", "Display", 3, "columnLabel"], ["data-imx-identifier", "typed-entity-candidates-paginator", 3, "dst"], [1, "object-type"]], template: function SelectedItemsComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 2)(1, "mat-card", 3)(2, "imx-data-source-toolbar", 4, 0);
            i0.ɵɵlistener("navigationStateChanged", function SelectedItemsComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.getData($event)); })("search", function SelectedItemsComponent_Template_imx_data_source_toolbar_search_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.search($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "div", 5)(5, "imx-data-table", 6, 1)(7, "imx-data-table-generic-column", 7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵtemplate(9, SelectedItemsComponent_ng_template_9_Template, 3, 2, "ng-template");
            i0.ɵɵelementEnd()()();
            i0.ɵɵelement(10, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            const dst_r3 = i0.ɵɵreference(3);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(9, _c0$1));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", dst_r3)("detailViewVisible", false)("selectable", false);
            i0.ɵɵadvance(2);
            i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(8, 7, "#LDS#Display name"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", dst_r3);
        } }, dependencies: [i1.DataSourceToolbarComponent, i1.DataSourcePaginatorComponent, i1.DataTableComponent, i1.DataTableGenericColumnComponent, i2$1.MatCard, i2.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.object-type[_ngcontent-%COMP%]{font-style:italic;font-size:smaller}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SelectedItemsComponent, [{
        type: Component,
        args: [{ selector: 'imx-selected-items', template: "<div class=\"imx-sidesheet-content__overflow\">\n  <mat-card class=\"imx-sidesheet-content\">\n    <imx-data-source-toolbar\n      #dst\n      [settings]=\"dstSettings\"\n      (navigationStateChanged)=\"getData($event)\"\n      (search)=\"search($event)\"\n      [options]=\"['search', 'filter']\"\n    >\n    </imx-data-source-toolbar>\n\n    <div class=\"imx-table-container\">\n      <imx-data-table\n        #dataTable\n        [dst]=\"dst\"\n        [detailViewVisible]=\"false\"\n        [selectable]=\"false\"\n        mode=\"manual\"\n        data-imx-identifier=\"outstanding-objects-table\"\n      >\n        <imx-data-table-generic-column columnName=\"Display\" columnLabel=\"{{ '#LDS#Display name' | translate }}\">\n          <ng-template let-data>\n            {{ data.Display.value }}\n            <div class=\"object-type\">{{ data.ObjectType.value }}</div>\n          </ng-template>\n        </imx-data-table-generic-column>\n      </imx-data-table>\n    </div>\n    <imx-data-source-paginator [dst]=\"dst\" data-imx-identifier=\"typed-entity-candidates-paginator\"> </imx-data-source-paginator>\n  </mat-card>\n</div>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-sidesheet-content{display:flex;flex-direction:column;overflow:hidden}.object-type{font-style:italic;font-size:smaller}\n"] }]
    }], () => [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SelectedItemsComponent, { className: "SelectedItemsComponent", filePath: "lib\\outstanding\\selected-items\\selected-items.component.ts", lineNumber: 39 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0 = a0 => ({ "imx-hidden": a0 });
const _c1 = () => ["filter"];
function OutstandingComponent_ng_container_0_eui_alert_4_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-alert", 22);
    i0.ɵɵlistener("dismissed", function OutstandingComponent_ng_container_0_eui_alert_4_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.onHelperDismissed()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, ctx_r2.LdsOutstandingText), " ");
} }
function OutstandingComponent_ng_container_0_mat_spinner_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner");
} }
function OutstandingComponent_ng_container_0_mat_option_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-option", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const pr_r4 = ctx.$implicit;
    i0.ɵɵproperty("value", pr_r4);
    i0.ɵɵattribute("data-imx-identifier", "outstanding-namespace-option-" + pr_r4.GetEntity().GetDisplay());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", pr_r4.GetEntity().GetDisplay(), " ");
} }
function OutstandingComponent_ng_container_0_mat_spinner_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner", 24);
} }
function OutstandingComponent_ng_container_0_mat_option_19_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-option", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const pr_r5 = ctx.$implicit;
    i0.ɵɵproperty("value", pr_r5);
    i0.ɵɵattribute("data-imx-identifier", "outstanding-table-option-" + pr_r5.GetEntity().GetDisplay());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate2(" ", pr_r5.GetEntity().GetDisplay(), " (", pr_r5.CountOutstanding.value, ") ");
} }
function OutstandingComponent_ng_container_0_imx_data_table_28_ng_template_4_eui_badge_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 32);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r7 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("matTooltip", data_r7.CanDeleteRestrictionReason.value);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Cannot delete"), " ");
} }
function OutstandingComponent_ng_container_0_imx_data_table_28_ng_template_4_eui_badge_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 32);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r7 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("matTooltip", data_r7.CanPublishRestrictionReason.value);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Cannot add"), " ");
} }
function OutstandingComponent_ng_container_0_imx_data_table_28_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 28)(1, "div", 29);
    i0.ɵɵtext(2);
    i0.ɵɵelementStart(3, "div", 30);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(5, OutstandingComponent_ng_container_0_imx_data_table_28_ng_template_4_eui_badge_5_Template, 3, 4, "eui-badge", 31)(6, OutstandingComponent_ng_container_0_imx_data_table_28_ng_template_4_eui_badge_6_Template, 3, 4, "eui-badge", 31);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r7 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", data_r7.Display.value, " ");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(data_r7.ObjectType.value);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", data_r7.CanDeleteRestrictionReason.value);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", data_r7.CanPublishRestrictionReason.value);
} }
function OutstandingComponent_ng_container_0_imx_data_table_28_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-data-table", 25, 1);
    i0.ɵɵlistener("selectionChanged", function OutstandingComponent_ng_container_0_imx_data_table_28_Template_imx_data_table_selectionChanged_0_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.selectionChanged($event)); });
    i0.ɵɵelementStart(2, "imx-data-table-generic-column", 26);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵtemplate(4, OutstandingComponent_ng_container_0_imx_data_table_28_ng_template_4_Template, 7, 4, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(5, "imx-data-table-column", 27)(6, "imx-data-table-column", 27);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵnextContext();
    const dst_r8 = i0.ɵɵreference(26);
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("dst", dst_r8)("detailViewVisible", false)("selectable", true)("showSelectedItemsMenu", false)("noDataText", ctx_r2.getNoDataText());
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(3, 8, "#LDS#Display name"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("entityColumn", ctx_r2.schema == null ? null : ctx_r2.schema.Columns == null ? null : ctx_r2.schema.Columns.LastLogEntry);
    i0.ɵɵadvance();
    i0.ɵɵproperty("entityColumn", ctx_r2.schema == null ? null : ctx_r2.schema.Columns == null ? null : ctx_r2.schema.Columns.LastMethodRun);
} }
function OutstandingComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "h2", 3);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, OutstandingComponent_ng_container_0_eui_alert_4_Template, 3, 6, "eui-alert", 4)(5, OutstandingComponent_ng_container_0_mat_spinner_5_Template, 1, 0, "mat-spinner", 2);
    i0.ɵɵelementStart(6, "div", 5)(7, "mat-form-field", 6)(8, "mat-label");
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "mat-select", 7);
    i0.ɵɵlistener("selectionChange", function OutstandingComponent_ng_container_0_Template_mat_select_selectionChange_11_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.optionSelected($event.value)); });
    i0.ɵɵtwoWayListener("valueChange", function OutstandingComponent_ng_container_0_Template_mat_select_valueChange_11_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r2.selectedNamespace, $event) || (ctx_r2.selectedNamespace = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵtemplate(12, OutstandingComponent_ng_container_0_mat_option_12_Template, 2, 3, "mat-option", 8);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(13, "mat-form-field", 9);
    i0.ɵɵtemplate(14, OutstandingComponent_ng_container_0_mat_spinner_14_Template, 1, 0, "mat-spinner", 10);
    i0.ɵɵelementStart(15, "mat-label");
    i0.ɵɵtext(16);
    i0.ɵɵpipe(17, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(18, "mat-select", 11);
    i0.ɵɵlistener("selectionChange", function OutstandingComponent_ng_container_0_Template_mat_select_selectionChange_18_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.tableSelected($event.value)); });
    i0.ɵɵtwoWayListener("valueChange", function OutstandingComponent_ng_container_0_Template_mat_select_valueChange_18_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r2.selectedTable, $event) || (ctx_r2.selectedTable = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵtemplate(19, OutstandingComponent_ng_container_0_mat_option_19_Template, 2, 4, "mat-option", 8);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(20, "mat-checkbox", 12);
    i0.ɵɵlistener("change", function OutstandingComponent_ng_container_0_Template_mat_checkbox_change_20_listener() { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onShowAllData()); });
    i0.ɵɵtwoWayListener("ngModelChange", function OutstandingComponent_ng_container_0_Template_mat_checkbox_ngModelChange_20_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r2.showAllData, $event) || (ctx_r2.showAllData = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵtext(21);
    i0.ɵɵpipe(22, "translate");
    i0.ɵɵpipe(23, "ldsReplace");
    i0.ɵɵpipe(24, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(25, "imx-data-source-toolbar", 13, 0);
    i0.ɵɵlistener("navigationStateChanged", function OutstandingComponent_ng_container_0_Template_imx_data_source_toolbar_navigationStateChanged_25_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.getData($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(27, "mat-card", 14);
    i0.ɵɵtemplate(28, OutstandingComponent_ng_container_0_imx_data_table_28_Template, 7, 10, "imx-data-table", 15);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(29, "div", 16);
    i0.ɵɵelement(30, "imx-selected-elements", 17);
    i0.ɵɵelementStart(31, "mat-checkbox", 18);
    i0.ɵɵpipe(32, "translate");
    i0.ɵɵtwoWayListener("ngModelChange", function OutstandingComponent_ng_container_0_Template_mat_checkbox_ngModelChange_31_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r2.bulk, $event) || (ctx_r2.bulk = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵtext(33);
    i0.ɵɵpipe(34, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(35, "button", 19);
    i0.ɵɵpipe(36, "translate");
    i0.ɵɵlistener("click", function OutstandingComponent_ng_container_0_Template_button_click_35_listener() { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.deleteObjects()); });
    i0.ɵɵtext(37);
    i0.ɵɵpipe(38, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(39, "button", 20);
    i0.ɵɵpipe(40, "translate");
    i0.ɵɵlistener("click", function OutstandingComponent_ng_container_0_Template_button_click_39_listener() { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.resetObjects()); });
    i0.ɵɵtext(41);
    i0.ɵɵpipe(42, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(43, "button", 21);
    i0.ɵɵpipe(44, "translate");
    i0.ɵɵlistener("click", function OutstandingComponent_ng_container_0_Template_button_click_43_listener() { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.publishObjects()); });
    i0.ɵɵtext(45);
    i0.ɵɵpipe(46, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 32, "#LDS#Heading Outstanding Objects"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.showHelper);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.busy);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(62, _c0, ctx_r2.busy));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 34, "#LDS#Target system type"));
    i0.ɵɵadvance(2);
    i0.ɵɵtwoWayProperty("value", ctx_r2.selectedNamespace);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.namespaces);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.loadingTableData);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(17, 36, "#LDS#Object type"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r2.tabledata.length == 0);
    i0.ɵɵtwoWayProperty("value", ctx_r2.selectedTable);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r2.tabledata);
    i0.ɵɵadvance();
    i0.ɵɵtwoWayProperty("ngModel", ctx_r2.showAllData);
    i0.ɵɵproperty("disabled", !ctx_r2.selectedNamespace || ctx_r2.loadingTableData);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", !!ctx_r2.selectedNamespaceTitle && !ctx_r2.loadingTableData ? i0.ɵɵpipeBind3(23, 40, i0.ɵɵpipeBind1(22, 38, "#LDS#Show all outstanding objects of {0} ({1})"), ctx_r2.selectedNamespaceTitle, ctx_r2.tableDataCount) : i0.ɵɵpipeBind1(24, 44, "#LDS#Show all outstanding objects of the target system type"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵproperty("settings", ctx_r2.dstSettings)("options", i0.ɵɵpureFunction0(64, _c1))("busyService", ctx_r2.busyService);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", !ctx_r2.busy);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("selectedElements", ctx_r2.selected);
    i0.ɵɵadvance();
    i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(32, 46, "#LDS#If you activate bulk processing, the selected objects are processed in parallel. This speeds up the performed action. If an error occurs during processing, the action is stopped and all changes are discarded. To locate errors, deactivate bulk processing. Thus, the objects are processed sequentially. All changes made until the error occurred are saved."));
    i0.ɵɵtwoWayProperty("ngModel", ctx_r2.bulk);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(34, 48, "#LDS#Bulk processing"), "");
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(36, 50, "#LDS#Deletes the selected objects in the database"));
    i0.ɵɵproperty("disabled", ctx_r2.selected.length === 0 || !ctx_r2.canDeleteAllSelected());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(38, 52, "#LDS#Delete"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(40, 54, "#LDS#Removes the Outstanding label for the selected objects"));
    i0.ɵɵproperty("disabled", ctx_r2.selected.length === 0);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(42, 56, "#LDS#Reset"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(44, 58, "#LDS#Adds the selected objects to the target system"));
    i0.ɵɵproperty("disabled", ctx_r2.selected.length === 0 || !ctx_r2.canPublishAllSelected());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(46, 60, "#LDS#Add to target system"), " ");
} }
class OutstandingComponent {
    apiService;
    translator;
    sidesheet;
    confirmationService;
    snackbar;
    translate;
    busyServiceElemental;
    namespaces = [];
    selectedNamespace;
    navigationState = {};
    dstSettings;
    tabledata = [];
    selectedTable;
    showHelper = true;
    bulk = true;
    selected = [];
    schema;
    busyService = new BusyService();
    loadingTableData = false;
    showAllData = false;
    tableDataCount = 0;
    LdsOutstandingText = '#LDS#Objects which do not exist in the target system are marked as outstanding. Here you can get an overview of outstanding objects, delete these objects in the database or add these objects to the target system again. Additionally, you can reset the status of these objects so that they are no longer marked as outstanding.';
    ldsPublishable;
    ldsActionFilter;
    ldsDeletable;
    currentFilterValue;
    constructor(apiService, translator, sidesheet, confirmationService, snackbar, translate, busyServiceElemental) {
        this.apiService = apiService;
        this.translator = translator;
        this.sidesheet = sidesheet;
        this.confirmationService = confirmationService;
        this.snackbar = snackbar;
        this.translate = translate;
        this.busyServiceElemental = busyServiceElemental;
    }
    busy = true;
    async ngOnInit() {
        this.busy = true;
        try {
            this.ldsPublishable = await this.translator.get('#LDS#Addable objects').toPromise();
            this.ldsDeletable = await this.translator.get('#LDS#Deletable objects').toPromise();
            this.ldsActionFilter = await this.translator.get('#LDS#Performable actions').toPromise();
            this.schema = await this.buildEntitySchema();
            this.buildDstSettings({ Data: [], totalCount: 0 });
            const typed = await this.apiService.getNamespaces();
            this.namespaces = typed.Data;
        }
        finally {
            this.busy = false;
        }
    }
    async tableSelected(table) {
        this.selectedTable = table;
        this.selected = [];
        this.showAllData = false;
        await this.navigate();
    }
    async optionSelected(newNamespace) {
        this.selectedNamespace = newNamespace;
        this.tabledata = [];
        this.selectedTable = null;
        this.selected = [];
        this.tableDataCount = 0;
        this.showAllData = false;
        this.buildDstSettings({ Data: [], totalCount: 0 });
        if (newNamespace) {
            this.loadingTableData = true;
            try {
                this.tabledata = (await this.apiService.getTableData(newNamespace)).Data
                    // remove tables without outstanding objects
                    .filter((m) => m.CountOutstanding.value > 0)
                    // count outstanding objects
                    .map((table) => {
                    this.tableDataCount += table.CountOutstanding.value;
                    return table;
                });
            }
            finally {
                this.loadingTableData = false;
            }
        }
    }
    async onShowAllData() {
        if (this.showAllData && (!!this.selectedTable || this.dstSettings?.dataSource?.totalCount === 0)) {
            this.confirmationService
                .confirm({
                Title: '#LDS#Heading Show All Outstanding Objects',
                Message: '#LDS#Displaying all outstanding objects may take some time. Are you sure you want to display all outstanding objects?',
                identifier: 'outstanding-objects-show-all-data',
            })
                .then((res) => {
                if (res) {
                    this.selectedTable = null;
                    this.navigate();
                }
                else {
                    this.showAllData = false;
                }
            });
        }
        else {
            this.buildDstSettings({ Data: [], totalCount: 0 });
        }
    }
    selectionChanged(selected) {
        this.selected = selected;
    }
    async getData(newState) {
        this.navigationState = newState;
        await this.navigate();
    }
    onHelperDismissed() {
        this.showHelper = false;
    }
    async showSelected(objects) {
        this.sidesheet.open(SelectedItemsComponent, {
            title: await this.translate.get('#LDS#Heading Selected Items').toPromise(),
            padding: '0',
            width: calculateSidesheetWidth(),
            data: { objects, schema: this.schema },
            testId: 'outstanding-objects-selected-elements-sidesheet',
        });
    }
    async confirmDependencies(action) {
        if (this.busyServiceElemental.overlayRefs.length === 0) {
            this.busyServiceElemental.show();
        }
        let dependencies;
        try {
            dependencies = await this.apiService.getDependencies(action, this.selected.map((m) => m.ObjectKey.value));
        }
        finally {
            this.busyServiceElemental.hide();
        }
        // no dependencies? don't show confirmation dialog
        if (dependencies.length === 0) {
            return true;
        }
        const sidesheetRef = this.sidesheet.open(DependenciesComponent, {
            title: await this.translator.get('#LDS#Heading View Dependencies').toPromise(),
            subTitle: this.selected.length === 1 ? this.selected[0].GetEntity().GetDisplay() : '',
            padding: '0px',
            width: calculateSidesheetWidth(),
            testId: 'outstanding-view-depedencies-sidesheet',
            data: {
                dependencies,
                action,
            },
        });
        const fromsidesheet = await sidesheetRef.afterClosed().toPromise();
        return fromsidesheet;
    }
    canPublishAllSelected() {
        return this.selected.every((elem) => elem.CanPublish.value);
    }
    canDeleteAllSelected() {
        return this.selected.every((elem) => elem.CanDelete.value);
    }
    deleteObjects() {
        return this.processWithConfirmation(OutstandingAction.Delete);
    }
    resetObjects() {
        return this.processWithConfirmation(OutstandingAction.DeleteState);
    }
    publishObjects() {
        return this.processWithConfirmation(OutstandingAction.Publish);
    }
    getNoDataText() {
        return this.selectedNamespace
            ? this.tabledata.length > 0
                ? '#LDS#Select an object type.'
                : '#LDS#There are currently no outstanding objects.'
            : '#LDS#Select a target system.';
    }
    buildDstSettings(data) {
        this.dstSettings = {
            navigationState: {},
            dataSource: data,
            entitySchema: this.schema,
            filters: [
                {
                    Description: this.ldsActionFilter,
                    Name: 'actionfilter',
                    Options: [
                        {
                            Display: this.ldsPublishable,
                            Value: 'publishable',
                        },
                        {
                            Display: this.ldsDeletable,
                            Value: 'deletable',
                        },
                    ],
                    CurrentValue: this.currentFilterValue,
                    Delimiter: ',',
                },
            ],
            displayedColumns: [this.schema.Columns.Display, this.schema.Columns?.LastLogEntry],
        };
    }
    async navigate() {
        const isBusy = this.busyService.beginBusy();
        try {
            await this.navigateWithoutBusy();
        }
        finally {
            isBusy.endBusy();
        }
    }
    async navigateWithoutBusy() {
        if (!this.selectedNamespace) {
            this.buildDstSettings({ Data: [], totalCount: 0 });
        }
        let baseObjects;
        this.currentFilterValue = this.navigationState.actionfilter;
        if (this.selectedTable) {
            baseObjects = await this.apiService.getOutstandingTable(this.selectedTable.TableName.value, this.selectedNamespace.Ident_DPRNameSpace.value, this.currentFilterValue);
        }
        else {
            baseObjects = await this.apiService.getOutstandingNamespace(this.selectedNamespace.Ident_DPRNameSpace.value, this.currentFilterValue);
        }
        const reduce = (m) => {
            if (!m || m.length == 0)
                return null;
            return m.reduce((p, v) => p + ' ' + v);
        };
        const typedEntities = baseObjects.map((obj) => new OutstandingObjectEntity(new ReadOnlyEntity(this.dstSettings.entitySchema, {
            Keys: [obj.ObjectKey ?? ''],
            Columns: {
                ObjectKey: {
                    Value: obj.ObjectKey,
                },
                CanDelete: {
                    Value: obj.CanDelete,
                },
                CanPublish: {
                    Value: obj.CanPublish,
                },
                CanDeleteRestrictionReason: {
                    Value: reduce(obj.CanDeleteRestrictionReasons),
                },
                CanPublishRestrictionReason: {
                    Value: reduce(obj.CanPublishRestrictionReasons),
                },
                Display: {
                    Value: obj.Display,
                },
                LastLogEntry: {
                    Value: obj.LastLogEntry,
                },
                ObjectType: {
                    Value: obj.ObjectType,
                },
                LastMethodRun: {
                    Value: obj.LastMethodRun,
                },
            },
        })));
        this.buildDstSettings({
            Data: typedEntities,
            totalCount: typedEntities.length,
        });
    }
    async processWithConfirmation(action) {
        let canProceed = await this.confirmationService.confirm({
            Title: this.getConfirmationTitle(action),
            Message: this.getConfirmationText(action),
            identifier: 'outstanding-objects-process-confirmation',
        });
        if (!canProceed) {
            return;
        }
        canProceed = await this.confirmDependencies(action);
        if (!canProceed) {
            return;
        }
        return this.process(action);
    }
    async process(action) {
        if (this.busyServiceElemental.overlayRefs.length === 0) {
            this.busyServiceElemental.show();
        }
        try {
            await this.apiService.processObjects(action, this.bulk, this.selected.map((k) => k.ObjectKey.value));
        }
        finally {
            this.busyServiceElemental.hide();
            this.snackbar.open({ key: this.getSnackbarText(action) });
        }
        // reload
        return this.navigate();
    }
    getConfirmationTitle(action) {
        switch (action) {
            case OutstandingAction.Delete:
                return this.selected.length > 1 ? '#LDS#Heading Delete Objects' : '#LDS#Heading Delete Object';
            case OutstandingAction.DeleteState:
                return this.selected.length > 1 ? '#LDS#Heading Reset Objects' : '#LDS#Heading Reset Object';
            case OutstandingAction.Publish:
                return this.selected.length > 1 ? '#LDS#Heading Add Objects' : '#LDS#Heading Add Object';
        }
    }
    getConfirmationText(action) {
        switch (action) {
            case OutstandingAction.Delete:
                return this.selected.length > 1
                    ? '#LDS#Are you sure you want to delete the selected objects in the database?'
                    : '#LDS#Are you sure you want to delete the selected object in the database?';
            case OutstandingAction.DeleteState:
                return this.selected.length > 1
                    ? '#LDS#Are you sure you want to remove the Outstanding labels for the selected objects?'
                    : '#LDS#Are you sure you want to remove the Outstanding label for the selected object?';
            case OutstandingAction.Publish:
                return this.selected.length > 1
                    ? '#LDS#Are you sure you want to add the selected objects to the target system?'
                    : '#LDS#Are you sure you want to add the selected object to the target system?';
        }
    }
    getSnackbarText(action) {
        switch (action) {
            case OutstandingAction.Delete:
                return this.selected.length > 1
                    ? '#LDS#The objects have been successfully deleted in the database.'
                    : '#LDS#The object has been successfully deleted in the database.';
            case OutstandingAction.DeleteState:
                return this.selected.length > 1
                    ? '#LDS#The Outstanding labels have been successfully removed for the objects.'
                    : '#LDS#The Outstanding label has been successfully removed for the object.';
            case OutstandingAction.Publish:
                return this.selected.length > 1
                    ? '#LDS#The objects have been successfully added to the target system.'
                    : '#LDS#The object has been successfully added to the target system.';
        }
    }
    async buildEntitySchema() {
        const columns = {
            ObjectKey: {
                ColumnName: 'ObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            Display: {
                ColumnName: 'Display',
                Display: await this.translator.get('#LDS#Object').toPromise(),
                Type: ValType.String,
                IsReadOnly: true,
            },
            LastMethodRun: {
                ColumnName: 'LastMethodRun',
                Display: await this.translator.get('#LDS#Last method run').toPromise(),
                Type: ValType.String,
                IsReadOnly: true,
            },
            ObjectType: {
                ColumnName: 'ObjectType',
                Display: await this.translator.get('#LDS#Object type').toPromise(),
                Type: ValType.String,
                IsReadOnly: true,
            },
            LastLogEntry: {
                ColumnName: 'LastLogEntry',
                Display: await this.translator.get('#LDS#Last log entry').toPromise(),
                Type: ValType.Date,
                IsReadOnly: true,
            },
            CanPublish: {
                ColumnName: 'CanPublish',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            CanDelete: {
                ColumnName: 'CanDelete',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            CanPublishRestrictionReason: {
                ColumnName: 'CanPublishRestrictionReason',
                Type: ValType.String,
                IsReadOnly: true,
            },
            CanDeleteRestrictionReason: {
                ColumnName: 'CanDeleteRestrictionReason',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'OutstandingObject', Columns: columns };
    }
    get selectedNamespaceTitle() {
        return this.selectedNamespace?.GetEntity()?.GetDisplayLong();
    }
    static ɵfac = function OutstandingComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OutstandingComponent)(i0.ɵɵdirectiveInject(OutstandingService), i0.ɵɵdirectiveInject(i2.TranslateService), i0.ɵɵdirectiveInject(i3.EuiSidesheetService), i0.ɵɵdirectiveInject(i1.ConfirmationService), i0.ɵɵdirectiveInject(i1.SnackBarService), i0.ɵɵdirectiveInject(i2.TranslateService), i0.ɵɵdirectiveInject(i3.EuiLoadingService)); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: OutstandingComponent, selectors: [["ng-component"]], decls: 1, vars: 1, consts: [["dst", ""], ["dataTable", ""], [4, "ngIf"], [1, "mat-headline-5"], ["type", "info", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [1, "filters", 3, "ngClass"], ["appearance", "outline", 1, "namespace-selector"], ["required", "", "data-imx-identifier", "outstanding-namespace-select", 3, "selectionChange", "valueChange", "value"], [3, "value", 4, "ngFor", "ngForOf"], ["appearance", "outline", 1, "table-selector"], ["diameter", "16", "matPrefix", "", 4, "ngIf"], ["data-imx-identifier", "outstanding-table-select", 3, "selectionChange", "valueChange", "disabled", "value"], [3, "change", "ngModelChange", "ngModel", "disabled"], [3, "navigationStateChanged", "settings", "options", "busyService"], [1, "scroll-container", "imx-table-container"], ["mode", "manual", "data-imx-identifier", "outstanding-objects-table", 3, "dst", "detailViewVisible", "selectable", "showSelectedItemsMenu", "noDataText", "selectionChanged", 4, "ngIf"], [1, "imx-button-bar-transparent"], [1, "justify-start", 3, "selectedElements"], [3, "ngModelChange", "matTooltip", "ngModel"], ["mat-flat-button", "", "color", "warn", "data-imx-identifier", "outstanding-delete-button", 3, "click", "disabled", "matTooltip"], ["mat-stroked-button", "", "data-imx-identifier", "outstanding-reset-button", 3, "click", "disabled", "matTooltip"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "outstanding-publish-button", 3, "click", "disabled", "matTooltip"], ["type", "info", 3, "dismissed", "condensed", "colored", "dismissable"], [3, "value"], ["diameter", "16", "matPrefix", ""], ["mode", "manual", "data-imx-identifier", "outstanding-objects-table", 3, "selectionChanged", "dst", "detailViewVisible", "selectable", "showSelectedItemsMenu", "noDataText"], ["columnName", "Display", 3, "columnLabel"], [3, "entityColumn"], [1, "first-cell"], [1, "first-col"], [1, "object-type"], [3, "matTooltip", 4, "ngIf"], [3, "matTooltip"]], template: function OutstandingComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, OutstandingComponent_ng_container_0_Template, 47, 65, "ng-container", 2);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.dstSettings);
        } }, dependencies: [i5.NgClass, i5.NgForOf, i5.NgIf, i1.DataSourceToolbarComponent, i1.DataTableComponent, i1.DataTableColumnComponent, i1.DataTableGenericColumnComponent, i3.EuiAlertComponent, i3.EuiBadgeComponent, i6.NgControlStatus, i6.NgModel, i7.MatOption, i3$1.MatButton, i2$1.MatCard, i10.MatCheckbox, i11.MatFormField, i11.MatLabel, i11.MatPrefix, i12.MatProgressSpinner, i13.MatSelect, i14.MatTooltip, i1.SelectedElementsComponent, i2.TranslatePipe, i1.LdsReplacePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}.filters[_ngcontent-%COMP%]{display:flex;flex-flow:wrap;align-items:center;gap:1em;margin-bottom:16px}.filters[_ngcontent-%COMP%]   .namespace-selector[_ngcontent-%COMP%], .filters[_ngcontent-%COMP%]   .table-selector[_ngcontent-%COMP%]{min-width:400px}.scroll-container[_ngcontent-%COMP%]{flex:1 1 auto;overflow:auto;display:flex}.object-type[_ngcontent-%COMP%]{font-style:italic;font-size:smaller}.imx-justify-start[_ngcontent-%COMP%]{align-self:flex-start;flex:1 1 auto}.first-cell[_ngcontent-%COMP%]{display:flex;flex-direction:row}.first-col[_ngcontent-%COMP%]{flex-grow:1}.loadingtable[_ngcontent-%COMP%]{visibility:hidden}.selected-objects[_ngcontent-%COMP%]{font-size:14px;color:#2f3233}.selected-objects[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#aab0b3;font-weight:700;margin-left:3px}.eui-dark-theme   [_nghost-%COMP%]   .selected-objects[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#aab0b3}"] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OutstandingComponent, [{
        type: Component,
        args: [{ template: "<ng-container *ngIf=\"dstSettings\">\n  <h2 class=\"mat-headline-5\">{{ '#LDS#Heading Outstanding Objects' | translate }}</h2>\n  <eui-alert *ngIf=\"showHelper\" type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"true\" (dismissed)=\"onHelperDismissed()\">\n    {{ LdsOutstandingText | translate }}\n  </eui-alert>\n\n  <mat-spinner *ngIf=\"busy\"></mat-spinner>\n  <div class=\"filters\" [ngClass]=\"{ 'imx-hidden': busy }\">\n    <mat-form-field class=\"namespace-selector\" appearance=\"outline\">\n      <mat-label>{{ '#LDS#Target system type' | translate }}</mat-label>\n      <mat-select\n        required\n        (selectionChange)=\"optionSelected($event.value)\"\n        [(value)]=\"selectedNamespace\"\n        data-imx-identifier=\"outstanding-namespace-select\"\n      >\n        <mat-option\n          *ngFor=\"let pr of namespaces\"\n          [value]=\"pr\"\n          [attr.data-imx-identifier]=\"'outstanding-namespace-option-' + pr.GetEntity().GetDisplay()\"\n        >\n          {{ pr.GetEntity().GetDisplay() }}\n        </mat-option>\n      </mat-select>\n    </mat-form-field>\n\n    <mat-form-field class=\"table-selector\" appearance=\"outline\">\n      <mat-spinner diameter=\"16\" *ngIf=\"loadingTableData\" matPrefix></mat-spinner>\n      <mat-label>{{ '#LDS#Object type' | translate }}</mat-label>\n      <mat-select\n        [disabled]=\"tabledata.length == 0\"\n        (selectionChange)=\"tableSelected($event.value)\"\n        [(value)]=\"selectedTable\"\n        data-imx-identifier=\"outstanding-table-select\"\n      >\n        <mat-option\n          *ngFor=\"let pr of tabledata\"\n          [value]=\"pr\"\n          [attr.data-imx-identifier]=\"'outstanding-table-option-' + pr.GetEntity().GetDisplay()\"\n        >\n          {{ pr.GetEntity().GetDisplay() }} ({{ pr.CountOutstanding.value }})\n        </mat-option>\n      </mat-select>\n    </mat-form-field>\n    <mat-checkbox (change)=\"onShowAllData()\" [(ngModel)]=\"showAllData\" [disabled]=\"!selectedNamespace || loadingTableData\">\n      {{\n        !!selectedNamespaceTitle && !loadingTableData\n          ? ('#LDS#Show all outstanding objects of {0} ({1})' | translate | ldsReplace: selectedNamespaceTitle : tableDataCount)\n          : ('#LDS#Show all outstanding objects of the target system type' | translate)\n      }}\n    </mat-checkbox>\n  </div>\n\n  <imx-data-source-toolbar\n    #dst\n    [settings]=\"dstSettings\"\n    (navigationStateChanged)=\"getData($event)\"\n    [options]=\"['filter']\"\n    [busyService]=\"busyService\"\n  >\n  </imx-data-source-toolbar>\n\n  <mat-card class=\"scroll-container imx-table-container\">\n    <imx-data-table\n      #dataTable\n      [dst]=\"dst\"\n      [detailViewVisible]=\"false\"\n      [selectable]=\"true\"\n      [showSelectedItemsMenu]=\"false\"\n      (selectionChanged)=\"selectionChanged($event)\"\n      mode=\"manual\"\n      [noDataText]=\"getNoDataText()\"\n      data-imx-identifier=\"outstanding-objects-table\"\n      *ngIf=\"!busy\"\n    >\n      <imx-data-table-generic-column columnName=\"Display\" columnLabel=\"{{ '#LDS#Display name' | translate }}\">\n        <ng-template let-data>\n          <div class=\"first-cell\">\n            <div class=\"first-col\">\n              {{ data.Display.value }}\n              <div class=\"object-type\">{{ data.ObjectType.value }}</div>\n            </div>\n            <eui-badge *ngIf=\"data.CanDeleteRestrictionReason.value\" [matTooltip]=\"data.CanDeleteRestrictionReason.value\">\n              {{ '#LDS#Cannot delete' | translate }}\n            </eui-badge>\n            <eui-badge *ngIf=\"data.CanPublishRestrictionReason.value\" [matTooltip]=\"data.CanPublishRestrictionReason.value\">\n              {{ '#LDS#Cannot add' | translate }}\n            </eui-badge>\n          </div>\n        </ng-template>\n      </imx-data-table-generic-column>\n      <imx-data-table-column [entityColumn]=\"schema?.Columns?.LastLogEntry\"> </imx-data-table-column>\n      <imx-data-table-column [entityColumn]=\"schema?.Columns?.LastMethodRun\"> </imx-data-table-column>\n    </imx-data-table>\n  </mat-card>\n  <div class=\"imx-button-bar-transparent\">\n    <imx-selected-elements class=\"justify-start\" [selectedElements]=\"selected\"></imx-selected-elements>\n    <mat-checkbox\n      matTooltip=\"{{\n        '#LDS#If you activate bulk processing, the selected objects are processed in parallel. This speeds up the performed action. If an error occurs during processing, the action is stopped and all changes are discarded. To locate errors, deactivate bulk processing. Thus, the objects are processed sequentially. All changes made until the error occurred are saved.'\n          | translate\n      }}\"\n      [(ngModel)]=\"bulk\"\n    >\n      {{ '#LDS#Bulk processing' | translate }}</mat-checkbox\n    >\n\n    <button\n      mat-flat-button\n      color=\"warn\"\n      [disabled]=\"selected.length === 0 || !canDeleteAllSelected()\"\n      data-imx-identifier=\"outstanding-delete-button\"\n      matTooltip=\"{{ '#LDS#Deletes the selected objects in the database' | translate }}\"\n      (click)=\"deleteObjects()\"\n    >\n      {{ '#LDS#Delete' | translate }}\n    </button>\n    <button\n      mat-stroked-button\n      [disabled]=\"selected.length === 0\"\n      data-imx-identifier=\"outstanding-reset-button\"\n      matTooltip=\"{{ '#LDS#Removes the Outstanding label for the selected objects' | translate }}\"\n      (click)=\"resetObjects()\"\n    >\n      {{ '#LDS#Reset' | translate }}\n    </button>\n    <button\n      mat-flat-button\n      [disabled]=\"selected.length === 0 || !canPublishAllSelected()\"\n      color=\"primary\"\n      data-imx-identifier=\"outstanding-publish-button\"\n      matTooltip=\"{{ '#LDS#Adds the selected objects to the target system' | translate }}\"\n      (click)=\"publishObjects()\"\n    >\n      {{ '#LDS#Add to target system' | translate }}\n    </button>\n  </div>\n</ng-container>\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;height:100%}.filters{display:flex;flex-flow:wrap;align-items:center;gap:1em;margin-bottom:16px}.filters .namespace-selector,.filters .table-selector{min-width:400px}.scroll-container{flex:1 1 auto;overflow:auto;display:flex}.object-type{font-style:italic;font-size:smaller}.imx-justify-start{align-self:flex-start;flex:1 1 auto}.first-cell{display:flex;flex-direction:row}.first-col{flex-grow:1}.loadingtable{visibility:hidden}.selected-objects{font-size:14px;color:#2f3233}.selected-objects span{color:#aab0b3;font-weight:700;margin-left:3px}.eui-dark-theme :host .selected-objects span{color:#aab0b3}\n"] }]
    }], () => [{ type: OutstandingService }, { type: i2.TranslateService }, { type: i3.EuiSidesheetService }, { type: i1.ConfirmationService }, { type: i1.SnackBarService }, { type: i2.TranslateService }, { type: i3.EuiLoadingService }], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(OutstandingComponent, { className: "OutstandingComponent", filePath: "lib\\outstanding\\outstanding.component.ts", lineNumber: 58 }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class OutstandingModule {
    static ɵfac = function OutstandingModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OutstandingModule)(); };
    static ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: OutstandingModule });
    static ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [OutstandingService], imports: [CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            EuiCoreModule,
            FormsModule,
            EuiMaterialModule,
            MatProgressSpinnerModule,
            MatTooltipModule,
            TranslateModule,
            SelectedElementsModule,
            LdsReplaceModule,
            BusyIndicatorModule] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OutstandingModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    EuiCoreModule,
                    FormsModule,
                    EuiMaterialModule,
                    MatProgressSpinnerModule,
                    MatTooltipModule,
                    TranslateModule,
                    SelectedElementsModule,
                    LdsReplaceModule,
                    BusyIndicatorModule,
                ],
                providers: [OutstandingService],
                declarations: [OutstandingComponent, DependenciesComponent, SelectedItemsComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(OutstandingModule, { declarations: [OutstandingComponent, DependenciesComponent, SelectedItemsComponent], imports: [CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        FormsModule,
        EuiMaterialModule,
        MatProgressSpinnerModule,
        MatTooltipModule,
        TranslateModule,
        SelectedElementsModule,
        LdsReplaceModule,
        BusyIndicatorModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OutstandingComponent, OutstandingModule };
//# sourceMappingURL=dpr.mjs.map
