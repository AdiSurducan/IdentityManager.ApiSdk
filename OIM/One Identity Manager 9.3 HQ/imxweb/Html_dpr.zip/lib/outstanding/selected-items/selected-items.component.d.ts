import { OnInit } from '@angular/core';
import { CollectionLoadParameters, EntitySchema, IClientProperty } from '@imx-modules/imx-qbm-dbts';
import { DataSourceToolbarSettings } from 'qbm';
import { OutstandingObjectEntity } from '../outstanding-object-entity';
import * as i0 from "@angular/core";
export declare class SelectedItemsComponent implements OnInit {
    readonly data: {
        objects: OutstandingObjectEntity[];
        schema: EntitySchema;
    };
    sortedEntities: OutstandingObjectEntity[];
    displayedColumns?: IClientProperty[];
    dstSettings: DataSourceToolbarSettings;
    private searchedEntities;
    private navigationState;
    constructor(data: {
        objects: OutstandingObjectEntity[];
        schema: EntitySchema;
    });
    ngOnInit(): void;
    search(key: string): void;
    getData(state: CollectionLoadParameters): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectedItemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectedItemsComponent, "imx-selected-items", never, {}, {}, never, never, false, never>;
}
